# NEXUS LEARN — Repository Instructions

## Authority and scope

- Treat the dated `NEXUS_LEARN_PRODUCT_BRIEF_AND_CODEX_PROMPT.md` as product research and direction; its §7 agent-role assignments are historical and superseded by `docs/AGENT_WORKFLOW.md` under the 2026-11-08 owner instruction. Do not silently rewrite historical evidence.
- Preserve the Phase 0 record in `DECISIONS.md`, `docs/`, and `reports/phase0/`. Record conflicts and their disposition; do not silently erase findings or owner gates.
- `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/API.md`, `docs/PRIVACY.md`, `docs/SECURITY.md`, `docs/TESTING.md`, `docs/ACCEPTANCE.md`, `docs/TRACEABILITY.md`, `docs/AGENT_WORKFLOW.md`, `DECISIONS.md`, `PLANS.md`, `TASKS.md`, and `PROJECT_STATUS.md` are canonical. Do not create competing root copies such as `ARCHITECTURE.md`, `DATA_MODEL.md`, or `TEST_STRATEGY.md`.
- Do not change the documented stack without a concrete blocker and a reviewed ADR.

## Product and engineering rules

- Build one complete, small learning journey before expanding content volume or adding subjects.
- Keep curriculum and exam formats versioned/configurable. Do not claim official alignment without a current source, version, date, and review evidence.
- Keep published question versions and raw attempt events immutable. Derive mastery; show evidence and uncertainty.
- A simple configurable review due date is a scheduling mechanism, not a mastery model or a grade guarantee.
- AI output is advisory or an unpublished draft until it passes the documented human review gate. Never put secrets in browser code or committed files.
- The bootstrap shell must label unfinished screens and must not fabricate user data, saving, scoring, or test results.

## Agent boundaries

- Product Owner decides product policy and is the sole final product acceptance authority.
- Codex is repository owner, Engineering Lead, architecture/task-contract author, and Primary Implementer; Codex integrates and verifies work but never calls its own work an independent audit.
- Antigravity/AGY may challenge important requirements and perform an independent audit only in a fresh, READ-ONLY context. It reviews source, diff, test evidence, and acceptance criteria; it does not edit, stage, or commit during audit.
- ChatGPT Project Co-Pilot supports Product Owner analysis and design; it must not claim repository changes without direct evidence.
- Exactly one writer may modify code in a task at a time. Codex may implement directly; avoid handoffs that do not add independent review or required expertise.
- Owner-gated product, data, privacy, legal, content-rights, scoring, provider, and deployment decisions remain gates until explicitly resolved.

## Approval and execution

- R0: reversible internal engineering work within the approved contract; proceed without renewed owner approval.
- R1: implementation within an approved PRD/task outcome, including useful loading, empty, validation, accessibility, and error states; proceed without changing product intent.
- R2: material data/API contract changes, runtime dependencies, external services, authentication, personal-data flows, content rights, retention, or AI-provider decisions; document options, rationale, risks, and obtain Product Owner approval first.
- R3: destructive real-data migration/deletion, production changes, secrets, or material external cost; obtain specific confirmation immediately before the action.
- For missing information, state a safe, reversible assumption and proceed. Ask only when the uncertainty could materially affect product intent, rights, privacy, data, cost, or security.
- Every task records the user problem/outcome, current and desired behavior, must-haves, quality constraints, scope, data/source requirements, testable acceptance, edge/failure cases, test plan, security/privacy, and any required owner decision.
- Definition of Done requires acceptance mapping, executed tests and build/typecheck, diff/scope and edge-case review, UI inspection when feasible, and truthful `VERIFIED` / `REPORTED` / `NOT RUN` evidence. Independent audit is required for material or multi-module changes; Product Owner acceptance is a separate state.
- Allow no more than two repair rounds unless Product Owner approves another limit. Low findings that do not affect acceptance are reported without automatically starting another round.
- Do not stage, commit, push, reset, clean, or discard user changes unless the active task explicitly authorizes that exact action.

## Change and evidence rules

- Read the task's allowed/forbidden file list before editing. Do not touch `../anti` or `job1.zip`.
- Run the existing relevant checks before claiming a result. Record command, exit code, concise output, changed files, known limitations, and rollback notes in the task report.
- Use `PASS`, `PASS WITH LIMITATIONS`, `FAILED`, `BLOCKED`, or `NOT RUN` accurately. Never report PASS for an unexecuted check.
