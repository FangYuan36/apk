---
name: test-and-regression
description: Inspect and run the existing NEXUS LEARN test/build checks, then report exact evidence. Use when asked to verify a change or assess regression risk.
---

# Test and Regression

1. Read root `AGENTS.md`, `docs/TESTING.md`, `package.json`, and the current test/build scripts before choosing commands.
2. Run the existing relevant test command(s) and production build in the repository's active runtime. Do not install or change dependencies unless separately authorized.
3. Preserve actual command output and exit code. Report unavailable commands as `NOT RUN`, environment blocks as `BLOCKED`, and failures as `FAILED`.
4. Inspect failures without changing tests to force PASS. Any test or implementation fix requires an approved task scope.
5. Summarize changed-file coverage, limitations, and any verification not performed. Never infer passing behavior from code inspection alone.
