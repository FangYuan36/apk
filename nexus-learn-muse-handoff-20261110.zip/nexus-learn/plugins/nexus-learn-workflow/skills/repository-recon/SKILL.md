---
name: repository-recon
description: Perform a read-only NEXUS LEARN repository reconnaissance. Use when asked to inspect repository state, architecture documents, package setup, or the active runtime before planning work.
---

# Repository Recon

Read root `AGENTS.md` first. This skill is read-only: do not edit, stage, install, claim, or commit.

1. Record `pwd -P`, Git root, branch, `git status --short --branch`, and latest commit. Report command failures as evidence.
2. Inspect `package.json`, lockfile presence, scripts, top-level source/doc/report structure, and the canonical architecture, database, testing, acceptance, workflow, and status documents relevant to the request.
3. Identify the active runtime with `uname`, Node, Python, and Termux markers when available. Distinguish installed tools from the runtime actually in use.
4. Report observed facts, exact paths, commands, and limitations. Label unavailable information `NOT RUN` or `UNKNOWN`; do not infer it.
5. Do not read or modify sibling projects, secrets, or files outside the requested repository scope.
