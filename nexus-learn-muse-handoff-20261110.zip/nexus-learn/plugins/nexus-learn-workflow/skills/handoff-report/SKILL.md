---
name: handoff-report
description: Create an evidence-based NEXUS LEARN task handoff report with verification, limitations, and rollback details. Use when implementation or review evidence must be recorded.
---

# Handoff Report

1. Read root `AGENTS.md` and the selected task contract. Create `reports/handoff/HANDOFF-XXX.md` only for an authorized task handoff; use the task identifier in place of `XXX` when appropriate. Do not create a product task.
2. Record task ID/scope, files changed, concise diff summary, exact commands and exit codes, actual test/build evidence, fixture provenance where relevant, limitations, and rollback instructions.
3. Classify each relevant check as `PASS`, `PASS WITH LIMITATIONS`, `FAILED`, `BLOCKED`, or `NOT RUN`. Never label an unexecuted check PASS.
4. State what was not reviewed or unavailable. Do not convert assumptions, screenshots, or prose into test evidence.
5. Do not claim task acceptance. Codex performs a technical implementation review; if the task requires an independent audit, a fresh Antigravity/AGY session reviews the exact diff READ-ONLY. Only the Product Owner accepts product work.
