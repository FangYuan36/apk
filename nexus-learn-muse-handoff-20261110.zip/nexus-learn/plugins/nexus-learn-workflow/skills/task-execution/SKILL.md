---
name: task-execution
description: Execute one explicitly approved NEXUS LEARN task within its written scope. Use when asked to implement or carry out a task from TASKS.md.
---

# Task Execution

1. Read root `AGENTS.md`, `TASKS.md`, the selected task contract, and the matching `agent-hub/rqcodex.txt` prompt when present. Confirm the task was explicitly approved and is not already being worked by another writer.
2. Extract the exact Target Files/allowlist, denylist, acceptance criteria, test commands, evidence requirements, and rollback notes before editing. If any required file is outside the allowlist, stop for Codex scope revision.
3. Work only on that task. Do not broaden architecture, dependencies, product scope, or skill/topic count.
4. Never claim or start a task through Agent Hub unless a worker protocol and assignment authority have been explicitly confirmed.
5. Submit evidence for Codex review after each implementation pass. At most 2 repair rounds are allowed; after round 2, stop and request review/escalation.
6. Do not report completion before actual verification and review. Keep changes reversible and note rollback paths.
