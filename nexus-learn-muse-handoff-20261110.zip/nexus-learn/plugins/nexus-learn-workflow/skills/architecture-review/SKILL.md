---
name: architecture-review
description: Review a NEXUS LEARN design or implementation against the canonical modular architecture and domain invariants. Use for technical reviews before accepting architecture or learning-slice changes.
---

# Architecture Review

Read root `AGENTS.md` and the canonical `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/API.md`, and `docs/ACCEPTANCE.md` as relevant.

Check and report evidence for:

- Modular boundaries and dependencies between domain, application, infrastructure, and UI.
- `AttemptEvent` append-only behavior and immutable question/version provenance.
- Separation of answer correctness, error diagnosis, recommendation, scheduling, and mastery derivation.
- Mastery evidence and uncertainty; due-date scheduling must not be treated as a mastery algorithm.
- Content source, rights, synthetic-fixture labels, curriculum versioning, and human review gates.

Cite paths and symbols or line numbers where possible. Separate confirmed defects from risks and unknowns. Do not edit files or change architecture; propose changes for Codex review.
