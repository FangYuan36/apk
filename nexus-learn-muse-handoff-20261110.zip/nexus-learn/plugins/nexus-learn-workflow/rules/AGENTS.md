# NEXUS LEARN Plugin Rules

- Read the repository root `AGENTS.md` before any task work.
- Treat `TASKS.md` and the selected task contract as the primary scope and acceptance sources. Read the matching dispatch prompt when the task uses Agent Hub.
- Follow Single-Writer: only one agent or person edits a given task scope at a time. Product Owner alone accepts product work; Codex owns repository/architecture/task contracts and is the primary implementer; Antigravity/AGY is a fresh-context READ-ONLY independent auditor and may challenge important requirements. During an audit it must not edit, stage, or commit. Do not create overlapping assignments.
- Follow risk tiers in `docs/AGENT_WORKFLOW.md`: R0/R1 within approved intent proceed without repeated owner questions; R2 requires prior owner approval; R3 needs specific confirmation immediately before action.
- Never add, print, or commit secrets, tokens, credentials, or private keys. If a possible secret is found, stop and report only its path and reason.
- Report only tests and checks that were actually run, with their real commands and outcomes. Never simulate or infer a PASS.
- Preserve the Phase 0 record in `DECISIONS.md`, `docs/`, and `reports/phase0/`; do not overwrite its findings or history.
- Do not decide or approve product-owner gates involving privacy, legal matters, content rights, scoring, or deployment. Record the gate and wait for the owner.
- Keep task scope bounded to its explicit allowlist and denylist. Do not expand a task without Codex scope approval.
