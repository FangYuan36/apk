# NEXUS LEARN Workflow Plugin

Version 0.1.0. This plugin packages five NEXUS LEARN project workflows and the always-on project rules in `rules/AGENTS.md`. It contains skills and rules only; it defines no MCP servers, hooks, or custom agents.

## Included skills

- `/repository-recon` — read-only repository and runtime inspection.
- `/task-execution` — execute only an approved, bounded task.
- `/architecture-review` — review the existing architecture and learning-domain boundaries.
- `/test-and-regression` — run the repository's actual checks and record evidence.
- `/handoff-report` — prepare a factual task report with limitations and rollback notes.

## Install and verify

From the NEXUS LEARN repository, validate and install the local plugin through the supported CLI:

```sh
agy plugin validate --strict ./plugins/nexus-learn-workflow
agy plugin install ./plugins/nexus-learn-workflow
agy plugin list --json
```

The CLI manages the installed copy. Keep this repository source directory under version control; do not copy or symlink it into Antigravity's configuration directory manually.

## Use

Ask Antigravity for a matching workflow or invoke a skill directly, for example `/repository-recon`. The repository's root `AGENTS.md`, `TASKS.md`, and the task contract remain authoritative. Plugin rules add no task approval or scope authority.
