# NEXUS LEARN — API Inventory (Phase 0)

> **Status:** All endpoints and shapes in this file are proposals. No FastAPI/Pydantic backend, API route, authentication, authorization middleware, or API integration test exists in the repository. The client currently runs a local sample learning flow only.

## Contract conventions

Proposed base: `/api/v1`; HTTPS JSON; Pydantic request/response models; UUID identifiers; UTC RFC 3339 timestamps; stable machine-readable error codes; pagination for collections; request IDs for traceability. Authentication mechanism is unresolved. The API derives owner identity from the authenticated principal, never a body field. Writes that may be retried accept idempotency keys. Published content is addressed by explicit version ID.

## Endpoint inventory (proposed)

| Method | Path | Module | Purpose / write semantics |
|---|---|---|---|
| GET | `/api/v1/me` | Identity | Current principal and allowed profile summary |
| GET/PATCH | `/api/v1/me/profile` | Identity | Read/update own profile; audited |
| GET | `/api/v1/curriculum-profiles` | Catalog | List selectable active profiles |
| GET | `/api/v1/subjects?curriculum_profile_id=` | Catalog | Configured subjects |
| GET | `/api/v1/topics?subject_id=&curriculum_profile_id=` | Catalog | Topic tree |
| GET | `/api/v1/questions` | Content | Practice candidates filtered by subject/topic/verification; learner-safe fields only |
| GET | `/api/v1/questions/{id}/versions/{version_id}` | Content | Fetch exact learner-visible version |
| GET | `/api/v1/exam-blueprints` | Blueprint | List learner-selectable published blueprints filtered by year/subject/profile |
| POST | `/api/v1/assessment-sessions` | Assessment | Create an exam or practice session using a discriminated request; idempotent |
| GET | `/api/v1/assessment-sessions/{id}` | Assessment | Own session and immutable session-item/version references |
| POST | `/api/v1/assessment-sessions/{id}/answers` | Assessment | Append answer event for a session item; owner checked; idempotent |
| POST | `/api/v1/assessment-sessions/{id}/submit` | Assessment | Atomically close submission window and calculate deterministic score |
| GET | `/api/v1/assessment-sessions/{id}/results` | Scoring | Own immutable score/result history |
| GET | `/api/v1/assessment-sessions/{id}/review` | Assessment | Return answer/explanation fields only when session review policy permits |
| GET | `/api/v1/progress` | Progress | Derived owner-scoped summaries |
| POST | `/api/v1/ai/assist` | AI | Allowlisted hint/explanation request; optional, bounded, advisory |
| POST | `/api/v1/ai/tutor` | AI Tutor | Context-bounded question/explanation over authorized, approved content; cites evidence and labels inference; advisory only |
| POST | `/api/v1/ai/learning-analysis` | AI Learning Analysis | Analyze an authorized learner's permitted event/evidence projection and return an explainable, non-authoritative recommendation |
| POST | `/api/v1/ai/tools/{tool_id}` | AI Web Agent gateway | Invoke one registered typed application tool after per-tool authorization, validation, rate limits, and audit; sensitive actions require a confirmation token/step |
| GET/POST | `/api/v1/editor/questions` | Content admin | Create draft and source evidence; restricted/audited |
| POST | `/api/v1/editor/questions/{id}/versions` | Content admin | Create successor immutable draft version |
| POST | `/api/v1/editor/questions/{id}/versions/{version_id}/publish` | Content admin | Verify/publish the identified version with reviewer evidence and reviewed content hash |
| POST | `/api/v1/editor/questions/{id}/versions/{version_id}/reviews` | Reviewer | Append independent source/content/answer/scoring review decision; generation principal is denied |
| POST | `/api/v1/editor/questions/generate-draft` | AI orchestration | Create unpublished draft and generation record; never verify or publish |
| GET/POST | `/api/v1/editor/blueprints` | Blueprint admin | Draft blueprint and create version |
| POST | `/api/v1/editor/blueprints/{id}/versions/{version}/publish` | Blueprint admin | Publish version with source and review evidence |
| GET | `/api/v1/admin/audit-events` | Audit admin | Restricted audit query; access logged |

## Key request/response shapes

`POST /assessment-sessions` uses a discriminated union. Exam: `{ kind:"exam", blueprint_version_id, idempotency_key }`. Practice: `{ kind:"practice", curriculum_profile_id, subject_id, topic_id?, selection_policy_version, idempotency_key }`. The policy version and any random seed are snapshotted; selection-policy behavior and allowable count/configuration require product approval. Response: `{ session_id, kind, blueprint_version_id?, status, items:[{session_item_id, question_version_id, position}] }`. Exam sessions require and pin an exact blueprint version; practice sessions must not silently substitute an exam blueprint or the latest question version.

Practice question list and detail responses use learner projections that omit normalized answer keys and unreleased scoring/rubric fields. Result/review fields become available only under the authorized session review policy after submission.

`POST /assessment-sessions/{id}/answers`: `{ session_item_id, client_event_id, response, client_recorded_at? }` → `{ answer_event_id, sequence_no, accepted_at }`. Server timestamp is authoritative. Persist a canonical request hash. Same key and same hash returns the original result; same key with a different hash returns `IDEMPOTENCY_CONFLICT` without appending. A changed answer uses a new client event ID and appends an event.

`POST /assessment-sessions/{id}/submit`: `{ idempotency_key }` → `{ result_id, score, max_score, scoring_algorithm_version, event_cutoff, item_results:[...] }`. In one transaction, serialize against answer insertion, require OPEN status, close the session, capture the final event cutoff, and score every session item. A racing answer either commits before close and is included or is rejected with `SESSION_CLOSED`. Repeated submit returns the existing result. Post-submit correction/re-score is not part of the learner API until owner policy is approved.

`POST /ai/assist`: `{ purpose, question_version_id, session_id?, answer_event_id?, context? }` → `{ artifact_id, status, advisory_text?, source_refs?, unavailable_reason? }`. Explicitly prohibit score, answer-event, question-version, and blueprint mutation tools.

## Error contract

Stable codes proposed: `UNAUTHENTICATED`, `FORBIDDEN`, `NOT_FOUND`, `VALIDATION_ERROR`, `VERSION_NOT_PUBLISHED`, `SESSION_CLOSED`, `IDEMPOTENCY_CONFLICT`, `RATE_LIMITED`, `AI_UNAVAILABLE`. Do not reveal whether another user's resource exists. Include field errors without returning submitted secrets or unnecessary personal data.

## Authorization and transaction requirements

- Scope learner session, events, results, profile, and progress to principal owner at query and write time.
- Start exam session transaction captures exact blueprint/question versions into immutable session items. Practice session creation stores its selection-policy/configuration snapshot and exact selected versions.
- Answer append validates session item membership and OPEN status; composite database constraints bind event to session/item/version. Unique idempotency constraints and request hash make retries safe.
- Submission/scoring transaction serializes session close with answer insertion, captures one event cutoff, and creates a score item for every session item, including unanswered items.
- Editorial publish is a reviewed transaction that checks source, verification evidence, exact question/blueprint version ID, and reviewed content hash. The published version cannot be changed in place.
- AI generation can create drafts only. Review and publish require separate human reviewer permissions and recorded evidence; AI principals are denied those actions.
- AI endpoint invokes only allowlisted tools with read-only access to permitted context; all writes are advisory artifact creation and audited.

The three AI capabilities are separate authorization surfaces even if they share provider infrastructure: Tutor reads only approved content/context; Learning Analysis reads only the authenticated owner's allowed attempt/evidence projection; Web Agent calls typed application APIs rather than a database or arbitrary shell/browser tools. No AI identity receives broad DB credentials. Provider/model, learner-data sharing, retention, and cost budgets are unresolved owner decisions; no provider is selected.

Contracts remain proposals pending auth, question types, selection-policy, lifecycle, and exam-format decisions. Generate OpenAPI from reviewed Pydantic schemas in Phase 1; do not treat this inventory as a substitute for schema review. The authenticated session mechanism and operator health/metrics endpoints are deployment decisions; specify them before production exposure.
