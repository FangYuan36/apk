# Operations, CI and Exam Reliability

> **Current status:** The repository has local npm test/build scripts and offline Agent Hub tests only. CI, branch protection, a backend/API, PostgreSQL, migrations, production deployment, health/metrics endpoints, backups, restore drills and on-call operations are NOT IMPLEMENTED. Requirements below are release targets, not completed evidence. The verified local runner stages work in Termux `$PREFIX/tmp` for Android native-module compatibility.

## Required CI gates

Branch protection requires separate passing jobs for:

1. Formatting and lint (frontend/backend).
2. Type checking (TypeScript and Python static typing policy).
3. Unit tests.
4. PostgreSQL integration tests, including tenancy and event/score integrity.
5. Security checks: dependency/advisory, secret scan, static security analysis, authorization and AI-tool boundary tests.
6. Migration checks: clean install, previous supported schema upgrade, constraints, and downgrade only where lossless.
7. Frontend production build and backend package/build verification.
8. End-to-end smoke for exam/practice, AI-outage core flow, and answer-key access boundary.

Concrete tools/commands are chosen and pinned in Phase 1 after dependency review. CI records command, exit code, logs, artifact, commit SHA and run ID. Skipped/failing required jobs block `CI_VERIFIED`. Any source change invalidates prior results. Agent reports and screenshots do not replace machine-generated CI artifacts tied to the exact commit.

## Exam timing and recovery

- Server timestamps determine start, deadline, accepted writes, close, and submission cutoff. Client clock is display-only; never accept client time as evidence of on-time submission.
- Resume returns canonical session state, deadline and last acknowledged event sequence. Client retries only unacknowledged events with original idempotency keys.
- Submission atomically closes OPEN session, captures final committed sequence/cutoff, and creates a result; repeated submit returns the same result. Writes racing after close fail with `SESSION_CLOSED`.
- Show answer save as pending until server acknowledgment. Network interruption preserves local draft only as unconfirmed; reconnect reconciles against server sequence before resend.
- Offline exam submission and offline answer sync are disabled until answer-key extraction, secure storage, replay conflict, device loss and reconciliation risks are reviewed and owner-approved. Do not cache answer keys before review authorization.
- AI outages do not affect timer, answer save, submit, scoring, session recovery or result review.

## Traffic and operational targets

Before pilot, owner approves concurrent-exam load, rate limits, backpressure, latency/availability targets, capacity, backup frequency, RPO/RTO, alert routing/on-call and incident contacts. Load checks cover synchronized start/submission spikes, retry storms, provider outages and DB contention. No values are invented in Phase 0.

Monitor API availability/latency, DB saturation and transaction failures, answer acknowledgment/submission errors, migration status, auth failures, AI timeout/rate/cost budgets, and backup freshness/restore. Avoid logging raw student answers, tokens, hidden answer keys, or full prompts by default. Keep a tested incident, rollback and restore runbook before pilot.

## Local Operational Runbook (MVP Pilot Web Client)

### Environment Prerequisites
- Node.js >= 20 (verified on Node 26.x / Termux Linux)
- Python >= 3.10
- Termux staging: `$PREFIX/tmp` runtime staging configured automatically via `scripts/run.mjs`

### Primary Verification Commands
1. **Core Domain & Feature Tests:**
   ```bash
   npm test
   ```
2. **Acceptance Suite (11 Protected Task Tests Included):**
   ```bash
   NEXUS_NL002_ACCEPTANCE=1 npm test
   ```
3. **Production Client Build:**
   ```bash
   npm run build
   ```
4. **Agent Hub Offline Verification Suite:**
   ```bash
   python3 agent-hub/tests/run_all_tests.py
   ```
5. **Git Diff Hygiene Check:**
   ```bash
   git diff --check
   ```

### Local Development & Preview
To start the local Vite development server:
```bash
npm run dev
```
Preview production bundle locally:
```bash
npm run preview
```
Visit `http://localhost:5173` (or the printed port) in a mobile or desktop browser. Storage uses browser IndexedDB where available; falls back cleanly to ephemeral in-memory session adapter if IndexedDB is blocked or unsupported.
