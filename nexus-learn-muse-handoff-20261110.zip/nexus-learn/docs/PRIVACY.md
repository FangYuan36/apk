# Learner Privacy and Data Protection

> **Current status:** Repository implementation contains synthetic, test-only questions and in-memory attempt state. It does not create accounts or persist learner data. This design does not establish legal compliance and is not approval to collect student data.

## Data and risk

Grade 12 learners may be minors. Potentially sensitive data includes account identifiers, age/guardian details if collected, study choices, answer history, scores, learning progress, AI prompts/responses, device/network identifiers, support records, and licensed content. Minimize collection and purpose, restrict access, isolate tenants, and use synthetic data in development and CI.

## Required controls

- Do not collect date of birth, school, guardian data, precise location, or sensitive identifiers unless a documented feature needs them and the owner approves purpose and retention.
- Define learner access/export, correction, deletion/deactivation, backup expiry, and legal-hold behavior before production. Do not silently mutate immutable score evidence; approve an anonymization/tombstone strategy with qualified counsel.
- Guardian/teacher access is disabled until separately scoped and authorized. No implicit family sharing.
- Set retention by data class; avoid indefinite telemetry. Restrict staff access and audit privileged reads/writes.
- Do not send identifiable learner data, raw answer histories, or licensed question content to AI providers by default. Require data minimization, privacy/security/contract review, retention review, purpose approval, and owner opt-in.
- Encrypt transport and backups, restrict backup access, and test restore without broadening operator access.
- Define breach/incident owner, escalation contacts, and response process before pilot.

## Data lifecycle and minors

Before any real collection, maintain a data inventory by class (identity/profile, learning event, score, AI request/response, operational log, source/license material), purpose, owner, access role, retention, export/correction/deletion process, backup expiry and any legal hold. Minimize fields at creation; do not infer/store date of birth or school identity unless separately approved. Keep credentials separate from learning events, and do not place learner data in logs or analytics by default.

Plan lifecycle from collection/consent and access through correction, export, retention, account closure, deletion/anonymization, backup expiration and recovery. Because immutable events/results may conflict with deletion requests, do not choose tombstoning, anonymization, or indefinite retention without Product Owner and qualified legal review. No guardian, teacher, or school access is enabled by implication. Grade-12 learners may be minors, so the applicable age/consent model is unresolved.

AI Tutor, Learning Analysis, and Web Agent have separate purposes and data scopes. Default to no identifiable learner data or licensed question content sent to a provider. Any proposed sharing requires purpose limitation, minimization, provider contract/retention/region review, security review, opt-in/consent decision where applicable, and an owner gate.

## Current-law review gate

This document makes no legal compliance determination. Before collecting real student data, a qualified reviewer must identify and verify laws, regulations, official guidance, and contractual duties in force at implementation and deployment time, including those relevant to minors, education data, cross-border transfer, retention/deletion, and AI processing. Record primary sources, effective dates, applicability, reviewer, and resulting controls. Do not infer obligations from stale summaries.

## Acceptance evidence

Before pilot: approved data inventory/purpose/retention schedule; access/export/delete or approved exception flow; AI data-sharing decision; minor/guardian policy; tenant and privileged-access tests; incident runbook; current primary-source legal review record. No real learner data before this gate.
