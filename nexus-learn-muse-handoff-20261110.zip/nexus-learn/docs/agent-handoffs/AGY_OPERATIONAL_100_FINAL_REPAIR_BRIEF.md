# AGY Repair Brief — Operational Campaign Final Audit

**Status:** REPAIR REQUIRED; Codex audit complete and stopped without source edits.
**Role:** AGY sole writer for this bounded repair; Codex verifies after AGY stops.
**Repository:** /data/data/com.termux/files/home/nexus-learn; recheck branch, HEAD, status and preserve the dirty/untracked baseline.
**Read first:** this brief, `docs/agent-handoffs/AGY_OPERATIONAL_90_BRIEF.md`, `reports/next-day-campaign/OPERATIONAL_100_FINAL_CODEX_AUDIT.md`, `AGENTS.md`, `docs/AGENT_WORKFLOW.md`, `DECISIONS.md`.

## Protected actions and files

Do not reset, clean, checkout, delete, stage, commit, push, add dependencies, weaken tests, or claim Product Owner acceptance. Do not modify `src/acceptance/task-nl-002/scoring.acceptance.test.ts). Preserve all existing user changes and draft status. No browser/rights/reviewer evidence may be fabricated.

Single writer: AGY implements this brief, then stops. Codex performs read-only verification. Do not begin another operational WP in this repair round.

## Exact repair scope

Allowed source/test paths:

- `src/domain/math/content-validation/validator.ts`
- `src/domain/math/provenance.ts`
- `src/domain/math/attempt.ts`
- `src/domain/math/math-domain.test.ts`
- `src/content/import/preview.ts`
- `src/content/import/preview.test.ts`
- `src/features/learning-core/MathLearningView.tsx`
- `src/features/learning-core/MathLearningView.test.tsx`
- `src/features/dashboard/DashboardView.tsx` and test
- `src/features/progress/ProgressView.tsx` and test
- `src/App.tsx` and test
- `src/domain/ai/learningContext.ts` and test
- `AGY_REPORT.md` append-only

No package manifest, lockfile, new dependency, content publication, production reviewer registry, or new import write path is authorized by this repair brief.

## Required fixes

1. **Hash/reviewer fail-closed**
   - Publication rejects missing, blank, malformed, or non-matching `QuestionVersion.contentHash`.
   - Reviewer timestamp regex matches are insufficient: reject timestamps whose parsed time is non-finite or calendar-invalid.
   - Import data must not supply its own trusted reviewer registry. Keep preview publication eligibility false unless a trusted registry is injected by the caller outside the package payload. No fallback registry.
   - Add adversarial tests for the current invalid-date probe and package-supplied reviewer record.

2. **Rights**
   - Fail closed when publication lacks explicit operation authorization and required commercial-use/attribution fields/evidence.
   - Do not claim a URL, issuer string or license ID proves rights. Keep unknown/uncertain content draft-only.
   - Add tests for missing permission fields, missing attribution, restricted/expired license and operation mismatch.

3. **Recheck and AttemptEvent write invariants**
   - Resolve the source attempt’s session and require session skill, schedule skill/sourceSkillId, source question mapping and requested recheck skill to agree.
   - Preserve exact source question/version/hash and old AttemptEvent.
   - Reject scored events with missing/empty part evidence, inconsistent part totals, and any invalid result status at constructor/append/repository write boundaries.
   - A failed recheck write must leave the schedule due and previous history untouched.
   - Add adversarial tests for mismatched source-session skill and forged empty-evidence/invalid events.

4. **Dashboard/progress and navigation**
   - Repository load failures must render a distinct error/retry state, not zero metrics or “no attempts”.
   - Do not label positive partial-credit attempts “correct”; use valid scoring denominators and explain partial credit.
   - Include diagnostics from all supported question families.
   - Dashboard quick navigation must keep active state and URL hash synchronized.
   - Add UI tests for rejection/failure, partial scores and hash consistency.

5. **AI context integrity**
   - Derive skill IDs from actual attempt evidence/question mapping; never use questionId as skillId.
   - Freeze nested output records or explicitly remove any runtime-immutability claim and ensure the typed context is isolated from input mutation.
   - Test true skill aggregation and nested mutation attempts. Keep context advisory, read-only, and provider-free.

## Acceptance and handoff

Run focused affected tests, then serially:

1. `npm test`
2. `NEXUS_NL002_ACCEPTANCE=1 npm test`
3. `npm run build`
4. `python3 agent-hub/tests/run_all_tests.py`
5. `git diff --check`

Report exact changed files, commands, exit codes, pass/fail/skip counts, warnings, unresolved items, browser checks as NOT RUN unless performed, and confirm that AGY stopped writing. Keep import explicitly labeled validation+preview only; draft persistence and full recommendation remain outside this narrow repair round.
