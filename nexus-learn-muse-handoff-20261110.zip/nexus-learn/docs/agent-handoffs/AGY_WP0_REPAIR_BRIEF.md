# AGY WP0 Follow-up Repair Brief — Codex Verification Findings

**Status:** REPAIR REQUIRED; not dispatched. AGY must be the only writer during any authorized implementation.
**Repo:** `/data/data/com.termux/files/home/nexus-learn`, `main`, observed base `b502fa7120cadd460c0e224d67fc5b1d8ac43691`.
**Verifier report:** [WP0_CODEX_VERIFICATION.md](../../reports/next-day-campaign/WP0_CODEX_VERIFICATION.md).
**Authority:** Original [WP0 execution brief](AGY_EXECUTION_BRIEF.md) plus this narrowly scoped follow-up. It does not modify D-025.
**PO gate:** WP0-B is blocked by the conflict below. Do not implement a reviewer workaround until PO explicitly authorizes a compatible acceptance-contract update.

## Goal

Repair independently reproduced WP0-A/C/D/E/F/G defects without weakening requirements. Do not claim WP0 verified while WP0-B remains blocked. Do not start another package.

## Single writer, protection and baseline

AGY is the only source writer for the repair. Codex does not edit these source files while AGY works. After handoff, AGY stops and Codex performs a read-only verification.

Capture current `git status --short` and preserve all existing modified/untracked files. The math source tree predates this follow-up as untracked; do not use Git checkout/reset/clean/delete to “restore” it. No stage, commit, push or dependency changes. Protected file `src/acceptance/task-nl-002/scoring.acceptance.test.ts` stays read-only. Do not touch secrets, `../anti/**`, or `job1.zip`.

## Allowlist

Only:
- `src/domain/math/content-validation/validator.ts`
- `src/domain/math/provenance.ts`
- `src/domain/math/scoring-policy.ts`
- `src/domain/math/scoring/scorer.ts`
- `src/domain/math/attempt.ts`
- `src/domain/math/math-domain.test.ts`
- `src/features/learning-core/MathLearningView.tsx`
- `src/features/learning-core/MathLearningView.test.tsx`
- `src/App.tsx` (persistence disclosure only)
- `AGY_REPORT.md` (append report only)

`src/domain/math/index.ts` is not allowed by this brief. Its reported WP0 export change is a recorded scope deviation. Do not alter or attempt to revert that pre-existing untracked file without a separately approved scope and a known baseline. Do not change any other file or add a file/dependency.

## Repair acceptance

### A — Hash actual solution source; fail closed

- Hash only the actual matching `SolutionVersion` resolved from the trusted validation context. Do not prefer an embedded/caller-supplied `questionVersion.solution` object.
- Missing solution, missing/empty required explanation, invalid solution identity/version or missing actual solution data makes publication ineligible.
- Changes to actual explanation, steps, keyPoints, answer/body/mapping/diagnostic data change canonical hash and invalidate an old review.
- Add adversarial validator tests for (1) no solution content, (2) embedded reviewed solution hiding altered context solution, (3) stale hash after actual solution change, and (4) key ordering/NFC/cyclic/non-finite behavior.
- Reject object keys that collide after Unicode NFC normalization; a direct probe currently emits duplicate canonical é keys for NFC and decomposed spellings.
- Keep status/timestamp/self-hash exclusions intentional and documented.

### B — Reviewer authorization: WAIT FOR PO

Known conflict: protected acceptance test expects bare `qualified-reviewer` to publish; secure requirement forbids that. Do not retain the bypass, add a synthetic default registry, trust self-asserted review evidence, or edit the protected test. Stop WP0-B and report unchanged until the PO authorizes an explicit contract/test update. A future safe contract must inject trusted registry evidence, bind reviewer ID, validate dates fail-closed, and check subject plus applicable curriculum. Test fixtures must be labeled synthetic and are not proof of an actual human reviewer.

### C — Rights and provenance fail closed

- Publication must request and enforce an explicit operation (including `publish`) through the license check.
- Missing/empty/unknown `allowedOperations` cannot mean unrestricted use.
- Validate source provenance kind and required traceability/evidence fields; do not accept an arbitrary ID/reference as proof of rights.
- Enforce attribution obligations and commercial-use permission when applicable; require derivative permission for adapted content. Missing or malformed evidence fails closed.
- Keep legal/ownership claims out of code and reports. No reviewer or rights evidence may be fabricated.

### D — Complete scoring invariants

- Constructor and runtime validator must reject all missing required fields, wrong types, NaN/±Infinity, negative points/tolerances, invalid separators, invalid flags, malformed bonus and invalid policy status.
- Validate required `groupingSeparators` and `allowExponent`, not merely when present.
- For each question family and response outcome, ensure every valid score has `0 ≤ totalPoints ≤ maxPoints`; reconcile part points and aggregate exactly. In particular, a valid policy must not produce T/F 8/4.
- Invalid question/policy/answer/execution error stays distinct; do not turn system failure into wrong answer.
- Preserve the policy's `PROPOSED` status and practice-only UI language. Do not change policy terms to imitate an official exam standard.

### E — Bind recheck to complete original evidence

- Resolve schedule `sourceAttemptId` from stored attempt history and confirm its question/version/hash exactly equals `sourceQuestionVersionRef`.
- Resolve question by question ID, version **and contentHash**; mismatch/missing data shows recoverable error and cannot start a recheck.
- Keep unrelated question navigation disabled while rechecking; do not silently clear recheck state.
- Persist result and schedule completion atomically. On failure, prior attempt is unchanged and schedule remains due/retryable.
- Recheck event is distinct, `isDelayedRecheck: true`, linked to the source evidence, and never a mastery claim. Give each scheduled recheck a distinct session identity if multiple rechecks can coexist.

### F — Validate append input shape as well as snapshot

- Deep-clone/freeze every accepted nested field, even for outer shallow-frozen input.
- Reject missing/invalid question ref fields, policy ref fields, response, result, part evidence and timestamp before returning new history.
- Duplicate/malformed input must not mutate history. Add adversarial nested mutation and malformed-field tests.

### G — Persistence disclosure matches active adapter

- Footer wording must not assert IndexedDB if active adapter is in-memory/unavailable; dynamically describe local-only storage without implying server/cloud backup.
- Keep save-success notification after the repository write transaction resolves; surface write errors.
- Do not claim Native IndexedDB verified without real browser execution. If no browser tool exists, record NOT RUN and leave a device/browser checklist.

## Required evidence and stop

Run serially (the wrapper shares a temp runtime):
1. `npm test`
2. `NEXUS_NL002_ACCEPTANCE=1 npm test`
3. `npm run build`
4. `python3 agent-hub/tests/run_all_tests.py`
5. `git diff --check`

Report exact exit codes, test counts, React warnings, changed files, limitations and whether browser tests ran. The raw command `node --test ...tsx` is not a supported verification substitute for the repository wrapper. Stop after these repairs. Do not mark VERIFIED/AUDITED/ACCEPTED. Return control to Codex with AGY explicitly paused. Product Owner alone accepts.

## PO decision required for WP0-B

The current protected acceptance expectation and fail-closed reviewer invariant conflict. Safe path: PO authorizes a new acceptance-contract revision so the protected test passes explicit injected synthetic fixture authorization evidence, while production validator has no bare-ID/default-registry path. If PO does not authorize that test-contract change, WP0-B remains blocked and publication must remain fail-closed. Do not choose the insecure bypass to make tests green.
