# AGY WP0 Final Repair Brief — Codex Gate Findings

**Status:** REPAIR REQUIRED; not dispatched by this report.
**Repository:** /data/data/com.termux/files/home/nexus-learn
**Gate evidence:** reports/next-day-campaign/WP0_FINAL_CODEX_ACCEPTANCE.md
**Owner:** Product Owner; **writer:** AGY only during repair; **verifier:** Codex after AGY stops.
**Scope:** Final focused WP0 repair only. Do not start WP1.

## Preserve and protect

Preserve all existing modified/untracked files. No reset, clean, checkout, deletion, stage, commit or push. Do not touch secrets, ../anti/** or job1.zip. Do not add dependencies or modify package manifests/lockfile. The Codex-owned src/acceptance/task-nl-002/scoring.acceptance.test.ts is protected and must not be edited. Do not edit governance/decision records. Append findings/results to AGY_REPORT.md only.

## Exact allowlist

- src/domain/math/content-validation/validator.ts
- src/domain/math/provenance.ts
- src/domain/math/scoring-policy.ts
- src/domain/math/scoring/scorer.ts
- src/domain/math/attempt.ts
- src/domain/math/index.ts only for exports required by implementation
- src/domain/math/math-domain.test.ts
- src/domain/persistence/types.ts only if a schedule contract field is required
- src/infrastructure/persistence/indexeddb/indexeddbRepository.ts and its existing indexeddbRepository.test.ts for event validation at write boundaries
- src/features/learning-core/MathLearningView.tsx
- src/features/learning-core/MathLearningView.test.tsx
- src/App.tsx only for accurate persistence disclosure
- AGY_REPORT.md append-only

No other path without a Codex scope amendment. Acceptance test remains immutable.

## Required repairs and adversarial acceptance

### A — Publication must hash actual complete content

Require a valid QuestionVersion body and its exact matching SolutionVersion from trusted context before publication. Do not let a precomputed hash or missing body/sparse solution bypass canonical content hashing. Validate solution fields and identity/version. Review hash must cover actual body/answer/mappings/diagnostics and complete solution explanation/steps/keyPoints. Stale review after any change fails. Preserve NFC collision, cyclic, unsupported and non-finite rejection.

Add support tests for:
- approved question with body absent and arbitrary declared hash is rejected;
- sparse/missing explanation/solution/steps required by the selected solution contract fails;
- body/answer/mapping/diagnostic/each solution field changes hash and invalidates old review;
- context solution mismatch, embedded override, key order, normalized key collision.

### B — Reviewer authorization must require curriculum and strict dates

Keep no default registry, no bare-ID and no review-self-evidence. Require exact reviewer identity, active status, non-empty subject scope and mandatory curriculum scope. Require strict ISO date syntax and valid interval; missing curriculum scope, malformed date, invalid reference time, expired/future/revoked/suspended/wrong-scope evidence fails. No evidence fixture is a real person. Production publication remains fail-closed absent a trusted authority source.

### C — Rights/provenance must enforce every permission

Require traceable source/right evidence, not just any non-empty reference. Require a publication permission for every status/provenance combination that may publish; missing allowedOperations is never unrestricted. Explicitly handle original, licensed, synthetic and public-domain cases without claiming metadata proves legal ownership. Enforce attributionRequired and commercialUseAllowed when applicable; missing/unknown/restricted/expired/malformed evidence fails. Do not fabricate legal evidence or publish candidate content.

### D — Derived scoring must remain finite and reconciled

Reject policies whose derived maximum or any aggregate/part arithmetic can overflow, including finite Number.MAX_VALUE components. Do not use score clamping to make malformed arithmetic look valid. Return distinct invalid policy/execution failure; never persist it as incorrect/scored. Ensure all family/partial/empty/bonus outcomes have finite part totals and 0 ≤ totalPoints ≤ maxPoints. Keep PROPOSED/practice-only.

### E — Recheck must match the skill as well as source version

Before starting, resolve sourceAttemptId, exact question ID/version/hash, source session and skill. Verify schedule.skillId/sourceSkillId, source session skill, source question skill mapping and selected skill are consistent. Failure leaves schedule due, creates no session/event and gives a recoverable message. Successful recheck uses a unique session/event, isDelayedRecheck=true, preserves original event and marks complete only inside the successful atomic save.

### F — Validate event shape and enforce at write boundary

Validate trimmed/canonical IDs and reject duplicates after normalization. Validate TF answers as boolean/null, result status and totals, every PartEvidence field, finite points, part/aggregate reconciliation and allowed nested diagnostics. Ensure malformed/cyclic/unsupported nested values fail safely. Use the same validation in constructor, append, InMemory adapter and NativeIndexedDB write methods. Failed append/storage leaves prior history/data unchanged.

### G — Finish persistence error disclosure

Make the global footer consistent with actual adapter: distinguish IndexedDB from volatile in-memory mode or phrase it truthfully without implying persistence. Show clearLocalData/reset failure. Success only follows transaction completion. Native IndexedDB and reload remain NOT VERIFIED unless an actual browser runtime is available; do not add a dependency or claim browser pass.

## Tests and handoff

Add supporting tests only in allowlisted files. Do not edit/skip/weaken the protected acceptance test. Run serially:
1. focused domain tests through the configured tsx runner;
2. focused MathLearningView tests;
3. npm test;
4. NEXUS_NL002_ACCEPTANCE=1 npm test;
5. npm run build;
6. python3 agent-hub/tests/run_all_tests.py;
7. git diff --check.

Report exact changed paths, exit codes/counts, failures/skips/warnings, browser evidence and limitations. Keep all 11 gated acceptance tests enabled for the acceptance run. Do not claim Native IndexedDB or mobile visual verification without a real browser.

End by stopping all writes and state: AGY STOPPED WRITING — READY FOR CODEX VERIFICATION. Do not mark VERIFIED, AUDITED or ACCEPTED. Product Owner retains final acceptance.
