# AGY EXECUTION BRIEF — NEXUS LEARN MVP 50%, WP0 ONLY

**Task:** NL-MVP-50-WP0 — stabilization of audited Math Learning Core invariants
**Repository:** `/data/data/com.termux/files/home/nexus-learn`
**Observed branch/base:** `main` / `b502fa7120cadd460c0e224d67fc5b1d8ac43691`
**Implementer:** AGY, under this task-local PO delegation. **Verifier:** Codex after AGY pauses. **Product acceptance:** PO only.
**Status:** CONTRACT READY; not dispatched, not implemented, not verified, not accepted.
**Canonical context:** [50% roadmap](../strategy/NEXUS_LEARN_50_PERCENT_ROADMAP.md), [scorecard](../strategy/NEXUS_LEARN_MVP_SCORECARD.md), [TASK-NL-002 contract](../TASK-NL-002-MATH-LEARNING-CORE-V1.md).

## 1. Goal and current behavior

Close the four HIGH and three MEDIUM findings from the last independent audit before expanding the learning product. Existing code includes typed math questions/scoring, publication validator, attempt events, React learning UI, delayed schedule, IndexedDB adapter and 15 draft questions. Latest audit verdict was REPAIR REQUIRED. Worktree includes earlier user changes; preserve every existing modified and untracked file.

## 2. Task-local role exception and single writer

The PO's current campaign instruction explicitly assigns AGY as implementer and Codex as planner/verifier. This exception is limited to this task and its per-package allowlist. It does not amend D-025 or permanently change `docs/AGENT_WORKFLOW.md`. Do not change governance. AGY is the only code writer during this WP; on handoff AGY pauses and Codex performs a read-only review. No overlapping writers. Codex cannot launch/control AGY TUI here; a human must paste the launch prompt below.

## 3. Required reading before work

Read each complete file before touching code:
- `AGENTS.md`
- `docs/AGENT_WORKFLOW.md`
- `DECISIONS.md` (especially D-017, D-020, D-024, D-025)
- `docs/TASK-NL-002-MATH-LEARNING-CORE-V1.md`
- `docs/strategy/NEXUS_LEARN_50_PERCENT_ROADMAP.md`
- `docs/strategy/NEXUS_LEARN_MVP_SCORECARD.md`
- `CODEX_REVIEW.md` and the final audit findings in `AGY_REPORT.md`
- relevant acceptance tests and every source module in this allowlist.

Summarize objective, WP0-only scope, exact expected files, protected paths and stop gates before implementation. If a required file is unavailable or conflicts with this task-local authority, stop and report it.

## 4. Scope and files

Allowed source/test files for WP0:
- `src/domain/math/content-validation/validator.ts`
- `src/domain/math/provenance.ts`
- `src/domain/math/scoring-policy.ts`
- `src/domain/math/scoring/scorer.ts`
- `src/domain/math/question.ts` (only if required for solution/hash invariants)
- `src/domain/math/attempt.ts`
- `src/domain/math/math-domain.test.ts` (supporting tests)
- `src/features/learning-core/MathLearningView.tsx`
- `src/features/learning-core/MathLearningView.test.tsx`
- `src/domain/persistence/types.ts` (only schedule fields needed for exact source)
- `src/App.tsx` (only persistence footer text)
- `src/acceptance/task-nl-002/scoring.acceptance.test.ts` is Codex-protected: read-only; do not edit, delete, skip, weaken, or replace assertions.
- `AGY_REPORT.md`: append an accurate WP0 implementation report; do not rewrite historical reports.

Do not edit `package.json`, `package-lock.json`, any dependency, protected acceptance tests, unrelated task/planning docs, unrelated UI, or files outside this list. No new files unless Codex explicitly adds them to an approved follow-up contract. Do not access secrets, `../anti/**`, or `job1.zip`.

Before work, capture `git status --short` and `git diff --name-only` as reference. Do not overwrite old modifications. No reset, checkout, clean, stage, commit, push, broad rollback, or delete command.

## 5. Required repairs and acceptance criteria

### WP0-A — Canonical content hash and solution binding [HIGH]

Current audit evidence: `computeQuestionContentHash` canonicalizes nested data, but hashes `solutionVersionId` rather than actual solution content; validator only matched solution id/question/version. Preserve canonical key sorting and NFC behavior.

- Hash actual canonical question content, answer, mappings, diagnostic metadata and the exact solution content/version.
- Validate that the solution is structurally valid and references the same question/version.
- If existing data contracts lack solution content at validation, update the bounded validator/context contract so caller supplies the actual referenced SolutionVersion; do not trust a caller-provided precomputed hash alone.
- Any change to explanation, steps, key points, answer, body or mapping changes hash. Old review hash cannot publish changed content.
- Reordered object keys yield same hash; invalid/cyclic/unsupported content fails closed.
- Add tests for each changed solution field and stale review after mutation.

### WP0-B — Reviewer authorization fail-closed [HIGH]

Current audit evidence: `validator.ts` has a special `reviewerId === 'qualified-reviewer'` branch. Delete this bypass.

- No ID string or self-supplied evidence alone proves a real reviewer.
- Reviewer evidence must come from an injected trusted registry/authority boundary, be bound to reviewer ID, active, validly dated, and scoped to subject and applicable curriculum.
- Missing/malformed dates, missing registry record, unknown/unapproved subject, expired/revoked/suspended authority fail closed.
- Test fixture records are named synthetic fixtures and must not be described as real reviewer validation.
- No real reviewer may be fabricated; all 15 pilot questions remain draft unless legitimate reviewer evidence exists.

### WP0-C — Rights and provenance [HIGH/MEDIUM]

- Explicit allowlist for eligible license/right statuses and operations.
- Validate validity interval including validFrom/validThrough and malformed dates.
- Require source record fields and traceable rights evidence; an arbitrary ID/reference alone is insufficient.
- Require/verify permitted use for intended operation, attribution when required, derivative permission for adapted content, and commercial permission if intended.
- Unknown/restricted/expired/incomplete/malformed records fail closed. Original/synthetic status does not itself prove human authorship/originality; label claims as unverified without evidence.
- Keep fixture rights synthetic and non-publishable. Do not add legal conclusions or use internet access as rights evidence.

### WP0-D — Scoring policy validation [HIGH]

Current audit runtime probe: `createScoringPolicyVersion` accepted NaN, negative points and Infinity although downstream validator rejected one later. Harden constructor and runtime validator consistently.

- Validate required nested objects and every numeric field as finite and non-negative; validate status, decimal separator/grouping arrays and flags.
- Enforce policy invariants so all valid results reconcile and `0 ≤ totalPoints ≤ maxPoints`, including empty, incorrect, partial-credit and bonus cases.
- Test NaN, ±Infinity, negatives, wrong types, missing nested policy, malformed decimal tolerance/separators, excessive bonus and inconsistent points.
- Preserve arbitrary-precision decimal arithmetic, allowed/rejected scientific notation, comma/dot normalization and inclusive tolerance boundaries.
- Result categories distinguish invalid answer, question, policy and execution failure. Runtime failure must not be persisted as incorrect/empty.
- Policy remains `PROPOSED` and practice-only. Do not change to approved, official or exam-aligned.

### WP0-E — Exact-source delayed recheck [HIGH]

Current audit evidence: schedule carries source attempt/question version, but due action may leave current question index unchanged and recheck a different item.

- When a due recheck starts, resolve and load the exact immutable question version referenced by the schedule; if unavailable, fail with a visible recovery/error state and do not label another question as its recheck.
- Use a distinct recheck session and a separate append-only result event; original attempt remains byte-for-byte unchanged.
- Persist schedule completion only with successful recheck persistence. Failed storage leaves schedule due and reports error.
- Preserve sourceAttemptId and question version/hash linkage after reload.
- A recheck is one evidence point, never mastery/proficiency.

### WP0-F — Deep immutable append [MEDIUM]

- `appendAttemptEvent` must always validate and deep clone/freeze nested event data, even if outer input is already frozen.
- Reject malformed event and duplicate IDs before changing returned history.
- Test mutation of original input and nested response/result/partEvidence/diagnostic objects after append; previous history remains unchanged.

### WP0-G — persistence disclosure [MEDIUM]

- Replace contradictory footer copy in `src/App.tsx` with wording consistent with local device IndexedDB persistence; explicitly do not call it cloud/server backup.
- Save success is shown only after repository transaction resolves. Keep exact storage error visible on failure.

## 6. Forbidden changes and architecture

No provider, API key, network AI, official scoring policy, mastery model, auth/account, cloud sync, backend, server backup, multi-device, exam submission, school/LMS, or new dependency. Do not publish sample content. Preserve React + TypeScript + Vite modular monolith; pure scoring stays UI-independent; raw attempts remain append-only. D-017/D-020/D-024 remain in force. No actual reviewer, curriculum alignment or rights claim may be invented.

## 7. Tests and evidence

Run and report actual exit code/output for:
1. focused WP0 tests (state exact command)
2. `npm test`
3. `NEXUS_NL002_ACCEPTANCE=1 npm test`
4. `npm run build`
5. `python3 agent-hub/tests/run_all_tests.py`
6. `git diff --check`

Do not run the two npm tests concurrently; `scripts/run.mjs` uses a shared temporary runtime. Report passed/failed/skipped and React warnings. No browser engine is currently known to be available: check installed tools. If unavailable, Native IndexedDB and mobile viewport remain NOT RUN; do not substitute jsdom/in-memory. Do not install dependencies.

## 8. Definition of Done and handoff

- All WP0 acceptance criteria above have supporting tests; protected Codex acceptance tests unchanged.
- Scope matches allowlist and dependency files unchanged.
- Actual diff and untracked files listed.
- Test/build output reported exactly; limitations and rollback limited to WP0-owned patch only.
- No stage/commit.
- Stop after WP0; do not start WP1. Return control to Codex for read-only independent verification. Do not mark VERIFIED, AUDITED or ACCEPTED on Codex's behalf.

## 9. Human-dispatch prompt (copy exactly)

> Before doing anything, read the complete `docs/agent-handoffs/AGY_EXECUTION_BRIEF.md`. Also read `AGENTS.md` if present, `docs/AGENT_WORKFLOW.md`, `DECISIONS.md`, `docs/TASK-NL-002-MATH-LEARNING-CORE-V1.md`, the 50% roadmap and MVP scorecard named in the brief, plus the latest Codex audit findings and every in-scope source/acceptance file. Do not work from this pasted summary alone.
>
> First report a concise summary of the goal, WP0-only scope, intended files, forbidden files, and stop gates. Then implement only WP0 in the exact allowlist. AGY is the sole writer; Codex verifies after you pause. Preserve every pre-existing modified and untracked file. Do not reset, clean, checkout, stage, commit, push, delete data, add dependencies, edit protected acceptance tests, change decisions, fabricate reviewer/rights evidence, publish draft questions, or start WP1. Run and report the exact checks and counts listed in the brief. If any required source/evidence is unavailable or a decision is R2/R3, stop that portion, keep the behavior fail-closed, and report the blocker. Finish with actual changed files, command outputs/exit codes, limitations, and a handoff stating you have stopped writing for Codex verification.
