# AGY Operational 90% Execution Brief

Task: NEXUS LEARN Operational local web pilot. Repository /data/data/com.termux/files/home/nexus-learn. Observed main / b502fa7120cadd460c0e224d67fc5b1d8ac43691; recheck before each WP. Codex updates WP0-B protected test before handoff. AGY implements; Codex verifies after AGY stops; PO alone accepts.

## Mandatory reading and authority

Before doing anything, read complete AGENTS.md, docs/AGENT_WORKFLOW.md, DECISIONS.md (D-017/D-020/D-024/D-025), docs/TASK-NL-002-MATH-LEARNING-CORE-V1.md, 50% roadmap/scorecard, Operational 90 roadmap/scorecard, docs/agent-handoffs/AGY_EXECUTION_BRIEF.md, docs/agent-handoffs/AGY_WP0_REPAIR_BRIEF.md, reports/next-day-campaign/WP0_CODEX_VERIFICATION.md, relevant AGY_REPORT.md/CODEX_REVIEW.md, and every active-WP source/test.

PO explicitly delegates AGY implementation for this campaign only. This does not amend D-025 or docs/AGENT_WORKFLOW.md. Codex owns planning and narrow acceptance-test update; test is frozen for AGY. AGY is sole source writer per active WP and pauses before Codex verification. Existing dirty/untracked files predate this handoff; do not infer ownership from status.

First report understanding, Git state, active WP, exact allowlist, protected files, criteria, dependencies and PO gates. Recheck status before each WP.

## Goal and boundaries

Single-user local-browser derivative-applications pilot: choose skill/session, answer MCQ/T-F/numeric, deterministic practice score, explanation, hypothesis-bounded diagnosis/recommendation, persist attempt/schedule, reload/recover, exact-source recheck, progress/history.

Forbidden: reset/clean/checkout/stage/commit/push/delete old files; touch ../anti/**, job1.zip, secrets/env; add dependencies/change package manifests or lock; weaken tests; fabricate reviewer/license evidence; publish candidates; claim official score/mastery; change D-017/020/024/025; backend/auth/cloud/provider/payment/AI chatbot/multi-user/external deployment. Local storage is not cloud backup. Rights/privacy/retention/scoring/dependency/production/destructive-data are PO gates. Fail closed.

Strict dependency order WP0 → WP1 → WP2 → WP3 → WP4 → WP5. One WP at a time; Codex gate before next.

## WP0 — Domain/publication stabilization A-G

Allowed:
- src/domain/math/content-validation/validator.ts
- src/domain/math/provenance.ts
- src/domain/math/scoring-policy.ts
- src/domain/math/scoring/scorer.ts
- src/domain/math/question.ts
- src/domain/math/attempt.ts
- src/domain/math/math-domain.test.ts
- src/domain/math/index.ts only to export the Codex-contracted reviewer authorization helper/type
- src/domain/persistence/types.ts
- src/infrastructure/persistence/indexeddb/indexeddbRepository.ts only if shared full event validation requires it; report rationale
- src/features/learning-core/MathLearningView.tsx and MathLearningView.test.tsx
- src/App.tsx for storage disclosure only
- AGY_REPORT.md append-only

Protected: src/acceptance/task-nl-002/scoring.acceptance.test.ts; campaign/decision docs; package files; unrelated features. No dependencies.

A: one canonical validated model/hash from exact question and complete referenced solution, answer/body/mappings/diagnostics/solution fields. Reject missing/mismatch, NFC key collision, cycle, unsupported/nonfinite. Stale review fails on content change.
B: no bare ID, review self-evidence, default registry or fallback. Explicit injected trusted registry evidence bound to reviewer/status/strict date/subject/curriculum. Missing/malformed/expired/suspended/revoked/wrong scope fails. Synthetic fixtures only. The protected test contract requires exported validateReviewerAuthorization(reviewerId, context) returning { authorized, errors }; context contains subjectId, curriculumVersionId, now and an explicitly injected reviewerRegistry. Review objects cannot self-authorize.
C: provenance/license allowlists, traceable rights evidence, strict dates, operation-specific publish/adaptation permission, attribution/commercial enforcement. Metadata alone not proof.
D: constructor/scorer share runtime validator; reject missing/wrong/nonfinite/negative and inconsistent partial/bonus/max policy. Results within 0..max. Runtime error is not wrong answer/attempt. Keep PROPOSED/practice-only.
E: schedule resolves sourceAttemptId to event, then exact question ID/version/hash/skill. No index/substitute. New recheck session/event, delayed marker/source link; original immutable. Completion only in committed atomic transaction. Mismatch/failure stays due with recovery.
F: full event schema at constructor/append/storage; deep clone/freeze even shallow-frozen input; malformed/duplicate rejected without history mutation.
G: UI reflects active adapter; IndexedDB only if active; no cloud claim. Surface load/save/reset/quota failure; success after commit.

Acceptance: adversarial supporting tests for all A-G. No BLOCKER/HIGH. Browser evidence separate from jsdom/memory. Codex verifies before WP1.

## WP1 — Persistence/recovery/recheck

Allowed: src/domain/persistence/types.ts; src/infrastructure/persistence/indexeddb/indexeddbRepository.ts and indexeddbRepository.test.ts; learning-core view/test; App.tsx/App.test.tsx; styles.css for storage/error state only. No WP0-domain source edits absent Codex amendment.
Implement explicit IndexedDB/memory/unsupported selection; atomic session/event/schedule/projection; resolve promises on transaction complete; duplicate/quota/migration/corruption; reload/close-open recovery; interrupted-session resume; scoped reset.
Acceptance: abort after request success, quota, duplicate, migration/corruption/recovery/reset. If no real browser, Native IndexedDB NOT VERIFIED; mocks are not proof.

## WP2 — Complete evidence-driven learning journey

Allowed: App.tsx/App.test.tsx; learning-core view/test; persistence types/repository/tests only if WP1 passed; styles.css; new src/features/dashboard/DashboardView.tsx + test and src/features/progress/ProgressView.tsx + test.
Wire dashboard/progress to actual stored sessions/attempts/schedules; all question types, explanation, hypothesis, reasoned recommendation, schedule/recheck/history/reload/resume and loading/empty/error/success.
Acceptance: mounted interactions end-to-end; invalid/empty no event; storage failure preserves old history/due schedule; duplicates prevented; projections match records; no mastery claim.

## WP3 — Draft-only data import

Allowed after WP0: validator.ts only by Codex amendment; derivative-applications.ts only fixture/schema corrections; new src/content/import/schema.ts, schema.test.ts, preview.ts, preview.test.ts, scripts/validate-content.ts; package.json only to add script (no deps, no lockfile change).
Implement versioned import contract, schema/content validation, duplicate report, preview and item-addressable errors for IDs/versions/answers/solutions/mappings/provenance/licenses/reviewer. No write/publish path; always draft/in_review.
Acceptance: valid/malformed fixtures, deterministic report, no publication/source mutation, rights/reviewer fail closed. If dependency/API change needed, stop for PO.

## WP4 — Mobile UX/deployable client

Allowed: App/tests; learning view/test; WP2 dashboard/progress; MathRenderer/test; styles.css; index.html; vite.config.ts; docs/OPERATIONS.md. No hosting/deployment.
Acceptance: actual browser at 360x800, 390x844 and wide if present; keyboard/touch/formulas/tables/errors/overflow; build, asset paths and local serve/version instructions. Otherwise visual NOT VERIFIED.

## WP5 — Read-only AI context boundary

Allowed: new src/domain/ai/learningContext.ts and test; docs/AI_GOVERNANCE.md small cross-reference only if needed.
Typed context carries refs, timestamps, evidence and uncertainty; no mutation/provider capability. Missing evidence abstains. Test no write authority over score, attempts, publication, reviewer or mastery. No chatbot.

## Verification, gates and copy-paste prompt

D-017/D-020/D-024 unchanged; no official scoring/mastery claim or draft publication. No real learner data/secrets. For each WP run focused tests then serially: npm test; NEXUS_NL002_ACCEPTANCE=1 npm test; npm run build; python3 agent-hub/tests/run_all_tests.py; git diff --check. Test wrapper shares temporary runtime; never run npm suites concurrently. Report exact counts/exit codes, warnings, files, dependency changes, limitations and browser evidence.

Stop for absent real rights/reviewer, destructive migration, or unresolved owner gate. No stage/commit. Do not start dependent WP before Codex gate. End: AGY STOPPED WRITING — READY FOR CODEX VERIFICATION.

Copy-paste AGY prompt:
Before doing anything, read the complete docs/agent-handoffs/AGY_OPERATIONAL_90_BRIEF.md. Also read AGENTS.md, docs/AGENT_WORKFLOW.md, DECISIONS.md, latest Codex verification report, latest WP0 repair brief, roadmaps/scorecards and every source/test for active WP. Do not work from this pasted text alone.

First report your understanding, Git state, active WP, exact allowlist, protected files, criteria and approval gates. Then implement only authorized work in dependency order, starting WP0; stop for Codex verification before WP1.

Do not reset, clean, checkout, stage, commit, push, delete old files, add dependencies, weaken tests, edit protected acceptance test, fabricate evidence, publish draft, change decisions, start dependent WP early or claim browser/mobile verification without actual runtime evidence. Fail closed when blocked. Finish with exact changed files, commands/counts/exit codes, failures/skips/warnings/limitations and confirm you stopped writing for Codex.
