# NEXUS LEARN — MVP Pilot Scorecard

**Scope:** one local-first Grade 12 mathematics vertical, not the whole long-term product.
**Baseline revision:** `b502fa7120cadd460c0e224d67fc5b1d8ac43691`, branch `main`; evidence from 2026-11-08.
**Freshness:** not rerun on 2026-11-09.
**Rule:** score only implemented behavior with relevant executed evidence. Draft content, prose, mock-only behavior and unrun browser checks earn no verified-completion credit. Product Owner alone records ACCEPTED.

| Area | Weight | Current status | Evidence-based score | Required outcome / acceptance evidence | Remaining risk |
|---|---:|---|---:|---|---|
| Core correctness & stabilization | 25% | IMPLEMENTED; AUDITED with HIGH findings | 12/25 | Close reviewer bypass, hash actual solution content, strict policy invariants, exact-source recheck, deep event snapshot, rights scope and inconsistent persistence label; adversarial tests and independent rerun | Publication can be bypassed; policy constructor/recheck errors remain |
| Complete Learning Loop | 30% | Partly implemented; not fully verified | 17/30 | Browser-backed select→session→answer→score→explain→diagnose/abstain→recommend/abstain→persist→schedule→reload→exact-source recheck→persist result | Existing component journey uses in-memory tests; source/recheck mismatch |
| Question Bank & governance | 20% | Foundation implemented; publication gate not trustworthy | 7/20 | Canonical actual-content hash; schema/mapping/answer/solution validation; trusted reviewer and rights evidence; report; pilot remains draft without real review/rights | Reviewer bypass, incomplete rights evidence, no qualified reviewer confirmed |
| Persistence & reliability | 10% | Adapter implemented; Native IndexedDB NOT VERIFIED | 3/10 | Real browser transaction, duplicate, quota/abort, reload, migration, corrupt record and reset evidence | Tests cover in-memory adapter; DB version 1; no real migration exercised |
| Mobile UX | 10% | Responsive styles/components; visual inspection NOT RUN | 3/10 | Browser check at 360×800 and 390×844, formulas/tables/keyboard/overflow/accessibility/error states | No browser/device inspection evidence |
| AI-ready foundation | 5% | No dedicated contract implemented | 0/5 | Typed bounded context/result, evidence references, uncertainty/abstention, advisory-only boundary, tests; no provider | Not implemented; provider out of scope |
| **Total** | **100%** |  | **42/100** |  |  |

**Baseline estimate: 42% evidence-based MVP pilot completeness**, not 42% of the entire NEXUS vision. Component tests and source inspection earn partial evidence only. They do not prove native IndexedDB or mobile browser behavior. Do not round this up to 75%.

## Point allocation rationale

These are partial-credit engineering estimates, not a claim that each category has passed its gate. The total is arithmetic over the weighted row scores above.

- **Core correctness (12/25):** domain/version contracts and many deterministic scoring cases exist (8 points); content/reviewer/rights safety earns only 1 point because publication still has a demonstrated bypass; attempt/recheck/policy hardening earns 3 points because code exists but the audit found correctness defects.
- **Learning Loop (17/30):** selection, answer, score and explanation flow exists (8); error/recommendation evidence is partially implemented (3); schedule/recheck exists but exact source binding fails (2); attempt/history/progress behavior exists in code/tests but browser persistence is unverified (4).
- **Question governance (7/20):** structured forms and versioned records exist (4); solution/hash binding is incomplete (1); provenance/rights evidence is incomplete (1); review/publication enforcement is bypassable (1).
- **Persistence (3/10):** stores and transaction-completion code exist (2); UI calls the repository (1); no native-browser evidence is available.
- **Mobile UX (3/10):** responsive CSS and semantic components exist (3); no real viewport/keyboard inspection points are awarded.
- **AI foundation (0/5):** no dedicated context-bounded AI contract is implemented.

## Evidence from latest audit

- `npm test`: exit 0; 71 passed, 0 failed, 11 skipped (acceptance suite gated).
- `NEXUS_NL002_ACCEPTANCE=1 npm test`: exit 0; 82 passed, 0 failed, 0 skipped.
- `npm run build`: exit 0.
- `python3 agent-hub/tests/run_all_tests.py`: exit 0; 9 passed.
- `git diff --check`: exit 0.
- React `act(...)` warnings occurred.
- Native browser IndexedDB and mobile viewport inspection: NOT RUN.
- 15 pilot questions: draft; no qualified human reviewer independently verified.

This evidence predates any future change and cannot prove a new revision. Re-run commands and record exact code/counts per package.

## Status vocabulary

- **IMPLEMENTED:** code exists.
- **VERIFIED:** acceptance behavior executed against a named revision.
- **AUDITED:** independent source/diff review completed with findings.
- **ACCEPTED:** Product Owner decision only.
- **BLOCKED:** an external/owner gate prevents the named outcome.
- **NOT VERIFIED:** no qualifying execution evidence.

No row is ACCEPTED. An area with an open acceptance-impacting HIGH finding does not pass its gate even when tests are green.
