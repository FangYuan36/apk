# NEXUS LEARN — 50% Product Roadmap

**Campaign:** NL-MVP-50 (campaign umbrella; each execution remains a bounded task)
**Repository inspected:** `/data/data/com.termux/files/home/nexus-learn`
**Observed revision:** `main`, `b502fa7120cadd460c0e224d67fc5b1d8ac43691`
**Inspection date:** 2026-11-09 (Asia/Ho_Chi_Minh)
**State:** Planning; no product code changed. Product Owner acceptance remains separate.

## Outcome

Deliver one trustworthy, local-first Grade 12 mathematics learning journey: structured curriculum and versioned questions; deterministic practice scoring; evidence-linked error feedback and reasoned recommendations or abstention; a due-date review schedule; an exact-source delayed recheck; persistent local history; and a mobile-usable interface. Keep future subject/curriculum expansion possible through domain contracts, not UI hard-coding. No mastery model is selected (D-017); review dates are scheduling only (D-020); a sample verification cycle is not mastery (D-024).

## Repository reality

At the observed revision, code is beyond stale bootstrap status prose. The repo has a React/Vite learning feature, three question forms, domain/content validation, a custom safe semantic math renderer, an IndexedDB adapter, 15 draft pilot questions, and acceptance/unit/component tests. The latest audit evidence (2026-11-08, not rerun today) was default tests 71 passed/11 skipped, enabled acceptance 82/82, production build passed, Agent Hub 9/9 and diff check passed. That audit also found open HIGH issues: (1) hard-coded `qualified-reviewer` publication bypass; (2) question hash includes only solution ID, not actual solution content; (3) `createScoringPolicyVersion` accepts invalid runtime numeric values; (4) recheck may present a different question than its recorded source. MEDIUM: shallow-frozen attempt can bypass deep snapshot, license/source checks omit rights scope, and app footer conflicts with IndexedDB persistence. Native browser IndexedDB and mobile viewports were NOT RUN.

The working tree is already dirty with prior TASK-NL-001/TASK-NL-002/planning work and untracked implementation. Preserve it. Do not reset, clean, checkout, stage, commit, or overwrite existing work. No new dependency is approved. `jsdom@31.0.0` is a previously approved test-only dependency.

## Work package order

| Order | Package | Outcome / gate |
|---|---|---|
| WP0 | Stabilize audited invariants | Close the four HIGHs and three MEDIUMs with adversarial tests; fail closed on unproven reviewer/rights data; no fake evidence. Codex verifies before WP1. |
| WP1 | Verified Learning Loop vertical | One skill/topic end-to-end: selection, version-pinned question, validate, score, explain, evidence-grounded error tag (ERR_CONCEPT, ERR_METHOD, ERR_CALC, ERR_READ), reasoned recommendation/abstention, schedule, exact-source delayed recheck, immutable history and evidence timeline. |
| WP2 | Question-bank governance | Validation report, immutable versions, answer/solution binding, rights and reviewer evidence, publish eligibility. Existing pilot stays draft until real rights and qualified review exist. |
| WP3 | Browser persistence and mobile reliability | Real-browser IndexedDB save/abort/quota/reload/recheck and migration/recovery evidence; inspect 360×800 and 390×844. Mocks do not count. |
| WP4 | AI-ready contracts | Typed context-bounded interfaces, evidence/uncertainty/abstention and advisory-only boundary. No provider, network, key or AI publication authority. |

WP0 is prerequisite; WP1 builds on it. WP2 and WP3 follow the learning vertical. WP4 is last and contract-only. Dispatch and audit one package at a time; do not start the next before the Codex gate.

## WP0 acceptance

1. No reserved reviewer ID or caller-supplied review object authorizes publication without trusted injected evidence active, in date, and scoped to subject/curriculum. Missing or malformed dates fail closed. Fixtures are labeled fixtures, never actual reviewer identity.
2. Canonical content hash binds question body, answer, mappings, diagnostics, curriculum/version and canonical actual solution content. Meaningful edits invalidate old review. Key order and Unicode normalization are deterministic.
3. Policy constructor and runtime evaluator reject missing, wrong-typed, negative, NaN, infinite, inconsistent and overflowing fields. Invalid answer, invalid question, invalid policy and execution failure are distinct; system error cannot become wrong answer. For valid results, `0 ≤ totalPoints ≤ maxPoints`, with part totals reconciled.
4. Recheck schedule stores source attempt and exact question version. Starting recheck loads that version into a separate session; completion writes a separate attempt and schedule status, never changes original history. No mastery claim.
5. Append always snapshots/deep-freezes nested event data, including shallow-frozen input; duplicate IDs fail without modifying history.
6. Publication checks an explicit rights whitelist and required operations, attribution, commercial and derivative evidence. Unknown/incomplete/malformed rights fail closed; source IDs resolve to validated metadata. Without rights, content remains draft.
7. Persistence labels consistently state local device storage, not cloud backup.

## Full pilot acceptance

- **Domain:** versioned data-driven taxonomy; question identity separated from immutable version; attempt pins exact question and scoring policy; statement evidence retains statement skill mapping.
- **Loop:** lifecycle label visible; invalid/empty answers do not persist; valid attempts report saved only after transaction commit; feedback/recommendation cites evidence or abstains; recheck traces to its exact source.
- **Content:** publication needs structural, answer/solution, mapping, source/rights, exact content hash review and reviewer authorization checks. No AI auto-publication.
- **Reliability:** native IndexedDB tested in a real browser for transaction atomicity, duplicates, reload, failure recovery, migration and local deletion, reported separately from memory tests.
- **UX:** real browser at 360×800 and 390×844; keyboard access, long formulas, tables, statement grouping, submit controls, overflow and loading/empty/error/success states.
- **AI readiness:** contracts only, no provider/secrets, advisory output and abstention when evidence is insufficient.

## Owner decisions still open (R2)

These do not block hardening; keep affected content/scoring test-only and unpublished.

- Reviewer qualification source: who qualifies a math reviewer, and what trusted evidence/registry is authoritative?
- Content rights: which sources and permitted operations, including derivatives, commercial use and attribution, are approved for pilot publication?
- Scoring: approve a versioned practice profile only if the PO wants a fixed policy. Until explicit approval it remains PROPOSED/non-official; no exam alignment claim without current primary source and review evidence.
- Browser test tooling: use an already-installed browser if available. If none, present install/runtime options, size, license and compatibility before requesting a dependency.
- Curriculum alignment: choose authoritative curriculum edition/source before claiming official mapping; until then label the mapping synthetic/unverified.

No backend, authentication, cloud sync, student PII profile, AI provider, production system or destructive migration is authorized here.

## Risks and rollback

Packages must be additive/reversible and preserve old dirty changes. Record exact allowed files before each package. Roll back only that package's own patch under its task authorization; never use broad `git checkout`, `reset`, `clean`, `rm -rf`, or indiscriminate deletion. Main risks: false publication eligibility; system error recorded as student error; wrong recheck item; untested browser storage; unreviewed/copyright-unclear questions; stale status prose; and overclaiming completion. Draft labels and abstention are safe defaults.

## Progress and dispatch

The evidence-based baseline is in [NEXUS_LEARN_MVP_SCORECARD.md](NEXUS_LEARN_MVP_SCORECARD.md). Latest audit verdict remains REPAIR REQUIRED; this plan does not change it. [AGY_EXECUTION_BRIEF.md](../agent-handoffs/AGY_EXECUTION_BRIEF.md) is the sole execution brief. AGY receives WP0 first; Codex independently checks actual diff/source and reruns checks; only PO can mark ACCEPTED.
