# NEXUS LEARN Operational 90% Roadmap

Campaign: single-user local-browser web pilot. Repository observed 2026-11-09 at /data/data/com.termux/files/home/nexus-learn, main, HEAD b502fa7120cadd460c0e224d67fc5b1d8ac43691. Status: planning only; implementation and PO acceptance pending.

## Reality and outcome

The tree is already dirty with earlier TASK-NL-001/TASK-NL-002 source, docs, protected tests and untracked trees. Git cannot attribute all untracked files. No staged changes observed. Preserve everything; no reset/clean/checkout/delete/stage/commit/push.

Current code has React/TS/Vite, three math question families, deterministic scorer, publication validator, 15 derivative-topic draft candidates, a mounted MathLearningView, IndexedDB and memory adapters. App mounts learning only in Study; Dashboard/Progress are placeholders, no import preview/error-report flow exists. Initial storage-read failures are swallowed. Recheck resolves ID/version but does not prove source attempt/hash/skill linkage. Real-browser persistence/mobile are NOT VERIFIED.

Target: choose skill/session → answer MCQ/T-F/numeric → deterministic practice score → explanation/diagnostic hypothesis/recommendation → persist → reload/recover → exact-source delayed recheck → inspect evidence timeline/dashboard. Draft items remain visibly draft. This is not SaaS.

Baseline: npm test exit 0 (76 passed, 0 failed, 11 skipped); acceptance-enabled npm test exit 0 (87/87) but bare reviewer ID currently passes; npm run build exit 0; Agent Hub 9/9 exit 0; git diff --check exit 0. React act warnings appeared. No browser executable found.

## WP0 findings and fix design

A — HIGH/open: validator hashes optional embedded solution and may prefer it to actual context solution; sparse/missing solution can be omitted; NFC-equivalent keys are not rejected. Build one validated canonical model from exact QuestionVersion + referenced complete SolutionVersion, including answer/body, mappings, diagnostics and solution fields. Reject missing/mismatched solution, colliding NFC keys, cycles, unsupported/non-finite input. Review hash must bind all content.

B — BLOCKED/HIGH/open: validator trusts review-attached evidence, ignores malformed dates, misses curriculum scope; qualified-reviewer branch adds no error. Protected acceptance test expects a bare ID. PO authorizes Codex to update only this test contract before AGY source work. Production: no default registry, bare-ID fallback or self-asserted review evidence. Require explicitly injected trusted registry evidence matched to reviewer, subject, curriculum, active status and strict dates. Fixture is synthetic and not a real reviewer.

C — HIGH/open: publication accepts sparse source/reference metadata and does not pass requested operation into license eligibility. Enforce provenance/license allowlists, traceable rights evidence, date interval, publish/adaptation operation, attribution and commercial conditions. URL/ID/original label alone is not proof; fail closed; no legal ownership claim.

D — HIGH/open: scoring policy validator permits incomplete allowExponent/groupingSeparators and does not fully constrain partial/bonus consistency. Constructor/scorer share validator; reject missing/wrong/nonfinite/negative fields, bad tolerance/separators and inconsistent totals. Results reconcile within max. Runtime failure is not an incorrect attempt. Policy remains PROPOSED/practice-only.

E — HIGH/partial: UI resolves question ID/version only; no sourceAttemptId/hash/sourceSkill verification; recheck session ID reused per skill. Resolve exact source event and immutable question/hash/skill; no index or substitution. Distinct session/event, delayed marker/source linkage, original immutable. Complete schedule atomically only after committed save. Missing/mismatch stays due with recovery state.

F — MEDIUM/open: append checks outer refs/IDs only. Share full AttemptEvent validator across constructor/append/storage; clone then freeze; malformed/duplicate must leave history unchanged.

G — MEDIUM/open: footer always claims IndexedDB though memory adapter exists; initial read errors are swallowed. Reflect active adapter, local-only/no cloud; expose read/write/reset/quota errors; success only on transaction complete. Browser claims need browser evidence.

## Sequence and gates

WP0 domain/publication A-G → WP1 persistence, recovery, exact recheck → WP2 full evidence-driven learner journey and real Dashboard/Progress → WP3 draft-only content import preview/report → WP4 mobile UX/accessibility and client deployment instructions → WP5 read-only AI context contract, no provider/chatbot. Strict sequential gates; no overlapping writers.

WP0 tests: adversarial hash mutation/stale review/NFC collision; reviewer bare-ID/self evidence/wrong scope/invalid dates; provenance/license/operation; malformed score policies and T/F/numeric boundaries; malformed/deep attempt append; adapter truthfulness; exact recheck/failure atomicity. No HIGH/BLOCKER before WP1.

WP1: IndexedDB transaction complete/abort/quota/duplicate/migration/corruption, reload/close-open recovery and exact schedule linkage. Memory tests do not prove browser behavior.

WP2: mounted interaction through all three families; invalid/empty no event; recommendation with reason/evidence; dashboard/progress match stored records; recover session and recheck; old attempt unchanged.

WP3: versioned import format, schema/answer/solution/mapping/provenance/license/reviewer/duplicate checks, preview and actionable item errors; always draft; no publish path.

WP4: actual viewport browser at 360x800, 390x844, wide when available; touch/keyboard/math/overflow/errors/empty; build and local serve/version instructions. No external deployment.

WP5: typed read-only context with refs/timestamps/uncertainty, no score/attempt/publication/mastery mutation.

Detailed allowlists and handoff are in docs/agent-handoffs/AGY_OPERATIONAL_90_BRIEF.md. No new dependency, backend, auth, cloud, external AI, secrets, payment, hosting or exam engine. D-017/D-020/D-024 unchanged. All 15 candidates draft; rights/privacy/scoring/dependency/deployment/destructive-data remain gates.

PO checkpoints: WP0 fail-closed publication; WP1 device save/reload/recheck; WP2 whole learning loop/evidence timeline; WP3 import preview and draft state; WP4 mobile/build; WP5 AI boundary. No checkpoint implies acceptance. Preserve IndexedDB through migration. Destructive data change is R3 and must stop for approval.
