# ADR-001: Preserve the documented stack and separate bootstrap from product delivery

- **Status:** Accepted for this bootstrap; implementation details still require dependency/runtime checks.
- **Date:** 2026-11-07
- **Decision owner:** Codex under the user's explicit instruction to preserve verified decisions; owner-gated choices remain open.

## Context

The workspace contains Phase 0 design documents, Agent Hub tooling, and a product brief, but no NEXUS application, package manifests, migrations, tests, Git metadata, or app runtime configuration. `DECISIONS.md` records React + TypeScript + Vite, FastAPI + Pydantic, PostgreSQL, and KaTeX as the owner's confirmed preference and modular monolith as a confirmed requirement. The current product brief asks for a minimal shell and independently tested contracts without implementing the whole product.

Historical Phase 0 decision D-009 says no product implementation in Phase 0. The current brief adds a distinct bootstrap step. This ADR does not rewrite the historical Phase 0 record; it authorizes only the explicitly requested bootstrap deliverables in this run.

## Approaches considered

1. **Retain the existing preferred stack, bootstrap only the frontend shell/domain contracts now.** Preserves documented decisions, permits a local mobile-first shell, and avoids inventing backend/auth/persistence choices. This is selected.
2. **Use a static HTML/JavaScript shell.** Smaller initially, but conflicts with the confirmed TypeScript/React/Vite preference and would create a throwaway frontend contract.
3. **Create the complete frontend and backend foundation now.** Could cover more architecture, but exceeds bootstrap scope and would force unresolved auth, database, privacy, content, and scoring decisions.

## Decision

Keep React + TypeScript + Vite for the minimal browser shell and pure TypeScript contracts. Keep FastAPI + Pydantic + PostgreSQL as the documented backend direction, but do not add backend code, database schema, authentication, learner persistence, or multi-tenant school/LMS features in this bootstrap. Keep subject/curriculum taxonomy configurable in domain contracts and future data; start with no claimed official content.

For the first learning slice, a configurable delayed review timestamp may be exercised as a transparent scheduling feature. This does not select a mastery algorithm and does not contradict D-017's prohibition on selecting a learning-intelligence model without evidence. D-017 remains binding for mastery estimates and recommendations exposed as claims about proficiency.

## Consequences

- Node 26.13.0 was observed in this workspace. The older reported Node 22.22.1 is not assumed to be current.
- The tested locked frontend toolchain is React/React DOM 19.3.1, Vite 8.3.6, `@vitejs/plugin-react` 6.2.1, TypeScript 5.9.3, and `tsx` 4.23.15. Vite's declared Node engine (`^20.19.0 || >=22.12.0`) includes both the observed Node 26.13.0 and the previously reported Node 22.22.1.
- npm's current `latest` TypeScript resolved to 7.0.2, whose launcher required a missing `@typescript/typescript-android-arm64` package. The official TypeScript README describes the 7.x native port as a preview; the reproducible bootstrap therefore pins the 5.9.3 JavaScript compiler. See [TypeScript Native Preview](https://github.com/microsoft/typescript/blob/f7973164a5f079a2d8b88d0fdb39347222549124/packages/typescript/README.md).
- Android shared storage also prevented executing esbuild and loading Rolldown's native binding directly from `/sdcard`. `scripts/run.mjs` copies the locked source to Termux's private temporary directory and runs npm/build tools there; this path was executed successfully.
- No `ts-fsrs` dependency is added. The product brief reports v6 requires Node >=24; even with the observed Node 26, selection still needs dependency/bundling review and is outside this bootstrap.
- Phase 0's no-code milestone remains historically documented as completed with blockers; bootstrap is tracked separately.
- App shell controls are navigation only and must clearly say not implemented.
- Backend, storage, account, content-rights, current curriculum and official exam choices remain gated.

## Revisit when

The first vertical slice proves the learning loop, or a concrete runtime/build/persistence requirement blocks the chosen stack. Any stack change requires a new ADR and review.
