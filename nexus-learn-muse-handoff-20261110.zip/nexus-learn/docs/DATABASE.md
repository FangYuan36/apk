# NEXUS LEARN — Database Design (Phase 0)

> **Status:** This is a proposed PostgreSQL design. The repository currently has no backend, PostgreSQL connection, ORM models, migration tool/files, authentication, persisted user records, or audit database. The TypeScript interfaces and frozen sample fixtures are client/test contracts only; they are not a relational schema. Alembic remains proposed, not installed or verified.

## ERD

```mermaid
erDiagram
  USER ||--o{ LEARNER_PROFILE : owns
  CURRICULUM_PROFILE ||--o{ CURRICULUM_PROFILE_VERSION : versions
  CURRICULUM_PROFILE_VERSION ||--o{ CURRICULUM_SUBJECT : includes
  SUBJECT ||--o{ CURRICULUM_SUBJECT : classified_as
  CURRICULUM_PROFILE_VERSION ||--o{ TOPIC : defines
  SUBJECT ||--o{ TOPIC : groups
  QUESTION ||--|{ QUESTION_VERSION : versions
  QUESTION_VERSION }o--|| SUBJECT : subject
  QUESTION_VERSION }o--o| TOPIC : topic
  QUESTION_VERSION ||--o{ QUESTION_SOURCE : provenance
  QUESTION_VERSION ||--o{ QUESTION_REVIEW : reviewed
  QUESTION_VERSION ||--o{ AI_GENERATION_RECORD : generated_draft
  QUESTION_VERSION ||--o{ QUESTION_VERSION_CURRICULA : compatible
  CURRICULUM_PROFILE_VERSION ||--o{ QUESTION_VERSION_CURRICULA : maps
  QUESTION_VERSION_CURRICULA ||--o{ QUESTION_VERSION_TOPICS : classifies
  TOPIC ||--o{ QUESTION_VERSION_TOPICS : maps
  EXAM_BLUEPRINT ||--|{ BLUEPRINT_VERSION : versions
  BLUEPRINT_VERSION ||--o{ BLUEPRINT_ITEM : contains
  QUESTION_VERSION ||--o{ BLUEPRINT_ITEM : selects
  USER ||--o{ ASSESSMENT_SESSION : starts
  BLUEPRINT_VERSION ||--o{ ASSESSMENT_SESSION : instantiates
  ASSESSMENT_SESSION ||--|{ SESSION_ITEM : snapshots
  BLUEPRINT_ITEM o|--o{ SESSION_ITEM : exam_source
  QUESTION_VERSION ||--o{ SESSION_ITEM : presents
  SESSION_ITEM ||--o{ ANSWER_EVENT : records
  ASSESSMENT_SESSION ||--o{ SCORE_RESULT : scores
  SCORE_RESULT ||--|{ SCORE_ITEM : details
  SESSION_ITEM ||--o{ SCORE_ITEM : scores
  ANSWER_EVENT o|--o{ SCORE_ITEM : selected_answer
  USER ||--o{ AUDIT_EVENT : acts
```

## Entity inventory

- `users`: authentication subject, status, timestamps; secrets/credentials handled by a vetted identity mechanism.
- `learner_profiles`: `user_id` owner, locale, selected curriculum profile; no cross-user sharing by default.
- `subjects`: stable subject identity, not year-specific exam rules.
- `curriculum_profiles`: stable identity for a named configurable curriculum; not assumed to be nationally authoritative.
- `curriculum_profile_versions`: immutable, effective-dated taxonomy/configuration snapshots with source and review status.
- `curriculum_subjects`, `units`, `topics`, `skills`: profile-version-scoped `Subject → Unit → Topic → Skill` taxonomy; each ID belongs to an exact curriculum version and parent. Support source/effective dates. A topic/skill key is unique within its parent and profile version.
- `questions`: stable logical identity and lifecycle metadata.
- `question_versions`: immutable content snapshot, type, normalized answer key/scoring spec, explanation, subject, exact curriculum profile version/mapping, source-version references, creation metadata, canonical content hash, publication/verification state.
- `question_version_curricula`: immutable many-to-many compatibility snapshot from a question version to curriculum profile versions.
- `question_version_topics`: optional profile-scoped topic mappings for a question version. Composite foreign keys ensure the topic belongs to the mapped profile and subject, and the profile is in the question-version compatibility set.
- `question_sources`: stable source identifier plus source version/date, issuer/publisher, locator, acquisition method/time, license/permission status and evidence, verification status and reviewer. Distinguish `official_verified` from `unverified`; verification is a claim with evidence, not a visual badge alone.
- `question_reviews`: append-only reviewer decision history tied to the exact question version and content hash for source validity/rights, curriculum mapping, answer correctness, explanation, scoring, and publication eligibility; include evidence references, reviewer identity/time and decision. Reviewer must be distinct from the generating AI principal.
- `ai_generation_records`: generation provider/model/version, prompt/template version, input references, output hash, timestamps and status, linked to an unpublished draft.
- `exam_blueprints`: stable identity and scope (year, subject, curriculum profile).
- `blueprint_versions`: immutable format/settings snapshot, version, status, source evidence, scoring policy version and content hash.
- `blueprint_items`: ordered/sectioned references to exact `question_version_id`, with points and selection metadata; no floating references to latest question.
- `assessment_sessions`: owner, kind (`exam` or `practice`), lifecycle and timestamps. Exam sessions require an exact blueprint version; practice sessions have no blueprint and record curriculum-profile version/subject/topic plus an immutable selection-policy/configuration snapshot. Store a deterministic seed when selection is randomized and the create-request idempotency key.
- `session_items`: immutable snapshot of the items presented in one session, ordered by a stable position. Each row references an exact question version. Exam rows additionally store exact `blueprint_version_id` and `blueprint_item_id`; practice rows set both to NULL and reference the session's recorded selection policy. Composite FKs ensure exam items belong to that session's pinned blueprint version.
- `answer_events`: append-only submitted/changed/cleared events referencing a `session_item`, with normalized response, event sequence/time, client idempotency key and canonical request hash. Preserve prior answer submissions; do not overwrite. Derive ownership through the session, or constrain any denormalized owner key to match its parent.
- `attempt_events` (domain concept): the learner-learning-loop name for an immutable attempt record. Reuse the assessment/session event model where appropriate; if diagnostic/practice attempts are modeled outside exam sessions, append them with exact question/skill versions, response, correctness, time, hint exposure, session ID, delayed-review marker, and grading provenance.
- `error_tags`: controlled, versioned classifications such as concept gap, procedure/formula, misread condition, calculation slip, data/graph interpretation, or time/guessing. Tags are evidence with confidence/provenance, not ground truth unless reviewed.
- `skill_mastery_snapshots`: rebuildable derived evidence for a learner/skill/curriculum version, including attempt/session counts, independent/hinted state, delayed-check evidence, policy version and uncertainty. Never overwrite raw events.
- `review_schedules`: versioned due-date policy and next review time linked to learner, skill/item and source evidence. Scheduling time does not itself establish mastery.
- `study_plan_items`: explainable next actions linked to skill/question/review evidence and a recommendation-policy version.
- `score_results`: immutable result for a specific assessment session and event cutoff, scoring algorithm version, inputs hash, totals and creation time. Re-scoring creates a new result linked to prior result/reason; never edits history.
- `score_items`: one deterministic outcome for every `session_item` in the result; includes `score_result_id`, `session_id`, `session_item_id`, and nullable `selected_answer_event_id`; unique `(score_result_id, session_item_id)`. The result/session composite FK and session-item FK require the item to belong to that result's session. `selected_answer_event_id` is nullable when no answer event applies (including never answered or cleared at cutoff); when present, it must belong to the same session item. Points/outcome follow the versioned scoring policy. Rows link to the exact question version through `session_item`.
- `audit_events`: append-only actor/action/target/time/request correlation and minimal before/after metadata; exclude credentials and minimize sensitive payloads.
- `ai_artifacts` (optional): request purpose, tool/provider/model version, input references, output, status, and provenance. Must not be an authority for score or source content.

## Content and learner-data lifecycle requirements

- Preserve chain of custody from source discovery through license/permission evidence, source version, ingestion record, curriculum-version mapping, question draft, answer/scoring verification evidence, independent review, exact content hash, immutable publication, delivery snapshot, answer/attempt events, derived analysis, and recommendation-policy version.
- A version is publishable only when its source rights, source/curriculum versions, answer evidence, reviewer decision, and content hash all refer to the same exact draft. Any edit creates a successor and requires review again.
- Keep raw learner events append-only for application roles; derived summaries are rebuildable. A personal-data deletion/anonymization policy is unresolved and must specify how identity is separated while respecting legal requirements and historical integrity before production collection.
- Define purpose, ownership, access/export, correction, retention, backup expiration, deletion/anonymization, and restore for each data class before real learner data is stored. Do not use real learner data in development or CI.
- Student age, guardian access, data residency and current legal duties require qualified review; no legal conclusion or retention period is selected by this schema.

## Implemented versus proposed

Implemented today: in-memory TypeScript question/taxonomy/attempt contracts and synthetic fixture validation. Not implemented: SQL tables, PostgreSQL, Alembic, migrations, authentication, persistence, audit storage, export/deletion, backup/recovery, or server-side ownership enforcement.

## Invariants and constraints

1. Published `question_versions` and `blueprint_versions` are immutable. Enforce in application services and with database privileges/triggers where practical; create successor versions for edits.
2. Every session item points to an exact immutable question version. Exam session items must point to blueprint items from the session's exact pinned blueprint version. Every answer event and score item references a session item from the same session; foreign keys use restrictive deletion behavior for historical records.
3. Answer events are insert-only for application roles. Corrections append a new event with sequence and actor/client idempotency key. Enforce unique `(session_id, sequence_no)` and `(session_id, client_event_id)` keys; same key and same canonical request hash returns the original result, while a different hash is rejected as an idempotency conflict.
4. Objective score is a pure deterministic function of captured blueprint/question versions, event cutoff, normalized answer, and scoring algorithm version. Store reproducibility hash and algorithm version.
5. AI identities/roles have no database permission to update or delete answer events or score results. AI can return advisory artifacts only.
6. Prefer deriving dependent-row ownership through session/profile relations. If an owner key is denormalized for indexing, composite unique keys and foreign keys must enforce it matches the parent owner. Enforce owner checks on every API access; never trust client-supplied ownership.
7. Verification state and provenance are separate from question content; unverified items cannot silently appear in an officially verified set.
8. An AI-generation record cannot satisfy reviewer identity or publish eligibility. Publication requires successful, auditable human review of source rights/provenance, answer key, explanation, and scoring configuration.

### Required relational constraints

- `assessment_sessions`: unique `(id, blueprint_version_id)`; CHECK requires a blueprint version for `kind='exam'` and NULL for `kind='practice'`.
- `blueprint_items`: unique `(blueprint_version_id, id, question_version_id)`; each row's question version is fixed.
- `session_items`: unique `(session_id, id)` and `(session_id, position)`; FK `(session_id, blueprint_version_id)` references the session's exact blueprint; exam rows require a matching `(blueprint_version_id, blueprint_item_id, question_version_id)` blueprint-item key, while practice rows have no blueprint item.
- `answer_events`: FK `(session_id, session_item_id)` references a session item; unique `(session_id, sequence_no)` and `(session_id, client_event_id)`; derive ownership through the session, avoiding a second unconstrained owner value.
- `score_items`: FK `(session_id, session_item_id)` references a session item; nullable selected event is constrained to the same session item. A result's selected event sequence cannot exceed its result cutoff.
- `question_version_curricula`: unique `(question_version_id, curriculum_profile_version_id)`; `question_version_topics` references both that compatibility row and a topic whose composite key includes the same profile version and subject.

Use `CHECK` constraints for session-kind nullability and non-negative/within-policy point bounds where the eventual score representation allows a stable rule. If a needed cross-row invariant cannot be expressed with a declarative FK/CHECK, enforce it in a transactionally safe service operation and add a PostgreSQL integration test; document the residual database limitation.

## Indexes and retention (proposal)

Index `(user_id, created_at)` for owner-scoped session/result access where owner is stored; `(session_id, sequence_no)` for event cutoff/replay; unique `(session_id, client_event_id)` for event idempotency; `(session_id, position)` for session item order; blueprint scope/version; question subject/status; curriculum/topic mappings; and audit target/time. Partitioning is not an MVP requirement. Retention and deletion/anonymization policy must be approved; legal obligations and learner age handling remain open.

## Migration strategy

Use Alembic migrations reviewed and checked into source control. Each migration is deterministic, forward-only in deployed environments, and has a tested downgrade only where lossless. Sequence: (1) identity/catalog base; (2) question/provenance/version tables; (3) blueprint/version tables; (4) sessions/events; (5) scoring; (6) progress/AI/audit additions as approved. Add constraints in stages: introduce nullable/additive fields, backfill with explicit provenance, validate, then enforce non-null/unique/FK constraints. Never rewrite historical answer or score rows as a “migration fix”; issue a new version/result with an audit reason. Test fresh install and upgrade from the previous schema on PostgreSQL. Establish backup/restore verification before production.

## Open schema decisions

Question type schema/answer normalization, scoring of unanswered/partial-credit items, collaborative editorial roles, deletion/anonymization semantics, post-submit correction/re-score policy, randomization/replay, and retention are not yet settled. Compatibility relations support multiple curriculum profiles, but their initial profile versions and mappings require owner/content decisions. Validate with sample licensed content and selected exam specifications before locking migrations.

The new product brief adds Unit/Skill taxonomy, error tags, mastery evidence, review scheduling, study-plan reasons, and personal-data export/backup expectations. These are domain requirements only; this repository has no application schema/migrations yet. Distinguish a scheduler's due time from the still-unselected mastery model in any future schema.
