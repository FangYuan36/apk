# NEXUS LEARN — Testing Strategy (Phase 0)

> **Repository status (2026-11-08):** Current scripts and evidence are listed below. Local tests/build are not CI artifacts, and no browser viewport, server/API, PostgreSQL, auth, migration, production, or accessibility audit is claimed.

## Test layers

1. **Domain unit tests:** version immutability, answer normalization, deterministic scoring, adaptation rules, curriculum/configuration resolution.
2. **Database integration tests:** PostgreSQL migrations, constraints, append-only behavior, transaction rollback/idempotency, ownership filters. SQLite alone is insufficient for PostgreSQL-specific behavior.
3. **API tests:** Pydantic validation, auth/role matrix, ownership isolation, stable error codes, version pinning, idempotency, AI unavailable behavior.
4. **Frontend component tests:** question controls, KaTeX rendering/fallback, accessible labels, answer state and save/error states.
5. **End-to-end tests:** learner onboarding → practice → submit → result/review; editor draft → verification → publish; AI outage with full core practice completion.
6. **Security tests:** IDOR/cross-user access, privilege escalation, XSS/content rendering, CSRF/auth controls, rate limits, prompt injection against tool boundary, secret/log scanning.
7. **Accessibility/responsive checks:** keyboard-only flows, screen-reader landmarks/names, zoom, narrow viewport, contrast checks and manual review.
8. **Operational checks:** fresh migration and upgrade, backup restore, health/readiness, timeout behavior and degraded AI provider.

Current local checks use Node's test runner through `tsx`: domain tests cover question provenance, `Subject → Unit → Topic → Skill` mapping, immutable attempt construction, verification-policy evidence, option validation, and recommendation inputs; mounted React/jsdom tests cover the complete in-memory learning slice and click-through navigation across all four hash areas. `npm run build` runs TypeScript `tsc --noEmit` then Vite production build. These do not verify persistence, API authorization, a real browser viewport, cross-user isolation, or CI.

## Bootstrap commands and Android shared-storage runner

- Unit contracts and server-rendered navigation check: `npm test`.
- Type check and production build: `npm run build`.
- Local Vite server: `npm run dev`.
- The `scripts/run.mjs` wrapper stages locked source/dependencies under `$PREFIX/tmp/nexus-learn-runtime` because this workspace is on Android shared storage; Vite/esbuild native files cannot execute/load there. Build output is copied back to `dist/`.
- Browser-based visual inspection was unavailable in the bootstrap environment. A server-rendered navigation test, CSS responsive media rule inspection, and live HTTP responses were checked; this does not substitute for a browser viewport/accessibility review.
- Current navigation integration test mounts `App` in jsdom, clicks Dashboard, Study, Progress and Settings, checks only the selected main area renders, checks exactly one active nav link (`aria-current="page"`), and proves the LearningSlice/sample fixture appears only in Study. This is DOM behavior evidence, not visual viewport inspection.

## Latest observed local verification

On 2026-11-08, under Termux native Android ARM64, Node v26.13.0 / npm 12.2.2 / Python 3.14.10:

- `npm test` — exit 0, 31 tests passed, 0 failed.
- `npm run build` — exit 0; TypeScript check passed, Vite 8.3.6 transformed 20 modules and emitted production assets.
- `python3 agent-hub/tests/run_all_tests.py` — exit 0, 9 tests passed.
- `git diff --check` — exit 0.
- Browser viewport, keyboard-only browser inspection, screen-reader audit and CI artifact checks — NOT RUN.

The repository runner copies source and lockfiles to `$PREFIX/tmp/nexus-learn-runtime` because shared Android storage does not support the needed native-module execution/symlink behavior. This is a local compatibility workaround, not a deployment architecture.

## Critical invariants to test

- Same exact blueprint, question versions, normalized answer events, and scoring algorithm version yield identical objective score and item outcomes.
- Updating/correcting published content creates a new version; existing session/results still resolve to the prior version.
- New answer events preserve earlier events; idempotent retry does not duplicate an event.
- AI outage, timeout, malformed response, or refusal does not block core session save, submit, deterministic scoring, or result review.
- AI cannot change answer events, scores, published questions, or blueprints, including via malicious question text.
- Two users cannot read or mutate each other's profile, session, answer, result, progress, or AI artifact.
- Official-verified and unverified content remain separately filterable and visibly labeled.
- Exam and topic-practice sessions create immutable session items; answer writes for a foreign session item or mismatched blueprint version are rejected.
- Database constraints reject an answer/session association whose denormalized owner does not match the session owner, or dependent result/item rows that cross session boundaries.
- An idempotency key retried with the same canonical request returns the original event; reuse with a different request hash returns `IDEMPOTENCY_CONFLICT`.
- Practice API projections omit answer keys before review authorization; allowed post-submit review returns only the permitted fields.
- Question publication targets an explicit version and reviewed content hash; foreign-version, stale-hash, and concurrent-draft attempts cannot publish a different version.
- Adaptive/progress behavior with zero, sparse, stale, or mixed-provenance evidence does not claim mastery and follows the approved low-evidence fallback.
- Concurrent answer and submit operations serialize to one documented event cutoff; writes after session close are rejected.
- Empty and partially answered submissions produce one score item per session item, with unanswered handling determined by the versioned scoring policy.
- Exam timer uses server time under client clock drift; reconnect restores server state and acknowledged sequence; pending writes are not shown as saved; offline answer submission remains disabled.
- AI-generated content cannot pass review/publish as the generator identity; source/license, correctness, explanation, scoring and exact content hash are required.
- Database application/AI roles cannot update/delete published versions, answer events, score results, or audit records; approved break-glass path is separately audited.

CI also records a machine-readable artifact for each required gate with command, exit code, commit SHA, and run ID. AGY or Codex narrative is not a substitute.

## Test data and environments

Use synthetic learners and authored fixtures; do not use real student records. Test both official-verified-shaped fixtures with explicit mock provenance and unverified fixtures; do not label fixtures as actual official content. CI uses pinned dependencies and disposable PostgreSQL. External AI calls are mocked in normal CI; a separately controlled contract check may be added after provider and data policy approval. No offline write behavior is part of MVP acceptance until separately approved.

## Release gates

No unverified exam rule may be enabled as official. No critical security or data-integrity test may fail. Migration upgrade/restore, core learner E2E, deterministic-score fixtures, cross-tenant negative tests, and AI-degraded flow must pass in CI before pilot. Coverage percentages are not yet set; correctness invariants matter more than a blanket percentage.

## CI command and evidence contract

Choose and pin concrete tool commands during Phase 1. CI must expose separate required jobs for lint/format, TypeScript and Python type checking, unit tests, PostgreSQL integration tests, security/dependency/secrets checks, clean and upgrade migration checks, and frontend/backend build verification. Each job records command, exit code, logs, artifact, commit SHA, and run ID. Branch protection rejects skipped or failing required jobs. Task acceptance names exact repository scripts and expected outputs once implementation files exist; until then no test is represented as run or passed. See [OPERATIONS.md](OPERATIONS.md).

AGY can report a command it ran but cannot set `CI_VERIFIED`; only CI artifacts tied to the submitted commit satisfy that state.
