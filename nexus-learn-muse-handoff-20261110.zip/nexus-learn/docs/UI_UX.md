# NEXUS LEARN — UI/UX Definition (Phase 0)

## UX goals

Mobile-first Vietnamese Grade 12 study flows; readable math notation; clear distinction between verified and unverified content; no AI dependency for core practice; preserve learner trust by showing which exam/curriculum configuration a session uses. Support keyboard and screen-reader navigation, sufficient contrast, scalable text, and reduced motion.

## Main learner flow

```text
Sign in → choose/confirm curriculum profile → dashboard → subject/topic
→ choose practice or configured exam → answer/save → submit
→ deterministic result → review item/explanation → progress
```

If an AI provider is unavailable, the hint control explains that assistance is temporarily unavailable while answers, submission, and deterministic results continue normally. Offline answer submission is not promised. Any cached offline reading behavior needs separate owner approval and must be labeled accurately.

## Frontend route map

| Route | Screen | Primary action |
|---|---|---|
| `/` | Welcome/sign-in | Authenticate |
| `/app` | Dashboard | Resume or choose subject |
| `/app/study` | Subject and topic picker | Configure practice |
| `/app/practice/:sessionId` | Question session | Save answer / navigate / submit |
| `/app/results/:sessionId` | Results and review | Inspect score and item evidence |
| `/app/progress` | Progress | Select subject/topic and review trends |
| `/app/settings` | Profile/curriculum | Update own study settings |
| `/editor/questions` | Editorial queue | Review source and version |
| `/editor/blueprints` | Blueprint editor | Review year/subject configuration |
| `/admin/*` | Admin tools | Restricted catalog/account/audit actions |

## Initial wireframes (structure only)

### Learner dashboard

```text
┌ NEXUS LEARN                 Profile ┐
│ Curriculum: [configured profile ▾]  │
│ Continue studying                   │
│ [Mathematics] [Physics] [Geography] │
│ Recent sessions      Topic progress │
│ Exam configuration: year / subject  │
└─────────────────────────────────────┘
```

### Practice session

```text
┌ Subject · topic       Q 3 / N   Save ┐
│ Question text / KaTeX-rendered math  │
│ [answer controls appropriate to type]│
│ Previous             Next / Submit  │
│ [Optional hint]  Verified/source tag │
└─────────────────────────────────────┘
```

### Results review

```text
┌ Result · blueprint version · date ┐
│ Score / max · scoring version      │
│ Item list: outcome + earned points │
│ Select item → submitted answer     │
│ correct answer · explanation · source status │
│ Progress link     Practice again   │
└───────────────────────────────────┘
```

### Editor question review

```text
┌ Draft/version · subject/topic ┐
│ Content preview (KaTeX)        │
│ Source + license + evidence    │
│ Verification status / reviewer │
│ [Request changes] [Publish version] │
└────────────────────────────────┘
```

## Interaction and content rules

- Always disclose curriculum profile and exact blueprint version for configured exams.
- Label unverified items distinctly; do not imply official status through color alone.
- Keep question stem, answer controls, navigation, and save/submit status usable on narrow screens.
- Confirm destructive or irreversible editorial actions; version corrections instead of editing published content.
- Explain score calculation with per-item deterministic results; distinguish AI explanation from official answer/source.
- KaTeX content must have text alternatives where practical and safe fallback when rendering fails.
- Do not show private data in shareable URLs or analytics events.

## Open UX questions

When evidence is absent or sparse, the progress screen states that there is not enough data to estimate mastery and offers neutral practice. It must not invent a proficiency level or confidence value.

Learner onboarding, low-bandwidth/offline scope, visual identity, exact question interaction types, accessibility conformance target, guardian/teacher roles, and content density for small screens require owner/user research. Wireframes define hierarchy, not final visual design.
