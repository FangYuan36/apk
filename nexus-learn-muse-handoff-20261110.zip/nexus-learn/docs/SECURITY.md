# NEXUS LEARN — Security and Privacy Model (Phase 0)

> **Status:** This is a threat model/design target. The current repository is a client-side React SPA with synthetic fixtures and in-memory state. There is no API, authentication, database, server authorization, secret manager, production deployment, or CI security gate to claim as implemented.

## Assets and boundaries

Assets: credentials/session tokens, learner identity/profile, answer history, scores/progress, unpublished/paid/licensed questions, source/license evidence, editorial permissions, AI prompts/responses, audit records, and database backups. Trust boundaries: browser ↔ API; API ↔ PostgreSQL; API ↔ optional AI provider; editor/admin ↔ privileged API; deployment/backup operators ↔ production data.

Grade 12 learners may be minors. Apply data minimization, purpose limitation, least privilege, retention/deletion controls, and synthetic-only development fixtures. Legal obligations must be checked against current primary legal texts and official guidance at implementation/deployment time by a qualified reviewer; this document makes no compliance conclusion. Detailed requirements are in [PRIVACY.md](PRIVACY.md).

## Threat model

| Threat | Example | Required controls / verification |
|---|---|---|
| Cross-tenant access (IDOR) | Guess another learner's session UUID | Derive owner from auth principal; scoped queries; deny-by-default; negative two-user API tests |
| Minor privacy/access misuse | Collect excess student identifiers or expose records to staff/guardians without an approved purpose | Data minimization, access/export/delete policy, guardian access off by default, retention schedule, current-law review before live data |
| Credential/session theft | XSS or leaked token | Vetted auth, secure cookies or documented token storage, TLS, CSP, CSRF protections as applicable, rate limits |
| Unauthorized editorial publish | Learner/admin compromise publishes false official content | Separate roles, least privilege, reviewer evidence, audited publication, MFA policy decision |
| Historical tampering | Change answer or score after submission | Append-only application permissions, immutable versions/results, restricted DB role, integrity checks and audit |
| AI prompt injection/tool abuse | Question text asks model to invoke write tool | Allowlisted typed tools, server-side authorization, no arbitrary SQL/shell, read-only context; AI cannot mutate historical records |
| AI Web Agent confused deputy | Prompt asks an allowed tool to act on another learner/resource | Every tool binds to authenticated principal, validates resource/version ownership, has minimal scope and emits audit evidence; sensitive actions require per-action confirmation |
| AI data exposure | Send PII or licensed content to provider | Data minimization, provider review/contract, explicit policy, redaction, retention controls, opt-in decision |
| False provenance | Unverified item presented as official | Evidence-backed status, distinct source records, editorial review, UI labels and query filters |
| AI question self-certification | Generator publishes its own false answer or unlicensed item | Generation principal is draft-only; separate human reviewer verifies exact hash, source rights, answer and scoring; immutable review audit |
| API abuse/DoS | Automated exam/AI calls | Per-user/IP quotas, payload limits, timeouts, bounded concurrency, cost controls |
| Supply-chain compromise | Vulnerable package/build artifact | Dependency justification, lockfiles, vulnerability review, secret scanning, reproducible build policy |
| Backup/log disclosure | Logs contain answers or tokens | Minimize logs, redact secrets, restrict access, retention and restore controls |

## Security boundaries and rules

- Every user-owned request is authorized on the server using authenticated ownership; UI hiding is not security.
- Learner practice projections omit answer keys, hidden rubrics and unreleased explanations. Review fields are returned only after submission and authorization under the approved session review policy.
- Content/editor/admin permissions are separate from learner permissions. Privileged changes require audit attribution.
- Database credentials follow least privilege. AI orchestration has no direct general-purpose database credentials and no write capability to immutable historical tables.
- Published content and exam submissions are protected by database-enforced immutability: app/AI roles receive no UPDATE/DELETE grants for historical records; immutable published-version triggers/constraints reject mutation. Privileged break-glass changes require separate credentials, reason, and audit trail.
- Secrets are held in a managed secret store/environment injection, never source control or logs.
- Validate and bound all request bodies, question content rendering, uploads (if introduced), and AI outputs. Render untrusted text safely; KaTeX configuration must avoid unsafe HTML features.
- Use TLS, secure headers, CSRF defenses appropriate to auth scheme, rate limits, dependency review, and encrypted backups as deployment requirements.
- Audit important profile, editorial, blueprint, answer, score, permission, and admin writes with actor and correlation ID. Avoid logging full PII or credentials.

## AI control policy

AI is optional and advisory. Its tools are explicit typed operations such as `get_question_context` or `get_topic_summary`; each enforces ownership and version status. There is no tool to edit a question, blueprint, answer event, score, or audit row. AI-generated explanations/hints are stored separately with model/provider/version and source references, labeled as generated, and may be unavailable. Deterministic scoring is independent of model output.

AI context must use the same learner-safe projection and ownership checks as the requesting endpoint. Answer keys, hidden scoring fields, and other learners' data are excluded unless a specific, approved post-submit explanation use case authorizes the minimum required fields.

Keep separate tool registries and authorization scopes for: (1) AI Tutor content/context reads; (2) AI Learning Analysis reads of the requesting learner's evidence; and (3) AI Web Agent typed application operations. The Web Agent cannot access raw databases, secrets, arbitrary URLs, shell commands, or unrestricted browser control. Validate tool input and output, enforce owner/resource authorization inside the server, log actor/tool/target/outcome without prompt secrets or unnecessary PII, and require a fresh user confirmation for sensitive or irreversible actions. No provider, model, or data-sharing path is currently implemented or selected.

AI output must pass typed schema, bounds, reference/ownership checks, and safe-render validation before storage or display. Apply per-user/provider rate limits, concurrency caps, token/output caps, daily cost budgets and a hard kill switch. Secrets must use a managed secret store or protected runtime injection; never place them in source, prompts, client bundles, or logs.

## Privacy decisions requiring approval

Learner age/consent assumptions, data residency, AI-provider sharing, analytics, retention, account deletion/anonymization, parental/teacher access, and incident response ownership are unresolved. Obtain qualified privacy/legal review before collecting real learner data or using real exam content. This document is a design threat model, not a legal compliance determination.

## Security acceptance gates

Before pilot: cross-user isolation tests, role matrix tests, immutable-history tests, AI tool allowlist tests, secret/log review, dependency scan, backup restore exercise, and documented incident/contact path. See [TESTING.md](TESTING.md).
