# NEXUS LEARN Bootstrap Implementation Plan

> Historical plan for the 2026-11-07 bootstrap. Its AGY-primary-developer and initial empty-repository assumptions are superseded by the 2026-11-08 governance contract and current repository state. Keep this as history; use `PLANS.md` and `docs/AGENT_WORKFLOW.md` for current work/status.

> **For agentic workers:** Execute this plan inline, task by task. Keep each task within its listed file scope and record evidence before marking it complete.

**Goal:** Reconcile the existing Phase 0 project decisions, establish a traceable bootstrap baseline, create a minimal runnable mobile-first app shell with tested learning contracts, and queue one bounded AGY vertical slice.

**Architecture:** Preserve the documented React + TypeScript + Vite frontend and the proposed FastAPI + Pydantic + PostgreSQL modular-monolith backend boundary. This bootstrap implements only the frontend shell and pure TypeScript domain contracts; it introduces no backend, persistence, authentication, real question content, or official exam claims.

**Tech Stack:** React, TypeScript, Vite, Node.js, Node's test runner via `tsx`; existing Python Agent Hub is retained unchanged except for a single scoped task prompt.

**Spec:** `NEXUS_LEARN_PRODUCT_BRIEF_AND_CODEX_PROMPT.md`, especially sections 6–10.

## Global Constraints

- Preserve React/TypeScript/Vite, FastAPI/Pydantic, PostgreSQL, modular monolith; do not introduce a replacement stack.
- Do not modify `../anti`, open `job1.zip`, or claim Git history exists for this workspace.
- Keep official curriculum, 2027 exam format, scoring policy, privacy/legal requirements, and mastery thresholds unresolved unless verified by approved evidence.
- Keep question and attempt history immutable in the contracts; derived mastery must expose evidence and uncertainty.
- The bootstrap shell contains explicit not-implemented labels and no fake saves, scores, or learner data.
- No PASS claim without an executed command and recorded exit status/output.

## Review Focus

- Missing package installation or unavailable network: report bootstrap commands as BLOCKED and preserve the attempted output.
- Empty, malformed, or unverified content: reject it as verified content and never infer official status.
- Zero or sparse attempts: return an insufficient-evidence state instead of mastery.
- Mobile-width navigation and keyboard interaction: keep controls semantic, reachable, and responsive.
- Attempt correction/retry: append an event; never overwrite an earlier attempt.

## File Map

- `AGENTS.md`: repository-wide rules and AGY/Codex boundaries.
- `PROJECT_STATUS.md`, `TASKS.md`, `PLANS.md`: current milestone, task queue, and phase order.
- `AGY_REPORT.md`, `CODEX_REVIEW.md`: actual delegation and review evidence.
- `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/TESTING.md`: canonical architecture/data/test references; no duplicate root versions.
- `docs/TRACEABILITY.md`, `DECISIONS.md`: preserve prior IDs and add explicit reconciliation rows/decisions.
- `docs/research/COMPETITOR_RESEARCH.md`, `docs/adr/ADR-001-stack-and-bootstrap-boundaries.md`: dated research and architecture decision.
- `src/domain/contracts.ts`, `src/domain/contracts.test.ts`: pure learning contracts and unit tests.
- `src/App.tsx`, `src/main.tsx`, `src/styles.css`, `index.html`: minimal responsive shell.
- `agent-hub/rqcodex.txt`: one exact AGY task; no other task is queued.

### Task 1: Reconcile project controls and architecture evidence

**Files:** Create/update the documentation files listed above except source files and `agent-hub/rqcodex.txt`.

- [ ] Record Repository Recon, verified facts, blockers, previous Phase 0 decisions, and requirement-to-evidence mapping.
- [ ] Add an ADR that retains the existing stack and separates bootstrap code from the historical Phase 0 no-code milestone.
- [ ] Add dated competitor evidence using only the already-provided research brief; label observations, claims, and hypotheses distinctly.
- [ ] Re-read changed docs and verify internal links, IDs, and status vocabulary.

### Task 2: Define and test pure learning contracts

**Files:** Create `src/domain/contracts.test.ts`, then `src/domain/contracts.ts`; modify `package.json` and `tsconfig.json` only as required for test execution.

- [ ] Add failing tests for valid/invalid question metadata, immutable attempt event shape, skill mapping, insufficient evidence at zero/sparse attempts, and recommendation reasons.
- [ ] Run `npm test` and confirm failures are caused by missing contract exports.
- [ ] Implement typed validation and deterministic status/recommendation inputs with no persistence or AI dependency.
- [ ] Run `npm test`; record output and exit code.

### Task 3: Build the minimal responsive shell

**Files:** Create `src/App.tsx`, `src/main.tsx`, `src/styles.css`, `index.html`; modify Vite/package configuration only as required.

- [ ] Implement semantic navigation among Dashboard, Study, Progress, and Settings placeholder sections.
- [ ] Label every section as not implemented; do not show fake learner data or pretend persistence exists.
- [ ] Add mobile-first styling and keyboard-visible focus states.
- [ ] Run `npm run build` and start Vite; verify the local HTTP response and route/navigation markup at a narrow viewport using available tooling.

### Task 4: Queue one AGY vertical slice and close bootstrap evidence

**Files:** Create/update `agent-hub/rqcodex.txt`, `TASKS.md`, `AGY_REPORT.md`, `CODEX_REVIEW.md`, `PROJECT_STATUS.md`, `docs/TRACEABILITY.md`.

- [ ] Create exactly one task with file allowlist/denylist, dependencies, test commands, acceptance evidence, rollback notes, and explicit test-only content labeling if no verified source is available.
- [ ] Validate task parsing through Agent Hub; report queued/claimed/running exactly as observed.
- [ ] Run the complete available test/build checks and record exact commands, exit codes, output, changed files, limitations, and next action.

## Execution Notes

- The workspace has no `.git`; do not claim branch, commit, or clean working-tree evidence. The adjacent `../anti` Git checkout is a separate TX statistical project and is out of scope.
- Node 26.13.0 and Python 3.14.10 were observed. No app manifest or installed app dependencies existed at recon time.
- The user explicitly requested execution beyond planning; this plan is executed inline.
