# NEXUS LEARN — Product Requirements (Phase 0)

> This PRD retains the Phase 0 product direction and proposals. It is not a feature-completion report. Current repository evidence and disposition of approved versus open scope are maintained in `PROJECT_STATUS.md` and `TRACEABILITY.md`.

## Purpose

NEXUS LEARN helps Vietnamese Grade 12 learners prepare for the THPT graduation examination, initially targeting 2027. It supports Mathematics, Physics, and Geography first. The system must accommodate additional subjects, curricula, and textbooks without binding content or scoring logic to one textbook. The product is personal-first; account and multi-user scope remains gated, and school/LMS tenancy is outside the MVP.

## Current product direction (2026-11-07 brief)

Position the product as a **personal-first learning coach**, not just a question bank or a general chatbot. The intended loop is **Diagnose → Classify error → Explain missing step → Targeted practice → Delayed recheck → Update skill evidence**. Every suggested next action should expose a short reason. Progress should state its evidence and uncertainty; one correct answer is not mastery.

Start with Vietnamese high-school learners and the Grade-12 experience. Initial subject packs are Mathematics, Physics, and Geography; Literature follows only after the learning loop is proven. Keep `Subject → Unit → Topic → Skill` mappings configurable and versioned by curriculum. Do not build school/LMS multi-tenancy in the MVP; keep domain ownership boundaries clean so multi-user support can be introduced later.

The bootstrap shell is navigation-only and is not a product flow. The first complete vertical slice should cover one topic/skill with reviewed content. If no verified content has been approved, use synthetic fixtures labelled `sample/test-only`; do not represent them as official or verified.

**Status reconciliation:** The repository now contains a locally tested synthetic, in-memory learning slice, which is narrower than the reviewed-content MVP direction above. D-024 permits its threshold only as a sample verification gate; it does not establish actual mastery/proficiency. General mastery language and policy remain unresolved under D-017. Backend, persistence, verified content, official curriculum alignment, analytics and AI features remain unimplemented.

## Confirmed requirements

- Adaptive exam preparation, usable on responsive web/PWA clients. With no or insufficient evidence, the product must avoid unsupported proficiency claims and offer a neutral next-practice option; numeric thresholds and recommendation policy require owner approval.
- Initial preferred stack: React, TypeScript, Vite, FastAPI, PostgreSQL, Pydantic, KaTeX.
- Use a modular monolith.
- Curriculum profile and 2027 examination rules are unresolved. Never present an assumed format or curriculum as official.
- Question versions and exam blueprint versions are immutable; answer events are append-only; objective scoring is deterministic.
- AI may assist through controlled application tools, but cannot rewrite source questions, answer history, or historical scores.
- Officially verified and unverified questions must be distinguishable.
- Examination format is configurable by year and subject.
- AI outage must not prevent core study and exam flows.
- Learner-owned personal data must be isolated; important writes must be auditable.
- Each module needs explicit acceptance criteria.
- Mobile-first responsive web experience must remain usable on Android browsers and desktop.
- Preserve raw attempts as immutable events; derived skill mastery may be recalculated and must explain its supporting evidence.
- A delayed review schedule may use transparent configurable intervals; it is not a mastery algorithm and must not imply guaranteed learning outcomes.

## Proposed MVP boundary

Deliver a personal-first learner experience, versioned `Subject → Unit → Topic → Skill` taxonomy, curated/reviewed question items, short diagnostics/practice, immutable attempt history, basic error tags and explanations, targeted recommendations, a delayed recheck queue, and progress evidence. Keep the shared engine configurable for Mathematics, Physics, and Geography, while validating one complete skill-level journey first. Account isolation, API and database controls remain necessary when persistence/accounts are implemented, but full school/LMS tenancy is out of scope. Begin with objective question types only when their answer normalization and scoring rules are explicit. Do not claim alignment to an official 2027 structure until an authoritative source is selected and reviewed.

Out of scope for Phase 0: production application code, importing unlicensed content, a specific curriculum selection, subjective/essay scoring, payments, social features, and a guarantee of official exam coverage.

## Product principles

1. Provenance and verification status travel with each question version.
2. Published content and blueprints are immutable; corrections create new versions.
3. A learner's submitted answer is an event, not a mutable field.
4. Scores are reproducible from the blueprint version, question versions, answer events, and scoring algorithm version.
5. AI suggestions are advisory artifacts with provenance and explicit acceptance; deterministic app rules own scoring.
6. Core practice remains available when an AI provider is unavailable.
7. AI-authored questions remain unpublished drafts until source, answer correctness, explanation, and scoring are independently verified by an authorized human reviewer.
8. Progress labels distinguish no data, early learning, inconsistent evidence, and repeated independent success across sessions including a delayed recheck; thresholds remain configurable and unapproved.
9. Explain the evidence behind each recommendation. Do not equate question volume or a same-session correct answer with durable skill evidence.

## Success measures to define with owner

Candidate measures: completed practice sessions, return rate, topic-level practice coverage, answer-event/scoring consistency, and successful online core flows while AI is unavailable. Offline behavior is a separate open decision; no offline answer-write success is claimed for the MVP. Targets and collection/retention rules are not yet approved. Avoid optimizing for raw study time alone.

For zero or sparse evidence, progress screens state that there is not enough practice data to estimate mastery and may offer neutral practice or a diagnostic set. They must not present a confidence/proficiency estimate until an owner-approved evidence policy exists. Thresholds, recency weighting, and mixed-source handling remain open decisions.

## User roles and main jobs

- Learner: configure study context, practice, review explanations, see progress, request optional hints.
- Content editor/reviewer: create drafts, record source/provenance, verify, publish a new immutable question version.
- Administrator: manage accounts, permissions, curriculum/catalog configuration, and audit review.

Role model and editorial workflow are proposals requiring owner approval.

## Open product decisions

- Which curriculum profiles, textbooks, and authoritative source documents are in scope first?
- Which 2027 examination formats and question types are verified per subject, and by whom?
- What are the MVP question types, adaptive-policy goals, and acceptable explanation depth?
- Are accounts single-device, family/teacher-managed, or self-service? What age/consent assumptions apply?
- What languages are required for UI, content, and explanations?
- What measurable launch thresholds, content volume, and service objectives define success?
- Which content licenses and provenance evidence may be stored and displayed?
- Which question/source verification roles and independence requirements apply to AI-generated content?
- Which learning-intelligence method is supported by actual event data and labels, and what sample evidence is sufficient?
- What exam timer, recovery, network interruption, and concurrent traffic objectives apply?
- What is the minimum approved evidence for “Đã vững,” and how will independent attempts, hints, sessions, and delayed checks be weighted?
- What export/backup behavior is required for personal data before any multi-user migration?

## Module acceptance criteria

Detailed, testable criteria are listed in [ACCEPTANCE.md](ACCEPTANCE.md). No module is approved for implementation solely because its endpoint exists.

Requirement-to-evidence mapping is maintained in [TRACEABILITY.md](TRACEABILITY.md). Development task approval, CI evidence, and separate reviews are specified in [AGENT_WORKFLOW.md](AGENT_WORKFLOW.md).
