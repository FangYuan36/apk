# AI Governance and Learning-Intelligence Evaluation

> **Current status:** AI Governance below is a target/control framework. No AI provider, model, AI Tutor, Learning Analysis service, AI Web Agent, AI tool API, or provider data-sharing path is implemented or selected in the current repository.

## Separate AI capabilities

- **AI Tutor:** retrieve only approved content and minimum session context; return bounded explanations/hints with source references and explicit uncertainty. Output is advisory and cannot grade or mutate records.
- **AI Learning Analysis:** read only the requesting learner's authorized attempts/evidence; describe evidence and policy behind recommendations. Do not claim mastery until data and a model have been evaluated and the owner approves a policy.
- **AI Web Agent:** call typed, per-tool allowlisted application APIs only. Each tool validates inputs, authenticates/authorizes the principal and target, audits the action, applies limits, and requires explicit confirmation for sensitive operations. No arbitrary SQL/shell, secrets, unrestricted browser/network, or direct database access.

These are separate purposes and authorization boundaries even if a future implementation shares model infrastructure. Provider/model, region, retention, cost limits, data sharing, and opt-in/consent are owner-gated R2 decisions. Provider outage must not block core practice or exam flows.

## Permission and content controls

AI tools are typed, allowlisted, purpose-limited, owner-authorized, rate-limited and cost-bounded. No arbitrary SQL/shell, direct database credentials, cross-tenant retrieval, or tools to change questions, blueprints, answer events, scores, verification state, audit events, or permissions. Treat model output as untrusted: validate schema, bounds, references, ownership, and safe-rendering before display/storage. Question text, user answers, sources and retrieved content are data, never instructions to the tool runtime.

AI-generated questions are drafts only. The generation principal cannot review, assert correctness, verify rights/provenance, or publish. An authorized human reviewer checks exact immutable content hash, source rights/provenance, answer key, explanation, topic mapping and scoring. Record generation and review events. AI may not approve its own answer.

## Learning-intelligence candidates (none selected)

| Candidate | Inputs required | Reliability / cold-start | Explainability | Compute cost | Validation |
|---|---|---|---|---|---|
| Transparent heuristic baseline | Item/topic tags, correctness, timestamps, attempts, explicit recency/coverage policy | Can abstain safely with sparse data; noisy tags and item difficulty confound results | High if evidence and rule are shown | Low | Held-out future outcomes, stability, educator review, coverage/abstention rate |
| BKT | Ordered correct/incorrect attempts per defensible skill tag; repeated observations to estimate transition/slip/guess parameters | Needs repeated skill observations; cold-start until enough evidence; tag errors bias mastery | Moderate; state/probabilities can be surfaced with caveats | Low–moderate per learner/skill | Held-out prediction/calibration, cohort checks, sensitivity and drift review |
| IRT | Large learner-item response matrix, quality items, stable item calibration, anchor/equating plan and suitable response model | Weak with sparse/new learners/items absent priors/anchors; population calibration required | Moderate; ability/item parameters and uncertainty need careful explanation | Moderate calibration, low serving cost | Fit diagnostics, held-out prediction, calibration, differential item functioning/fairness review, cohort stability |
| FSRS-style scheduler | Repeated recall/retention outcomes or ratings, review timestamps/intervals, item-specific history | Optimizes review timing, not exam proficiency; cold-start for new learner/item | Moderate via due-time/retrievability concepts | Low serving, data-dependent fit | Retention at fixed horizons and workload versus baseline |

No numeric sample-size threshold is declared without inspecting real, consented data. Establish thresholds from power/precision, calibration, subgroup, and stability evidence, then obtain owner approval. FSRS is a scheduler, not a substitute for a subject mastery or exam-score model.

## Evaluation protocol

Inventory event counts, labels, missingness, provenance/curriculum mix, timestamps, consent and retention limits using de-identified or synthetic data. Define outcomes with educators/owner. Prevent leakage with chronological and learner-separated evaluation where appropriate. Compare candidates with the heuristic/abstain baseline for predictive quality, calibration, cold-start coverage, interpretability, subgroup performance, drift, compute/cost and educator usefulness. Run offline evaluation and shadow mode before exposure. Promote only with approved thresholds, version traceability, monitoring and rollback.

## Prompt injection and output validation

Keep fixed policies outside retrieved content; use typed arguments and allowlist checks after model output; authorize each tool server-side; exclude secrets and other-tenant data; enforce output size/schema/reference validation. Refusals, malformed responses, timeout, or provider outage do not block non-AI study flows.
