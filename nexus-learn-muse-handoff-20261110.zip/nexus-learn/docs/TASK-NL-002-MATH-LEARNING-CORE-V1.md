# TASK-NL-002 — Math Learning Core V1 Campaign Contract

**Status:** Planning complete; WP1 is ready for Product Owner handoff to AGY. No implementation is claimed or accepted.

**Canonical contract:** This document owns the campaign sequence, interfaces, package scopes, acceptance, owner gates, handoff prompts, and verification checklist. `TASKS.md` is the queue/index only.

**Repository baseline:** `/data/data/com.termux/files/home/nexus-learn`, branch `main`, base `b502fa7120cadd460c0e224d67fc5b1d8ac43691` (preflight 2026-11-08).

**Planning writer:** Codex. **Implementation writer per package:** AGY, when the Product Owner transfers that package prompt. **Independent technical verifier:** Codex after AGY reports the writer pause. **Product acceptance:** Product Owner only.

## Campaign outcome

Turn the current React/TypeScript/Vite prototype into one useful, local-first Grade 12 mathematics practice journey backed by explicit versioned domain records, three structured question forms, deterministic configurable scoring, a traceable content review pipeline, shared math rendering, durable local learning history, and contracts that can later map to the existing FastAPI/PostgreSQL target.

This campaign implements a browser client and local storage only. It does not implement a backend, accounts, cloud sync, school tenancy, exam submission, an AI tutor, or official exam alignment. A synthetic curriculum profile may use the topic “Ứng dụng đạo hàm để khảo sát và vẽ đồ thị hàm số” as a planning label; it must be marked as an unverified sample mapping until an owner-selected curriculum source and qualified review exist.

## Repository reality and guardrails

Read-only preflight reconfirmed the required `~/nexus-learn` repository, `main`, and the reported HEAD. The working tree contains existing modified files and untracked TASK-NL-001 implementation files. They are user work and remain untouched by this planning change. Current app evidence is one React shell with a synthetic in-memory `LearningSlice`, four sample questions, basic legacy contracts, tests, and no browser viewport inspection. No structured question-family contract, scorer/policy version, full content publication gate, math renderer, IndexedDB repository, or real content pipeline exists.

Do not reset, clean, checkout, stage, commit, or overwrite existing changes. Do not read or modify secrets, `../anti/**`, or `job1.zip`. Keep Phase 0 reports and historical decisions intact. Do not make an owner decision by turning a `PROPOSED` policy into a confirmed default.

### Task-local role exception

The Product Owner explicitly authorizes this campaign with the sequence Codex plans → AGY implements the assigned package → Codex verifies while AGY pauses → Product Owner accepts. This authorization is limited to TASK-NL-002 and its current package allowlists; it is not a permanent governance revision. It overrides D-025, `docs/AGENT_WORKFLOW.md`, and installed/repository AGY plugin wording only for the named implementation role in this campaign. D-025 remains unchanged. Product Owner remains the only product acceptance authority. AGY must use this contract as the task-specific authority and stop for any out-of-scope change or R2/R3 gate. Codex does not claim to have launched or controlled AGY TUI.

Single writer applies at all times: AGY writes during one assigned WP; on handoff AGY pauses; Codex reads/reviews/tests without editing AGY-owned source scope; any repair returns to AGY under an explicit scoped request, followed by another pause and Codex verification. Codex-owned acceptance files below are never in an AGY allowlist.

## Architecture and shared contracts

Stay within React 19 + TypeScript 5.9 + Vite 8, modular monolith boundaries, content-as-code, immutable version records, append-only attempt events, deterministic scoring, and the documented FastAPI/Pydantic/PostgreSQL future boundary. No package or platform changes are implied by this plan.

Use stable IDs separately from versions. A question version must carry a canonical content hash and the exact curriculum, skill mappings, source/license references, review state, solution version, and question-family body. Edits create a successor version. Publish records bind an exact version ID and hash; they do not mutate the version. `AttemptEvent` carries `questionVersionRef: { questionId, version, contentHash }` and `scoringPolicyVersionRef: { id, version }`, the submitted response, result, timestamp, and per-part evidence. WP1 exports `createAttemptEvent(input)` and `appendAttemptEvent(history, event)`. The constructor freezes nested payload values; append rejects a duplicate event ID and leaves earlier values untouched. Diagnostic distractor tags are hypotheses tied to a response, never mastery conclusions.

Use these family names exactly: `MCQ_SINGLE`, `TRUE_FALSE_CLUSTER`, `SHORT_NUMERIC`. `TRUE_FALSE_CLUSTER` has exactly four independently answerable statements; each statement can map to multiple skills, and evidence is recorded per statement and mapping. Numeric answers are decimal strings at the domain boundary. Normalization and tolerance are configuration, not UI constants. Blank and malformed responses are distinguishable. A failed validation must not append an attempt.

Local progress is a rebuildable projection of append-only attempts and versioned policy inputs. A recommendation with no relevant evidence returns an explicit abstention/insufficient-evidence result. A diagnostic hypothesis is not a verified error or mastery label. Local persistence is not cloud backup.

The later FastAPI/PostgreSQL mapping should be direct: TypeScript domain records map to Pydantic schemas and normalized relational rows; immutable IDs/hashes map to unique constraints; append-only events map to insert-only event tables; publication and attempt writes are transactions; browser IndexedDB remains an adapter behind a repository interface. This campaign does not create those server components.

## Dependency graph and execution order

```mermaid
flowchart LR
  WP1[WP1 Domain and content contract] --> WP2[WP2 Scoring and validation]
  WP2 --> WP3[WP3 Math renderer and learning UI]
  WP1 --> WP4[WP4 IndexedDB persistence]
  WP3 --> WP5[WP5 Integration and content pilot]
  WP4 --> WP5
  WP2 --> WP5
```

Run one package at a time in the serialized sequence WP1 → WP2 → WP3 → WP4 → WP5. Actual dependency edges are shown above: WP4 needs the WP1 event/session contracts, not the scorer; WP2 and WP4 remain serialized only to honor the single-writer and Codex pause/review gate. WP1 freezes types and invariants. WP2 implements pure scoring, publication eligibility, and validation against those types. WP3 consumes the stable domain/scoring interface. WP5 composes the proven pieces and adds the single pilot. Do not begin a later WP until Codex has recorded its technical review result and any acceptance-impacting repairs are closed. Package prompts and evidence can be prepared while an audit is pending, but AGY does not begin another implementation until Codex closes the current review.

## Work package contracts

### WP1 — Math Domain & Content Contract

**Outcome:** typed records and runtime-safe constructors/guards for curriculum versions, Subject/Topic/Skill, Question/QuestionVersion, QuestionPart/Statement, SolutionVersion, QuestionSkillMapping, SourceAsset, LicenseRecord, ReviewRecord, PublicationRecord, AttemptEvent, and ScoringPolicyVersion. Version identities are stable and explicit. Published version records cannot be edited through domain operations. This WP does not select a grading policy or add UI/storage.

**Allowed:** `src/domain/math/**` (new; types, constructors, guards, and focused tests only); `AGY_REPORT.md` for evidence only.  
**Forbidden:** all other files, including legacy `src/domain/contracts.ts` and its tests, app/UI/CSS, all `src/content/**`, `package.json`, lockfiles, scripts, `TASKS.md`, Codex-protected `src/acceptance/task-nl-002/**`, `../anti/**`, `job1.zip`, secrets, backend/auth/cloud/deployment paths. Every file in the allowlist must remain within domain contracts and tests; no dependency changes.

**Acceptance:**

1. Identity and version are separate; question successor v2 does not alter v1 or its canonical hash.
2. Question-family type guards require exactly four MCQ options and exactly four T/F statements; statement skill mappings and evidence retain statement IDs.
3. Numeric answer keys are finite canonical decimal strings; policy precision/tolerance is represented as versioned data, not a global constant.
4. Taxonomy and mappings reject missing or cross-version IDs.
5. AttemptEvent requires question-version and scoring-policy-version references; nested evidence and payload are immutable values; append operation rejects duplicate event IDs and preserves earlier event values.
6. Distractor diagnosis can only be represented as a hypothesis/evidence record with source response/version; it cannot directly set a skill mastery status.
7. Source, license, review, publication, and solution are distinct records with IDs/version/hash references; no `verified`/`published` state can be inferred from a source label alone.
8. Tests cover version successor, attempt snapshot pinning, statement-to-skill evidence, append-only semantics, and absent/cross-version references.

**Codex check:** inspect exact diff and declared model boundaries; compare protected WP1 invariant list in this document; run focused math-domain tests, full `npm test`, `npm run build`, and `git diff --check`; confirm no forbidden file or package changed. Codex records exact output, limitations, and finding severity before WP2.

### WP2 — Scoring & Content Validation

**Outcome:** pure functions operating on WP1 records. Required exports: `scoreQuestionVersion(questionVersion, response, scoringPolicyVersion)` and `validatePublication(questionVersion, context)`. `ScoreResult` is `{ status: 'scored' | 'empty' | 'invalid', totalPoints: integer, maxPoints: integer, parts: [{ partId, status, points, maxPoints, skillIds }] }`; invalid/empty parts have zero points, and a wholly empty response has status `empty`. Scoring does not write events. Integration decides whether a valid score can become an AttemptEvent. `validatePublication` receives context with `now`, taxonomy IDs, referenced source assets, licenses, solutions, reviews, existing publication records, and existing canonical content hashes; it returns `{ eligible, errors }` with stable error codes. It never publishes or mutates a version.

**Allowed:** `src/domain/math/scoring/**`; `src/domain/math/content-validation/**`; focused tests adjacent to those modules; `AGY_REPORT.md` for evidence only.  
**Forbidden:** WP1 type changes without a Codex scope revision, `src/domain/contracts.ts`, UI/CSS, persistence, pilot content, `TASKS.md`, Codex acceptance tests, package/lockfiles/dependencies, scripts, `../anti/**`, `job1.zip`, secrets, backend/auth/cloud/deployment paths.

**Acceptance:**

1. MCQ: exactly one valid selected option; correct gives configured points, incorrect/empty gives configured outcomes; unknown option is invalid and cannot be recorded.
2. T/F: scores each of four statements independently, preserves each statement’s skill mappings/evidence, and applies the supplied policy including partial credit and empty parts.
3. Numeric: accepts configured decimal separators for signed decimals; rejects malformed/mixed separators, grouping, non-finite, and exponent forms unless explicitly configured. It must not silently reinterpret a thousands-grouped value. Comparison uses decimal-safe arithmetic. Boundary tests just below, equal to, and just above tolerance prove no false positive. Absolute/relative tolerances and max points come from the exact policy version.
4. Empty, invalid, and scored are distinct statuses. Invalid response produces no scoreable attempt event.
5. Replaying an old attempt with its pinned question and policy versions returns the same score after a successor question/policy exists.
6. Publication rejects missing taxonomy/mapping, answer/solution, source provenance, rights eligibility, independent human review of exact content hash, and an already-published duplicate. An expired license is ineligible. Only an exact eligible draft can be published by a separate application operation; this WP exposes eligibility only.
7. Duplicate detection at minimum catches exact normalized-content hash duplicates within the bank. Semantic similarity is not claimed or implemented.
8. `SAMPLE / TEST ONLY` and original-candidate content are not `OFFICIAL`; reference format profiles have year/source/status and can be superseded.
9. Recommendation logic either has explicit event evidence or abstains; diagnostic hypothesis alone cannot generate mastery/proficiency status.

**Scoring gate:** a general grading rule is an R2 decision. The implementation must accept versioned policy inputs. A proposed `sample-practice-v1` can be used in tests labelled proposed only. Do not ship user-facing score/progress claims until the Product Owner approves the exact partial-credit behavior, empty-answer behavior, numeric normalization, and tolerances. Never label an unapproved profile official.  
**Codex check:** run protected scorer/publication acceptance suite plus focused tests, full suite, build, diff/scope check. Test each edge below against exact returned status and part evidence; inspect for float comparison, mutation, missing license/review, and unpinned-policy defects.

### WP3 — Math Rendering & Learning UI

**Outcome:** one shared `MathRenderer` interface for inline/display expression content with accessible fallback, and a functional Study journey consuming structured question versions for all three families. Include fraction, radical, derivative, integral, limit, sign table, variation table, long vertical formulas, syntax error fallback, keyboard controls, and loading/empty/invalid/success states. Preserve evidence and policy labels. Do not fabricate Dashboard/Progress/Settings data.

**Allowed:** `src/components/math/**`; `src/features/learning-core/**`; focused tests under those new paths; `AGY_REPORT.md` for evidence only. No app mounting in this WP; WP5 owns `src/App.tsx` integration.  
**Forbidden:** domain contracts/scoring, IndexedDB adapter, `src/App.tsx`, other existing shell sections, content pilot, `TASKS.md`, Codex acceptance tests, package/lockfiles unless a written R2 approval is included, scripts, `../anti/**`, `job1.zip`, secrets, backend/auth/cloud paths.

**Acceptance:**

1. Shared renderer distinguishes inline/display input, has non-crashing readable fallback for invalid TeX, and never treats untrusted TeX as raw HTML.
2. UI presents MCQ, four-item T/F, and short numeric response using domain records and scoring results; answer evidence references exact part/question versions.
3. Long expressions and tables have horizontal containment/scroll behavior that does not widen the page; controls remain usable at narrow portrait width.
4. Screen-reader/keyboard labels expose question type, statement index, math fallback, status and errors.
5. Unit/DOM tests cover semantics and states, but jsdom is not evidence of layout. An actual Android device or real browser engine at a documented narrow viewport is required before claiming responsive acceptance. If unavailable, report `NOT RUN` and leave the mobile visual checkpoint open.
6. Existing `#progress` and `#settings` remain explicitly unfinished until real data/preferences are implemented.

**Dependency gate (R2):** Preferred candidate is `katex@0.19.1` runtime dependency, MIT, with KaTeX CSS/fonts bundled locally (no CDN request). It supports major browsers per upstream docs; the repo currently runs Node `v26.13.0`, but browser compatibility must be tested on target Android browser. Exact Vite gzip delta is not measured yet and must be reported from the actual production build before acceptance. Upstream docs/package pages: [KaTeX browser docs](https://katex.org/docs/browser.html), [KaTeX API/error behavior](https://katex.org/docs/api), [npm version/license](https://www.npmjs.com/package/katex). This is a proposed version only; do not install until owner approval is recorded. No SymPy dependency is proposed; deterministic arithmetic and human math review suffice for this pilot.  
**Codex check:** inspect React boundary and sanitizer assumptions, run tests/build, inspect built bundle size, then perform a real device/browser viewport review or record it `NOT RUN`. Codex must not substitute jsdom/SSR screenshots for the required layout check.

### WP4 — IndexedDB Persistence

**Outcome:** typed `PersistenceRepository` boundary and native IndexedDB adapter for practice sessions, immutable AttemptEvents, review schedule, rebuildable progress projection, and schema version. Include atomic writes, duplicate-event prevention, migration, quota/blocked/error paths, and user-initiated local deletion. No network or server backup.  
**Allowed:** `src/domain/persistence/**`; `src/infrastructure/persistence/indexeddb/**`; focused persistence tests in those paths; `AGY_REPORT.md` for evidence only.  
**Forbidden:** UI integration, domain/scoring contract changes, content pilot, package/runtime dependencies, authentication, server/cloud sync, backup, multi-device, offline exam submission, `TASKS.md`, Codex acceptance tests, scripts, `../anti/**`, `job1.zip`, secrets.

**Acceptance:**

1. Repository interface can later be implemented by a server adapter without exposing IndexedDB types to domain/use-case callers.
2. A session plus event plus updated projection/schedule is atomic: inject failure at each write point and verify no partial visible state.
3. Duplicate event IDs are idempotently rejected or return the existing immutable event per the local repository contract; never create a second event.
4. Close/reopen and app refresh restore the same session and attempts; projection can be rebuilt from events and stored policy/version references.
5. Schema upgrade from the prior test schema preserves records; failed upgrade is surfaced without deleting the prior database.
6. Quota, blocked upgrade, unavailable IndexedDB, transaction abort, and deletion failure produce visible repository errors and do not claim save success.
7. Local deletion is explicitly scoped and confirmed by the user; tests use synthetic data only. Documentation/UI state that local device storage is not cloud backup and can be lost with browser/device data removal.
8. Real browser/device persistence/reload check is required before PASS; fake IndexedDB only verifies API-level transaction logic.

**Dependency gate (R2):** Prefer native IndexedDB for runtime (zero runtime dependency). Candidate test-only dependency is `fake-indexeddb@6.2.7`, Apache-2.0, 0 dependencies, Node `>=18` (compatible by declared engine range with current Node `26.13.0`), no shipped runtime bundle impact; exact dev install footprint should be reported from lockfile/install. Source: [npm package and license/engine](https://www.npmjs.com/package/fake-indexeddb), [upstream package metadata](https://github.com/dumbmatter/fakeIndexedDB/blob/master/package.json). Product Owner approval is required before adding it. Do not add Dexie or another adapter library absent a new R2 review.  
**Codex check:** inspect transaction boundaries and migration sequencing; run persistence suite with forced aborts and the full suite/build; conduct reload test on a real browser/device or leave the gate `NOT RUN`.

### WP5 — Integration & Content Pilot

**Outcome:** mount the core journey in Study using WP1–4; connect versioned content, scorer, persistence, schedule, and evidence-based recommendations. Add roughly 15–20 original candidate questions for the derivative-application topic, all three question types represented. Quality overrides count. Each item has a worked solution, deterministic answer evidence, skill mapping, source/original designation, license record, and lifecycle status. Without qualified human review, keep each item `draft` or `in_review`; never set `PUBLISHED` by AGY or Codex self-review. No real learner data or official claim.

**Allowed:** `src/content/pilots/derivative-applications/**`; integration-only changes in `src/features/learning-core/**`; Study mounting in `src/App.tsx`; only new `.learning-core-*` styles in `src/styles.css`; integration tests for the pilot; `AGY_REPORT.md` for evidence only.  
**Forbidden:** WP1/WP2 contracts and Codex acceptance suite, IndexedDB adapter, unrelated App sections, `src/main.tsx`, `index.html`, package/lockfiles unless separately approved R2, scripts, all `reports/phase0/**`, `../anti/**`, `job1.zip`, secrets, auth/backend/cloud/deployment, invented user data.

**Acceptance:**

1. One end-to-end Study journey can load a versioned pilot item, accept/validate a response, score deterministically, append a pinned AttemptEvent, persist/reload it, display its per-part evidence, and derive the next recommendation from evidence.
2. All three formats work through actual user controls; invalid response creates no event; reload restores event history; duplicate event does not double-count.
3. Recommendation abstains with an explicit insufficient-evidence reason for no/relevant sparse events. Diagnostic hypotheses remain hypotheses and do not become mastery.
4. Dataset has a target of 15–20 original candidate items, all three forms, complete answer/solution/mapping/provenance/license metadata, and duplicate-ID/hash validation. Fewer is acceptable when unresolved quality issues are documented.
5. Exact content hash must have qualified independent answer/scoring review before `approved`; rights evidence must be eligible before publication. Until a named qualified human reviewer and rights evidence exist, status stays `draft`/`in_review` and there are zero PUBLISHED records.
6. No false Grade-12 official mapping or official exam profile. 2025 exam format is reference-only, versioned and source-linked.
7. Mobile check is on real browser/device and reports viewport, browser/version, cases rendered, horizontal overflow, and interaction findings.
8. App never fabricates Progress/Dashboard/Settings values. Storage limitation and delete behavior are visible and truthful.

**Codex check:** run independent acceptance suite, full tests/build, content validation against every pilot item, inspect actual diff and status records, manually follow Study journey, verify no content publication absent evidence, and inspect narrow phone browser. Record remaining defects and owner decisions; do not mark accepted.

## Codex-protected acceptance suite and invariants

Codex prepares these before WP1; AGY may read and run them but may not edit/delete/weaken them. The independent scorer/publication executable is `src/acceptance/task-nl-002/scoring.acceptance.test.ts`; it imports only the published domain API in `src/domain/math/index.ts`. Required API names are fixed in this contract. The acceptance suite is outside all AGY allowlists. The test file skips by default so WP1 and the existing full suite remain runnable; after WP2, run `NEXUS_NL002_ACCEPTANCE=1 npm test` to enable it through the repository's existing staged runtime. WP1/WP2 supporting tests do not replace this suite.

The verifier also checks these cross-layer invariants explicitly:

| Case | Required invariant/evidence |
|---|---|
| Question edited after learner attempt | v1 hash/body remains unchanged; successor v2 gets a new version/hash; old event references v1 and policy v1; old replay result is unchanged. |
| Attempt points to the right version | Event stores `questionVersionRef` and `scoringPolicyVersionRef`, not a mutable “latest” pointer. |
| T/F skills differ by statement | Four part results remain distinct; each part has its own skill evidence even when a statement maps to multiple skills. |
| Decimal comma/period and negatives | Both configured decimal separators parse to the same exact value; `-1,25` and `-1.25` test equal; mixed/grouped malformed input is invalid, never guessed. |
| Tolerance boundary | Exact decimal comparison checks expected value, `tol - epsilon`, `tol`, `tol + epsilon`, very large/small values, zero, negative expected value, malformed and non-finite input. |
| Unapproved question | Missing/mismatched review of exact content hash cannot be publication-eligible. |
| Missing/expired license | Unknown/missing rights or `validThrough < publicationTime` blocks eligibility; synthetic/original designation is explicit and is not mislabeled licensed/official. |
| IndexedDB partial failure | Abort each transaction step; no half session/event/projection visible. Real adapter test is separate from mocked/fake tests. |
| Reload | New repository instance after database close/reopen reads identical immutable events and reconstructs projection; prove on a browser/device. |
| No recommendation evidence | Return abstention/insufficient evidence with no mastery assertion. |
| Distractor hypothesis | A distractor selection records a hypothesis linked to the item/version and response; it cannot set verified misconception/mastery state. |
| Mobile formulas | Real browser/device at a narrow portrait viewport shows long formulas/tables without body-level horizontal overflow; math fallback remains readable. |

The protected suite must assert, at minimum: MCQ correct/wrong/empty/unknown option; T/F all-correct, partial, empty and per-statement evidence; numeric signed comma/dot values, mixed separators, invalid values, and tolerance boundary; policy version changes do not alter old replay; publication blocked by missing/mismatched review, missing/expired license, bad mappings and duplicate exact content; and eligible publication only when all exact-hash evidence is valid. If a concrete public API defect prevents running the suite, Codex records a finding and updates this contract before any protected-test change; AGY never changes the tests to fit an implementation.

## Official format source and current disposition

The Ministry’s Quality Management Agency describes the 2025 reference format as using multiple choice, four-statement true/false clusters, and short-answer questions; its published format page reports 34 Math items and 90 minutes, while explicitly saying item counts and related details may be adjusted. Source: [Cục Quản lý chất lượng — Cấu trúc định dạng đề thi tốt nghiệp THPT từ năm 2025](https://vqa.moet.gov.vn/vi/news/thong-bao/cau-truc-dinh-dang-de-thi-tot-nghiep-thpt-tu-nam-2025-74.html). This is evidence for a dated reference profile, not proof of an eternal format or a 2026/2027 policy. Record profile `vn-thpt-2025-reference`, source URL, issuer, access date, source/version date and `reference_only` status; no `OFFICIAL` product claim without current-year confirmation and human review.

## Dependency approvals and unresolved owner decisions

R0/R1 implementation within this approved scope is authorized; do not ask the owner to reconfirm. The following are actual gates:

1. **R2, before WP3 install:** approve or reject the proposed exact `katex@0.19.1` runtime dependency (MIT). Must bundle locally, no CDN; report the measured gzip bundle delta and target Android browser test. No package install before approval.
2. **R2, before WP4 install:** approve or reject exact `fake-indexeddb@6.2.7` dev dependency (Apache-2.0; Node engine `>=18`; zero runtime bundle impact and zero package dependencies). Record lockfile install footprint. No install before approval.
3. **R2, before scored pilot results:** approve a versioned sample practice scoring profile: T/F partial-credit and empty-answer behavior, decimal-separator normalization, absolute/relative tolerance, and numeric display/precision. Candidate values may be proposed with rationale in WP2, but stay `PROPOSED` until the owner chooses. No unapproved scoring profile may be called official or used to make learning ability claims.
4. **R2 content gate before publication:** select curriculum/source profile and identify qualified independent mathematics reviewer(s), rights evidence/permission, and exact review responsibility. Until supplied, WP5 may create original draft candidates but not publish or claim official alignment.
5. **R2 only if needed for personal-data collection:** this campaign uses synthetic development data. Do not collect real learner data; retention, privacy/age/consent and deployment remain their existing owner gates.

No SymPy is required for the planned features; it would add a Python dependency and runtime/tooling surface without replacing a human answer review. Do not add it. If a task discovers a specific symbolic-verification need, stop that sub-scope and propose version/license/runtime/install/size/compatibility and a less costly alternative for R2 review.

## AGY handoff prompts

Copy only the current package prompt to AGY TUI. AGY reports evidence and pauses; it does not call `done`, stage, commit, alter acceptance, or begin another WP. The user transfers the prompt; Codex does not claim to launch the TUI.

### Copy prompt — WP1

```text
TASK-NL-002 / WP1 — MATH DOMAIN & CONTENT CONTRACT

Role: You are AGY, the sole implementation writer for this assigned WP under the Product Owner’s task-local authorization. Codex is planner and later verifier; Product Owner alone accepts. This exact WP exception permits you to implement; it does not change D-025 or grant authority outside this allowlist. Read repository AGENTS.md, this complete campaign contract, DECISIONS.md (especially D-003–D-005, D-012–D-025), docs/ARCHITECTURE.md, docs/DATABASE.md, docs/API.md, docs/TESTING.md, docs/ACCEPTANCE.md, and docs/AGENT_WORKFLOW.md. Do not rerun historical audits.

Current base: b502fa7120cadd460c0e224d67fc5b1d8ac43691 on main. The working tree contains valuable uncommitted TASK-NL-001 changes. Preserve them. Do not reset, clean, checkout, stage, commit, or overwrite. Do not read secrets or touch ../anti/** or job1.zip. Before editing, record pwd, branch, HEAD and status; if any differs from the contract or a forbidden file is dirty in your proposed edit, stop and report.

Goal: implement only typed math domain/content contracts and focused tests. Create `src/domain/math/**`; update `AGY_REPORT.md` only for evidence. No UI, scoring algorithm, persistence, pilot content, dependency, or global governance edits. `src/acceptance/task-nl-002/**` is Codex-protected: read/run only, never edit. Exact allowlist and WP1 acceptance are in “WP1 — Math Domain & Content Contract” above; forbidden scope is binding.

Model separate CurriculumVersion, Subject/Topic/Skill, stable Question identity and immutable QuestionVersion, QuestionPart/Statement, SolutionVersion, QuestionSkillMapping, SourceAsset, LicenseRecord, ReviewRecord, PublicationRecord, append-only AttemptEvent, and ScoringPolicyVersion. Use exact family tags MCQ_SINGLE, TRUE_FALSE_CLUSTER, SHORT_NUMERIC. Require four options for MCQ and exactly four independent statements for T/F. Store statement-level skill mapping/evidence. Numeric canonical value is a decimal string and tolerance/precision belongs to policy data. Keep question ID separate from version ID/hash. Attempt pins exact question and scoring policy versions. Represent distractor diagnosis only as a hypothesis tied to response/version; no mastery conclusions.

Keep source/rights/review/publication separate. Domain contracts must make missing evidence observable, not assume `published` from a label. Published content is immutable; correction means successor version. Runtime guards/constructors should reject missing/cross-version references, duplicate IDs, invalid types and mutable event payloads. Do not edit old `src/domain/contracts.ts` or `LearningSlice`.

Tests first where applicable. Add tests for version successor, old attempt pinning, T/F part-to-skill evidence, append-only/duplicate event behavior, taxonomy/version references, and non-promotion of diagnostic hypotheses. Do not edit protected Codex tests to make your tests pass. Run focused WP1 tests, `npm test`, `npm run build`, and `git diff --check`; report exact command, exit and concise output. Check changed-file list and confirm no stage/commit.

At handoff: stop writing. Report exact files, diff summary, tests/output, limitation, unrun checks, rollback path, and any blocking contract ambiguity in AGY_REPORT.md and your message. Do not mark task accepted or start WP2. Codex will inspect your diff and independently rerun checks.
```

### Copy prompt — WP2

```text
TASK-NL-002 / WP2 — SCORING & CONTENT VALIDATION

Start only after Codex reports WP1 verified and Product Owner has explicitly approved any R2 decision required for your exact behavior. You are the single writer for this WP under task-local authorization. Read the campaign contract, WP1 contracts, repository AGENTS.md, DECISIONS.md, and relevant architecture/testing docs. Preserve all existing dirty and untracked work; no reset/clean/checkout/stage/commit. Do not touch secrets, ../anti/**, job1.zip, or Codex acceptance tests.

Allowed only: `src/domain/math/scoring/**`, `src/domain/math/content-validation/**`, focused tests adjacent to those folders, and `AGY_REPORT.md` evidence. WP1 types are frozen. Any necessary type/API change is a stop-and-request-Codex-scope-revision condition. No UI, persistence, package/dependency, pilot content, governance, or other files.

Implement pure functions with the exact API `scoreQuestionVersion(questionVersion, response, scoringPolicyVersion)` and `validatePublication(questionVersion, context)`. No DOM/storage/network. Score returns explicit scored/empty/invalid status, integer total/max points, and per-part results. Invalid input cannot create an AttemptEvent. Policy ID/version is always an explicit input. MCQ single, four independently scored T/F statements with partial credit, and short numeric must work. Numeric parsing accepts only configured decimal separators and signed decimal values; reject non-finite, ambiguous/mixed, grouped, malformed and exponent forms unless explicitly configured. Use decimal-safe comparison. Test tolerance below/equal/above boundaries. Do not embed global scoring values in UI or domain constants.

Publication validation checks schema, unique/versioned IDs, taxonomy and statement mappings, answer/solution, provenance, exact content hash, human review, rights/license eligibility at `publishedAt`, and exact duplicate content. Expired/missing/unknown license or stale review hash blocks publication. Validator is pure and never changes status. Exact hash duplicate detection is required; do not claim semantic duplicate detection. A 2025 profile is reference-only and year-versioned.

`sample-practice-v1` and its values remain PROPOSED until Product Owner approves the R2 scoring semantics listed in the campaign. If that approval is absent, implement policy-parameterized functions and synthetic test policies only; do not show scored pilot results or claim official policy. No SymPy.

Add supporting unit tests but do not edit or weaken `src/acceptance/task-nl-002/**`. Run focused tests, `NEXUS_NL002_ACCEPTANCE=1 npm test`, `npm run build`, and `git diff --check`; report exact results. At handoff pause all writes; report files, tests, limitations, rollback, and R2 status. Do not start WP3.
```

### Copy prompt — WP3

```text
TASK-NL-002 / WP3 — SHARED MATH RENDERER & LEARNING UI

Start only after Codex verifies WP2. One writer: AGY. Read this campaign contract and relevant app/domain/UI docs. Preserve all existing dirty/untracked work. Do not reset, clean, checkout, stage, commit, or touch secrets, ../anti/**, job1.zip, or Codex acceptance tests.

Before installing KaTeX, require the Product Owner’s recorded R2 approval for exact `katex@0.19.1` runtime dependency. If approval is absent, stop only the KaTeX implementation step; continue independent text/table UI and report the renderer dependency gate. No other dependency is allowed. If approved, bundle package/CSS/fonts locally, use no CDN, include error fallback, and record exact Vite gzip asset delta and browser compatibility. Do not claim Android compatibility without actual device/browser evidence.

Allowed: `src/components/math/**`, `src/features/learning-core/**`, focused tests in those new paths, and `AGY_REPORT.md` evidence. No `src/App.tsx` mounting (WP5 owns it), no CSS outside this feature, no domain/scoring/persistence/content pilot/package files absent the exact approval. See WP3 allow/deny list in the contract.

Create shared `MathRenderer` for inline/display expressions and accessible invalid-TeX fallback. Cover fractions, radicals, derivatives, integrals, limits, sign tables, variation tables, long portrait formulas. Render content as text/TeX through the renderer, never raw HTML. Make the Study question view support MCQ_SINGLE, four-part TRUE_FALSE_CLUSTER, and SHORT_NUMERIC using WP1/WP2 data and scoring response contracts. Include loading, empty, invalid, explanation, and success states; accessible labels, keyboard use, visible validation. Keep progress/dashboard/settings without real data as explicit unfinished screens.

Automated DOM/SSR tests do not prove layout. Inspect a real browser/device at a narrow portrait viewport and record viewport, browser/version, formula/table cases, overflow and interaction results. If unavailable, state NOT RUN and leave the visual acceptance open. Do not claim responsive PASS from jsdom.

Run focused UI/renderer tests, `npm test`, `npm run build`, `git diff --check`; report exact output and bundle size. At handoff pause writes, provide changed files, result and limitations; do not start WP4.
```

### Copy prompt — WP4

```text
TASK-NL-002 / WP4 — INDEXEDDB PERSISTENCE

Start only after Codex verifies WP2. One writer: AGY. Read the campaign contract and repository architecture/database/privacy/testing docs. Preserve existing dirty/untracked changes; do not reset, clean, checkout, stage, commit, inspect secrets, or touch ../anti/**, job1.zip, or Codex acceptance tests.

Before adding `fake-indexeddb`, require Product Owner’s recorded R2 approval for exact `fake-indexeddb@6.2.7` devDependency. It is test-only, Apache-2.0, zero package dependencies, Node >=18; current observed Node is 26.13.0. Record actual install/lockfile footprint. If approval is absent, continue interface/adapter work and use available non-dependency tests, but mark transaction test gate BLOCKED pending approval. No Dexie or runtime dependency without separate R2 approval.

Allowed only: `src/domain/persistence/**`, `src/infrastructure/persistence/indexeddb/**`, focused tests in those new paths, `AGY_REPORT.md` evidence. No UI, domain/scoring changes, content, App, package files absent exact approval, backend/cloud/auth/backup/multidevice/exam submission, protected Codex tests, or other paths.

Create repository boundary and native IndexedDB adapter for practice sessions, append-only AttemptEvents, review schedule, rebuildable progress projection, and schema version. Keep IndexedDB types behind adapter. Use transactions for session/event/projection/schedule writes; reject duplicate event IDs without mutating prior data. Implement ordered schema upgrade and preserve existing records. Surface quota, blocked, unavailable API, abort, upgrade, and delete errors. Add explicit, user-confirmed local-only delete API, tested with synthetic records. Documentation/UI text must state local storage is not cloud backup.

Tests must force abort after each transaction step, duplicate writes, migration from previous schema, and rebuild projection from event history/pinned policy. fake-indexeddb does not prove cross-refresh durability or browser quota behavior. Verify close/reopen + page reload on a real browser/device and record details; if unavailable, NOT RUN. Do not claim actual persistence acceptance from in-memory mocks.

Run focused persistence tests, `npm test`, `npm run build`, `git diff --check`; report exact commands/results, actual browser/device check, limitations and rollback. Stop writes at handoff and do not start WP5.
```

### Copy prompt — WP5

```text
TASK-NL-002 / WP5 — INTEGRATION & ORIGINAL CONTENT PILOT

Start only after Codex verifies WP3 and WP4. AGY is the single writer under the campaign-local authorization. Read this entire campaign, verified WP1–4 diffs/reports, repository AGENTS.md and relevant docs. Preserve all dirty/untracked changes. Do not reset, clean, checkout, stage, commit, touch secrets, ../anti/**, job1.zip, or Codex acceptance tests.

Allowed only: `src/content/pilots/derivative-applications/**`; integration changes in `src/features/learning-core/**`; Study mount changes in `src/App.tsx`; new `.learning-core-*` styles in `src/styles.css`; integration tests for this pilot; `AGY_REPORT.md` evidence. Do not modify domain/scoring contracts, IndexedDB adapter, unrelated navigation, src/main.tsx, index.html, package/lockfiles, scripts, Phase 0 records, or acceptance suite. Ask Codex for a written scope revision if required work escapes this list.

Integrate structured question versions, pure scoring/publication validator, shared MathRenderer/UI, and PersistenceRepository. Deliver one real Study journey: load item → answer → validate → deterministic score → append exact-version/policy event → persist → reload → show per-part evidence/explanation → recommend from actual events or abstain. Invalid answers must create no attempt; retries must preserve earlier events.

Create about 15–20 ORIGINAL candidate questions for “Ứng dụng đạo hàm để khảo sát và vẽ đồ thị hàm số,” with all three forms represented and full IDs/versions, solutions, answer evidence, skill mappings, provenance, rights status and review state. The number is a target, not a quality override. Do not copy third-party material. Until qualified independent mathematics review of the exact content hash and rights evidence exist, every item remains draft/in_review and there are zero PUBLISHED records. Do not label any candidate verified/official or use it to claim ability. No recommendation evidence means explicit abstention; distractor diagnosis remains a hypothesis.

Do not fabricate Dashboard/Progress/Settings data. Report local-only persistence and deletion clearly. Perform actual phone/browser flow and formula overflow check; record viewport/browser and issues, or NOT RUN.

Run Codex-protected acceptance suite with `NEXUS_NL002_ACCEPTANCE=1 npm test`, content validator on all pilot items, `npm run build`, and `git diff --check`. Report exact output, changed-file allowlist, content provenance, publication count, manual browser results, limitations and rollback. Pause at handoff. Codex independently reviews diff and reruns checks; do not claim acceptance.
```

## Codex verification checklist and Product Owner checkpoints

After every AGY handoff: confirm AGY has paused; read changed-file list and diff directly; check untracked files and forbidden paths; compare the original campaign requirement and protected acceptance suite; run the named focused and full commands independently; inspect test edge cases and output; verify no stage/commit; record PASS / PASS WITH LIMITATIONS / FAILED / BLOCKED / NOT RUN precisely. Findings affecting acceptance return to the same AGY WP for a bounded repair while Codex remains read-only. Only after Codex clears that WP may the next package start. No WP status is Product Owner acceptance.

| Checkpoint | Show the Product Owner | Decision/exit condition |
|---|---|---|
| After WP1 | Versioned model, sample JSON example, statement evidence trace, invariant tests | Confirm domain representation is understandable; WP1 code has Codex verification. |
| After WP2 | Three scored examples including partial T/F, empty/invalid numeric boundaries, publication rejection examples | Owner resolves R2 sample scoring semantics before any scored pilot results. |
| After WP3 | Live Study screens with math rendering at narrow phone viewport; fallback and error states | Owner approves KaTeX R2 before install; visual inspection evidence required. |
| After WP4 | Persisted session survives reload, event history view, local deletion confirmation, failure injection report | Owner approves fake-indexeddb R2 before install; no cloud backup claim. |
| After WP5 | Complete Study journey, candidate set and review state, reviewer/source/license evidence, mobile check, Codex findings | Qualified review and rights gates decide publication; Product Owner alone decides campaign acceptance. |

## Risks and rollback

Main risks: wrong scoring/decimal semantics become sticky; a sample mapping is mistaken for official Grade 12; math content/answer is wrong; attempt history loses its pinned version; IndexedDB transaction exposes partial data; users mistake local data for backup; phone formulas overflow. Controls are versioned policy inputs, explicit candidate labels, exact-hash independent review, Codex-owned invariants, transaction fault tests, and real device/browser checks.

Rollback is package-scoped only after Codex identifies the exact package diff and confirms no user data is being deleted. Do not use `git checkout`, `reset`, `clean`, broad revert, or remove another package’s files. WP1/WP2 source changes can be reverted only by a reviewed inverse patch preserving earlier uncommitted edits. WP3 can be disabled by reverting only its new feature paths/imports. WP4 must not delete a real browser database as a code rollback; retain compatible schema/read path or require a separately approved R3 migration/deletion plan. WP5 content can be unpublished by status/route gating; do not erase attempt events. No rollback action is performed as part of this planning task.

## Planning evidence and limitations

Preflight was read-only. Current runtime observed: Node `v26.13.0`, npm `12.2.2`, Python `3.14.10`; no Chromium/Chrome binary or relevant browser automation package was found in the inspected repository environment. Current package pins are listed in DECISIONS.md and package.json. Existing tests use `node:test` through `tsx` and the repository runtime wrapper; jsdom is already a dev dependency from TASK-NL-001. No tests/build were run for this planning-only change. Browser layout and real IndexedDB reload remain future evidence requirements.

The official-format source and current dependency metadata were checked during planning on 2026-11-08. Upstream/npm metadata can change; recheck versions, license, Node/browser compatibility, security advisories and size at each R2 approval/installation. A source citation or test report is not a substitute for content rights or mathematics review.
