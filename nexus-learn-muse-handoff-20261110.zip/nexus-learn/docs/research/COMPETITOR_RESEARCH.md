# NEXUS LEARN — Competitor Research Evidence

**Evidence date:** 2026-11-07<br>
**Source of this snapshot:** `NEXUS_LEARN_PRODUCT_BRIEF_AND_CODEX_PROMPT.md` section 2. The source brief records inspections/reports dated 2026-11-07. This file transfers that evidence; it does not claim a fresh live-site inspection in this bootstrap.

## DOLTHPT

| Item | Evidence class | What the supplied research brief reports | Source |
|---|---|---|---|
| Subject collections and test listings | Observed public site | Mathematics, Physics, Geography and other subject collections; Grade-12 Math listing by school/year/exam period with question count and engagement metadata. | [DOLTHPT](https://dolthpt.vn/), [Grade-12 Mathematics listing](https://dolthpt.vn/tot-nghiep-thpt/toan?practice-type=GRADE_12), [Physics listing](https://dolthpt.vn/tot-nghiep-thpt/ly?practice-type=GRADE_12), [Geography listing](https://dolthpt.vn/tot-nghiep-thpt/dia) |
| Sample paper workflow | Observed sample detail page, according to supplied browser inspection | A 22-question sample with multiple choice, true/false and short-answer sections, answers/explanations, PDF, practice and answer-view actions; sample content was publicly readable without login. | [Sample paper](https://dolthpt.vn/pdf-de-tham-khao-so-12-mon-toan-giua-ky-2-lop-12-truong-thpt-minh-ha-nam-hoc-2024-2025-co-dap-an) |
| Progress and personalization | Vendor claim | Public practice-management route/marketing claims progress tracking, strengths/weakness analysis, and personalized exercise recommendations. Do not treat this as proof of an independently measured outcome. | [DOLTHPT](https://dolthpt.vn/) |
| Launch inventory | Dated press report | Tuoi Tre reported a 10,000-test library at launch in March 2026. This is a dated press report, not an audited live inventory. | [Tuoi Tre News, 2026-03-22](https://news.tuoitre.vn/vietnams-english-center-chain-launches-free-online-exam-prep-platform-for-national-high-school-tests-103260320183029381.htm) |

## Other familiar alternatives

- HOCMAI app listing describes courses and practice tests: [Google Play listing](https://play.google.com/store/apps/details?id=com.hocmai&hl=en_US).
- Tuyensinh247 offers online lessons, teacher-led courses and Grade-12 exam-preparation routes: [Tuyensinh247](https://tuyensinh247.com/).

These observations establish familiar lessons and test-preparation patterns. They do not establish that competitors lack a particular diagnostic or retention feature. Do not claim NEXUS is unique without inspecting and testing the same workflow.

## Product implications and hypotheses

- **Observed market context:** question banks, explanations, practice, progress claims and personalization claims already exist.
- **Hypothesis to validate:** NEXUS may earn trust through traceable error diagnosis, teaching the missing step, reasoned next-task selection, and delayed evidence of retained skill.
- **Research next step:** run comparable task-based sessions with students on the same topic and inspect exact competitor flows before making uniqueness claims.

## Citation/use boundary

Do not copy or scrape competitor questions. Reuse these links as research evidence only. Curriculum and exam decisions must use current official references, source versions, issuer, and review status recorded independently of competitor research.
