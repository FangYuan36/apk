# NEXUS LEARN — Module Acceptance Criteria (Phase 0)

These criteria are the proposed minimum gates for Phase 1+; product owner must approve unresolved policy inputs before the affected module is built.

## Status and evidence rules

These module criteria are targets, not evidence of implementation. Record each criterion as **VERIFIED** (fresh test/inspection evidence), **REPORTED** (agent/prior-report statement not freshly verified), or **NOT RUN**. Local verification does not equal `CI_VERIFIED`, independent audit, or Product Owner acceptance. For UI work, browser viewport inspection is required when the environment permits; otherwise report `NOT RUN` and keep the limitation visible. Current implemented scope is limited to a React/Vite client shell, synthetic sample learning slice, local domain contracts, and tests; see [TRACEABILITY.md](TRACEABILITY.md).

| Module | Acceptance criteria |
|---|---|
| Identity & tenancy | Authenticated principal is server-derived; every learner-owned read/write is owner-scoped; two-user tests prove zero cross-access; role denials are consistent and audited where privileged. |
| Curriculum/catalog | At least one profile can be configured without code changes; year/subject/profile associations are explicit; unknown or unverified format is not displayed as official; catalog changes have provenance and audit. |
| Question bank | Draft/published states are explicit; published version cannot be edited/deleted through app role; correction creates successor; publication addresses the exact version ID and reviewed content hash; source/license/verification evidence is queryable; unverified is distinguishable in API and UI; learner practice projections omit answer keys until review is authorized. |
| Blueprint | Blueprint is scoped by exam year, subject and curriculum profile; published versions are immutable; each item references exact question version; source evidence and version hash are present. |
| Assessment | Exam and topic-practice sessions can be created through explicit request kinds; each captures immutable session items with exact question versions; exam items bind to the pinned blueprint; answer submissions append events tied to session items; identical idempotent retry is safe and conflicting key reuse fails; submit serializes with answers and rejects writes after close. |
| Objective scoring | Scoring is deterministic and versioned; one score item exists per session item, including unanswered items; item and total results cite exact inputs/cutoff; repeated scoring for same cutoff is identical; AI/provider availability cannot affect outcome. Point values and partial-credit rules require approved scoring policy. |
| Progress/adaptation | Derived view is reproducible from source events/results; no source history is rewritten; recommendations identify inputs/policy and are usable without AI; zero/sparse/stale evidence produces an explicit insufficient-data state without unsupported mastery claims. |
| AI assistance | Only allowlisted typed tools; all reads authorize owner and version; no mutation path to original content, answers, or scores; output is advisory/labeled/auditable; timeout/provider failure leaves core flows intact. |
| Audit | Important writes include actor, action, target, timestamp and correlation ID; records are append-only to app role; secrets and unnecessary personal data are excluded. |
| PWA/UI | Main flow works on phone and desktop with keyboard navigation, accessible question controls, KaTeX fallback, clear verification status and explicit AI-unavailable state. |
| Data/migrations | Fresh install and previous-version upgrade succeed on PostgreSQL; composite integrity constraints enforce owner/session/item/blueprint/version links; backup restore is demonstrated before pilot against owner-approved recovery objectives. |
| Operations | Before pilot, owner-approved hosting/recovery targets and alert ownership exist; staging evidence demonstrates health alerting and database restore against those targets; on-call/incident contacts are documented. No numeric target is presumed by Phase 0. |
| Source management & publishing | Every item has provenance/license state; official and unverified sources are distinct; AI-generated items remain drafts; a separate authorized human review verifies source, answer, explanation and scoring at exact content hash before publish; review and publish actions are auditable. |
| AI-generated questions | AI generation can create a draft only; generator principal cannot review/verify/publish; human reviewer sees source, answer key, explanation, scoring and exact hash; publication requires recorded approval and licensing/provenance evidence. |
| Exam reliability | Server timestamps/deadlines are authoritative; client drift cannot extend an exam; submission retries are idempotent; reconnect restores canonical session and acknowledged sequence; unacknowledged answers remain visibly pending; offline exam submission and pre-review answer-key caching are disabled. |
| CI verification | All required CI gates in OPERATIONS.md pass for the exact commit and artifacts are retained; agent self-report cannot mark CI verified. |
| Agent workflow | Task follows approved state sequence; scope allowlist is enforced; Codex and independent read-only auditor reviews are separate; project owner performs final acceptance; bounded retries/escalation are recorded. |
| Privacy | No real learner data before approved data inventory/retention, minor/guardian and access/delete policy, AI sharing decision, incident owner, and dated current-source legal review. |

## End-to-end release acceptance

An isolated synthetic learner can choose a configured profile, complete a practice session using exact versions, append answers, submit, receive reproducible objective results, and review them. A second learner cannot access any of the first learner's records. The same flow completes when AI is unreachable. An editor can publish only with required provenance/review evidence, and prior sessions remain bound to prior versions. No official 2027 exam claim is made until owner-approved authoritative sources exist.
