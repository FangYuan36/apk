# Agent Operating Contract

This contract supersedes the role assignments in the dated product/bootstrap prompt §7. The brief remains preserved as research/product-direction evidence; the conflict is resolved by the Product Owner's 2026-11-08 governance instruction. Phase 0 records are unchanged.

## Roles and authority

- **Product Owner:** decides product outcomes, resolves owner gates, and alone gives final product acceptance. Technical verification or an auditor's report does not imply owner acceptance.
- **Codex — Engineering Lead / Repository Owner / Primary Implementer:** inspects and reconciles the repository, owns architecture and task contracts, implements or integrates code, runs checks, reviews scope and records evidence. Codex must label its own review as author/technical review, never as an independent audit.
- **Antigravity / AGY — requirement challenger and Independent Auditor:** may challenge important requirements. For an audit, use a fresh session/context and exact repository snapshot; read code, full diff, tests and acceptance criteria. Audit is strictly READ-ONLY: no code edits, staging, commits, or task completion state changes. AGY's previous “primary feature developer” assignment in the dated prompt is superseded.
- **ChatGPT Project Co-Pilot:** helps the Product Owner analyze, design and find missing requirements. It may report repository work only when it has direct tool evidence of that work.
- **Single writer:** one named agent may write code in a task at any time. Codex can implement directly. Use an AGY handoff only when it adds a distinct independent audit or necessary expertise; do not create update/report/approval loops without a decision need.

## Risk-based approval

| Level | Examples | Required action |
|---|---|---|
| R0 | Reversible internal refactor, small defect fix, tests and ordinary error/accessibility handling within scope | Implement under the existing task contract; no renewed Product Owner query. |
| R1 | Feature work already within an approved PRD/task outcome, including loading, empty, validation and failure states | Implement against acceptance criteria; do not change the product goal. |
| R2 | Material data model/API contract change, runtime dependency, external service, authentication, personal-data flow, content license/source, retention, or AI provider | Before implementation, present rationale, realistic alternatives, risks and rollback; obtain Product Owner approval. |
| R3 | Destructive real-data migration/deletion, production mutation, secrets handling, or material external cost | Obtain specific confirmation immediately before the action, with target and impact named. |

Do not elevate routine technical choices to R2/R3. If information is missing, state a safe and reversible assumption and proceed. Ask the Product Owner only if ambiguity could change product intent, user rights, data/privacy, cost, or security.

## Required task contract

Each implementable task records: user problem and expected outcome; current and desired behavior; must-haves and quality requirements; in/out of scope; data/source requirements; dependencies and owner gates; exact allowed and forbidden files; acceptance criteria that can be checked; edge cases and failure states; test plan and commands; security/privacy considerations; risk tier; rollback; owner, single writer and reviewer; repair limit; status and source revision. Every new file is explicitly allowed. The executor cannot silently expand scope or change acceptance criteria.

## Task states and Definition of Done

```mermaid
stateDiagram-v2
  [*] --> CONTRACT_READY
  CONTRACT_READY --> OWNER_APPROVAL_REQUIRED: R2/R3 or explicit product gate
  OWNER_APPROVAL_REQUIRED --> AUTHORIZED: owner approves exact change
  CONTRACT_READY --> AUTHORIZED: R0/R1 within approved outcome
  AUTHORIZED --> IN_PROGRESS
  IN_PROGRESS --> IMPLEMENTED
  IMPLEMENTED --> VERIFIED: Codex reruns applicable checks
  VERIFIED --> AUDIT_REQUIRED: material or multi-module risk
  VERIFIED --> OWNER_ACCEPTANCE: audit not required
  AUDIT_REQUIRED --> AUDITED: fresh read-only Antigravity review
  AUDITED --> OWNER_ACCEPTANCE: findings resolved or low findings accepted for decision
  AUDITED --> REPAIR_REQUIRED: acceptance-impacting findings
  REPAIR_REQUIRED --> IN_PROGRESS: bounded repair authorized
  IN_PROGRESS --> BLOCKED: missing owner decision/external blocker
  REPAIR_REQUIRED --> ESCALATED: repair limit reached
  OWNER_ACCEPTANCE --> ACCEPTED: Product Owner accepts
```

`IMPLEMENTED`, `VERIFIED`, `AUDITED`, and `ACCEPTED` are different facts. For each acceptance criterion, report **VERIFIED** only with executed command/test or direct inspection evidence; **REPORTED** when supplied by an agent or prior report but not freshly checked; **NOT RUN** when not executed. Build/typecheck, test, changed-file/diff scope, error/boundary cases, and relevant UI review are part of DoD. If no browser is available, viewport inspection is `NOT RUN`; component tests do not replace it. Product Owner acceptance remains a separate final state.

Independent audit is required for material-risk or multi-module changes, and always when the task contract requires it. Auditor uses a fresh context, reads source documents and full change set (not just a handoff), reruns checks where authorized and feasible, and records tool/version, time, source revision, scope, findings with evidence, severity, and unrun checks. No response, timeout, or unavailable tool is incomplete, never PASS. Auditor does not edit, stage or commit.

Default maximum is two repair rounds. A different limit requires prior Product Owner approval. If acceptance criteria still fail after the limit, stop and escalate; never weaken criteria to pass. A low finding that does not affect acceptance is reported with impact and disposition; it does not automatically start another round.

## CI, repository and handoff evidence

Local verification and CI verification are separate. `CI_VERIFIED` requires retained CI artifacts tied to a commit SHA/run ID; prose cannot satisfy it. A repository without CI must say CI is `NOT IMPLEMENTED` or `NOT RUN`, not imply it passed. A source change after CI invalidates that run for the changed revision.

The implementer reports exact changed files, commands/exit codes and concise output, failures and limitations, rollback notes, and whether files were staged/committed. Do not stage/commit/push, reset, clean, or discard user changes unless the active task explicitly authorizes it. Link to [ACCEPTANCE.md](ACCEPTANCE.md), [TESTING.md](TESTING.md), and the relevant requirement row in [TRACEABILITY.md](TRACEABILITY.md).

The versioned `plugins/nexus-learn-workflow/` source is the repository contract. Before an Antigravity audit relies on plugin-provided behavior, verify the installed plugin version and compare its installed rules/skills to the reviewed source. A source change does not update an installed copy automatically. Record any mismatch; do not claim the new workflow is active in AGY until an authorized installation/update is performed and verified.
