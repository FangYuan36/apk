# NEXUS LEARN — Architecture (Phase 0)

## Architectural choice

Use a modular monolith: one React PWA and one FastAPI application, backed by PostgreSQL. Keep domain modules separated by ownership and interfaces; deploy as one backend initially. Do not add a message broker, service mesh, or separate AI service until measured load or independent deployment needs justify it.

**Current repository reality (verified 2026-11-08):** the implemented client is a React/TypeScript/Vite SPA with hash-based navigation and one synthetic, in-memory learning slice. It has domain contracts and automated tests. It is not yet an installable/offline PWA. No FastAPI service, Pydantic API, PostgreSQL database, schema migration, authentication, account/profile persistence, production deployment, or CI workflow is implemented. The target architecture below is a design boundary, not evidence that these components run. The product is personal-first; school/LMS tenancy is out of MVP. Keep learner ownership boundaries ready for later multi-user support without implementing school tenancy now.

## Product module map and implementation status

Statuses describe repository evidence, not planned completeness. `IMPLEMENTED` is limited to the behavior named in the evidence column; `NOT IMPLEMENTED` means architecture/UI copy is not a working product capability.

| Product module | Target responsibility | Current implementation evidence | Status |
|---|---|---|---|
| Dashboard | Learner entry and summary | `src/App.tsx` renders an explicit development placeholder. | Placeholder only |
| Curriculum and Subject Explorer | Versioned curriculum, subjects, units, topics, skills, and source-backed exploration | One frozen synthetic taxonomy fixture exists in `src/content/fixtures/derivative-sign.ts`; no configurable catalog, explorer, or official mapping. | Sample contract only |
| Question Bank | Searchable/versioned questions with learner-safe projections | Four synthetic questions are bundled for one sample skill; no question-bank UI or persistence. | Fixtures only |
| Practice / Learning Engine | Diagnostic, response, explanation, targeted practice, delayed recheck, evidence | `src/features/learning-slice/` implements one sample journey in memory; mounted tests exercise its flow. | Implemented sample slice; owner acceptance pending |
| Exam Engine | Versioned blueprint, exam session, timing, submission, deterministic score | No exam/blueprint UI or backend. | Not implemented |
| Learning Progress & Analytics | Rebuildable summaries from immutable events with uncertainty | The sample slice has an in-session evidence panel; no saved cross-session analytics or analytics module. | In-memory slice evidence only |
| AI Tutor | Context-bounded help over approved content; advisory and cited | No AI runtime, provider, or tutor UI. | Not implemented |
| AI Learning Analysis | Explainable analysis of authorized attempt/evidence history | No analysis service or real learner history. | Not implemented |
| AI Web Agent | Authorized actions through typed allowlisted application tools | No agent, tool API, or authorization layer. | Not implemented |
| User Settings and Personal Data | Minimal profile/preferences and governed access/export/delete | `#settings` is a placeholder; no profile or persistence. | Placeholder only |
| Content Administration / Review | Source, rights, answer review, versioned publish and audit | Domain fixture validation exists; no editorial workflow or publication service. | Not implemented |

## Content provenance and publication pipeline

Target pipeline:

`Source discovery → source/license verification → content ingestion → curriculum mapping → question drafting → answer/scoring verification → independent human review → immutable publication → practice/exam delivery → attempt events → learning analysis → recommendation`.

Every draft/version must carry provenance and review evidence: source identity and locator; issuer; source and source-version/date; license/permission state and evidence; ingestion method/time; exact curriculum-profile version and mapping; question/content version; canonical content hash; answer/scoring evidence and method; reviewer identity, decision and time; and publication status. A published version is immutable; corrections create a successor. AI generation may create a draft only and cannot verify, review, or publish its own output. Do not scrape or copy third-party questions unless permissions allow the specific acquisition, storage, transformation, and display. Unresolved rights block publication and official-alignment claims.

## Context and container diagram

```mermaid
flowchart LR
  L[Learner / editor / admin] --> PWA[React + TypeScript PWA\nVite, KaTeX]
  PWA -->|HTTPS JSON API| API[FastAPI modular monolith\nPydantic contracts]
  API --> AUTH[Identity & access module]
  API --> CAT[Curriculum & catalog module]
  API --> Q[Question bank & provenance module]
  API --> EX[Blueprint & exam module]
  API --> SC[Answer events & deterministic scoring]
  API --> AD[Adaptation & progress module]
  API --> AI[AI orchestration / controlled tools]
  API --> AUD[Audit module]
  AUTH & CAT & Q & EX & SC & AD & AI & AUD --> DB[(PostgreSQL)]
  AI -. optional provider call .-> EXT[AI provider]
```

Provider calls are optional and must never be required to read content, submit answers, score objective items, or view saved results.

## Module dependency map

```mermaid
flowchart TD
  Identity --> Catalog
  Identity --> Content
  Source --> Content
  AI -->|draft only| Content
  Catalog --> Content
  Catalog --> Blueprint
  Content --> Blueprint
  Blueprint --> Assessment
  Content --> Assessment
  Assessment --> Scoring
  Scoring --> Progress
  Assessment --> Progress
  Content --> AI[AI assistance]
  Assessment --> AI
  Progress --> AI
  Identity --> Audit
  Catalog --> Audit
  Content --> Audit
  Source --> Audit
  Blueprint --> Audit
  Assessment --> Audit
  AI --> Audit
```

Rules: modules call application/domain interfaces, not one another's tables directly. Assessment captures immutable references to exact blueprint and question versions. Scoring consumes submitted events and the captured versions; it does not call AI. Audit records actor, action, target, time, and relevant change metadata without duplicating secrets or unnecessary answer content.

## Backend target and status

Target: React + TypeScript + Vite PWA client; FastAPI + Pydantic API; PostgreSQL system of record; one modular monolith with explicit bounded modules. This is not permission to add services or dependencies: no backend component currently exists. Before backend implementation, design and test API versioning, strict request/response validation, authentication and owner authorization, Alembic migration/recovery, idempotency for retryable writes, immutable event/version boundaries, and append-only audit events. API authorization is authoritative; client route hiding is UX only. The exact auth provider, deployment, hosting, and operational targets remain unresolved.

## AI capability boundaries

- **AI Tutor:** may answer within retrieved, approved content and explicit session context; distinguish cited evidence from inference and disclose uncertainty. It is advisory, cannot decide correctness, grade, mutate attempts/scores/content, or block core learning when unavailable.
- **AI Learning Analysis:** may read only owner-authorized attempt and evidence projections; recommendations must name input evidence and policy/version. It cannot assert mastery absent a separately approved and validated model; D-017/D-024 remain constraints.
- **AI Web Agent:** may invoke only typed, allowlisted application APIs/tools. Each tool performs authorization, input/output validation, rate/egress limits, and audit logging. Sensitive or irreversible actions require explicit confirmation; no arbitrary SQL, direct database access, secrets access, or unrestricted browser/network action.
- No provider or model is selected. Provider choice requires an R2 review of quality, cost, retention, region, and data-sharing terms. No identifiable learner or licensed content is sent by default.

## Backend module responsibilities

- Identity & tenancy: authentication, roles, user-owned resources and authorization.
- Curriculum/catalog: configurable curriculum profiles, subjects, topics, textbook/source references, effective dates and status.
- Learning taxonomy: `Subject → Unit → Topic → Skill`, with each taxonomy mapped to a versioned curriculum source. Subject-specific conditions belong in versioned content/configuration rather than UI logic.
- Content: question drafts, immutable versions, provenance, verification state, publication.
- Source management: source records, licensing/provenance evidence, verification assignments and review history. Source/question verification and publishing gate precede or run in parallel with exam-engine delivery.
- Blueprint: versioned exam composition and scoring configuration by year, subject and curriculum profile.
- Assessment: exam and topic-practice session lifecycle, immutable session-item snapshots, and append-only answer events bound to exact content versions. Exam items additionally bind to exact blueprint items; practice items bind to a recorded selection-policy snapshot.
- Scoring: deterministic objective scoring with algorithm version and reproducible inputs.
- Adaptation/progress: derived learner summaries and recommendation policy; never mutate source events/scores.
- Review scheduling: a simple configurable due-date policy can queue delayed retrieval attempts. It is separate from skill mastery; do not adopt FSRS/BKT/IRT or claim mastery from the schedule alone.
- AI orchestration: allowlisted tools, provider abstraction, timeouts, limits, provenance, and degraded mode.
- AI question generation: creates unpublished drafts with generation provenance; it cannot verify or publish its own output or answer key.
- Audit: append-only records for important writes and privileged reads where justified.

## Frontend route map

```text
/                         public landing / sign-in
/app                      learner dashboard
/app/study                subject & topic selection
/app/practice/:sessionId  active exam or topic-practice session
/app/results/:sessionId   score, answer review, explanation
/app/progress             topic-level progress
/app/settings             learner profile and curriculum choice
/editor/questions        restricted question authoring/review
/editor/blueprints       restricted blueprint authoring/review
/admin/*                  restricted account/catalog/audit tools
```

Exact account flows and access rules remain to be approved. Route guards improve UX; API authorization is authoritative.

## Data and consistency boundaries

PostgreSQL is the system of record. Use transactions for answer-event insertion plus scoring/result creation and for publish operations. A published question/blueprint version cannot be updated or deleted through ordinary application paths. Corrections publish a successor version. Derived progress can be rebuilt from source records. Store timestamps in UTC and render in the user's selected locale/time zone.

## Data lifecycle

The proposed lifecycle is: approved source and rights evidence → immutable curriculum/source versions → draft/review/published question versions with hashes → session snapshots pinned to exact versions → append-only answer/attempt events → immutable score results and rebuildable analysis → explainable recommendations. Record content edits as successor versions and preserve the review chain. On real learner data, define purpose/access, export, correction, retention, backup expiry, deletion/anonymization/tombstone, legal holds, and restore behavior before collection. Deletion policy must reconcile learner rights with event/score immutability; no strategy is selected here. Grade-12 learners may be minors: only synthetic fixtures are present, and no live collection/guardian access is enabled. Qualified current-law/privacy review remains a pre-production gate.

## Deployment and operations proposal

Start with a same-origin deployment behind TLS, one stateless API deployment, managed PostgreSQL with backups, and static PWA assets. Add background execution only for non-critical AI/content jobs if needed. Define retention, backup recovery objectives, monitoring, and hosting region before production. Core-flow availability when AI is unavailable is required. Offline mode is not an MVP write capability; cached read-only behavior remains a separate owner decision. Do not queue answer writes until idempotency, event ordering, and conflict/replay rules are approved and tested.

Before pilot, the owner must approve hosting region, recovery objectives, alert ownership, retention, and incident contacts. A staging restore and health/alert exercise must produce evidence against those approved targets; no target values are assumed here.

## Risks and mitigations

| Risk | Mitigation / evidence needed |
|---|---|
| 2027 exam/curriculum format unresolved | Configuration and source provenance; no hard-coded claims; owner selects authoritative references |
| Mutable records undermine score history | Append-only events and immutable published versions; DB constraints and mutation tests |
| Tenant data leak | Central authorization policy, ownership scoping, negative cross-user tests, optional PostgreSQL RLS after design review |
| AI produces incorrect or unsafe advice | Allowlisted tools, clear advisory status, provider-independent core flows, evaluation and audit |
| Content rights/provenance unclear | Require source/license metadata and editorial approval before publication |
| PWA offline writes conflict with immutable events | Defer write queue until idempotency and event ordering are specified |
| Modular boundaries collapse in one codebase | Import/dependency rules, module-owned repositories, architecture checks |

## Exam engine reliability

The server is authoritative for exam start, deadline, and submission times. Client time is display-only; never accept client time as proof that a response met a deadline. Submission is idempotent and atomically closes the session with an event cutoff. Recovery reloads server session state and reconciles unacknowledged client drafts; retries use event idempotency keys. No offline exam submission is supported until answer-key exposure and conflict/replay risks are resolved. Concurrency targets, rate limits, and backpressure behavior require owner-approved operational inputs. See [OPERATIONS.md](OPERATIONS.md).

## Learning-intelligence selection

Do not commit to BKT, IRT, FSRS, or a heuristic before auditing representative event data and labels. Compare candidates against actual data volume, reliability, cold-start behavior, interpretability, compute cost, and offline evaluation. Use a transparent baseline and insufficient-data output until an offline evaluation shows calibrated benefit. See [AI_GOVERNANCE.md](AI_GOVERNANCE.md).

For the first slice, product direction permits a transparent configurable review interval to set a due date. This is a scheduling mechanic, not a learned retention model or a proficiency estimate; keep D-017's model-selection gate for mastery claims.

## Evolution triggers

Extract a module only when independent scaling, release cadence, isolation, or reliability requirements are demonstrated. Preserve domain contracts and event/version semantics if extraction occurs.
