# NEXUS LEARN — Product Research Brief & Codex Bootstrap Prompt

**Research snapshot:** 07 Nov 2026<br>
**Purpose:** Give Codex CLI in Termux a grounded product direction, repository-bootstrap scope, and an execution contract for AGY as the primary developer.

---

## 1. Product decision

NEXUS LEARN should not be positioned as another generic online test bank or an AI chatbot attached to a question page. The initial product thesis is:

> **A personal-first learning coach that turns a student's mistakes into a traceable, skill-level study plan, teaches the missing step, and checks whether the skill is retained later.**

The product should help a student answer four questions every study session:

1. What exact skill am I weak at?
2. Why did I get this type of question wrong?
3. What is the smallest useful thing I should learn or practise next?
4. Did I actually improve when I tried again later?

### Known project direction to preserve

- Primary initial audience: Vietnamese high-school students, with the first complete experience focused on Grade 12.
- Personal-first architecture; do not build a full school/LMS multi-tenant system in the MVP. Keep boundaries clean enough to add multi-user support later.
- Initial subject direction: Mathematics, Physics, Geography; Literature can follow after the first learning loop is proven.
- The curriculum and exam blueprint must be configurable/versioned. Do not hard-code a single exam year's format throughout the code.
- Mobile-first web experience; it must work well on Android browsers and remain usable on desktop.
- Codex is Chief Architect, bootstrapper, task planner and independent reviewer. AGY is the primary implementation developer.

If the repository already contains Phase 0 decisions, audit reports, traceability documents, or implementation work, read and reconcile those first. Do not silently replace or contradict them.

---

## 2. Research findings — observed products, not assumptions

### 2.1 DOLTHPT is a direct competitor

Sources inspected on 07 Nov 2026:

- Public site: https://dolthpt.vn/
- Grade-12 Mathematics listing: https://dolthpt.vn/tot-nghiep-thpt/toan?practice-type=GRADE_12
- Grade-12 Physics listing: https://dolthpt.vn/tot-nghiep-thpt/ly?practice-type=GRADE_12
- Geography listing: https://dolthpt.vn/tot-nghiep-thpt/dia
- Tuoi Tre News report (22 Mar 2026): https://news.tuoitre.vn/vietnams-english-center-chain-launches-free-online-exam-prep-platform-for-national-high-school-tests-103260320183029381.htm

Observed on the live public site:

- Subject-based test collections exist for Mathematics, Physics, Geography and other subjects.
- The Grade-12 Mathematics listing is organised by school, academic year and exam period. Cards expose metadata such as question count, school/year, views and likes.
- A public Grade-12 Mathematics sample detail page was inspected with a browser agent. The inspected page exposed a 22-question paper, multiple-choice, true/false and short-answer sections, an answer/explanation section, PDF download, a practice action and an answer-view action. Login was not required to read that sample detail page. The inspected sample was: https://dolthpt.vn/pdf-de-tham-khao-so-12-mon-toan-giua-ky-2-lop-12-truong-thpt-minh-ha-nam-hoc-2024-2025-co-dap-an
- The site has a practice-management route and publicly claims progress tracking, analysis of strengths/weaknesses and personalised exercise recommendations.
- The live page's counters are dynamic and not internally consistent across marketing text and category counts. Treat the feature set and page structure as evidence; do not repeat any counter as a verified market total.
- Tuoi Tre reported that DOL English launched DOLTHPT in March 2026, described it as a free exam-preparation platform and reported a 10,000-test library at launch. That is a dated press report, not an independently audited inventory.

**Product implication:** NEXUS must not claim that “personalisation”, “weakness analysis”, “question banks” or “mock tests” are unique. DOLTHPT already publicly claims several of these. The potential NEXUS distinction should be tested at the actual learning-process level: how accurately it diagnoses the cause of an error, how well it teaches the missing skill, whether the student understands the correction, and whether they can still solve a related question later.

### 2.2 Other Vietnamese alternatives

- HOCMAI's public app listing describes courses and hundreds of practice tests: https://play.google.com/store/apps/details?id=com.hocmai&hl=en_US
- Tuyensinh247 publicly offers online lessons, teacher-led courses and Grade-12 exam-preparation routes: https://tuyensinh247.com/

These establish that online lessons, exam preparation and practice tests are already familiar product categories. They do not prove that every provider has the same diagnostic or retention workflow. Do not make negative claims about competitors without inspecting the exact workflow.

### 2.3 Official exam/curriculum source policy

Useful official references found:

- Ministry of Education and Training / Quality Management Department — exam structure and format from 2025: https://vqa.moet.gov.vn/vi/news/thong-bao/cau-truc-dinh-dang-de-thi-tot-nghiep-thpt-tu-nam-2025-74.html
- Official reference exams from 2025: https://vqa.moet.gov.vn/vi/news/tin-tuc-su-kien/de-thi-tham-khao-ky-thi-tot-nghiep-thpt-tu-nam-2025-159.html
- Circular 24/2024/TT-BGDDT exam regulations PDF: https://vqa.moet.gov.vn/uploads/news/2024_12/final-quy-che-thi-tot-nghiep-thpt.pdf
- MOET page on amendments/supplements to the graduation exam regulations: https://moet.gov.vn/tin-tuc/tin-tong-hop2/sua-doi-bo-sung-mot-so-dieu-cua-quy-che-thi-tot-nghiep-trung-hoc-pho-thong.html

The official material found describes exam content as following the current high-school curriculum, primarily Grade 12, and the official notice says the 2025–2026 format was kept stable. **Do not infer the 2027 or later format from that statement.** Every curriculum/exam blueprint needs a source URL, issuer, publication/effective date, version label and review status. Update it only when a new official notice or verified document is found.

### 2.4 Learning-science basis

Use retrieval practice and spaced practice as design principles, not as marketing claims that guarantee grades.

- Yang et al. (2021), *Testing (quizzing) boosts classroom learning: a systematic and meta-analytic review*, Psychological Bulletin: https://doi.org/10.1037/bul0000309
- Agarwal, Nunes & Blunt (2021), *Retrieval practice consistently benefits student learning: a systematic review of applied research in schools and classrooms*, Educational Psychology Review: https://doi.org/10.1007/s10648-021-09595-9
- Meta-analytic review of spacing out retrieval practice episodes: https://eric.ed.gov/?id=EJ1310148

Design consequence: do not build an app that only asks students to read an explanation once. Make the learner actively retrieve, answer, explain or apply the skill, then revisit it after a delay. Use low-stakes attempts as learning signals. Do not equate one correct answer with mastery.

### 2.5 Technical reference: spaced repetition

- Official TypeScript FSRS implementation: https://github.com/open-spaced-repetition/ts-fsrs
- Its current README states that `ts-fsrs` v6 and its binding package require Node.js >=24.0.0. The README for the older `fsrs.js` package recommends moving to `ts-fsrs` because `fsrs.js` is less actively maintained: https://github.com/open-spaced-repetition/fsrs.js

The previously reported Termux/Ubuntu environment was Node 22.22.1. Therefore, do not add current `ts-fsrs` v6 to the MVP without first resolving the Node-version compatibility issue. For the first vertical slice, a transparent, simple review schedule is acceptable. Evaluate an FSRS package/version later after confirming runtime compatibility and browser bundling. FSRS schedules reviews of memory items; it must not be treated as a complete model of conceptual skill mastery.

### 2.6 Open-source discovery

GitHub discovery found the official `open-spaced-repetition` family, including `ts-fsrs`, `fsrs.js` and scheduler/benchmark projects. This is a useful implementation reference for review scheduling, not a reason to clone an entire flashcard app or copy a large LMS. The first MVP should reuse small, well-maintained libraries where justified and keep NEXUS's learning domain model under project control.

---

## 3. Recommended product differentiation — hypothesis to validate

### Core loop: Diagnose → Explain → Practise → Recheck → Update mastery

1. **Diagnose:** short topic/skill-level diagnostic, not necessarily a full mock exam.
2. **Classify the error:** likely concept gap, wrong formula/procedure, misread condition, calculation slip, data/graph interpretation, or time/guessing issue.
3. **Explain:** give a stepwise explanation and name the missing prerequisite. Show the worked step that changes the answer, not merely the final answer.
4. **Practise:** provide a small sequence from guided to independent questions targeting the same skill.
5. **Recheck later:** schedule a delayed retrieval attempt. Start with simple configurable intervals; do not assume a complex algorithm is required before real usage data exists.
6. **Update mastery:** show what evidence changed the status, what remains uncertain, and why the next task is recommended.

### Student-facing status language

Prefer transparent labels such as:

- **Chưa có dữ liệu** — not enough evidence yet.
- **Đang học** — early attempts or frequent hints.
- **Đang củng cố** — improving, but inconsistent or not yet checked after a delay.
- **Đã vững** — repeated, independent success across separate sessions, including a delayed recheck.

Thresholds are provisional and must be configurable/tested. A reasonable pilot hypothesis is that a skill should not become “Đã vững” from one correct answer; require several independent correct attempts across at least two sessions and one delayed recheck. Record the evidence count and confidence, not only a percentage.

### Candidate differentiators to test with students

- Error diagnosis explains *why* the answer went wrong, not only whether it is wrong.
- A prerequisite/skill map connects symptoms to the missing concept.
- Every recommendation explains its reason (for example: “you missed two independent questions about interpreting a derivative sign chart”).
- The app distinguishes verified content from AI-generated drafts.
- Progress measures durable skill improvement, not only question volume or same-session accuracy.

These are product hypotheses, not proven market gaps. Run small user tests against existing platforms before claiming NEXUS is unique.

---

## 4. MVP boundary

### In scope for the first complete vertical slice

- Mobile-first responsive web shell.
- Personal learner profile/preferences with the minimum necessary data.
- Subject → unit → topic → skill taxonomy that can be versioned.
- Initial subject packs: Mathematics, Physics, Geography. Literature remains a later expansion.
- Curated, reviewed question items with answer, explanation, type, difficulty and source metadata.
- A short diagnostic/practice session.
- Answer capture and immutable attempt history.
- Basic error tags and a learner-readable explanation of the likely error.
- A simple targeted practice recommendation.
- A delayed review/recheck queue.
- A small progress view showing evidence and uncertainty.
- Export/backup strategy for personal data before any multi-user migration.

### Out of scope until the learning loop works

- Full school/LMS multi-tenancy, teacher/admin dashboards and complex permission hierarchies.
- Payments, subscriptions, chat/community/social feeds.
- Large video-course catalogue.
- Automatic ingestion/copying of third-party test banks.
- Unreviewed AI-generated questions being published as verified content.
- Complex ML knowledge-tracing models before enough reliable attempt data exists.
- Arbitrary gamification that rewards streaks or clicks without measuring learning.

### First milestone should be small

Build the shared engine so all three initial subjects can use the same data structures, but implement and validate one complete topic-level learning journey first. Do not populate an enormous question bank before proving that the learner loop works.

---

## 5. Data and logic requirements

### Suggested core entities

- `Subject`
- `CurriculumVersion`
- `ExamBlueprintVersion`
- `Unit` / `Topic` / `Skill`
- `QuestionItem`
- `QuestionSource`
- `QuestionReviewRecord`
- `AttemptEvent`
- `ErrorTag`
- `SkillMasterySnapshot`
- `ReviewSchedule`
- `StudyPlanItem`

### Question item minimum metadata

`id`, `subject_id`, `grade_level`, `curriculum_version`, `unit_id`, `topic_id`, `skill_ids`, `question_type`, `difficulty`, `cognitive_level`, `prompt`, `options` (if applicable), `correct_answer`, `solution_steps`, `misconception_tags`, `source_url`, `source_issuer`, `source_date`, `license_or_permission_status`, `review_status`, `verified_by`, `answer_validation_method`, `created_at`, `updated_at`.

### Attempt history

Store attempts as events; do not overwrite previous answers when a student retries. Keep at least:

- question/item ID and item version;
- submitted answer and correctness;
- timestamp and duration;
- hints/solution steps shown before answering;
- error tags, if known;
- session ID and whether attempt was delayed/review;
- grading method and confidence/validation status.

Derived mastery may be recalculated. Raw attempt events must remain intact so future algorithms can be compared and audited.

### MVP adaptation logic

Start deterministic and explainable. The recommendation engine may consider:

- skill-level recent accuracy;
- unassisted vs. hinted attempts;
- repeated error tags;
- difficulty of each item;
- time since last successful retrieval;
- prerequisite skill state;
- whether the same skill has been checked in more than one session.

Use this to choose among: prerequisite micro-lesson, guided practice, independent practice, or delayed review. Every recommendation should expose a short reason. Keep thresholds in configuration, not scattered across UI components. Do not report statistically precise mastery if the sample is too small.

### AI content quality gate

Generated content starts as `draft`, never `verified`:

`draft → schema validation → answer/solution validation → duplicate/similarity check → curriculum/source check → human review → published`.

- Use deterministic or symbolic checks where possible for mathematics.
- Verify Physics units, formulas and assumptions.
- Verify Geography facts, map/table/chart readings and data dates.
- Keep source provenance and rights status.
- A failed or uncertain check blocks publication and creates a review task.
- Do not scrape or republish competitors' copyrighted questions. Use original questions, properly licensed/open materials, official public references where reuse is permitted, or student-provided material for private study.

---

## 6. Technical guardrails for Codex and AGY

- First inspect the existing repository and preserve its working state. Do not reset, delete or rewrite existing code just to impose a preferred stack.
- If a stack exists, document and use it unless a concrete blocker is demonstrated.
- If the repository is empty, compare at least two low-complexity options, then record a short Architecture Decision Record (ADR). Prioritise mobile browser performance, maintainability, testability and compatibility with Termux/Android workflows.
- Prefer a mobile-first web app/PWA direction if it fits the existing project; do not add PWA/offline complexity until the core flow runs.
- Check the actual Node engine requirements of every new dependency. The user's last reported development runtime was Node 22.22.1; current `ts-fsrs` v6 requires Node >=24, so flag this incompatibility before use.
- Never put model/API secrets in browser JavaScript, HTML, client-side environment variables or committed files. Any model call requiring a secret must go through a protected server-side boundary.
- Use TypeScript types or equivalent contracts for question, attempt, skill and curriculum data if the existing stack supports them.
- Keep UI components separate from assessment, mastery and scheduling logic. Core learning logic must be unit-testable without a browser.
- Keep content data separate from application code. Curriculum/exam versions must be selectable and traceable.
- Show loading, empty, error and success states. A disabled or placeholder feature must be labelled as not implemented; do not fake a successful test or save.
- Use accessible semantic HTML, keyboard-friendly controls, readable math and responsive layouts.

---

## 7. Agent operating model

### GPT App — Product Research & Product Architect

- Research actual sources and product flows.
- Separate observed facts, vendor claims, hypotheses and recommendations.
- Prepare/refresh the Product Brief, Research Evidence and Master Prompt.
- Never claim a competitor lacks a feature unless the exact feature was inspected.

### Codex CLI in Termux — Chief Architect / Bootstrapper / Auditor

- Reconcile previous project decisions and repository reality.
- Own architecture, interfaces, task decomposition, repo scaffolding and acceptance criteria.
- Create the project control files and a small runnable skeleton.
- Delegate primary feature implementation to AGY.
- Review AGY's diffs, rerun tests where possible and reject claims without evidence.

### AGY — Primary Developer

- Implement assigned tasks end-to-end.
- Own the main feature code, UI, integration and debugging.
- Run relevant tests and report actual command output.
- Do not expand scope or silently change architecture without an ADR/approval from Codex.

### Per-task cycle

`Codex task → AGY implementation → AGY report + diff → Codex independent review → PASS or repair task → next task`.

Do not assign multiple agents to edit the same files concurrently. Keep each task small enough to review. Each task must include touched-file scope, acceptance criteria, test commands, expected evidence and rollback notes.

### Required control files

Preserve existing naming if already established; otherwise create or reconcile:

- `AGENTS.md` — global instructions and agent boundaries.
- `PROJECT_STATUS.md` — current milestone, blockers and next action.
- `TASKS.md` — ordered task queue with status, owner and acceptance criteria.
- `PLANS.md` — phase and implementation plan.
- `ARCHITECTURE.md` — current architecture and boundaries.
- `DATA_MODEL.md` — entities, IDs, relations and versioning.
- `TEST_STRATEGY.md` — unit/integration/e2e/acceptance approach.
- `AGY_REPORT.md` — latest implementation evidence from AGY.
- `CODEX_REVIEW.md` — independent review findings and decisions.
- `docs/research/COMPETITOR_RESEARCH.md` — dated evidence, links, claims vs. observations.
- `docs/adr/` — architecture decisions and rejected alternatives.

---

## 8. Acceptance criteria for the first Codex bootstrap

The bootstrap is not complete because files were created. It is complete only when:

1. Codex has inspected the repository, git status, existing docs, scripts, package manifests, runtime versions and current tests.
2. Prior Phase 0 findings are reconciled in a traceability table; contradictions are listed, not silently resolved.
3. The architecture decision records a small, supportable stack and explains its compatibility with the actual Termux/Android environment.
4. The project control files exist and agree with each other.
5. There is a minimal app shell that starts locally, renders at a phone viewport and has working navigation between the agreed placeholder sections.
6. The question/attempt/skill data contracts are defined and tested independently of the UI.
7. The first vertical-slice task is assigned to AGY with exact file scope and acceptance criteria.
8. The bootstrap report lists exact commands, exit codes, test output, changed files, known limitations and the next task.

No feature may be marked `PASS` unless the corresponding command/test was actually run and its output recorded. Distinguish `NOT RUN`, `BLOCKED`, `FAILED`, `PASS` and `PASS WITH LIMITATIONS`.

---

## 9. Copy-ready prompt for Codex CLI

Paste the following prompt while Codex is running in the NEXUS LEARN repository root in Termux.

```text
Bạn là CHIEF ARCHITECT, REPOSITORY BOOTSTRAPPER và INDEPENDENT TECHNICAL AUDITOR của dự án NEXUS LEARN.

MÔ HÌNH ĐỘI NGŨ (KHÔNG ĐƯỢC ĐẢO VAI):
- GPT App: Product Research + Product Architect. Cung cấp research brief, bằng chứng, PRD và định hướng sản phẩm.
- BẠN (Codex CLI): kiểm tra repository, kiến trúc, xây khung dự án, chuẩn hoá quy trình, chia task, tạo acceptance criteria, kiểm toán diff và test.
- AGY: PRIMARY DEVELOPER. AGY là người triển khai phần lớn feature code, UI, logic và debugging. Bạn không được biến AGY thành người phụ việc cho mọi dòng code.

MỤC TIÊU LẦN CHẠY NÀY:
Thực hiện REPOSITORY RECON + ARCHITECTURE RECONCILIATION + BOOTSTRAP PLAN. Tạo khung điều phối và app shell tối thiểu nếu repository đang thiếu. Chưa triển khai toàn bộ sản phẩm. Sau khi hoàn thành, giao task vertical-slice đầu tiên cho AGY.

PRODUCT DIRECTION ĐÃ CHỐT:
NEXUS LEARN là personal-first learning coach cho học sinh THPT Việt Nam, ưu tiên trải nghiệm lớp 12. Hướng môn học đầu tiên: Toán, Vật lí, Địa lí; Ngữ văn mở rộng sau. Kiến trúc cần cho phép thêm môn/lớp/năm học mà không hard-code. Trải nghiệm mobile-first, chạy tốt trên Android browser và desktop.

SẢN PHẨM KHÔNG ĐƯỢC BIẾN THÀNH:
- Chỉ một kho đề thi hoặc website mock-test.
- Một chatbot AI chung chung không có dữ liệu học tập.
- Một LMS nhiều trường/phân quyền phức tạp ngay trong MVP.
- Một ứng dụng có vẻ hoạt động nhưng dữ liệu, lưu trữ, chấm điểm hoặc test chỉ là giả.

CORE LEARNING LOOP:
Diagnose → Classify error → Explain missing step → Targeted practice → Delayed recheck → Update skill evidence.
Mỗi đề xuất học tiếp phải giải thích ngắn gọn lý do. Một đáp án đúng không đủ để đánh dấu mastery. Theo dõi attempt events bất biến; mastery là dữ liệu suy ra có thể tính lại.

BẰNG CHỨNG NGHIÊN CỨU CẦN TÍNH ĐẾN:
1. DOLTHPT (https://dolthpt.vn/) là đối thủ trực tiếp đã hoạt động. Trang công khai có kho đề theo môn, trang Toán 12/Vật lí 12/Địa lí, metadata đề, đáp án/giải thích, PDF và luồng làm bài. DOL cũng công khai tuyên bố theo dõi tiến độ, phân tích điểm yếu và cá nhân hoá bài tập. Không được tuyên bố những tính năng này là độc quyền của NEXUS.
2. Trang Toán 12 đã được inspect bằng browser agent: listing theo trường/năm học/học kỳ; trang đề mẫu 22 câu có MCQ, đúng/sai, trả lời ngắn, phần đáp án/giải thích, PDF và action làm bài/xem đáp án; đọc nội dung mẫu không cần login.
3. Official MOET references: https://vqa.moet.gov.vn/vi/news/thong-bao/cau-truc-dinh-dang-de-thi-tot-nghiep-thpt-tu-nam-2025-74.html và https://vqa.moet.gov.vn/vi/news/tin-tuc-su-kien/de-thi-tham-khao-ky-thi-tot-nghiep-thpt-tu-nam-2025-159.html. Curriculum/exam blueprint phải gắn source + version + date; không tự suy diễn format 2027 từ thông tin 2025/2026.
4. Retrieval practice/spaced practice có nền tảng tổng quan nghiên cứu: https://doi.org/10.1037/bul0000309 và https://doi.org/10.1007/s10648-021-09595-9. Triển khai như nguyên tắc học tập, không quảng cáo cam kết điểm.
5. FSRS: https://github.com/open-spaced-repetition/ts-fsrs. README hiện tại ghi ts-fsrs v6 cần Node >=24. Môi trường đã từng được báo là Node 22.22.1; phải kiểm tra runtime thực tế và dependency engine trước khi chọn. Không cài mù quáng.

NGUYÊN TẮC BẤT DI BẤT DỊCH:
- Bắt đầu bằng `pwd`, `git status`, `git branch --show-current`, xem lịch sử commit, cây file, README/AGENTS.md, package manifests, lockfiles, scripts và tests.
- Không reset, không xoá, không ghi đè file, không đổi framework hoặc package manager chỉ vì sở thích. Giữ mọi thay đổi hiện có của user.
- Nếu thấy nhiều repository hoặc workspace có vẻ liên quan mà không chắc cái nào là NEXUS LEARN, dừng và báo các candidate; không tự chọn bừa.
- Đọc toàn bộ tài liệu Phase 0/phase plan/audit/traceability đã tồn tại. Lập traceability: requirement → source/decision → implementation evidence → status. Nêu xung đột; không tự xoá phát hiện audit cũ.
- Nếu repo có app đang hoạt động, chạy test hiện tại trước khi sửa. Ghi baseline.
- Nếu thiếu stack, đưa ít nhất 2 lựa chọn đơn giản, so sánh khả năng chạy trên Android/Termux và Node thực tế, rồi ghi ADR. Ưu tiên giữ stack hiện tại nếu không có blocker.
- Không đưa API key/secret vào HTML, JS client, file public hoặc git. Không scrape/copy nội dung câu hỏi có bản quyền của đối thủ.
- Không ghi `PASS` khi chưa chạy command/test tương ứng.

GIAI ĐOẠN A — REPOSITORY RECON:
1. Tóm tắt branch, commit, working tree, file chính, framework, runtime, dependency manager, build/test commands.
2. Liệt kê tài liệu Phase 0/architecture/traceability/audit hiện có và quyết định nào phải bảo toàn.
3. Chạy baseline test/build/lint hiện có nếu an toàn. Ghi exact command và output/exit code.
4. Ghi risk register: Node/runtime compatibility, data persistence, secrets, content copyright/provenance, math rendering/answer validation, responsive layout, lack of test data.

GIAI ĐOẠN B — PRODUCT/ARCHITECTURE RECONCILIATION:
1. Cập nhật Product Brief với core loop nêu trên.
2. Thiết kế taxonomy `Subject → Unit → Topic → Skill` có curriculum version.
3. Đề xuất domain entities tối thiểu: Subject, CurriculumVersion, ExamBlueprintVersion, Unit, Topic, Skill, QuestionItem, QuestionSource, QuestionReviewRecord, AttemptEvent, ErrorTag, SkillMasterySnapshot, ReviewSchedule, StudyPlanItem.
4. Tách logic đánh giá, error classification, recommendation và review scheduling khỏi UI.
5. Dùng rule-based explainable adaptation trong MVP; không cần ML knowledge tracing khi chưa có attempt data đáng tin.
6. Tách AI-generated draft khỏi verified question. Pipeline tối thiểu: draft → schema check → answer/solution validation → duplicate/source/curriculum check → human review → published.
7. Ghi rõ MVP out-of-scope: school tenancy, teacher admin, payment, social/community, mass question scraping, unreviewed AI question publishing, heavy ML.

GIAI ĐOẠN C — BOOTSTRAP:
1. Tạo hoặc reconcile các file: AGENTS.md, PROJECT_STATUS.md, TASKS.md, PLANS.md, ARCHITECTURE.md, DATA_MODEL.md, TEST_STRATEGY.md, AGY_REPORT.md, CODEX_REVIEW.md, docs/research/COMPETITOR_RESEARCH.md, docs/adr/.
2. Giữ tên file cũ nếu dự án đã có quy ước khác; tránh tạo bản trùng lặp.
3. Xây app shell tối thiểu responsive cho mobile và desktop. Placeholder phải ghi rõ chưa triển khai; không giả vờ có dữ liệu/chức năng.
4. Định nghĩa model/type contracts và unit tests cho QuestionItem, AttemptEvent, Skill, mastery/recommendation inputs.
5. Chỉ xây khung đủ chạy và đủ test. Không tự triển khai tràn lan feature khi chưa có task.

GIAI ĐOẠN D — DELEGATE TO AGY:
Tạo đúng một task đầu tiên cho AGY theo hướng vertical slice nhỏ: một topic đã có curriculum mapping rõ, một số câu hỏi đã được kiểm duyệt, một phiên diagnostic/practice, lưu attempt, phân loại lỗi cơ bản, giải thích, gợi ý bài tiếp và delayed recheck tối giản. Nếu chưa có nội dung verified, task đầu tiên của AGY là dựng contract + test fixture có nhãn sample/test-only; không giả làm dữ liệu thật.

MỖI TASK AGY PHẢI CÓ:
- Task ID, mục tiêu, lý do sản phẩm.
- Files/module được phép sửa.
- Files/module không được sửa.
- Input/output contract.
- Acceptance criteria đo được.
- Unit/integration/e2e test cần chạy.
- UI states: loading, empty, error, success.
- Evidence phải trả về.
- Rollback/known risk.

AGY REPORT FORMAT:
- Task ID + status: PASS / PASS WITH LIMITATIONS / FAILED / BLOCKED / NOT RUN.
- Files changed.
- Commands executed + exit codes.
- Test output (không chỉ nói “tests passed”).
- Screens/flows manually checked nếu có.
- Known issues và việc chưa làm.

CODEX REVIEW FORMAT:
- Review độc lập diff, không chỉ đọc AGY_REPORT.
- Check scope creep, regressions, data integrity, security/secrets, accessibility/responsive behavior, correctness of learning logic.
- Chạy lại tests quan trọng nếu môi trường cho phép.
- Ghi findings theo severity: BLOCKER / HIGH / MEDIUM / LOW.
- Kết luận PASS chỉ khi đủ acceptance evidence; nếu không, giao AGY task repair cụ thể.

OUTPUT CUỐI LẦN CHẠY NÀY:
1. Repository Recon Report.
2. Requirements Traceability Table.
3. Architecture Decision Record (stack/runtime and key boundaries).
4. Updated product/data/test docs.
5. Minimal app shell run instructions and exact verification output.
6. TASKS.md có task tiếp theo được giao cho AGY.
7. PROJECT_STATUS.md và AGY_REPORT.md/CODEX_REVIEW.md cập nhật đúng trạng thái.
8. Một bản tóm tắt ngắn cho Product Owner: đã làm gì, chưa làm gì, rủi ro nào, task tiếp theo AGY cần chạy.

ƯU TIÊN CHẤT LƯỢNG HƠN SỐ LƯỢNG FILE. KHÔNG ĐƯỢC BÁO CÁO THÀNH CÔNG NẾU CHỈ TẠO TÀI LIỆU MÀ APP KHÔNG CHẠY. HÃY BẮT ĐẦU BẰNG REPOSITORY RECON, SAU ĐÓ MỚI SỬA.
```

---

## 10. Next project gates

### Gate 1 — Codex bootstrap verified

- Repository and previous decisions reconciled.
- Control files in place.
- App shell starts on the actual Termux environment.
- Runtime and dependency choices are documented.

### Gate 2 — First vertical slice verified by Codex

- One skill mapped to an official/current curriculum source.
- Small set of reviewed questions with provenance.
- Attempt history persists and can be reloaded.
- Error explanation and next recommendation are visible and reasoned.
- Delayed recheck is scheduled and testable.
- Automated tests cover scoring and state transitions.

### Gate 3 — Learner pilot

Test with a small number of students using the same topic and comparable tasks. Measure:

- Can a student identify the weak skill after the diagnostic?
- Can they explain the mistake after the teaching step?
- Can they solve a new related item without hints?
- Can they still solve a related item after 48 hours and again after about a week?
- Did the next-task recommendation feel relevant, and why?

Do not collect unnecessary personal data. Use feedback to refine the workflow before expanding question volume or adding more subjects.

### Gate 4 — Expand carefully

After the first learning loop is proven: extend the same contracts to more Math, Physics and Geography topics; then Literature; then consider sync/accounts/multi-user support only when there is a real need.

---

## 11. Current recommendation

**Do next:** run the Codex prompt in the actual NEXUS LEARN repository root on Termux. Codex should first inspect and reconcile the existing project state, then create the minimal control structure and shell, then delegate the first vertical slice to AGY. Bring Codex's `Repository Recon Report`, `TASKS.md`, and `Architecture Decision Record` back for an independent product/technical review before AGY starts a larger implementation batch.
