# NEXUS LEARN — Muse AI Handoff

Snapshot timestamp: 2026-11-10T08:59:07+07:00 (Asia/Ho_Chi_Minh)
Source repository: `/data/data/com.termux/files/home/nexus-learn`
Branch / HEAD: `main` / `b502fa7120cadd460c0e224d67fc5b1d8ac43691`
Current status: **REPAIR REQUIRED**. Not complete and not Product Owner accepted.

## Product and vision
NEXUS LEARN is a personal learning platform starting with Vietnamese Grade 12 Math. Its intended verified learning loop is learn → answer → preserve evidence → diagnose possible errors → recommend next work → schedule review → check again. Diagnostic tags are hypotheses; a due date is a scheduling aid, not mastery. This snapshot is a local-browser client, not a SaaS or multi-user production system.

## Current repository and architecture
The archive includes tracked changes and untracked source/docs/tests from the actual filesystem. It omits Git metadata, dependencies/build output/caches, and local Agent Hub logs/state. It is a source snapshot, not a Git clone; review the manifest and establish a new VCS baseline only after preserving this exact snapshot. The original working tree was not edited for packaging; this README exists only in the staging/archive copy.

Stack: React + TypeScript + Vite, modular domain/features/content/components/infrastructure. Domain code defines versioned math questions and MCQ_SINGLE, TRUE_FALSE_CLUSTER, SHORT_NUMERIC evaluators. UI uses bundled draft candidates and repository adapters (Native IndexedDB when the browser exposes it, otherwise in-memory). Import currently validates/previews but does not persist drafts. AI code is an advisory typed context contract only. FastAPI/PostgreSQL, auth, cloud sync, and multi-user service are not implemented.

## Implemented capabilities (implementation does not equal verified)
- Three structured question families and deterministic practice scoring.
- Taxonomy/question/solution contracts and derivative-applications draft candidates.
- Learning UI, explanations, diagnostic hypotheses, session/attempt/review schedule and delayed-recheck paths.
- Repository-backed Dashboard and Progress views.
- Draft-only import validation/preview.
- MathRenderer, responsive styles, tests, Agent Hub, docs, roadmaps, scorecards, audit reports.

## Latest audit and blockers
Read `reports/next-day-campaign/OPERATIONAL_100_FINAL_CODEX_AUDIT.md` and `docs/agent-handoffs/AGY_OPERATIONAL_100_FINAL_REPAIR_BRIEF.md` first. Latest result: **REPAIR REQUIRED**.
The audit found: blank QuestionVersion hash can bypass declared-hash enforcement; malformed calendar date can authorize reviewer evidence; untrusted import package can supply reviewer registry for preview eligibility; rights metadata is not proof and missing commercial-use evidence can pass; source session skill is not bound in recheck; AttemptEvent validation accepts scored records with no part evidence and permits invalid status; Dashboard/Progress hide read failures as empty data; partial credit may count as correct; dashboard quick navigation can leave URL hash stale; evidence-based recommendation is not wired; import is preview-only; AI context aggregates question ID as skill ID and is not fully deeply frozen. Native IndexedDB/reload and mobile rendering were not tested in a real browser.

The last audit reported evidence-weighted estimates: functional readiness 48%, educational content readiness 20%, local client production/deployment readiness 40%. All 15 pilot questions remain drafts; 0 qualified-reviewed/published items. Those are not acceptance scores.

## Work packages and status
Authoritative Operational 90 sequence: WP0 domain/security stabilization → WP1 persistence/recovery → WP2 learning journey → WP3 draft import preview → WP4 mobile/deployability → WP5 read-only AI context. AGY’s final report renumbered several packages; see the final audit mapping. WP0 has unresolved repair findings. Dashboard/Progress, preview import, responsive CSS and AI context are implemented with limitations. None is Product Owner ACCEPTED.

## Decisions and governance
- D-017: do not select BKT, IRT, FSRS or heuristic mastery without real-data evaluation.
- D-020: configured due dates schedule review only, never mastery.
- D-024: sample verification cycle is evidence about that cycle, not mastery/proficiency.
- D-025 and `docs/AGENT_WORKFLOW.md`: Product Owner decides and alone accepts; single writer; independent audit is read-only. Any task-local AGY implementation authorization must not be treated as a permanent governance amendment.
- Scoring remains PROPOSED/practice-only, not official exam scoring.
- Reviewer evidence must come from a trusted authority boundary; no fake reviewers or package-supplied registry. Rights/license metadata must be substantiated; absent evidence means draft.
- No mastery claims, cloud backup, backend, auth, or AI provider. AI is advisory and cannot mutate score/events/publication/mastery.
- No secrets belong in client code.

## Setup and commands
Use a Node version compatible with the pinned Vite toolchain (repository environment used Node 26.x), npm, and Python 3.10+ for Agent Hub checks:
```sh
npm ci
npm test
NEXUS_NL002_ACCEPTANCE=1 npm test
npm run build
python3 agent-hub/tests/run_all_tests.py
npm run dev
```
`scripts/run.mjs` stages runtime files under the system temp directory for Termux compatibility; inspect it before adapting on VPS. Current package.json has no `preview` script although Operations mentions one. Tests/build were last recorded by Codex on 2026-11-09; packaging did not rerun them. Rerun on the target VPS.

## Recommended Muse steps
1. Verify the adjacent SHA-256 and manifest before extraction; inspect included/excluded lists.
2. Read `AGENTS.md`, `docs/AGENT_WORKFLOW.md`, `DECISIONS.md`, the Operational 90 brief, latest audit, and repair brief.
3. Preserve the source snapshot and dirty/untracked history; do not assume these files were all tracked or accepted.
4. Repair WP0 findings first, with one writer and independent re-verification. Do not advance to broader feature work until hash/reviewer/rights/recheck/event invariants are safe.
5. Keep content draft until a real qualified math reviewer and traceable rights evidence are available.
6. Then design/import persisted drafts (beyond the current preview-only capability), wire an evidence-based recommendation, and verify native IndexedDB reload and mobile layouts in a real browser.
7. Correct the preview runbook/script mismatch and recompute scores only from reproducible evidence. Obtain Product Owner acceptance separately.

This handoff is not legal clearance, deployment, or Product Owner acceptance.
