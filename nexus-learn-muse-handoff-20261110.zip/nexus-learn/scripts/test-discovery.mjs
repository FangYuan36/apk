import { readdir } from 'node:fs/promises';
import { join } from 'node:path';

export async function findTestFiles(root) {
  const entries = await readdir(root, { withFileTypes: true });
  const discovered = await Promise.all(entries.map(async (entry) => {
    const path = join(root, entry.name);
    if (entry.isDirectory()) return findTestFiles(path);
    if (entry.isFile() && /\.test\.tsx?$/.test(entry.name)) return [path];
    return [];
  }));
  return discovered.flat().sort();
}
