import { chmod, copyFile, cp, mkdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { findTestFiles } from './test-discovery.mjs';

const command = process.argv[2];
const sourceRoot = process.cwd();
const runtimeRoot = join(tmpdir(), 'nexus-learn-runtime');

if (process.env.NEXUS_RUNTIME_COPY !== '1') {
  await mkdir(runtimeRoot, { recursive: true });
  for (const file of ['package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'index.html']) {
    await copyFile(join(sourceRoot, file), join(runtimeRoot, file));
  }
  for (const directory of ['src', 'scripts']) {
    await cp(join(sourceRoot, directory), join(runtimeRoot, directory), { recursive: true, force: true });
  }

  const lockHash = createHash('sha256').update(await readFile(join(runtimeRoot, 'package-lock.json'))).digest('hex');
  let installedHash = '';
  try {
    installedHash = await readFile(join(runtimeRoot, '.dependency-lock-hash'), 'utf8');
  } catch {}
  if (installedHash !== lockHash) {
    const install = spawnSync('npm', ['ci', '--bin-links=false'], { cwd: runtimeRoot, stdio: 'inherit' });
    if (install.status !== 0) process.exit(install.status ?? 1);
    await writeFile(join(runtimeRoot, '.dependency-lock-hash'), lockHash);
  }

  const result = spawnSync(process.execPath, ['scripts/run.mjs', command], {
    cwd: runtimeRoot,
    stdio: 'inherit',
    env: { ...process.env, NEXUS_RUNTIME_COPY: '1' },
  });
  if (result.error) {
    console.error(result.error.message);
    process.exit(1);
  }
  if (command === 'build' && result.status === 0) {
    await cp(join(runtimeRoot, 'dist'), join(sourceRoot, 'dist'), { recursive: true, force: true });
  }
  process.exit(result.status ?? 1);
}

const platformPackage = process.platform === 'android' ? `android-${process.arch}` : `${process.platform}-${process.arch}`;
const esbuildSource = join(
  process.cwd(),
  'node_modules',
  '@esbuild',
  platformPackage,
  'bin',
  process.platform === 'win32' ? 'esbuild.exe' : 'esbuild',
);
const esbuildCopy = join(tmpdir(), 'nexus-learn-esbuild');

try {
  await copyFile(esbuildSource, esbuildCopy);
  if (process.platform !== 'win32') await chmod(esbuildCopy, 0o755);
} catch (error) {
  if (!process.env.ESBUILD_BINARY_PATH) {
    console.error(`Could not prepare the esbuild binary outside the project filesystem: ${error.message}`);
    process.exit(1);
  }
}

const env = { ...process.env, ESBUILD_BINARY_PATH: process.env.ESBUILD_BINARY_PATH || esbuildCopy };
const commands = {
  test: [[process.execPath, ['node_modules/tsx/dist/cli.mjs', '--test', ...(await findTestFiles(join(process.cwd(), 'src')))]]],
  build: [
    [process.execPath, ['node_modules/typescript/bin/tsc', '--noEmit']],
    [process.execPath, ['node_modules/vite/bin/vite.js', 'build']],
  ],
  dev: [[process.execPath, ['node_modules/vite/bin/vite.js', '--host', '127.0.0.1']]],
};

if (!commands[command]) {
  console.error('Usage: node scripts/run.mjs <test|build|dev>');
  process.exit(2);
}

for (const [executable, args] of commands[command]) {
  const result = spawnSync(executable, args, { stdio: 'inherit', env });
  if (result.error) {
    console.error(result.error.message);
    process.exit(1);
  }
  if (result.status !== 0) process.exit(result.status ?? 1);
}
