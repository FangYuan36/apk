export function findTestFiles(root: string): Promise<string[]>;
