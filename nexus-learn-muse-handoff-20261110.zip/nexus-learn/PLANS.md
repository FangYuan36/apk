# NEXUS LEARN — Roadmap and Dependency Plan

Statuses distinguish implemented local code from owner acceptance and future architecture. Phase 0 history remains in `reports/phase0/FINAL_VERIFICATION.md`; this roadmap does not rewrite it.

| Milestone | Outcome / dependency | Status |
|---|---|---|
| M0 — Repository and governance baseline | Existing repository, current diffs, runtime, governance, module boundaries, evidence and owner gates are reconciled. | Repo documents aligned and local checks pass; installed Antigravity plugin still has stale role text, so operational synchronization is NOT COMPLETE. No CI or Antigravity audit is claimed. |
| M1 — Product, source and data policy lock | Owner selects initial curriculum/source and reuse rights; exam/year rules; question types/scoring; age/consent, retention/deletion, AI sharing, and pilot measures. | OPEN; owner gates in `DECISIONS.md`. No official 2027 alignment or real learner data. |
| M2 — Platform/domain foundation | After M1 policy inputs: implement FastAPI/Pydantic modular monolith, PostgreSQL migrations, authentication/owner authorization, append-only events, idempotency, audit, CI and privacy controls. | PROPOSED / NOT IMPLEMENTED. Exact R2 architecture/tool choices require review before dependencies/services. |
| M3 — Verified content pipeline | Depends on approved sources/rights and versioned catalog: source discovery → license verification → ingestion → curriculum mapping → draft → answer/scoring verification → human review at exact hash → immutable publication. | PROPOSED / NOT IMPLEMENTED. Synthetic slice fixture is not a published bank. |
| M4 — Practice and learning engine | Depends on M2 event/session model and M3 verified content; build reusable practice, exact-version delivery, deterministic scoring/events, explanations and delayed scheduling. | One synthetic in-memory slice is implemented locally under TASK-NL-001; owner acceptance pending. Reusable persistent engine not implemented. |
| M5 — Exam engine | Depends on verified, owner-approved year/subject blueprint and M2 session/event/idempotency foundation; server-authoritative timing, scoring, recovery and answer-key protection. | PROPOSED / NOT IMPLEMENTED; exam format/source unresolved. |
| M6 — Progress and governed AI | Progress depends on valid persisted events and measured evidence. AI Tutor depends on approved content/read scope; Learning Analysis depends on authorized event projections and evaluated policy; Web Agent depends on per-tool auth, audit and confirmation. | PROPOSED / NOT IMPLEMENTED. No AI provider selected. D-017/D-020 remain in force. |
| M7 — Pilot readiness | Depends on approved content, privacy/legal and operations; accessible/responsive/security gates, restore evidence, success measures, rollback and owner acceptance. | BLOCKED BY OWNER/OPERATIONS GATES; no pilot data or deployment. |

### Current bounded work

- **TASK-NL-001:** Codex implemented the one-skill synthetic learning slice and navigation correction; current local verification is 31/31 tests, build exit 0. Product Owner acceptance is separate and pending. No fresh independent Antigravity audit is recorded.
- **Navigation correction:** repository has the four hash areas, distinct placeholders for Dashboard/Progress/Settings, LearningSlice only on Study, and a mounted DOM navigation test. It is resolved in code; no duplicate backlog task is opened.
- **TASK-NL-002:** Math Learning Core implementation exists in the working tree; latest Codex independent audit (2026-11-08) returned REPAIR REQUIRED with four HIGH and three MEDIUM findings. It is not accepted. Preserve its history and contract at [`docs/TASK-NL-002-MATH-LEARNING-CORE-V1.md`](docs/TASK-NL-002-MATH-LEARNING-CORE-V1.md).
- **NL-MVP-50:** The 2026-11-09 50% product campaign begins with WP0 stabilization, not the stale NL-002 WP1 handoff. Roadmap, evidence scorecard and exact WP0 AGY brief: [roadmap](docs/strategy/NEXUS_LEARN_50_PERCENT_ROADMAP.md), [scorecard](docs/strategy/NEXUS_LEARN_MVP_SCORECARD.md), [AGY brief](docs/agent-handoffs/AGY_EXECUTION_BRIEF.md). WP0 is contract-ready but not dispatched. The PO's AGY implementation instruction is a task-local exception only; D-025 remains unchanged.
- **Next action:** PO/operator transfers the one WP0 prompt to AGY TUI. AGY pauses after WP0; Codex audits before any later package. Keep TASK-NL-001 acceptance pending and resolve R2 gates only at their stated scope.

Detailed bootstrap notes remain at [`docs/superpowers/plans/2026-11-07-nexus-bootstrap.md`](docs/superpowers/plans/2026-11-07-nexus-bootstrap.md).
