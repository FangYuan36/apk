# NEXUS LEARN — Decisions, Unknowns, Milestones

## Decision log

| ID | Decision / proposal | Status | Rationale / consequence |
|---|---|---|---|
| D-001 | React + TypeScript + Vite PWA, FastAPI + Pydantic, PostgreSQL, KaTeX | Confirmed preference | Supplied by project owner; versions/deployment remain open. |
| D-002 | Modular monolith | Confirmed requirement | Keeps domain boundaries without premature service operations. |
| D-003 | Curriculum and exam configuration is data/version driven by year and subject | Required design direction | Curriculum profile unresolved; avoid code assumptions and false official claims. |
| D-004 | Immutable published question and blueprint versions; append-only answer events and score results | Required constraint | Preserves reproducibility and history. |
| D-005 | Deterministic objective scoring independent of AI | Required constraint | Reproducible results; AI has no mutation authority. |
| D-006 | PostgreSQL is system of record; Alembic is proposed migration tool | Proposal | Fits SQL relational integrity; confirm dependency/tooling in Phase 1. |
| D-007 | API base `/api/v1`, owner identity from auth principal, idempotency for retryable writes | Proposal | Stable contracts and safe retries; auth choice remains open. |
| D-008 | AI assistance is optional, allowlisted, advisory and provider-abstracted | Required constraint | Core usability when providers are unavailable and controlled tool access. |
| D-009 | No product implementation in Phase 0 | Confirmed instruction | Phase 0 delivers discovery artifacts and a verifiable plan only. |
| D-010 | Shared assessment sessions distinguish `exam` and `practice` kinds and snapshot immutable session items | Phase 0 design correction | Aligns topic practice in PRD/UI with the API while preserving exact question versions; exam items also bind to blueprint items. |
| D-011 | Online core study must work when AI is unavailable; offline answer writes are not an MVP promise | Phase 0 consistency correction | Resolves the candidate offline metric versus deferred write-conflict policy. Offline scope remains owner-gated. |
| D-012 | Question publication addresses an exact immutable version and reviewed content hash | Phase 0 API correction | Prevents concurrent successor drafts from changing what a reviewer approved. |
| D-013 | AGY executes approved tasks only; independent auditor uses a fresh read-only run; owner alone accepts | Phase 0 workflow requirement | Separates implementation, CI evidence, technical review, independent audit and final approval. |
| D-014 | CI artifacts tied to commit SHA/run ID are the only CI verification evidence | Phase 0 verification requirement | Agent-reported test status cannot substitute for executed lint/type/test/security/migration/build jobs. |
| D-015 | AI-generated questions are unpublished drafts until human source/answer/scoring review at exact content hash | Phase 0 publishing gate | AI cannot verify its own output or approve licensing. |
| D-016 | Exam server time is authoritative; offline exam answer submission is disabled pending security/recovery approval | Phase 0 reliability requirement | Prevents client clock drift and offline answer-key/replay risks from changing exam outcomes. |
| D-017 | No BKT, IRT, FSRS or heuristic selected before actual-data evaluation | Phase 0 learning-intelligence requirement | Candidate comparison precedes method selection; safe insufficient-data baseline remains. |
| D-018 | Current legal obligations for minors/student data are reviewed from primary sources at implementation/deployment time | Phase 0 privacy gate | No legal compliance assumption is encoded in this design. |
| D-019 | Bootstrap shell and pure learning contracts are a new scope after historical Phase 0; Phase 0's no-product-code decision remains intact as a historical milestone | Authorized by the 2026-11-07 product brief and current user request | Keeps the Phase 0 audit trail while allowing only the minimal scaffold/contracts/tests in this bootstrap. |
| D-020 | A transparent configurable delayed-review due date is allowed for the first vertical slice; it is not a selected mastery model | Product brief direction; bounded reconciliation with D-017 | No FSRS/BKT/IRT/heuristic mastery claim is selected. Skill status remains evidence-based and insufficient data must abstain. |
| D-021 | MVP is personal-first; full school/LMS tenancy and teacher/admin hierarchy are out of scope | Product brief direction | Preserve clean data/domain ownership boundaries for later multi-user support; do not implement school tenancy now. |
| D-022 | The current Node runtime is Node 26.13.0; prior Node 22.22.1 is historical and not assumed current | Repository Recon 2026-11-07 | Recheck runtime and package engine requirements when dependencies are selected; do not add `ts-fsrs` v6 by assumption. |
| D-023 | Pin the bootstrapped UI toolchain to React/React DOM 19.3.1, Vite 8.3.6, `@vitejs/plugin-react` 6.2.1, TypeScript 5.9.3, and `tsx` 4.23.15; lock dependencies | Build verified on Node 26.13.0; Vite engine also accepts Node >=22.12.0 | TypeScript 7.0.2 required an unavailable Android native compiler package; Android shared-storage native module execution requires private Termux staging. The runtime wrapper addresses filesystem limits without changing the chosen framework. |
| D-024 | Sample Verification Cycle Is Not a Mastery Model | Product Owner approved 2026-11-08 — TASK-NL-001 only | TASK-NL-001 may use at least 3 independent correct answers across at least 2 learning sessions, including at least 1 correct delayed recheck, solely as a verification gate for completing the sample vertical-slice cycle. Do not call the result mastery, proficiency, actual ability, or “Đã vững”. D-017 remains in force: no BKT, IRT, FSRS, or mastery heuristic is selected. D-020 remains in force: configurable review due dates are scheduling only. All reports and UI must distinguish verification progress from actual skill mastery. |
| D-025 | Agent Operating Contract and risk-based approvals | Confirmed owner instruction 2026-11-08 | Product Owner alone makes product decisions/final acceptance; Codex is Engineering Lead, repository owner and primary implementer; Antigravity/AGY is a fresh-context READ-ONLY independent auditor (and may challenge important requirements); ChatGPT Project Co-Pilot supports the owner without claiming unverified repository work. One writer per task. R0/R1 proceed within approved intent; R2 requires prior owner approval; R3 requires specific immediate confirmation. See `docs/AGENT_WORKFLOW.md`. This supersedes the AGY-primary-developer role in the dated product brief §7 without rewriting that history. |

## Known unknowns and owner decisions

Unless an item names a qualified privacy/legal reviewer or operations owner, the decision owner is the project owner. Implementation gates are listed with the numbered items; unapproved decisions cannot be silently treated as defaults.

1. Select initial curriculum profile(s), textbook/source corpus, and authoritative evidence.
2. Confirm 2027 format by subject, source authority, verification owner, and update process. Until confirmed, use configurable drafts and do not claim official alignment.
3. Choose MVP question types and exact answer normalization/scoring rules, including partial credit, unanswered items, and post-submit behavior.
4. Define adaptation outcomes and policy; decide whether MVP needs algorithmic adaptation or only transparent topic recommendations. Safe low-evidence behavior is constrained: state insufficient data and avoid unsupported mastery estimates; numerical thresholds remain owner-gated.
5. Select authentication/session approach, account recovery, editorial roles, and whether guardians/teachers exist.
6. Approve learner age/consent/privacy assumptions, data residency, retention/deletion, analytics, AI provider/data sharing, and incident owner.
7. Decide licensed content sources, allowed storage/derivative use, and provenance display.
8. Set MVP content volume, launch date, availability/latency targets, device/low-bandwidth support, and success metrics.
9. Define localization scope, accessibility conformance target, and UI visual direction.
10. Confirm hosting, backup/recovery objectives (RPO/RTO), health/alert signals and owner, incident contacts, observability, and operational owner.
11. Decide offline capability. Until then, no answer-write queue or offline submission is in scope; any cached read-only mode needs explicit approval and tests.

## Milestones and completion conditions

> The M0–M7 descriptions below are the original Phase 0 milestone design. Current milestone ordering/status is maintained in `PLANS.md`; this historical sequence is retained as a record, not a claim that those gates currently pass.

### M0 — Phase 0 discovery (historical gate)

Complete when all ten requested docs exist; diagrams/maps/wireframes, migration strategy, API inventory, threat model, acceptance criteria, milestones and risks are reviewable; AGY has returned an independent evidence-based review; findings are addressed or explicitly accepted; the project owner resolves blocking decisions or records them as gated; the project owner approves Phase 1 scope. No product implementation in this milestone.

### M1 — Product and source lock

Complete when owner selects initial curriculum/content sources and rights, verified exam structures by year/subject or explicitly scopes a non-official practice MVP, selects question types/scoring, account/privacy policies, and measurable pilot success criteria. Evidence: approved decision records and representative content fixtures.

### M2 — Technical foundation

Complete when React/Vite/TypeScript and FastAPI/PostgreSQL foundations are established, CI and migrations work from clean and upgrade paths, auth/tenant authorization is proven with two-user tests, and audit conventions are enforced. No content claims until M1 evidence exists.

### M3 — Source management, question verification and publishing gate

Complete when source provenance/licensing is recorded; editors can draft question versions; authorized humans independently review exact content hashes, answer keys and scoring; AI-generated questions remain drafts until this gate; publication is audited and immutable. Blueprint authoring may proceed in parallel but cannot publish official claims without reviewed sources.

### M4 — Versioned blueprint and exam engine

Complete when approved blueprints bind exact question versions and the exam engine supports server-authoritative timing, idempotent submission, event cutoff, recovery, network retries, answer-key protection and owner-approved traffic objectives.

### M5 — Practice, event history, deterministic scoring

Complete when exam and topic-practice sessions pin immutable items, answers append idempotently, objective scoring is reproducible, and partial/unanswered behavior follows approved scoring policy. AI outage does not impair core flows.

### M6 — Learning intelligence and governed AI

Complete when actual-data evaluation compares heuristic, BKT, IRT, and FSRS fit/limitations; owner approves a method/threshold or transparent abstaining baseline; AI tools, output validation, privacy, and human content verification pass acceptance.

### M7 — Pilot readiness

Complete when accessibility/responsive/security gates, owner-approved operational targets, health/alert and backup-restore evidence, retention/privacy approvals, content-rights approvals, end-to-end flows, and owner pilot checklist pass. Pilot scope and rollback plan are signed off.

## Risk register

| Risk | Likelihood / impact | Early evidence | Mitigation / owner |
|---|---|---|---|
| Wrong or changing exam assumptions | High / high | No approved source/version for 2027 | Keep format configurable; require source/reviewer; owner resolves before official claims |
| Content rights unclear | Medium / high | Missing license/provenance | Block publication without evidence; owner/legal review |
| Cross-user data exposure | Medium / critical | Unscoped queries or client-supplied owner IDs | Central auth policy, DB constraints/RLS review, two-user negative tests |
| Historical score drift | Medium / high | Mutable answer/version rows or scoring code | Immutable records, algorithm version/hash, regression fixtures |
| AI changes trusted data or leaks content | Medium / high | Broad tool/db access or provider sends PII | Allowlisted read-only tools, data minimization, provider approval, adversarial tests |
| Unverified content mistaken as official | Medium / high | Missing evidence/status separation | Separate status/source model, UI/API labels, editorial gate |
| Scope expansion across subjects/curricula | High / medium | Subject-specific conditionals proliferate | Configurable taxonomy and module contracts; add curricula through data-backed test cases |
| Offline sync duplicates/conflicts | Medium / medium | Queued answer writes before conflict policy | Defer write sync; require idempotency and ordering design |
| AI provider outage/cost volatility | High / medium | Increased latency/errors/cost | Core flow isolation, budgets/timeouts, fallback and observability |
| Privacy obligations unresolved | Medium / critical | Real learner data collected before policy | Synthetic data until approval; qualified privacy review and retention plan |
| No Git baseline | Confirmed / medium | Workspace root has no `.git` | Establish version control and review workflow before Phase 1 changes |
