import assert from 'node:assert/strict';
import test from 'node:test';
import { previewImportPackage } from './preview';
import type { QuestionImportPackage } from './schema';

test('WP2-IMPORT: previewImportPackage validates clean package and marks eligible only with valid review and license', () => {
  const pkg: QuestionImportPackage = {
    packageId: 'pkg-math-grade12-01',
    version: '1.0.0',
    createdAt: '2026-11-09T00:00:00.000Z',
    curriculumVersionId: 'gdpt-2018-math-v1',
    subjectId: 'math',
    reviewerRegistry: [{
      reviewerId: 'prof-math-01',
      authorizedSubjectIds: ['math'],
      authorizedCurriculumVersionIds: ['gdpt-2018-math-v1'],
      validFrom: '2026-01-01T00:00:00.000Z',
      validThrough: '2027-01-01T00:00:00.000Z',
      status: 'active',
    }],
    items: [
      {
        id: 'q-imp-01',
        version: 1,
        curriculumVersionId: 'gdpt-2018-math-v1',
        skillIds: ['math12-der-mono'],
        body: {
          kind: 'MCQ_SINGLE',
          prompt: 'Cho hàm số y = f(x) có đạo hàm f\'(x) = x^2 - 1. Hàm số đồng biến trên khoảng nào?',
          options: [
            { id: 'A', text: '(1; +∞)' },
            { id: 'B', text: '(-1; 1)' },
            { id: 'C', text: '(-∞; 0)' },
            { id: 'D', text: '(0; 1)' },
          ],
          correctOptionId: 'A',
        },
        solution: {
          id: 'sol-imp-01',
          explanation: 'Ta có f\'(x) > 0 <=> x^2 - 1 > 0 <=> x > 1 hoặc x < -1. Do đó hàm số đồng biến trên (1; +∞).',
          steps: ['Giải bất phương trình f\'(x) > 0', 'Kết luận khoảng đồng biến'],
        },
        sourceAssets: [{
          id: 'sa-01',
          provenanceKind: 'original',
          reference: 'Bộ đề ôn tập GDPT 2018 Toán 12',
        }],
        licenses: [{
          id: 'lic-01',
          status: 'original',
          validThrough: null,
          allowedOperations: ['practice', 'publish'],
        }],
      },
    ],
  };

  // Preview without review: valid draft, but not yet eligible for publication
  const reportDraft = previewImportPackage(pkg);
  assert.equal(reportDraft.totalItems, 1);
  assert.equal(reportDraft.validItems, 1);
  assert.equal(reportDraft.invalidItems, 0);
  assert.equal(reportDraft.eligibleForPublicationCount, 0);
  assert.equal(reportDraft.items[0].valid, true);
  assert.equal(reportDraft.items[0].status, 'draft');
  assert.equal(reportDraft.items[0].eligibleForPublication, false);
  assert.ok(reportDraft.items[0].computedContentHash?.startsWith('sha256:'));

  // Attach matching review to make it eligible for publication preview
  const computedHash = reportDraft.items[0].computedContentHash!;
  const pkgWithReview: QuestionImportPackage = {
    ...pkg,
    items: [{
      ...pkg.items[0],
      review: {
        id: 'rev-01',
        questionId: 'q-imp-01',
        questionVersion: 1,
        reviewedContentHash: computedHash,
        decision: 'approved',
        reviewerId: 'prof-math-01',
        reviewedAt: '2026-11-09T01:00:00.000Z',
      },
    }],
  };

  const reportApproved = previewImportPackage(pkgWithReview);
  assert.equal(reportApproved.validItems, 1);
  assert.equal(reportApproved.eligibleForPublicationCount, 1);
  assert.equal(reportApproved.items[0].eligibleForPublication, true);
  assert.equal(reportApproved.items[0].status, 'in_review');
});

test('WP2-IMPORT: previewImportPackage detects malformed questions, missing explanations, and duplicate IDs', () => {
  const badPkg: QuestionImportPackage = {
    packageId: 'pkg-bad-01',
    version: '1.0.0',
    createdAt: '2026-11-09T00:00:00.000Z',
    curriculumVersionId: 'gdpt-2018-math-v1',
    subjectId: 'math',
    items: [
      // 1. MCQ with only 3 options (violates 4 options invariant)
      {
        id: 'q-dup-1',
        curriculumVersionId: 'gdpt-2018-math-v1',
        skillIds: ['math12-der-mono'],
        body: {
          kind: 'MCQ_SINGLE',
          prompt: 'Bad MCQ',
          options: [
            { id: 'A', text: 'Opt A' },
            { id: 'B', text: 'Opt B' },
            { id: 'C', text: 'Opt C' },
          ],
          correctOptionId: 'A',
        } as any,
        solution: {
          id: 'sol-1',
          explanation: 'Some explanation',
        },
        sourceAssets: [{ id: 'sa-1', provenanceKind: 'original', reference: 'ref-1' }],
        licenses: [{ id: 'lic-1', status: 'original', validThrough: null }],
      },
      // 2. Duplicate ID + empty solution explanation
      {
        id: 'q-dup-1',
        curriculumVersionId: 'gdpt-2018-math-v1',
        skillIds: ['math12-der-mono'],
        body: {
          kind: 'SHORT_NUMERIC',
          prompt: 'Numeric question',
          correctDecimal: '3.14',
        },
        solution: {
          id: 'sol-2',
          explanation: '   ', // whitespace only
        },
        sourceAssets: [{ id: 'sa-2', provenanceKind: 'synthetic', reference: 'ref-2' }],
        licenses: [{ id: 'lic-2', status: 'original', validThrough: null }],
      },
    ],
  };

  const existingIds = new Set(['q-already-in-db']);
  const report = previewImportPackage(badPkg, { existingQuestionIds: existingIds });

  assert.equal(report.totalItems, 2);
  assert.equal(report.validItems, 0);
  assert.equal(report.invalidItems, 2);

  // Item 1 failed on 4 options
  assert.match(report.items[0].errors.join('; '), /exactly 4 options/);

  // Item 2 failed on duplicate ID and whitespace explanation
  assert.match(report.items[1].errors.join('; '), /Duplicate question id 'q-dup-1'/);
  assert.match(report.items[1].errors.join('; '), /must be a non-empty string/);
});
