import type { QuestionBody } from '../../domain/math/question';
import type { SourceAsset, LicenseRecord, ReviewRecord } from '../../domain/math/provenance';
import type { ReviewerAuthorizationEvidence } from '../../domain/math/content-validation/validator';

export interface QuestionImportItem {
  readonly id: string;
  readonly version?: number;
  readonly curriculumVersionId: string;
  readonly skillIds: readonly string[];
  readonly body: QuestionBody;
  readonly solution: {
    readonly id: string;
    readonly explanation: string;
    readonly steps?: readonly string[];
    readonly keyPoints?: readonly string[];
  };
  readonly sourceAssets: readonly SourceAsset[];
  readonly licenses: readonly LicenseRecord[];
  readonly review?: ReviewRecord;
  readonly reviewerEvidence?: ReviewerAuthorizationEvidence;
  readonly status?: 'draft' | 'in_review';
}

export interface QuestionImportPackage {
  readonly packageId: string;
  readonly version: string;
  readonly createdAt: string;
  readonly createdBy?: string;
  readonly curriculumVersionId: string;
  readonly subjectId: string;
  readonly items: readonly QuestionImportItem[];
  readonly reviewerRegistry?: readonly ReviewerAuthorizationEvidence[];
}

export interface ItemPreviewResult {
  readonly itemId: string;
  readonly valid: boolean;
  readonly eligibleForPublication: boolean;
  readonly status: 'draft' | 'in_review';
  readonly computedContentHash?: string;
  readonly errors: readonly string[];
  readonly warnings: readonly string[];
  readonly promptSnippet?: string;
}

export interface ImportPreviewReport {
  readonly packageId: string;
  readonly totalItems: number;
  readonly validItems: number;
  readonly invalidItems: number;
  readonly eligibleForPublicationCount: number;
  readonly items: readonly ItemPreviewResult[];
  readonly globalErrors: readonly string[];
}
