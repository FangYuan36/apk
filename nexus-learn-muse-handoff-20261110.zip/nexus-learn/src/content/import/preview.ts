import { validateQuestionBody } from '../../domain/math/question';
import { isLicenseValidAt } from '../../domain/math/provenance';
import {
  computeQuestionContentHash,
  validateReviewerAuthorization,
  type ReviewerAuthorizationEvidence,
} from '../../domain/math/content-validation/validator';
import type {
  QuestionImportPackage,
  QuestionImportItem,
  ItemPreviewResult,
  ImportPreviewReport,
} from './schema';

const ALLOWED_PROVENANCE_KINDS = new Set(['original', 'synthetic', 'reference', 'licensed']);
const ALLOWED_LICENSE_STATUSES = new Set(['original', 'licensed', 'open']);

export function previewImportPackage(
  pkg: QuestionImportPackage,
  context?: {
    readonly existingQuestionIds?: ReadonlySet<string>;
    readonly existingContentHashes?: ReadonlySet<string>;
    readonly now?: string;
    readonly trustedReviewerRegistry?: readonly ReviewerAuthorizationEvidence[];
  },
): ImportPreviewReport {
  const globalErrors: string[] = [];

  if (!pkg || typeof pkg !== 'object') {
    return {
      packageId: 'unknown',
      totalItems: 0,
      validItems: 0,
      invalidItems: 0,
      eligibleForPublicationCount: 0,
      items: [],
      globalErrors: ['Import package must be a non-null object'],
    };
  }

  if (!pkg.packageId || typeof pkg.packageId !== 'string' || !pkg.packageId.trim()) {
    globalErrors.push('Import package must have a non-empty packageId');
  }
  if (!pkg.curriculumVersionId || typeof pkg.curriculumVersionId !== 'string' || !pkg.curriculumVersionId.trim()) {
    globalErrors.push('Import package must have a non-empty curriculumVersionId');
  }
  if (Array.isArray(pkg.reviewerRegistry) && pkg.reviewerRegistry.length > 0) {
    globalErrors.push(
      'Self-asserted reviewerRegistry inside package payload is rejected; reviewer authority must be injected by host system',
    );
  }
  if (!Array.isArray(pkg.items)) {
    globalErrors.push('Import package items must be an array');
    return {
      packageId: pkg.packageId || 'unknown',
      totalItems: 0,
      validItems: 0,
      invalidItems: 0,
      eligibleForPublicationCount: 0,
      items: [],
      globalErrors,
    };
  }

  const seenIds = new Set<string>();
  const seenHashes = new Set<string>();
  const existingIds = context?.existingQuestionIds || new Set<string>();
  const existingHashes = context?.existingContentHashes || new Set<string>();
  const referenceTime = context?.now || pkg.createdAt || new Date().toISOString();
  const trustedReviewerRegistry = context?.trustedReviewerRegistry;

  const itemResults: ItemPreviewResult[] = pkg.items.map((item, idx) => {
    return previewImportItem(item, idx, {
      pkg,
      seenIds,
      seenHashes,
      existingIds,
      existingHashes,
      referenceTime,
      trustedReviewerRegistry,
    });
  });

  const validItems = itemResults.filter((r) => r.valid).length;
  const invalidItems = itemResults.length - validItems;
  const eligibleForPublicationCount = itemResults.filter((r) => r.eligibleForPublication).length;

  return {
    packageId: pkg.packageId || 'unknown',
    totalItems: itemResults.length,
    validItems,
    invalidItems,
    eligibleForPublicationCount,
    items: Object.freeze(itemResults),
    globalErrors: Object.freeze(globalErrors),
  };
}

function previewImportItem(
  item: QuestionImportItem,
  index: number,
  ctx: {
    readonly pkg: QuestionImportPackage;
    readonly seenIds: Set<string>;
    readonly seenHashes: Set<string>;
    readonly existingIds: ReadonlySet<string>;
    readonly existingHashes: ReadonlySet<string>;
    readonly referenceTime: string;
    readonly trustedReviewerRegistry?: readonly ReviewerAuthorizationEvidence[];
  },
): ItemPreviewResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!item || typeof item !== 'object') {
    return {
      itemId: `item-${index}`,
      valid: false,
      eligibleForPublication: false,
      status: 'draft',
      errors: ['Item must be a non-null object'],
      warnings: [],
    };
  }

  // 1. Identity & uniqueness
  const rawId = typeof item.id === 'string' ? item.id : '';
  const trimmedId = rawId.trim();
  if (!trimmedId) {
    errors.push('Item id must be a non-empty string');
  } else {
    if (ctx.seenIds.has(trimmedId)) {
      errors.push(`Duplicate question id '${trimmedId}' found within this import package`);
    } else {
      ctx.seenIds.add(trimmedId);
    }
    if (ctx.existingIds.has(trimmedId)) {
      errors.push(`Question id '${trimmedId}' already exists in repository`);
    }
  }

  // 2. Curriculum & Skill mapping
  if (item.curriculumVersionId !== ctx.pkg.curriculumVersionId) {
    errors.push(
      `Item curriculumVersionId '${item.curriculumVersionId}' does not match package '${ctx.pkg.curriculumVersionId}'`,
    );
  }
  if (!Array.isArray(item.skillIds) || item.skillIds.length === 0) {
    errors.push('Item must map to at least one skillId');
  }

  // 3. Question Body
  let promptSnippet: string | undefined;
  if (!item.body) {
    errors.push('Item body is missing');
  } else {
    const bodyRes = validateQuestionBody(item.body);
    if (!bodyRes.valid) {
      errors.push(...bodyRes.errors);
    }
    if (typeof item.body.prompt === 'string') {
      promptSnippet = item.body.prompt.slice(0, 80);
    }
  }

  // 4. Solution
  if (!item.solution) {
    errors.push('Item solution is missing');
  } else {
    if (!item.solution.id?.trim()) {
      errors.push('Solution id must be non-empty');
    }
    if (typeof item.solution.explanation !== 'string' || !item.solution.explanation.trim()) {
      errors.push('Solution explanation must be a non-empty string');
    }
  }

  // 5. Source Assets
  if (!Array.isArray(item.sourceAssets) || item.sourceAssets.length === 0) {
    errors.push('Item must specify at least one sourceAsset');
  } else {
    for (const sa of item.sourceAssets) {
      if (!sa.id?.trim()) errors.push('SourceAsset id must be non-empty');
      if (!ALLOWED_PROVENANCE_KINDS.has(sa.provenanceKind)) {
        errors.push(`Disallowed or unknown provenanceKind: '${sa.provenanceKind}'`);
      }
      if (!sa.reference?.trim()) {
        errors.push(`SourceAsset '${sa.id}' reference must be non-empty`);
      }
    }
  }

  // 6. Licenses
  let licenseValidForPublish = false;
  if (!Array.isArray(item.licenses) || item.licenses.length === 0) {
    errors.push('Item must specify at least one license record');
  } else {
    for (const lic of item.licenses) {
      if (!lic.id?.trim()) errors.push('License id must be non-empty');
      if (!ALLOWED_LICENSE_STATUSES.has(lic.status)) {
        errors.push(`Disallowed license status: '${lic.status}'`);
      }
      const canPublish = isLicenseValidAt(lic, ctx.referenceTime, 'publish') && lic.commercialUseAllowed === true;
      if (canPublish) {
        licenseValidForPublish = true;
      }
    }
  }

  // 7. Compute canonical content hash
  let computedHash: string | undefined;
  if (errors.length === 0 && item.body && item.solution) {
    computedHash = computeQuestionContentHash({
      questionId: trimmedId,
      version: item.version || 1,
      body: item.body,
      curriculumVersionId: item.curriculumVersionId,
      skillIds: item.skillIds,
      solutionVersionId: item.solution.id,
      solution: {
        id: item.solution.id,
        explanation: item.solution.explanation,
        ...(item.solution.steps ? { steps: item.solution.steps } : {}),
        ...(item.solution.keyPoints ? { keyPoints: item.solution.keyPoints } : {}),
      },
    });

    if (ctx.seenHashes.has(computedHash)) {
      warnings.push(`Duplicate content hash '${computedHash}' detected within package (duplicate content)`);
    } else {
      ctx.seenHashes.add(computedHash);
    }
    if (ctx.existingHashes.has(computedHash)) {
      warnings.push(`Content hash '${computedHash}' already exists in repository`);
    }
  }

  // 8. Reviewer evidence & publication eligibility
  let eligibleForPublication = false;
  if (computedHash && errors.length === 0 && item.review && licenseValidForPublish) {
    const rev = item.review;
    if (rev.decision === 'approved' && rev.reviewedContentHash === computedHash && rev.reviewerId?.trim()) {
      if (Array.isArray(ctx.pkg.reviewerRegistry) && ctx.pkg.reviewerRegistry.length > 0) {
        warnings.push('Import package supplied self-asserted reviewerRegistry; ignored for publication authority');
      }
      const auth = validateReviewerAuthorization(rev.reviewerId, {
        subjectId: ctx.pkg.subjectId,
        curriculumVersionId: item.curriculumVersionId,
        now: ctx.referenceTime,
        reviewerRegistry: ctx.trustedReviewerRegistry,
      });
      if (auth.authorized) {
        eligibleForPublication = true;
      } else {
        warnings.push(`Reviewer '${rev.reviewerId}' is not authorized: ${auth.errors.join('; ')}`);
      }
    } else {
      warnings.push('Review record is present but does not match computed hash or approved decision');
    }
  }

  // By design: all incoming imports default to 'draft' or 'in_review', never directly 'approved' / 'published'
  const importStatus: 'draft' | 'in_review' = item.review?.decision === 'approved' ? 'in_review' : 'draft';

  return {
    itemId: trimmedId || `item-${index}`,
    valid: errors.length === 0,
    eligibleForPublication,
    status: importStatus,
    computedContentHash: computedHash,
    errors: Object.freeze(errors),
    warnings: Object.freeze(warnings),
    promptSnippet,
  };
}
