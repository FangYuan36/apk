import type { QuestionItem, SkillMapping } from '../../domain/contracts';

export const sampleTaxonomy: SkillMapping = Object.freeze({
  subject: Object.freeze({
    id: 'math',
    curriculumVersionId: 'sample-curriculum-v1',
    name: 'Toán học',
  }),
  unit: Object.freeze({
    id: 'functions',
    subjectId: 'math',
    curriculumVersionId: 'sample-curriculum-v1',
    name: 'Hàm số',
  }),
  topic: Object.freeze({
    id: 'derivatives',
    subjectId: 'math',
    unitId: 'functions',
    curriculumVersionId: 'sample-curriculum-v1',
    name: 'Đạo hàm',
  }),
  skill: Object.freeze({
    id: 'sample-skill-derivative-sign',
    subjectId: 'math',
    unitId: 'functions',
    topicId: 'derivatives',
    curriculumVersionId: 'sample-curriculum-v1',
    name: 'Đọc dấu đạo hàm',
  }),
});

export const sampleQuestions: readonly QuestionItem[] = Object.freeze([
  Object.freeze({
    id: 'q-derivative-sign-diag-01',
    version: 1,
    subjectId: 'math',
    curriculumVersionId: 'sample-curriculum-v1',
    skillIds: Object.freeze(['sample-skill-derivative-sign']),
    questionType: 'multiple_choice',
    difficulty: 'introductory',
    prompt:
      "SAMPLE / TEST ONLY: Cho bảng xét dấu của đạo hàm f'(x): trên khoảng (-∞, 1) mang dấu (+), trên (1, 3) mang dấu (-), trên (3, +∞) mang dấu (+). Hàm số f(x) đồng biến trên khoảng nào dưới đây?",
    options: Object.freeze([
      Object.freeze({
        id: 'A',
        text: '(1, 3)',
        distractorErrorTag: 'concept_gap',
        likelyMissingStep: 'Nhầm lẫn giữa dấu âm (-) và tính đồng biến của hàm số (f\'(x) > 0 mới là đồng biến).',
      }),
      Object.freeze({
        id: 'B',
        text: '(-∞, 1)',
        distractorErrorTag: undefined,
        likelyMissingStep: undefined,
      }),
      Object.freeze({
        id: 'C',
        text: '(1, +∞)',
        distractorErrorTag: 'misread_condition',
        likelyMissingStep: 'Đọc thiếu điểm x = 3; f\'(x) đổi dấu qua 3 nên không đồng biến trên toàn bộ (1, +∞).',
      }),
      Object.freeze({
        id: 'D',
        text: '(-∞, 3)',
        distractorErrorTag: 'data_interpretation',
        likelyMissingStep: 'Gộp cả khoảng f\'(x) âm và dương trên bảng xét dấu đạo hàm.',
      }),
    ]),
    correctAnswer: 'B',
    explanation:
      "SAMPLE / TEST ONLY: Theo định lý về dấu đạo hàm, hàm số đồng biến trên khoảng mà f'(x) > 0. Dựa vào bảng xét dấu, f'(x) > 0 trên (-∞, 1) và (3, +∞). Do đó khoảng (-∞, 1) là đáp án đúng.",
    source: Object.freeze({
      kind: 'synthetic',
      reference: 'synthetic:nexus-sample-slice-v1',
      licenseStatus: 'synthetic',
    }),
    reviewStatus: 'sample_test_only',
  }),

  Object.freeze({
    id: 'q-derivative-sign-practice-01',
    version: 1,
    subjectId: 'math',
    curriculumVersionId: 'sample-curriculum-v1',
    skillIds: Object.freeze(['sample-skill-derivative-sign']),
    questionType: 'multiple_choice',
    difficulty: 'introductory',
    prompt:
      "SAMPLE / TEST ONLY: Cho hàm số y = f(x) có đạo hàm f'(x) xác định trên R. Bảng xét dấu cho biết: f'(x) < 0 với mọi x thuộc (-2, 4), và f'(x) > 0 với mọi x thuộc (-∞, -2) và (4, +∞). Hàm số nghịch biến trên khoảng nào?",
    options: Object.freeze([
      Object.freeze({
        id: 'A',
        text: '(-∞, -2)',
        distractorErrorTag: 'concept_gap',
        likelyMissingStep: 'Nhầm lẫn giữa f\'(x) > 0 và tính nghịch biến (nghịch biến yêu cầu f\'(x) < 0).',
      }),
      Object.freeze({
        id: 'B',
        text: '(4, +∞)',
        distractorErrorTag: 'misread_condition',
        likelyMissingStep: 'Chọn khoảng f\'(x) mang dấu dương thay vì yêu cầu nghịch biến (dấu âm).',
      }),
      Object.freeze({
        id: 'C',
        text: '(-2, 4)',
        distractorErrorTag: undefined,
        likelyMissingStep: undefined,
      }),
      Object.freeze({
        id: 'D',
        text: '(-2, +∞)',
        distractorErrorTag: 'data_interpretation',
        likelyMissingStep: 'Bỏ qua mốc x = 4 khiến f\'(x) đổi dấu từ âm sang dương.',
      }),
    ]),
    correctAnswer: 'C',
    explanation:
      "SAMPLE / TEST ONLY: Hàm số nghịch biến trên khoảng mà f'(x) < 0. Từ bảng xét dấu, f'(x) mang dấu âm (-) trên khoảng (-2, 4). Vậy hàm số nghịch biến trên khoảng (-2, 4).",
    source: Object.freeze({
      kind: 'synthetic',
      reference: 'synthetic:nexus-sample-slice-v1',
      licenseStatus: 'synthetic',
    }),
    reviewStatus: 'sample_test_only',
  }),

  Object.freeze({
    id: 'q-derivative-sign-practice-02',
    version: 1,
    subjectId: 'math',
    curriculumVersionId: 'sample-curriculum-v1',
    skillIds: Object.freeze(['sample-skill-derivative-sign']),
    questionType: 'multiple_choice',
    difficulty: 'intermediate',
    prompt:
      "SAMPLE / TEST ONLY: Cho bảng biến thiên của hàm số f(x). Hàng f'(x) có các số 0 tại x = -1 và x = 2; dấu của f'(x) là (-) trên (-1, 2) và (+) trên (-∞, -1) cùng (2, +∞). Khẳng định nào sau đây là đúng?",
    options: Object.freeze([
      Object.freeze({
        id: 'A',
        text: "f'(x) < 0 với mọi x thuộc (-1, 2)",
        distractorErrorTag: undefined,
        likelyMissingStep: undefined,
      }),
      Object.freeze({
        id: 'B',
        text: "f'(x) > 0 với mọi x thuộc (-1, 2)",
        distractorErrorTag: 'data_interpretation',
        likelyMissingStep: 'Đọc nhầm dấu (-) thành (+) tại dòng xét dấu f\'(x).',
      }),
      Object.freeze({
        id: 'C',
        text: "Hàm số đồng biến trên (-1, 2)",
        distractorErrorTag: 'concept_gap',
        likelyMissingStep: 'Nhầm rằng f\'(x) < 0 là hàm số đồng biến.',
      }),
      Object.freeze({
        id: 'D',
        text: "f'(x) đổi dấu từ (+) sang (-) khi qua x = 2",
        distractorErrorTag: 'misread_condition',
        likelyMissingStep: 'Đọc ngược chiều biến thiên của f\'(x) qua điểm x = 2.',
      }),
    ]),
    correctAnswer: 'A',
    explanation:
      "SAMPLE / TEST ONLY: Quan sát dòng f'(x) giữa hai mốc x = -1 và x = 2, dấu ghi là (-), tức f'(x) < 0 trên khoảng (-1, 2). Khẳng định A đúng.",
    source: Object.freeze({
      kind: 'synthetic',
      reference: 'synthetic:nexus-sample-slice-v1',
      licenseStatus: 'synthetic',
    }),
    reviewStatus: 'sample_test_only',
  }),

  Object.freeze({
    id: 'q-derivative-sign-recheck-01',
    version: 1,
    subjectId: 'math',
    curriculumVersionId: 'sample-curriculum-v1',
    skillIds: Object.freeze(['sample-skill-derivative-sign']),
    questionType: 'multiple_choice',
    difficulty: 'intermediate',
    prompt:
      "SAMPLE / TEST ONLY: [Kiểm tra lại sau] Cho đồ thị đạo hàm y = f'(x) cắt trục Ox tại x = -1 và x = 2. Phần đồ thị f'(x) nằm phía trên trục Ox ứng với x thuộc khoảng (-1, 2). Hỏi f'(x) > 0 trên khoảng nào?",
    options: Object.freeze([
      Object.freeze({
        id: 'A',
        text: '(-∞, -1)',
        distractorErrorTag: 'data_interpretation',
        likelyMissingStep: 'Phần đồ thị nằm phía dưới trục hoành Ox tương ứng với f\'(x) < 0, không phải > 0.',
      }),
      Object.freeze({
        id: 'B',
        text: '(-1, 2)',
        distractorErrorTag: undefined,
        likelyMissingStep: undefined,
      }),
      Object.freeze({
        id: 'C',
        text: '(2, +∞)',
        distractorErrorTag: 'misread_condition',
        likelyMissingStep: 'Chọn khoảng đồ thị f\'(x) nằm phía dưới trục Ox.',
      }),
      Object.freeze({
        id: 'D',
        text: '(-∞, 2)',
        distractorErrorTag: 'concept_gap',
        likelyMissingStep: 'Gộp cả phần đồ thị nằm trên và nằm dưới trục hoành.',
      }),
    ]),
    correctAnswer: 'B',
    explanation:
      "SAMPLE / TEST ONLY: Các điểm nằm phía trên trục Ox có tung độ dương (y > 0). Vì đồ thị là của y = f'(x), nên phần nằm trên Ox tương ứng với f'(x) > 0, tức khoảng (-1, 2).",
    source: Object.freeze({
      kind: 'synthetic',
      reference: 'synthetic:nexus-sample-slice-v1',
      licenseStatus: 'synthetic',
    }),
    reviewStatus: 'sample_test_only',
  }),
]);
