import type { QuestionVersion, SolutionVersion } from '../../domain/math/question';

export interface PilotQuestionItem {
  readonly version: QuestionVersion;
  readonly solution: SolutionVersion;
}

export const PILOT_CURRICULUM_ID = 'curriculum-math-12-gdpt2018';
export const PILOT_TOPIC_ID = 'topic-derivative-applications';

export const PILOT_SKILLS = [
  { id: 'skill-monotonicity', name: 'Xét tính đơn điệu của hàm số' },
  { id: 'skill-extrema', name: 'Tìm cực trị của hàm số' },
  { id: 'skill-min-max', name: 'Tìm giá trị lớn nhất, nhỏ nhất trên đoạn' },
  { id: 'skill-asymptotes', name: 'Xác định đường tiệm cận của đồ thị hàm số' },
] as const;

export const PILOT_QUESTIONS: readonly PilotQuestionItem[] = [
  // 1. MCQ 1 - Monotonicity of cubic function
  {
    version: {
      questionId: 'q-math-pilot-001',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-001-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-monotonicity'],
      sourceAssetIds: ['source-nexus-original-001'],
      licenseRecordIds: ['license-nexus-original-001'],
      solutionVersionId: 'sol-pilot-001-v1',
      body: {
        kind: 'MCQ_SINGLE',
        prompt: 'Hàm số $y = x^3 - 3x^2 + 2$ đồng biến trên khoảng nào dưới đây? (SAMPLE / TEST ONLY)',
        options: [
          {
            id: 'A',
            text: '$(0; 2)$',
            diagnosticHypothesis: {
              tag: 'nham_khoang_nghich_bien',
              likelyMissingStep: 'Chưa đổi dấu của đạo hàm khi xác định khoảng đồng biến',
              explanation: 'Trên khoảng $(0; 2)$, $y\' = 3x(x-2) < 0$ nên hàm số nghịch biến.',
              isHypothesis: true,
            },
          },
          { id: 'B', text: '$(2; +\\infty)$' },
          {
            id: 'C',
            text: '$(-\\infty; 2)$',
            diagnosticHypothesis: {
              tag: 'hop_khoang_sai',
              likelyMissingStep: 'Gộp nhầm khoảng không liên tục của dấu đạo hàm',
              explanation: 'Đạo hàm đổi dấu tại $x = 0$, không thể đồng biến trên toàn khoảng $(-\\infty; 2)$.',
              isHypothesis: true,
            },
          },
          {
            id: 'D',
            text: '$\\mathbb{R}$',
            diagnosticHypothesis: {
              tag: 'bo_qua_nghiem_dao_ham',
              likelyMissingStep: 'Không giải phương trình $y\' = 0$',
              explanation: 'Hàm bậc ba có hai điểm cực trị nên không thể đồng biến trên $\\mathbb{R}$.',
              isHypothesis: true,
            },
          },
        ],
        correctOptionId: 'B',
      },
    },
    solution: {
      id: 'sol-pilot-001-v1',
      questionId: 'q-math-pilot-001',
      questionVersion: 1,
      explanation: 'Ta có $y\' = 3x^2 - 6x = 3x(x - 2)$. Cho $y\' = 0 \\iff x = 0$ hoặc $x = 2$. Bảng xét dấu cho thấy $y\' > 0$ trên $(-\\infty; 0)$ và $(2; +\\infty)$. Do đó hàm số đồng biến trên $(2; +\\infty)$.',
      steps: [
        'Tính đạo hàm: $y\' = 3x^2 - 6x$.',
        'Giải phương trình $y\' = 0 \\iff 3x(x - 2) = 0 \\iff x = 0$ hoặc $x = 2$.',
        'Xét dấu $y\': y\' > 0 \\iff x \\in (-\\infty; 0) \\cup (2; +\\infty)$.',
        'Kết luận: Hàm số đồng biến trên $(2; +\\infty)$.',
      ],
    },
  },

  // 2. MCQ 2 - Rational function monotonicity
  {
    version: {
      questionId: 'q-math-pilot-002',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-002-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-monotonicity'],
      sourceAssetIds: ['source-nexus-original-002'],
      licenseRecordIds: ['license-nexus-original-002'],
      solutionVersionId: 'sol-pilot-002-v1',
      body: {
        kind: 'MCQ_SINGLE',
        prompt: 'Cho hàm số $y = \\frac{2x + 1}{x - 1}$. Mệnh đề nào sau đây đúng? (SAMPLE / TEST ONLY)',
        options: [
          {
            id: 'A',
            text: 'Hàm số đồng biến trên $\\mathbb{R} \\setminus \\{1\\}$',
            diagnosticHypothesis: {
              tag: 'sai_dieu_kien_dong_bien',
              likelyMissingStep: 'Dùng ký hiệu hiệu tập hợp $\\setminus$ thay vì từng khoảng',
              explanation: 'Tính đơn điệu chỉ xét trên từng khoảng xác định, không dùng ký hiệu $\\setminus$.',
              isHypothesis: true,
            },
          },
          { id: 'B', text: 'Hàm số nghịch biến trên từng khoảng $(-\\infty; 1)$ và $(1; +\\infty)$' },
          {
            id: 'C',
            text: 'Hàm số đồng biến trên từng khoảng $(-\\infty; 1)$ và $(1; +\\infty)$',
            diagnosticHypothesis: {
              tag: 'tinh_sai_dao_ham_phan_thuc',
              likelyMissingStep: 'Tính nhầm $ad - bc$ thành $2(-1) - 1(1)$ âm thành dương',
              explanation: 'Đạo hàm $y\' = \\frac{-3}{(x-1)^2} < 0$, hàm số phải nghịch biến.',
              isHypothesis: true,
            },
          },
          {
            id: 'D',
            text: 'Hàm số nghịch biến trên $\\mathbb{R}$',
            diagnosticHypothesis: {
              tag: 'bo_qua_tap_xac_dinh',
              likelyMissingStep: 'Quên điều kiện xác định $x \\neq 1$',
              explanation: 'Hàm số không xác định tại $x = 1$ nên không thể nghịch biến trên $\\mathbb{R}$.',
              isHypothesis: true,
            },
          },
        ],
        correctOptionId: 'B',
      },
    },
    solution: {
      id: 'sol-pilot-002-v1',
      questionId: 'q-math-pilot-002',
      questionVersion: 1,
      explanation: 'Tập xác định $D = \\mathbb{R} \\setminus \\{1\\}$. Đạo hàm $y\' = \\frac{2(-1) - 1(1)}{(x-1)^2} = \\frac{-3}{(x-1)^2} < 0, \\forall x \\neq 1$. Do đó hàm số nghịch biến trên từng khoảng $(-\\infty; 1)$ và $(1; +\\infty)$.',
    },
  },

  // 3. MCQ 3 - Extrema count of quartic function
  {
    version: {
      questionId: 'q-math-pilot-003',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-003-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-extrema'],
      sourceAssetIds: ['source-nexus-original-003'],
      licenseRecordIds: ['license-nexus-original-003'],
      solutionVersionId: 'sol-pilot-003-v1',
      body: {
        kind: 'MCQ_SINGLE',
        prompt: 'Số điểm cực trị của hàm số $y = -x^4 + 2x^2 + 3$ là: (SAMPLE / TEST ONLY)',
        options: [
          { id: 'A', text: '1' },
          { id: 'B', text: '2' },
          { id: 'C', text: '3' },
          { id: 'D', text: '0' },
        ],
        correctOptionId: 'C',
      },
    },
    solution: {
      id: 'sol-pilot-003-v1',
      questionId: 'q-math-pilot-003',
      questionVersion: 1,
      explanation: 'Ta có $y\' = -4x^3 + 4x = -4x(x^2 - 1)$. $y\' = 0 \\iff x = 0$ hoặc $x = \\pm 1$. Vì $y\'$ đổi dấu qua cả ba nghiệm đơn này nên hàm số có đúng 3 điểm cực trị.',
    },
  },

  // 4. MCQ 4 - Vertical and Horizontal Asymptotes
  {
    version: {
      questionId: 'q-math-pilot-004',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-004-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-asymptotes'],
      sourceAssetIds: ['source-nexus-original-004'],
      licenseRecordIds: ['license-nexus-original-004'],
      solutionVersionId: 'sol-pilot-004-v1',
      body: {
        kind: 'MCQ_SINGLE',
        prompt: 'Đồ thị hàm số $y = \\frac{3x - 1}{x - 2}$ có đường tiệm cận đứng và tiệm cận ngang lần lượt là: (SAMPLE / TEST ONLY)',
        options: [
          { id: 'A', text: '$x = 2$ và $y = 3$' },
          { id: 'B', text: '$x = -2$ và $y = 3$' },
          { id: 'C', text: '$x = 2$ và $y = -1$' },
          { id: 'D', text: '$x = 3$ và $y = 2$' },
        ],
        correctOptionId: 'A',
      },
    },
    solution: {
      id: 'sol-pilot-004-v1',
      questionId: 'q-math-pilot-004',
      questionVersion: 1,
      explanation: 'Ta có $\\lim_{x \\to 2^+} y = +\\infty$ nên $x = 2$ là tiệm cận đứng. $\\lim_{x \\to \\pm\\infty} y = 3$ nên $y = 3$ là tiệm cận ngang.',
    },
  },

  // 5. MCQ 5 - Min/Max on Interval
  {
    version: {
      questionId: 'q-math-pilot-005',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-005-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-min-max'],
      sourceAssetIds: ['source-nexus-original-005'],
      licenseRecordIds: ['license-nexus-original-005'],
      solutionVersionId: 'sol-pilot-005-v1',
      body: {
        kind: 'MCQ_SINGLE',
        prompt: 'Giá trị nhỏ nhất của hàm số $f(x) = x + \\frac{4}{x}$ trên đoạn $[1; 3]$ bằng: (SAMPLE / TEST ONLY)',
        options: [
          { id: 'A', text: '5' },
          { id: 'B', text: '4' },
          { id: 'C', text: '$\\frac{13}{3}$' },
          { id: 'D', text: '2' },
        ],
        correctOptionId: 'B',
      },
    },
    solution: {
      id: 'sol-pilot-005-v1',
      questionId: 'q-math-pilot-005',
      questionVersion: 1,
      explanation: 'Ta có $f\'(x) = 1 - \\frac{4}{x^2} = \\frac{x^2 - 4}{x^2}$. Trên $[1; 3]$, $f\'(x) = 0 \\iff x = 2$. Tính $f(1) = 5, f(2) = 4, f(3) = \\frac{13}{3}$. Do đó $\\min_{[1; 3]} f(x) = f(2) = 4$.',
    },
  },

  // 6. MCQ 6 - Monotonicity with table
  {
    version: {
      questionId: 'q-math-pilot-006',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-006-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-monotonicity'],
      sourceAssetIds: ['source-nexus-original-006'],
      licenseRecordIds: ['license-nexus-original-006'],
      solutionVersionId: 'sol-pilot-006-v1',
      body: {
        kind: 'MCQ_SINGLE',
        prompt: 'Cho hàm số $y = f(x)$ có đạo hàm $f\'(x) = x(x - 1)^2 (x + 2)$. Hàm số đã cho nghịch biến trên khoảng nào? (SAMPLE / TEST ONLY)',
        options: [
          { id: 'A', text: '$(-2; 0)$' },
          { id: 'B', text: '$(0; 1)$' },
          { id: 'C', text: '$(1; +\\infty)$' },
          { id: 'D', text: '$(-\\infty; -2)$' },
        ],
        correctOptionId: 'A',
      },
    },
    solution: {
      id: 'sol-pilot-006-v1',
      questionId: 'q-math-pilot-006',
      questionVersion: 1,
      explanation: 'Nghiệm $x = 1$ là nghiệm bội chẵn nên $f\'(x)$ không đổi dấu qua $x = 1$. Dấu của $f\'(x)$ phụ thuộc vào tích $x(x + 2)$. Khi $x \\in (-2; 0)$, tích âm nên $f\'(x) < 0$. Do đó hàm số nghịch biến trên $(-2; 0)$.',
    },
  },

  // 7. TRUE_FALSE_CLUSTER 1 - Comprehensive Survey of Cubic Function
  {
    version: {
      questionId: 'q-math-pilot-007',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-007-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-monotonicity', 'skill-extrema'],
      sourceAssetIds: ['source-nexus-original-007'],
      licenseRecordIds: ['license-nexus-original-007'],
      solutionVersionId: 'sol-pilot-007-v1',
      body: {
        kind: 'TRUE_FALSE_CLUSTER',
        prompt: 'Cho hàm số $y = f(x) = x^3 - 3x^2 + 2$. Xét tính đúng/sai của các mệnh đề sau: (SAMPLE / TEST ONLY)',
        statements: [
          {
            id: 's1',
            prompt: 'Hàm số đồng biến trên khoảng $(2; +\\infty)$.',
            correctValue: true,
            skillIds: ['skill-monotonicity'],
          },
          {
            id: 's2',
            prompt: 'Hàm số đạt cực đại tại điểm $x = 2$.',
            correctValue: false,
            skillIds: ['skill-extrema'],
          },
          {
            id: 's3',
            prompt: 'Giá trị cực tiểu của hàm số bằng $-2$.',
            correctValue: true,
            skillIds: ['skill-extrema'],
          },
          {
            id: 's4',
            prompt: 'Hàm số có hai điểm cực trị nằm về cùng một phía đối với trục tung.',
            correctValue: false,
            skillIds: ['skill-extrema'],
          },
        ],
      },
    },
    solution: {
      id: 'sol-pilot-007-v1',
      questionId: 'q-math-pilot-007',
      questionVersion: 1,
      explanation: 'Đạo hàm $y\' = 3x^2 - 6x = 3x(x - 2)$. Điểm cực đại là $x = 0$ với giá trị $y(0) = 2$. Điểm cực tiểu là $x = 2$ với giá trị $y(2) = -2$. Điểm cực đại nằm trên trục tung ($x = 0$), không phải nằm về cùng một phía.',
    },
  },

  // 8. TRUE_FALSE_CLUSTER 2 - Asymptotes and Rational Function
  {
    version: {
      questionId: 'q-math-pilot-008',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-008-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-asymptotes', 'skill-monotonicity'],
      sourceAssetIds: ['source-nexus-original-008'],
      licenseRecordIds: ['license-nexus-original-008'],
      solutionVersionId: 'sol-pilot-008-v1',
      body: {
        kind: 'TRUE_FALSE_CLUSTER',
        prompt: 'Cho hàm số $y = \\frac{2x - 3}{x + 1}$. Xét tính đúng/sai của các mệnh đề sau: (SAMPLE / TEST ONLY)',
        statements: [
          {
            id: 's1',
            prompt: 'Đường thẳng $x = -1$ là tiệm cận đứng của đồ thị hàm số.',
            correctValue: true,
            skillIds: ['skill-asymptotes'],
          },
          {
            id: 's2',
            prompt: 'Đường thẳng $y = 2$ là tiệm cận ngang của đồ thị hàm số.',
            correctValue: true,
            skillIds: ['skill-asymptotes'],
          },
          {
            id: 's3',
            prompt: 'Hàm số đồng biến trên từng khoảng xác định.',
            correctValue: true,
            skillIds: ['skill-monotonicity'],
          },
          {
            id: 's4',
            prompt: 'Giao điểm hai đường tiệm cận có tọa độ là $(1; 2)$.',
            correctValue: false,
            skillIds: ['skill-asymptotes'],
          },
        ],
      },
    },
    solution: {
      id: 'sol-pilot-008-v1',
      questionId: 'q-math-pilot-008',
      questionVersion: 1,
      explanation: 'TCĐ: $x = -1$; TCN: $y = 2$. Giao điểm là $I(-1; 2)$, do đó mệnh đề d sai. $y\' = \\frac{5}{(x+1)^2} > 0$ nên hàm số đồng biến trên $(-\\infty; -1)$ và $(-1; +\\infty)$.',
    },
  },

  // 9. TRUE_FALSE_CLUSTER 3 - Min / Max Optimization
  {
    version: {
      questionId: 'q-math-pilot-009',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-009-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-min-max'],
      sourceAssetIds: ['source-nexus-original-009'],
      licenseRecordIds: ['license-nexus-original-009'],
      solutionVersionId: 'sol-pilot-009-v1',
      body: {
        kind: 'TRUE_FALSE_CLUSTER',
        prompt: 'Cho hàm số $f(x) = x^4 - 2x^2 + 5$ trên đoạn $[0; 2]$. Xét tính đúng/sai của các mệnh đề: (SAMPLE / TEST ONLY)',
        statements: [
          {
            id: 's1',
            prompt: 'Phương trình $f\'(x) = 0$ có đúng một nghiệm thuộc khoảng $(0; 2)$.',
            correctValue: true,
            skillIds: ['skill-min-max'],
          },
          {
            id: 's2',
            prompt: 'Giá trị nhỏ nhất của hàm số trên $[0; 2]$ bằng 4.',
            correctValue: true,
            skillIds: ['skill-min-max'],
          },
          {
            id: 's3',
            prompt: 'Giá trị lớn nhất của hàm số trên $[0; 2]$ bằng 5.',
            correctValue: false,
            skillIds: ['skill-min-max'],
          },
          {
            id: 's4',
            prompt: 'Hàm số đạt giá trị nhỏ nhất tại $x = 1$.',
            correctValue: true,
            skillIds: ['skill-min-max'],
          },
        ],
      },
    },
    solution: {
      id: 'sol-pilot-009-v1',
      questionId: 'q-math-pilot-009',
      questionVersion: 1,
      explanation: 'Ta có $f\'(x) = 4x^3 - 4x = 4x(x^2 - 1)$. Trên $(0; 2)$, nghiệm duy nhất là $x = 1$. $f(0) = 5, f(1) = 4, f(2) = 13$. Giá trị lớn nhất bằng 13 (tại $x = 2$), nhỏ nhất bằng 4 (tại $x = 1$).',
    },
  },

  // 10. TRUE_FALSE_CLUSTER 4 - Quartic Extrema Properties
  {
    version: {
      questionId: 'q-math-pilot-010',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-010-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-extrema'],
      sourceAssetIds: ['source-nexus-original-010'],
      licenseRecordIds: ['license-nexus-original-010'],
      solutionVersionId: 'sol-pilot-010-v1',
      body: {
        kind: 'TRUE_FALSE_CLUSTER',
        prompt: 'Cho hàm số $y = -x^4 + 2x^2 + 3$. Xét tính đúng/sai của các khẳng định sau: (SAMPLE / TEST ONLY)',
        statements: [
          {
            id: 's1',
            prompt: 'Đồ thị hàm số có 3 điểm cực trị tạo thành một tam giác cân.',
            correctValue: true,
            skillIds: ['skill-extrema'],
          },
          {
            id: 's2',
            prompt: 'Điểm cực tiểu của đồ thị hàm số là gốc tọa độ $O(0; 0)$.',
            correctValue: false,
            skillIds: ['skill-extrema'],
          },
          {
            id: 's3',
            prompt: 'Hàm số có hai điểm cực đại là $x = -1$ và $x = 1$.',
            correctValue: true,
            skillIds: ['skill-extrema'],
          },
          {
            id: 's4',
            prompt: 'Giá trị cực đại của hàm số là 4.',
            correctValue: true,
            skillIds: ['skill-extrema'],
          },
        ],
      },
    },
    solution: {
      id: 'sol-pilot-010-v1',
      questionId: 'q-math-pilot-010',
      questionVersion: 1,
      explanation: 'Điểm cực tiểu là $A(0; 3)$, hai điểm cực đại là $B(-1; 4)$ và $C(1; 4)$. Tam giác $ABC$ cân tại $A$.',
    },
  },

  // 11. TRUE_FALSE_CLUSTER 5 - Derivative sign and variation table
  {
    version: {
      questionId: 'q-math-pilot-011',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-011-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-monotonicity'],
      sourceAssetIds: ['source-nexus-original-011'],
      licenseRecordIds: ['license-nexus-original-011'],
      solutionVersionId: 'sol-pilot-011-v1',
      body: {
        kind: 'TRUE_FALSE_CLUSTER',
        prompt: 'Cho hàm số $y = f(x)$ xác định trên $\\mathbb{R} \\setminus \\{0\\}$ có bảng xét dấu $f\'(x)$ như sau: $f\'(x) > 0$ trên $(-\\infty; -1)$ và $(2; +\\infty)$, $f\'(x) < 0$ trên $(-1; 0)$ và $(0; 2)$. Xét tính đúng/sai: (SAMPLE / TEST ONLY)',
        statements: [
          {
            id: 's1',
            prompt: 'Hàm số đồng biến trên khoảng $(-\\infty; -1)$.',
            correctValue: true,
            skillIds: ['skill-monotonicity'],
          },
          {
            id: 's2',
            prompt: 'Hàm số nghịch biến trên khoảng $(-1; 2)$.',
            correctValue: false,
            skillIds: ['skill-monotonicity'],
          },
          {
            id: 's3',
            prompt: 'Hàm số đạt cực đại tại $x = -1$.',
            correctValue: true,
            skillIds: ['skill-monotonicity'],
          },
          {
            id: 's4',
            prompt: 'Hàm số đạt cực tiểu tại $x = 2$.',
            correctValue: true,
            skillIds: ['skill-monotonicity'],
          },
        ],
      },
    },
    solution: {
      id: 'sol-pilot-011-v1',
      questionId: 'q-math-pilot-011',
      questionVersion: 1,
      explanation: 'Hàm số không xác định tại $x = 0$ nên không nghịch biến trên toàn khoảng $(-1; 2)$, mà nghịch biến trên từng khoảng $(-1; 0)$ và $(0; 2)$.',
    },
  },

  // 12. SHORT_NUMERIC 1 - Local minimum value
  {
    version: {
      questionId: 'q-math-pilot-012',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-012-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-extrema'],
      sourceAssetIds: ['source-nexus-original-012'],
      licenseRecordIds: ['license-nexus-original-012'],
      solutionVersionId: 'sol-pilot-012-v1',
      body: {
        kind: 'SHORT_NUMERIC',
        prompt: 'Tìm giá trị cực tiểu của hàm số $y = x^3 - 3x^2 + 2$. Nhập số nguyên hoặc số thập phân chuẩn. (SAMPLE / TEST ONLY)',
        correctDecimal: '-2',
      },
    },
    solution: {
      id: 'sol-pilot-012-v1',
      questionId: 'q-math-pilot-012',
      questionVersion: 1,
      explanation: '$y\' = 3x^2 - 6x = 0 \\iff x = 0$ hoặc $x = 2$. $y\'$ đổi dấu từ âm sang dương tại $x = 2$, suy ra điểm cực tiểu là $x = 2$. Giá trị cực tiểu $y(2) = 2^3 - 3(2^2) + 2 = -2$.',
    },
  },

  // 13. SHORT_NUMERIC 2 - Min value on interval
  {
    version: {
      questionId: 'q-math-pilot-013',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-013-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-min-max'],
      sourceAssetIds: ['source-nexus-original-013'],
      licenseRecordIds: ['license-nexus-original-013'],
      solutionVersionId: 'sol-pilot-013-v1',
      body: {
        kind: 'SHORT_NUMERIC',
        prompt: 'Tìm giá trị nhỏ nhất của hàm số $y = x + \\frac{4}{x}$ trên đoạn $[1; 3]$. Nhập kết quả dưới dạng số: (SAMPLE / TEST ONLY)',
        correctDecimal: '4',
      },
    },
    solution: {
      id: 'sol-pilot-013-v1',
      questionId: 'q-math-pilot-013',
      questionVersion: 1,
      explanation: '$y\' = 1 - \\frac{4}{x^2} = 0 \\iff x = 2 \\in [1; 3]$. So sánh $y(1) = 5, y(2) = 4, y(3) = 13/3$, ta được giá trị nhỏ nhất bằng 4.',
    },
  },

  // 14. SHORT_NUMERIC 3 - Point of local maximum
  {
    version: {
      questionId: 'q-math-pilot-014',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-014-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-extrema'],
      sourceAssetIds: ['source-nexus-original-014'],
      licenseRecordIds: ['license-nexus-original-014'],
      solutionVersionId: 'sol-pilot-014-v1',
      body: {
        kind: 'SHORT_NUMERIC',
        prompt: 'Tìm điểm cực đại $x_0$ của hàm số $y = -x^3 + 3x + 1$: (SAMPLE / TEST ONLY)',
        correctDecimal: '1',
      },
    },
    solution: {
      id: 'sol-pilot-014-v1',
      questionId: 'q-math-pilot-014',
      questionVersion: 1,
      explanation: '$y\' = -3x^2 + 3 = -3(x-1)(x+1) = 0 \\iff x = \\pm 1$. Đạo hàm đổi dấu từ dương sang âm tại $x = 1$. Do đó điểm cực đại là $x = 1$.',
    },
  },

  // 15. SHORT_NUMERIC 4 - Tangent slope
  {
    version: {
      questionId: 'q-math-pilot-015',
      version: 1,
      status: 'draft',
      contentHash: 'sha256:pilot-015-v1',
      curriculumVersionId: PILOT_CURRICULUM_ID,
      skillIds: ['skill-monotonicity'],
      sourceAssetIds: ['source-nexus-original-015'],
      licenseRecordIds: ['license-nexus-original-015'],
      solutionVersionId: 'sol-pilot-015-v1',
      body: {
        kind: 'SHORT_NUMERIC',
        prompt: 'Tìm hệ số góc tiếp tuyến của đồ thị hàm số $y = \\frac{2x+1}{x-1}$ tại điểm có hoành độ $x = 2$: (SAMPLE / TEST ONLY)',
        correctDecimal: '-3',
      },
    },
    solution: {
      id: 'sol-pilot-015-v1',
      questionId: 'q-math-pilot-015',
      questionVersion: 1,
      explanation: '$y\' = \\frac{-3}{(x-1)^2}$. Tại $x = 2$, hệ số góc tiếp tuyến là $k = y\'(2) = \\frac{-3}{(2-1)^2} = -3$.',
    },
  },
];
