import { useEffect, useState, useMemo, useCallback } from 'react';
import { MathRenderer } from '../../components/math/MathRenderer';
import {
  scoreQuestionVersion,
  type ScoreResult,
} from '../../domain/math/scoring/scorer';
import {
  createAttemptEvent,
  type AttemptEvent,
  type AttemptResponse,
} from '../../domain/math/attempt';
import {
  PILOT_QUESTIONS,
  PILOT_SKILLS,
  type PilotQuestionItem,
} from '../../content/math/derivative-applications';
import {
  createPersistenceRepository,
  type PersistenceRepository,
} from '../../infrastructure/persistence/indexeddb/indexeddbRepository';
import type { StoredReviewSchedule, PracticeSession } from '../../domain/persistence/types';

export interface AppClock {
  readonly now: () => string;
  readonly advanceByMs?: (ms: number) => void;
}

const DEFAULT_CLOCK: AppClock = {
  now: () => new Date().toISOString(),
};

export const DEFAULT_SCORING_POLICY = {
  id: 'standard-practice-policy-v1',
  version: 1,
  status: 'proposed' as const,
  description: 'Chính sách chấm điểm thực hành đề xuất (PROPOSED) — chưa phải thang điểm thi chính thức',
  mcqSingle: { pointsCorrect: 1, pointsIncorrect: 0, pointsEmpty: 0 },
  trueFalseCluster: { pointsPerCorrectStatement: 1, pointsIncorrect: 0, pointsEmpty: 0, allCorrectBonus: 0 },
  shortNumeric: {
    pointsCorrect: 1,
    pointsIncorrect: 0,
    pointsEmpty: 0,
    absoluteTolerance: '0.01',
    relativeTolerance: '0',
    decimalSeparators: [',', '.'],
    groupingSeparators: [],
    allowExponent: true,
  },
};

export default function MathLearningView({
  repository: injectedRepo,
  clock = DEFAULT_CLOCK,
}: {
  readonly repository?: PersistenceRepository;
  readonly clock?: AppClock;
}) {
  const repo = useMemo(() => injectedRepo || createPersistenceRepository(), [injectedRepo]);

  // Skill & Question State
  const [selectedSkillId, setSelectedSkillId] = useState<string>('all');
  const [questionIndex, setQuestionIndex] = useState<number>(0);
  const [isRecheckMode, setIsRecheckMode] = useState<boolean>(false);
  const [recheckSessionId, setRecheckSessionId] = useState<string | null>(null);

  // User input states
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [tfAnswers, setTfAnswers] = useState<Record<string, boolean | null>>({});
  const [numericValue, setNumericValue] = useState<string>('');

  // Submission & Result states
  const [validationError, setValidationError] = useState<string | null>(null);
  const [scoreResult, setScoreResult] = useState<ScoreResult | null>(null);

  // Persistent History & Schedule
  const [history, setHistory] = useState<readonly AttemptEvent[]>([]);
  const [reviewSchedule, setReviewSchedule] = useState<StoredReviewSchedule | null>(null);
  const [storageNotification, setStorageNotification] = useState<string | null>(null);
  const [clockTick, setClockTick] = useState<number>(0);

  // Filter questions based on selected skill
  const availableQuestions = useMemo(() => {
    if (selectedSkillId === 'all') return PILOT_QUESTIONS;
    return PILOT_QUESTIONS.filter((q) => q.version.skillIds.includes(selectedSkillId));
  }, [selectedSkillId]);

  // In recheck mode, resolve the exact question referenced by the review schedule
  const recheckSourceRef = reviewSchedule?.sourceQuestionVersionRef;
  const recheckQuestionItem: PilotQuestionItem | null = useMemo(() => {
    if (!isRecheckMode || !reviewSchedule || !recheckSourceRef) return null;

    // 1. Resolve source attempt from history and confirm it points to the same question-version ref
    const sourceAttempt = history.find((e) => e.id === reviewSchedule.sourceAttemptId);
    if (!sourceAttempt) {
      return null;
    }
    if (
      sourceAttempt.questionVersionRef.questionId !== recheckSourceRef.questionId ||
      sourceAttempt.questionVersionRef.version !== recheckSourceRef.version ||
      sourceAttempt.questionVersionRef.contentHash !== recheckSourceRef.contentHash
    ) {
      return null;
    }

    // 2. Resolve question by questionId, version AND contentHash
    const found = PILOT_QUESTIONS.find(
      (q) =>
        q.version.questionId === recheckSourceRef.questionId &&
        q.version.version === recheckSourceRef.version &&
        q.version.contentHash === recheckSourceRef.contentHash,
    );
    if (!found) return null;

    // 3. Validate schedule skill, source attempt, and question mapping consistency
    if (!found.version.skillIds.includes(reviewSchedule.skillId)) {
      return null;
    }
    const sourceSkill = (reviewSchedule as any).sourceSkillId;
    if (sourceSkill && sourceSkill !== reviewSchedule.skillId) {
      return null;
    }

    return found;
  }, [isRecheckMode, reviewSchedule, recheckSourceRef, history]);

  const currentItem: PilotQuestionItem | undefined = isRecheckMode
    ? (recheckQuestionItem || undefined)
    : (availableQuestions[questionIndex] || availableQuestions[0]);

  // Refresh data from repository
  const refreshStorageData = useCallback(async () => {
    try {
      const events = await repo.getAttemptEvents();
      setHistory(events);
      if (selectedSkillId !== 'all') {
        const sched = await repo.getReviewSchedule(selectedSkillId);
        setReviewSchedule(sched);
      } else {
        setReviewSchedule(null);
      }
    } catch (err: unknown) {
      setStorageNotification(`Tải dữ liệu từ bộ nhớ thất bại: ${(err as Error).message}`);
    }
  }, [repo, selectedSkillId]);

  useEffect(() => {
    let active = true;
    if (active) refreshStorageData();
    return () => {
      active = false;
    };
  }, [refreshStorageData, clockTick]);

  // Reset inputs when switching question
  const resetInput = () => {
    setSelectedOptionId(null);
    setTfAnswers({});
    setNumericValue('');
    setValidationError(null);
    setScoreResult(null);
  };

  const handleSkillChange = (skillId: string) => {
    setSelectedSkillId(skillId);
    setQuestionIndex(0);
    setIsRecheckMode(false);
    setRecheckSessionId(null);
    resetInput();
  };

  const handleNextQuestion = () => {
    setQuestionIndex((prev) => (prev + 1) % availableQuestions.length);
    resetInput();
  };

  const handlePrevQuestion = () => {
    setQuestionIndex((prev) => (prev - 1 + availableQuestions.length) % availableQuestions.length);
    resetInput();
  };

  const handleSubmit = async () => {
    if (!currentItem) return;
    setValidationError(null);

    let response: AttemptResponse;
    const body = currentItem.version.body;

    if (body.kind === 'MCQ_SINGLE') {
      if (!selectedOptionId) {
        setValidationError('Vui lòng chọn một đáp án trước khi nộp bài.');
        return;
      }
      response = { kind: 'MCQ_SINGLE', optionId: selectedOptionId };
    } else if (body.kind === 'TRUE_FALSE_CLUSTER') {
      const answeredCount = Object.keys(tfAnswers).length;
      if (answeredCount < body.statements.length) {
        setValidationError('Vui lòng chọn Đúng hoặc Sai cho tất cả 4 mệnh đề.');
        return;
      }
      response = { kind: 'TRUE_FALSE_CLUSTER', answers: { ...tfAnswers } };
    } else {
      if (!numericValue.trim()) {
        setValidationError('Vui lòng nhập giá trị số trước khi nộp bài.');
        return;
      }
      response = { kind: 'SHORT_NUMERIC', value: numericValue.trim() };
    }

    // Pure domain scoring
    const result = scoreQuestionVersion(currentItem.version, response, DEFAULT_SCORING_POLICY);

    // High Requirement: Invalid Attempt Prevention
    // No invalid scoring result may create an AttemptEvent
    if (result.status === 'invalid') {
      setValidationError('Câu trả lời không hợp lệ hoặc sai định dạng. Không thể ghi nhận lần làm bài này.');
      setScoreResult(null);
      return;
    }

    if (result.status === 'empty') {
      setValidationError('Vui lòng hoàn thành câu trả lời trước khi nộp bài.');
      setScoreResult(null);
      return;
    }

    // Set scored result for feedback
    setScoreResult(result);

    const nowIso = clock.now();
    const sessionId = isRecheckMode
      ? (recheckSessionId || `session-recheck-${selectedSkillId}-${Date.now()}`)
      : `session-math-${selectedSkillId}`;

    // Create immutable attempt event
    const attemptEvent = createAttemptEvent({
      id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      sessionId,
      questionVersionRef: {
        questionId: currentItem.version.questionId,
        version: currentItem.version.version,
        contentHash: currentItem.version.contentHash,
      },
      scoringPolicyVersionRef: {
        id: DEFAULT_SCORING_POLICY.id,
        version: DEFAULT_SCORING_POLICY.version,
      },
      response,
      result,
      partEvidence: result.parts,
      timestamp: nowIso,
      isDelayedRecheck: isRecheckMode,
    });

    try {
      // Manage session record
      const existingSession = await repo.getSession(sessionId);
      const sessionRecord: PracticeSession = {
        id: sessionId,
        skillId: selectedSkillId,
        startedAt: existingSession?.startedAt || nowIso,
        attemptIds: [...(existingSession?.attemptIds || []), attemptEvent.id],
      };

      // Review schedule (24h later)
      let scheduleRecord: StoredReviewSchedule | undefined;
      if (selectedSkillId !== 'all') {
        const recheckDueAt = new Date(Date.parse(nowIso) + 24 * 60 * 60 * 1000).toISOString();
        scheduleRecord = {
          skillId: selectedSkillId,
          recheckDueAt: isRecheckMode ? (reviewSchedule?.recheckDueAt || recheckDueAt) : recheckDueAt,
          createdAt: isRecheckMode ? (reviewSchedule?.createdAt || nowIso) : nowIso,
          isCompleted: isRecheckMode,
          sourceAttemptId: isRecheckMode ? (reviewSchedule?.sourceAttemptId || attemptEvent.id) : attemptEvent.id,
          sourceQuestionVersionRef: isRecheckMode
            ? (reviewSchedule?.sourceQuestionVersionRef || attemptEvent.questionVersionRef)
            : attemptEvent.questionVersionRef,
          sourceSkillId: selectedSkillId,
          dueAt: isRecheckMode ? (reviewSchedule?.dueAt || recheckDueAt) : recheckDueAt,
          reviewStatus: isRecheckMode ? 'completed' : 'pending',
          recheckSessionRef: isRecheckMode ? sessionId : undefined,
          completedAt: isRecheckMode ? nowIso : undefined,
        };
      }

      // Atomic multi-store save operation
      await repo.saveSessionAndAttempt(sessionRecord, attemptEvent, scheduleRecord);
      await refreshStorageData();

      if (repo.isNativeIndexedDB()) {
        setStorageNotification('Đã lưu thành công vào IndexedDB của thiết bị.');
      } else {
        setStorageNotification('Đã ghi nhận trong phiên làm việc hiện tại (In-memory mode).');
      }
      setTimeout(() => setStorageNotification(null), 3000);
    } catch (err: unknown) {
      setStorageNotification(`Lưu trữ nội bộ thất bại: ${(err as Error).message}`);
    }
  };

  const handleClearHistory = async () => {
    if (window.confirm('Bạn có chắc chắn muốn xóa toàn bộ lịch sử học tập trên thiết bị này?')) {
      try {
        await repo.clearLocalData();
        await refreshStorageData();
        setStorageNotification('Đã xóa dữ liệu lưu trữ trên thiết bị.');
        setTimeout(() => setStorageNotification(null), 3000);
      } catch (err: unknown) {
        setStorageNotification(`Xóa dữ liệu lưu trữ thất bại: ${(err as Error)?.message || 'Lỗi không xác định'}`);
      }
    }
  };

  // Check if delayed recheck is due
  const isRecheckDue = Boolean(
    reviewSchedule &&
      !reviewSchedule.isCompleted &&
      Date.parse(clock.now()) >= Date.parse(reviewSchedule.recheckDueAt),
  );

  if (isRecheckMode && !recheckQuestionItem) {
    return (
      <div className="learning-slice-container" role="region" aria-label="Lỗi tải bài kiểm tra lại">
        <div className="empty-state" role="alert">
          <h3>Không thể tải câu hỏi kiểm tra lại gốc</h3>
          <p>
            Phiên bản câu hỏi tham chiếu ({reviewSchedule?.sourceQuestionVersionRef ? `${reviewSchedule.sourceQuestionVersionRef.questionId} v${reviewSchedule.sourceQuestionVersionRef.version}` : 'thiếu tham chiếu'}) hoặc bản ghi bài làm gốc không tìm thấy hoặc không khớp trong hệ thống.
          </p>
          <button
            type="button"
            className="math-control-button"
            onClick={() => {
              setIsRecheckMode(false);
              setRecheckSessionId(null);
              resetInput();
            }}
          >
            Quay lại luyện tập
          </button>
        </div>
      </div>
    );
  }

  if (!currentItem) {
    return (
      <div className="learning-slice-container" role="region" aria-label="Khu vực học Toán">
        <div className="empty-state">
          <h3>Không tìm thấy câu hỏi phù hợp</h3>
          <p>Vui lòng chọn kỹ năng khác hoặc quay lại danh sách chủ đề.</p>
        </div>
      </div>
    );
  }

  const { body } = currentItem.version;

  return (
    <div className="learning-slice-container math-learning-core" role="region" aria-label="Khu vực học Toán">
      {/* Header Badges */}
      <div className="learning-slice-badges" style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '12px' }}>
        <span className="learning-slice-badge badge-sample" aria-label="Nội dung thử nghiệm">
          SAMPLE / TEST ONLY
        </span>
        <span className="learning-slice-badge badge-memory" style={{ background: '#fef3c7', color: '#92400e' }}>
          DRAFT / CANDIDATE
        </span>
        <span
          className="learning-slice-badge"
          style={{
            background: repo.isNativeIndexedDB() ? '#e0f2fe' : '#f1f5f9',
            color: repo.isNativeIndexedDB() ? '#0369a1' : '#475569',
          }}
        >
          {repo.isNativeIndexedDB() ? 'IndexedDB Persistent Storage' : 'In-Memory Storage Mode'}
        </span>
        {isRecheckMode && (
          <span className="learning-slice-badge" style={{ background: '#dbeafe', color: '#1e40af' }}>
            DELAYED RECHECK ACTIVE
          </span>
        )}
      </div>

      {/* Storage Notification Banner */}
      {storageNotification && (
        <div
          style={{
            padding: '8px 12px',
            background: storageNotification.includes('thất bại') ? '#fee2e2' : '#dcfce7',
            color: storageNotification.includes('thất bại') ? '#991b1b' : '#166534',
            borderRadius: '6px',
            marginBottom: '12px',
            fontSize: '13px',
          }}
          role="status"
        >
          {storageNotification}
        </div>
      )}

      {/* Delayed Recheck Due Alert */}
      {isRecheckDue && !isRecheckMode && (
        <div
          style={{
            padding: '12px 16px',
            background: '#eff6ff',
            border: '1px solid #bfdbfe',
            borderRadius: '8px',
            marginBottom: '16px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div>
            <strong style={{ color: '#1e40af' }}>🔔 Đã đến lịch kiểm tra lại (Delayed Recheck)!</strong>
            <div style={{ fontSize: '13px', color: '#3b82f6', marginTop: '2px' }}>
              Thời hạn ôn tập sau 24h đã đến. Hãy làm bài kiểm tra để củng cố kỹ năng.
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setIsRecheckMode(true);
              setRecheckSessionId(`session-recheck-${selectedSkillId}-${Date.now()}`);
              resetInput();
            }}
            style={{
              padding: '8px 14px',
              borderRadius: '6px',
              background: '#2563eb',
              color: '#ffffff',
              border: 'none',
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            Làm bài recheck
          </button>
        </div>
      )}

      {/* Test-Only Clock Controls (Completely hidden unless advanceByMs is injected) */}
      {typeof clock.advanceByMs === 'function' && (
        <div
          style={{
            padding: '8px 12px',
            background: '#fef3c7',
            border: '1px dashed #d97706',
            borderRadius: '6px',
            marginBottom: '14px',
            fontSize: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <span>
            <strong>Test Clock:</strong> {new Date(clock.now()).toLocaleString('vi-VN')}
          </span>
          <button
            type="button"
            onClick={() => {
              clock.advanceByMs?.(25 * 60 * 60 * 1000); // Advance 25 hours
              setClockTick((t) => t + 1);
            }}
            style={{ padding: '4px 8px', borderRadius: '4px', background: '#d97706', color: '#fff', border: 'none', cursor: 'pointer' }}
          >
            +25h (Tua đến hạn recheck)
          </button>
        </div>
      )}

      {/* Skill Navigation Bar */}
      <div style={{ marginBottom: '16px' }}>
        <label
          htmlFor="math-skill-select"
          style={{ fontSize: '12px', fontWeight: 600, color: 'var(--muted)', display: 'block', marginBottom: '4px' }}
        >
          CHỌN KỸ NĂNG:
        </label>
        <select
          id="math-skill-select"
          value={selectedSkillId}
          disabled={isRecheckMode}
          onChange={(e) => handleSkillChange(e.target.value)}
          style={{
            width: '100%',
            padding: '10px',
            borderRadius: '8px',
            border: '1px solid var(--line)',
            fontSize: '14px',
            background: isRecheckMode ? '#f1f5f9' : '#fff',
            cursor: isRecheckMode ? 'not-allowed' : 'default',
          }}
        >
          <option value="all">Tất cả kỹ năng — Ứng dụng đạo hàm ({PILOT_QUESTIONS.length} câu)</option>
          {PILOT_SKILLS.map((sk) => (
            <option key={sk.id} value={sk.id}>
              {sk.name}
            </option>
          ))}
        </select>
      </div>

      {/* Scoring Policy Disclaimer */}
      <div style={{ fontSize: '12px', color: '#64748b', marginBottom: '12px', background: '#f8fafc', padding: '6px 10px', borderRadius: '6px' }}>
        <em>{DEFAULT_SCORING_POLICY.description}</em>
      </div>

      {/* Question Card */}
      <div className="learning-slice-card" style={{ background: '#fff', border: '1px solid var(--line)', borderRadius: '12px', padding: '16px', marginBottom: '16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', borderBottom: '1px solid var(--line)', paddingBottom: '8px' }}>
          <span style={{ fontSize: '12px', fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase' }}>
            {isRecheckMode
              ? `[RECHECK] Câu hỏi gốc: ${currentItem.version.questionId} (v${currentItem.version.version})`
              : `Câu ${questionIndex + 1} / ${availableQuestions.length} (${body.kind})`}
          </span>
          <span style={{ fontSize: '11px', color: 'var(--muted)' }}>
            ID: {currentItem.version.questionId}
          </span>
        </div>

        {/* Prompt */}
        <div className="math-prompt" style={{ fontSize: '16px', lineHeight: 1.6, marginBottom: '20px', color: 'var(--ink)' }}>
          <MathRenderer math={body.prompt || ''} />
        </div>

        {/* Render MCQ Options */}
        {body.kind === 'MCQ_SINGLE' && (
          <div className="mcq-options" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {body.options.map((opt) => {
              const isSelected = selectedOptionId === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  className={`math-control-button ${isSelected ? 'selected' : ''}`}
                  onClick={() => {
                    if (!scoreResult) setSelectedOptionId(opt.id);
                  }}
                  disabled={Boolean(scoreResult)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    textAlign: 'left',
                    background: isSelected ? '#eff6ff' : '#ffffff',
                    border: isSelected ? '2px solid #2563eb' : '1px solid var(--line)',
                  }}
                >
                  <span
                    style={{
                      width: '32px',
                      height: '32px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: '50%',
                      background: isSelected ? '#2563eb' : '#f1f5f9',
                      color: isSelected ? '#ffffff' : 'var(--ink)',
                      fontWeight: 700,
                    }}
                  >
                    {opt.id}
                  </span>
                  <span style={{ flex: 1 }}>
                    <MathRenderer math={opt.text} />
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {/* Render TRUE_FALSE_CLUSTER Statements (Grouped semantically by fieldset) */}
        {body.kind === 'TRUE_FALSE_CLUSTER' && (
          <div className="tf-cluster-statements" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {body.statements.map((st, idx) => {
              const currentAns = tfAnswers[st.id];
              return (
                <fieldset
                  key={st.id}
                  className="tf-statement-row"
                  style={{ border: '1px solid var(--line)', borderRadius: '8px', padding: '12px', margin: 0 }}
                >
                  <legend style={{ fontWeight: 600, fontSize: '14px', padding: '0 4px', color: 'var(--ink)' }}>
                    Mệnh đề {String.fromCharCode(97 + idx)}
                  </legend>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <div style={{ flex: 1 }}>
                      <MathRenderer math={st.prompt} />
                    </div>
                    <div className="tf-buttons-group">
                      <button
                        type="button"
                        className={`tf-choice-btn ${currentAns === true ? 'selected-true' : ''}`}
                        onClick={() => {
                          if (!scoreResult) setTfAnswers((prev) => ({ ...prev, [st.id]: true }));
                        }}
                        disabled={Boolean(scoreResult)}
                        aria-pressed={currentAns === true}
                      >
                        Đúng
                      </button>
                      <button
                        type="button"
                        className={`tf-choice-btn ${currentAns === false ? 'selected-false' : ''}`}
                        onClick={() => {
                          if (!scoreResult) setTfAnswers((prev) => ({ ...prev, [st.id]: false }));
                        }}
                        disabled={Boolean(scoreResult)}
                        aria-pressed={currentAns === false}
                      >
                        Sai
                      </button>
                    </div>
                  </div>
                </fieldset>
              );
            })}
          </div>
        )}

        {/* Render SHORT_NUMERIC Input */}
        {body.kind === 'SHORT_NUMERIC' && (
          <div className="short-numeric-input-block" style={{ marginTop: '12px' }}>
            <label htmlFor="numeric-answer-input" style={{ display: 'block', fontSize: '13px', color: 'var(--muted)', marginBottom: '6px' }}>
              Nhập đáp án số (hỗ trợ dấu âm -, số thập phân dấu chấm/phẩy, ký hiệu khoa học ví dụ 1.5e3):
            </label>
            <div style={{ display: 'flex', gap: '8px', maxWidth: '320px' }}>
              <input
                id="numeric-answer-input"
                type="text"
                inputMode="decimal"
                value={numericValue}
                onChange={(e) => setNumericValue(e.target.value)}
                disabled={Boolean(scoreResult)}
                placeholder="Ví dụ: -2 hoặc 1.25"
                style={{
                  flex: 1,
                  padding: '12px',
                  fontSize: '18px',
                  borderRadius: '8px',
                  border: '1px solid var(--line)',
                  fontWeight: 600,
                }}
              />
              <button
                type="button"
                onClick={() => setNumericValue((prev) => (prev.startsWith('-') ? prev.slice(1) : '-' + prev))}
                disabled={Boolean(scoreResult)}
                style={{ padding: '0 12px', borderRadius: '8px', border: '1px solid var(--line)', background: '#f8fafc', fontWeight: 700 }}
                title="Đổi dấu âm / dương"
              >
                &plusmn;
              </button>
            </div>
          </div>
        )}

        {/* Validation Error Banner */}
        {validationError && (
          <div style={{ marginTop: '14px', padding: '10px 14px', background: '#fee2e2', color: '#991b1b', borderRadius: '8px', fontSize: '14px' }} role="alert">
            {validationError}
          </div>
        )}

        {/* Submit or Navigation Controls */}
        <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          {!isRecheckMode && (
            <button
              type="button"
              onClick={handlePrevQuestion}
              style={{ padding: '10px 16px', borderRadius: '8px', border: '1px solid var(--line)', background: '#f8fafc', cursor: 'pointer' }}
            >
              &larr; Câu trước
            </button>
          )}

          {!scoreResult ? (
            <button
              type="button"
              onClick={handleSubmit}
              className="math-control-button"
              style={{ background: '#2563eb', color: '#ffffff', border: 'none', fontWeight: 600, minWidth: '140px' }}
            >
              {isRecheckMode ? 'Nộp bài recheck' : 'Nộp bài'}
            </button>
          ) : isRecheckMode ? (
            <button
              type="button"
              onClick={() => {
                setIsRecheckMode(false);
                resetInput();
              }}
              className="math-control-button"
              style={{ background: '#2563eb', color: '#ffffff', border: 'none', fontWeight: 600, minWidth: '140px' }}
            >
              Hoàn tất recheck &rarr;
            </button>
          ) : (
            <button
              type="button"
              onClick={handleNextQuestion}
              className="math-control-button"
              style={{ background: '#16a34a', color: '#ffffff', border: 'none', fontWeight: 600, minWidth: '140px' }}
            >
              Câu tiếp theo &rarr;
            </button>
          )}

          {!isRecheckMode && (
            <button
              type="button"
              onClick={handleNextQuestion}
              style={{ padding: '10px 16px', borderRadius: '8px', border: '1px solid var(--line)', background: '#f8fafc', cursor: 'pointer' }}
            >
              Câu sau &rarr;
            </button>
          )}
        </div>
      </div>

      {/* Scored Feedback & Worked Solution */}
      {scoreResult && (
        <div className="feedback-section" style={{ background: '#ffffff', border: '1px solid var(--line)', borderRadius: '12px', padding: '16px', marginBottom: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
            <h4 style={{ margin: 0, fontSize: '16px' }}>
              {scoreResult.totalPoints === scoreResult.maxPoints ? (
                <span style={{ color: '#16a34a' }}>&#10004; Trả lời đúng hoàn toàn!</span>
              ) : scoreResult.totalPoints > 0 ? (
                <span style={{ color: '#d97706' }}>&#9888; Đúng một phần ({scoreResult.totalPoints}/{scoreResult.maxPoints} điểm)</span>
              ) : (
                <span style={{ color: '#dc2626' }}>&#10008; Chưa chính xác ({scoreResult.totalPoints}/{scoreResult.maxPoints} điểm)</span>
              )}
            </h4>
            <span style={{ fontWeight: 700, padding: '4px 10px', background: '#f1f5f9', borderRadius: '6px', fontSize: '13px' }}>
              Điểm: {scoreResult.totalPoints} / {scoreResult.maxPoints}
            </span>
          </div>

          {/* Statement Breakdowns for T/F */}
          {body.kind === 'TRUE_FALSE_CLUSTER' && scoreResult.parts && (
            <div style={{ marginBottom: '14px', background: '#f8fafc', padding: '10px', borderRadius: '8px' }}>
              <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--muted)', marginBottom: '6px' }}>
                CHI TIẾT TỪNG MỆNH ĐỀ:
              </div>
              {scoreResult.parts.map((p, idx) => (
                <div key={p.partId} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', padding: '4px 0' }}>
                  <span>Mệnh đề {String.fromCharCode(97 + idx)}:</span>
                  <span style={{ fontWeight: 600, color: p.status === 'correct' ? '#16a34a' : '#dc2626' }}>
                    {p.status === 'correct' ? 'Đúng (+1 điểm)' : p.status === 'empty' ? 'Chưa trả lời (0 điểm)' : 'Sai (0 điểm)'}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Diagnostic Hypothesis (Error feedback) */}
          {scoreResult.parts.some((p) => p.diagnosticHypothesis) && (
            <div style={{ background: '#fffbeb', borderLeft: '4px solid #f59e0b', padding: '10px 14px', borderRadius: '4px', marginBottom: '14px' }}>
              <div style={{ fontWeight: 700, color: '#92400e', fontSize: '13px', marginBottom: '4px' }}>
                PHÂN TÍCH CHẨN ĐOÁN LỖI SAI:
              </div>
              {scoreResult.parts
                .filter((p) => p.diagnosticHypothesis)
                .map((p, i) => (
                  <div key={i} style={{ fontSize: '13px', color: '#78350f', marginTop: '4px' }}>
                    <strong>Mã lỗi:</strong> {p.diagnosticHypothesis?.tag} <br />
                    <strong>Bước có thể thiếu:</strong> {p.diagnosticHypothesis?.likelyMissingStep} <br />
                    <strong>Giải thích:</strong> {p.diagnosticHypothesis?.explanation}
                  </div>
                ))}
            </div>
          )}

          {/* Worked Solution */}
          <div style={{ borderTop: '1px solid var(--line)', paddingTop: '12px', marginTop: '12px' }}>
            <h5 style={{ margin: '0 0 8px 0', fontSize: '14px', color: 'var(--ink)' }}>
              Lời giải chi tiết:
            </h5>
            <div style={{ fontSize: '14px', lineHeight: 1.6, color: '#334155' }}>
              <MathRenderer math={currentItem.solution.explanation} />
            </div>
            {currentItem.solution.steps && (
              <ol style={{ paddingLeft: '20px', marginTop: '8px', fontSize: '13px', color: '#475569' }}>
                {currentItem.solution.steps.map((st, i) => (
                  <li key={i} style={{ marginBottom: '4px' }}>
                    <MathRenderer math={st} />
                  </li>
                ))}
              </ol>
            )}
          </div>
        </div>
      )}

      {/* Study History & Persistence Audit Trail */}
      <div className="learning-slice-history" style={{ background: '#fff', border: '1px solid var(--line)', borderRadius: '12px', padding: '16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
          <h4 style={{ margin: 0, fontSize: '14px', textTransform: 'uppercase', color: 'var(--muted)' }}>
            Lịch sử học tập cục bộ ({history.length} lượt làm)
          </h4>
          {history.length > 0 && (
            <button
              type="button"
              onClick={handleClearHistory}
              style={{ fontSize: '11px', color: '#dc2626', background: 'none', border: 'none', cursor: 'pointer', textDecoration: 'underline' }}
            >
              Xóa lịch sử trên máy
            </button>
          )}
        </div>

        {history.length === 0 ? (
          <p style={{ fontSize: '13px', color: 'var(--muted)', margin: 0 }}>
            Chưa có lịch sử làm bài. Kết quả sau khi nộp sẽ tự động được lưu vào IndexedDB của trình duyệt.
          </p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', maxHeight: '220px', overflowY: 'auto' }}>
            {history
              .slice(-5)
              .reverse()
              .map((ev) => (
                <div
                  key={ev.id}
                  style={{
                    padding: '8px 12px',
                    borderRadius: '6px',
                    border: '1px solid var(--line)',
                    background: '#f8fafc',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    fontSize: '12px',
                  }}
                >
                  <div>
                    <strong>{ev.questionVersionRef.questionId}</strong> (v{ev.questionVersionRef.version})
                    {ev.isDelayedRecheck && (
                      <span style={{ background: '#dbeafe', color: '#1e40af', padding: '1px 4px', borderRadius: '3px', marginLeft: '6px', fontSize: '10px' }}>
                        Recheck
                      </span>
                    )}
                    <span style={{ color: 'var(--muted)', marginLeft: '8px' }}>
                      {new Date(ev.timestamp).toLocaleTimeString('vi-VN')}
                    </span>
                  </div>
                  <div>
                    <span
                      style={{
                        padding: '2px 8px',
                        borderRadius: '4px',
                        fontWeight: 600,
                        background: ev.result.totalPoints > 0 ? '#dcfce7' : '#fee2e2',
                        color: ev.result.totalPoints > 0 ? '#166534' : '#991b1b',
                      }}
                    >
                      {ev.result.totalPoints}/{ev.result.maxPoints} đ
                    </span>
                  </div>
                </div>
              ))}
          </div>
        )}
      </div>
    </div>
  );
}
