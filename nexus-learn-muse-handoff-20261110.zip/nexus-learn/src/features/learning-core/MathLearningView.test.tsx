import assert from 'node:assert/strict';
import test from 'node:test';
import { JSDOM } from 'jsdom';

const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
  url: 'http://localhost/#study',
  pretendToBeVisual: true,
});
const g = globalThis as Record<string, unknown>;
const win = dom.window as unknown as Window & typeof globalThis & { HTMLInputElement: typeof HTMLInputElement };
g.window = win;
g.document = win.document;
g.HTMLElement = win.HTMLElement;
g.HTMLInputElement = win.HTMLInputElement;
g.Node = win.Node;
g.Event = win.Event;
g.MouseEvent = win.MouseEvent;
g.IS_REACT_ACT_ENVIRONMENT = true;

const { act, createElement } = await import('react');
const { createRoot } = await import('react-dom/client');
const { default: MathLearningView } = await import('./MathLearningView');
const { InMemoryPersistenceRepository } = await import(
  '../../infrastructure/persistence/indexeddb/indexeddbRepository'
);
type AppClock = import('./MathLearningView').AppClock;

function setupDom() {
  const container = dom.window.document.createElement('div');
  dom.window.document.body.appendChild(container);
  return {
    dom,
    container,
    cleanup: () => {
      container.remove();
    },
  };
}

test('MathLearningView mounts, displays MCQ question, submits answer, and records attempt in persistence repository', async () => {
  const { container } = setupDom();
  const repo = new InMemoryPersistenceRepository();
  const root = createRoot(container);

  await act(async () => {
    root.render(createElement(MathLearningView, { repository: repo }));
  });

  // Verify header badges
  assert.match(container.textContent ?? '', /SAMPLE \/ TEST ONLY/);
  assert.match(container.textContent ?? '', /DRAFT \/ CANDIDATE/);

  // Question 1 is MCQ
  const mcqButtons = container.querySelectorAll<HTMLButtonElement>('.mcq-options button');
  assert.equal(mcqButtons.length, 4, 'Should render 4 MCQ option buttons');

  // Select Option B (which is correct for Question 1)
  await act(async () => {
    mcqButtons[1].click();
  });

  // Find and click Submit button
  const submitBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Nộp bài'),
  );
  assert.ok(submitBtn, 'Submit button should exist');

  await act(async () => {
    submitBtn.click();
    await new Promise((r) => setTimeout(r, 50));
  });

  // Check feedback section
  assert.match(container.textContent ?? '', /Trả lời đúng hoàn toàn/);
  assert.match(container.textContent ?? '', /Điểm: 1 \/ 1/);
  assert.match(container.textContent ?? '', /Lời giải chi tiết/);

  // Verify attempt is recorded in repository
  const attempts = await repo.getAttemptEvents();
  assert.equal(attempts.length, 1, 'Should record 1 attempt event');
  assert.equal(attempts[0].result.totalPoints, 1);
  assert.equal(attempts[0].response.kind, 'MCQ_SINGLE');
});

test('MathLearningView validates incomplete submissions without creating attempt events', async () => {
  const { container } = setupDom();
  const repo = new InMemoryPersistenceRepository();
  const root = createRoot(container);

  await act(async () => {
    root.render(createElement(MathLearningView, { repository: repo }));
  });

  // Click submit without selecting any option
  const submitBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Nộp bài'),
  );
  assert.ok(submitBtn);

  await act(async () => {
    submitBtn.click();
    await new Promise((r) => setTimeout(r, 50));
  });

  // Validation error shown
  assert.match(container.textContent ?? '', /Vui lòng chọn một đáp án trước khi nộp bài/);

  // No attempt recorded
  const attempts = await repo.getAttemptEvents();
  assert.equal(attempts.length, 0, 'No attempt should be recorded on validation error');
});

test('MathLearningView displays diagnostic error hypothesis when an incorrect option is chosen', async () => {
  const { container } = setupDom();
  const repo = new InMemoryPersistenceRepository();
  const root = createRoot(container);

  await act(async () => {
    root.render(createElement(MathLearningView, { repository: repo }));
  });

  // Select Option A (incorrect distractor with diagnostic hypothesis)
  const mcqButtons = container.querySelectorAll<HTMLButtonElement>('.mcq-options button');
  await act(async () => {
    mcqButtons[0].click();
  });

  const submitBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Nộp bài'),
  );
  assert.ok(submitBtn);

  await act(async () => {
    submitBtn.click();
    await new Promise((r) => setTimeout(r, 50));
  });

  // Check diagnostic hypothesis feedback
  assert.match(container.textContent ?? '', /PHÂN TÍCH CHẨN ĐOÁN LỖI SAI/);
  assert.match(container.textContent ?? '', /nham_khoang_nghich_bien/);
  assert.match(container.textContent ?? '', /Chưa đổi dấu của đạo hàm/);
});

test('MathLearningView rejects invalid numeric response format without recording attempt event', async () => {
  const { container } = setupDom();
  const repo = new InMemoryPersistenceRepository();
  const root = createRoot(container);

  await act(async () => {
    root.render(createElement(MathLearningView, { repository: repo }));
  });

  // Navigate to Short Numeric question (find button with "Câu sau")
  const nextBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Câu sau'),
  );
  assert.ok(nextBtn, 'Next button should exist');

  while (!container.querySelector('#numeric-answer-input')) {
    await act(async () => {
      nextBtn.click();
    });
  }

  const numericInput = container.querySelector<HTMLInputElement>('#numeric-answer-input');
  assert.ok(numericInput, 'Numeric input should be present');

  // Input an invalid non-numeric string
  const setInputValue = (input: HTMLInputElement, val: string) => {
    const valueSetter = Object.getOwnPropertyDescriptor(win.HTMLInputElement.prototype, 'value')?.set;
    valueSetter?.call(input, val);
    input.dispatchEvent(new dom.window.Event('input', { bubbles: true }));
  };

  await act(async () => {
    setInputValue(numericInput, 'invalid-non-number');
  });

  const submitBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Nộp bài'),
  );
  assert.ok(submitBtn);

  await act(async () => {
    submitBtn.click();
    await new Promise((r) => setTimeout(r, 50));
  });

  // Validation error for invalid answer format must be shown
  assert.match(container.textContent ?? '', /Câu trả lời không hợp lệ hoặc sai định dạng/);

  // Persistence must remain untouched
  const attempts = await repo.getAttemptEvents();
  assert.equal(attempts.length, 0, 'Invalid submission must never create or store an attempt event');

  // Now input valid correct answer "-2"
  await act(async () => {
    setInputValue(numericInput, '-2');
  });

  await act(async () => {
    submitBtn.click();
    await new Promise((r) => setTimeout(r, 50));
  });

  // Valid answer succeeds
  assert.match(container.textContent ?? '', /Trả lời đúng hoàn toàn/);
  const attemptsAfterValid = await repo.getAttemptEvents();
  assert.equal(attemptsAfterValid.length, 1, 'Valid submission must record exactly 1 attempt event');
  assert.equal(attemptsAfterValid[0].result.totalPoints, 1);
});

test('MathLearningView supports controlled clock, delayed recheck scheduling and completion flow', async () => {
  const { container } = setupDom();
  const repo = new InMemoryPersistenceRepository();
  const root = createRoot(container);

  let currentTimeMs = Date.parse('2026-11-08T09:00:00.000Z');
  const clock: AppClock = {
    now: () => new Date(currentTimeMs).toISOString(),
    advanceByMs: (ms: number) => {
      currentTimeMs += ms;
    },
  };

  await act(async () => {
    root.render(createElement(MathLearningView, { repository: repo, clock }));
  });

  // Select a specific skill so review schedule is generated
  const skillSelect = container.querySelector<HTMLSelectElement>('#math-skill-select');
  assert.ok(skillSelect, 'Skill selector must exist');

  await act(async () => {
    skillSelect.value = 'skill-monotonicity';
    skillSelect.dispatchEvent(new dom.window.Event('change', { bubbles: true }));
  });

  // Verify test clock control is visible because advanceByMs is injected
  assert.match(container.textContent ?? '', /Test Clock:/);
  assert.match(container.textContent ?? '', /\+25h \(Tua đến hạn recheck\)/);

  // Submit correct answer to Question 1 (MCQ Option B)
  const mcqButtons = container.querySelectorAll<HTMLButtonElement>('.mcq-options button');
  await act(async () => {
    mcqButtons[1].click();
  });

  const submitBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Nộp bài'),
  );
  assert.ok(submitBtn);

  await act(async () => {
    submitBtn.click();
    await new Promise((r) => setTimeout(r, 50));
  });

  // Verify 1st attempt recorded and review schedule exists (due in 24h)
  const initialAttempts = await repo.getAttemptEvents();
  assert.equal(initialAttempts.length, 1);
  assert.equal(initialAttempts[0].isDelayedRecheck, false);

  const schedule = await repo.getReviewSchedule('skill-monotonicity');
  assert.ok(schedule, 'Review schedule should be saved');
  assert.equal(schedule.isCompleted, false);
  assert.equal(schedule.recheckDueAt, '2026-11-09T09:00:00.000Z');

  // Currently, recheck is not due
  assert.doesNotMatch(container.textContent ?? '', /Đã đến lịch kiểm tra lại/);

  // Advance clock by 25 hours using the UI button
  const advanceBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('+25h'),
  );
  assert.ok(advanceBtn);

  await act(async () => {
    advanceBtn.click();
    await new Promise((r) => setTimeout(r, 50));
  });

  // Alert is now visible
  assert.match(container.textContent ?? '', /🔔 Đã đến lịch kiểm tra lại \(Delayed Recheck\)!/);

  // Click "Làm bài recheck" button
  const startRecheckBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Làm bài recheck'),
  );
  assert.ok(startRecheckBtn);

  await act(async () => {
    startRecheckBtn.click();
  });

  // Verify Recheck Active badge
  assert.match(container.textContent ?? '', /DELAYED RECHECK ACTIVE/);

  // Answer question again in recheck mode
  const recheckMcqButtons = container.querySelectorAll<HTMLButtonElement>('.mcq-options button');
  await act(async () => {
    recheckMcqButtons[1].click();
  });

  const recheckSubmitBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Nộp bài'),
  );
  assert.ok(recheckSubmitBtn);

  await act(async () => {
    recheckSubmitBtn.click();
    await new Promise((r) => setTimeout(r, 50));
  });

  // Verify 2nd attempt recorded with isDelayedRecheck: true in a separate recheck session
  const finalAttempts = await repo.getAttemptEvents();
  assert.equal(finalAttempts.length, 2);
  assert.equal(finalAttempts[0].sessionId, 'session-math-skill-monotonicity');
  assert.ok(finalAttempts[1].sessionId.startsWith('session-recheck-skill-monotonicity'));
  assert.equal(finalAttempts[1].isDelayedRecheck, true);

  // Verify review schedule is now marked as completed with source provenance chain intact
  const completedSchedule = await repo.getReviewSchedule('skill-monotonicity');
  assert.ok(completedSchedule);
  assert.equal(completedSchedule.isCompleted, true);
  assert.equal(completedSchedule.reviewStatus, 'completed');
  assert.equal(completedSchedule.sourceAttemptId, initialAttempts[0].id);
  assert.equal(completedSchedule.recheckSessionRef, finalAttempts[1].sessionId);
});

test('WP0-E: Delayed recheck resolves exact source question version regardless of current question index', async () => {
  const { container } = setupDom();
  const repo = new InMemoryPersistenceRepository();
  const root = createRoot(container);

  let currentTimeMs = Date.parse('2026-11-08T09:00:00.000Z');
  const clock: AppClock = {
    now: () => new Date(currentTimeMs).toISOString(),
    advanceByMs: (ms: number) => {
      currentTimeMs += ms;
    },
  };

  // Seed source attempt and review schedule pointing specifically to q-math-pilot-001 (v1)
  await repo.saveAttemptEvent({
    id: 'att-source-1',
    sessionId: 'session-math-skill-monotonicity',
    questionVersionRef: {
      questionId: 'q-math-pilot-001',
      version: 1,
      contentHash: 'sha256:pilot-001-v1',
    },
    scoringPolicyVersionRef: { id: 'sample-practice-v1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'B' },
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [{ partId: 'question', status: 'correct', points: 1, maxPoints: 1 }],
    timestamp: '2026-11-08T09:00:00.000Z',
  });

  await repo.saveReviewSchedule({
    skillId: 'skill-monotonicity',
    recheckDueAt: '2026-11-09T09:00:00.000Z',
    createdAt: '2026-11-08T09:00:00.000Z',
    isCompleted: false,
    sourceAttemptId: 'att-source-1',
    sourceQuestionVersionRef: {
      questionId: 'q-math-pilot-001',
      version: 1,
      contentHash: 'sha256:pilot-001-v1',
    },
  });

  // Fast forward past due time
  currentTimeMs += 25 * 60 * 60 * 1000;

  await act(async () => {
    root.render(createElement(MathLearningView, { repository: repo, clock }));
  });

  // Select skill
  const skillSelect = container.querySelector<HTMLSelectElement>('#math-skill-select');
  assert.ok(skillSelect);
  await act(async () => {
    skillSelect.value = 'skill-monotonicity';
    skillSelect.dispatchEvent(new dom.window.Event('change', { bubbles: true }));
    await new Promise((r) => setTimeout(r, 50));
  });

  // Navigate to Question 2
  const nextBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Câu sau'),
  );
  assert.ok(nextBtn);
  await act(async () => {
    nextBtn.click();
  });
  // Now current question is Question 2 (q-math-pilot-002)
  assert.match(container.textContent ?? '', /q-math-pilot-002/);

  // Click "Làm bài recheck"
  const startRecheckBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Làm bài recheck'),
  );
  assert.ok(startRecheckBtn);

  await act(async () => {
    startRecheckBtn.click();
  });

  // In recheck mode, it MUST load the exact source question (q-math-pilot-001), NOT q-math-pilot-002!
  assert.match(container.textContent ?? '', /q-math-pilot-001/);
  assert.match(container.textContent ?? '', /\[RECHECK\] Câu hỏi gốc: q-math-pilot-001/);

  // Previous and Next buttons are hidden in recheck mode
  const navButtons = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).filter(
    (b) => b.textContent?.includes('Câu trước') || b.textContent?.includes('Câu sau'),
  );
  assert.equal(navButtons.length, 0);

  // Skill selector is disabled in recheck mode
  assert.equal(skillSelect.disabled, true);
});

test('WP0-E: Delayed recheck fails closed when contentHash does not match or source attempt is missing', async () => {
  const { container } = setupDom();
  const repo = new InMemoryPersistenceRepository();
  const root = createRoot(container);

  let currentTimeMs = Date.parse('2026-11-08T09:00:00.000Z');
  const clock: AppClock = {
    now: () => new Date(currentTimeMs).toISOString(),
    advanceByMs: (ms: number) => {
      currentTimeMs += ms;
    },
  };

  // Seed valid attempt
  await repo.saveAttemptEvent({
    id: 'att-source-mismatch',
    sessionId: 'session-math-skill-monotonicity',
    questionVersionRef: {
      questionId: 'q-math-pilot-001',
      version: 1,
      contentHash: 'sha256:pilot-001-v1',
    },
    scoringPolicyVersionRef: { id: 'sample-practice-v1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'B' },
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [{ partId: 'question', status: 'correct', points: 1, maxPoints: 1 }],
    timestamp: '2026-11-08T09:00:00.000Z',
  });

  // Seed review schedule with tampered contentHash
  await repo.saveReviewSchedule({
    skillId: 'skill-monotonicity',
    recheckDueAt: '2026-11-09T09:00:00.000Z',
    createdAt: '2026-11-08T09:00:00.000Z',
    isCompleted: false,
    sourceAttemptId: 'att-source-mismatch',
    sourceQuestionVersionRef: {
      questionId: 'q-math-pilot-001',
      version: 1,
      contentHash: 'sha256:tampered-hash-does-not-match',
    },
  });

  // Fast forward past due time
  currentTimeMs += 25 * 60 * 60 * 1000;

  await act(async () => {
    root.render(createElement(MathLearningView, { repository: repo, clock }));
  });

  // Select skill
  const skillSelect = container.querySelector<HTMLSelectElement>('#math-skill-select');
  assert.ok(skillSelect);
  await act(async () => {
    skillSelect.value = 'skill-monotonicity';
    skillSelect.dispatchEvent(new dom.window.Event('change', { bubbles: true }));
    await new Promise((r) => setTimeout(r, 50));
  });

  // Click "Làm bài recheck"
  const startRecheckBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Làm bài recheck'),
  );
  assert.ok(startRecheckBtn);

  await act(async () => {
    startRecheckBtn.click();
  });

  // Because contentHash is tampered, recheck fails closed with recoverable error
  assert.match(container.textContent ?? '', /Không thể tải câu hỏi kiểm tra lại gốc/);

  // Recovery button exists to return
  const backBtn = Array.from(container.querySelectorAll<HTMLButtonElement>('button')).find(
    (b) => b.textContent?.includes('Quay lại luyện tập'),
  );
  assert.ok(backBtn);

  await act(async () => {
    backBtn.click();
  });

  // Returns safely to normal practice view
  assert.doesNotMatch(container.textContent ?? '', /Không thể tải câu hỏi kiểm tra lại gốc/);
});
