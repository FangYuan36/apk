import assert from 'node:assert/strict';
import test from 'node:test';
import { act, createElement } from 'react';
import { createRoot } from 'react-dom/client';
import { JSDOM } from 'jsdom';
import DashboardView from './DashboardView';
import { InMemoryPersistenceRepository } from '../../infrastructure/persistence/indexeddb/indexeddbRepository';

test('DashboardView renders metrics, due review notices, and handles study navigation', async () => {
  const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
    url: 'http://localhost/#dashboard',
    pretendToBeVisual: true,
  });
  const globals: Record<string, unknown> = {
    window: dom.window,
    document: dom.window.document,
    navigator: dom.window.navigator,
    HTMLElement: dom.window.HTMLElement,
    Node: dom.window.Node,
    Event: dom.window.Event,
    MouseEvent: dom.window.MouseEvent,
    IS_REACT_ACT_ENVIRONMENT: true,
  };
  const previousGlobals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries(globals)) {
    previousGlobals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  }

  const repo = new InMemoryPersistenceRepository();
  await repo.saveSession({
    id: 'sess-dash-1',
    skillId: 'math12-der-mono',
    startedAt: '2026-11-09T08:00:00.000Z',
    attemptIds: ['att-1'],
  });
  await repo.saveAttemptEvent({
    id: 'att-1',
    sessionId: 'sess-dash-1',
    questionVersionRef: { questionId: 'q-math-01', version: 1, contentHash: 'sha256:abc' },
    scoringPolicyVersionRef: { id: 'pol-1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'A' },
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [{ partId: 'p1', status: 'correct', points: 1, maxPoints: 1 }],
    timestamp: '2026-11-09T08:05:00.000Z',
  });
  await repo.saveReviewSchedule({
    skillId: 'math12-der-mono',
    recheckDueAt: '2026-11-08T00:00:00.000Z', // due in past
    createdAt: '2026-11-07T00:00:00.000Z',
    isCompleted: false,
  });

  let navigatedToStudy = false;
  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);

  try {
    await act(async () => {
      root.render(
        createElement(DashboardView, {
          repository: repo,
          onNavigateToStudy: () => {
            navigatedToStudy = true;
          },
        }),
      );
    });

    // Verify metrics rendered
    const text = container.textContent ?? '';
    assert.match(text, /Phiên học/);
    assert.match(text, /Câu hỏi đã làm/);
    assert.match(text, /Tỷ lệ chính xác/);
    assert.match(text, /Nhắc nhở kiểm tra lại/);
    assert.match(text, /100%/); // accuracy

    // Verify action button clicks
    const studyBtn = container.querySelector<HTMLButtonElement>('.action-button-primary');
    assert.ok(studyBtn, 'Study action button should exist');

    await act(async () => {
      studyBtn.click();
    });
    assert.equal(navigatedToStudy, true, 'onNavigateToStudy should be called on button click');
  } finally {
    await act(async () => root.unmount());
    dom.window.close();
    for (const [key, descriptor] of previousGlobals) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else Reflect.deleteProperty(globalThis, key);
    }
  }
});
