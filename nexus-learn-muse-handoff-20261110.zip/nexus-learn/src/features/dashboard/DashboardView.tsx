import { useEffect, useState } from 'react';
import type { PersistenceRepository, PracticeSession, StoredReviewSchedule } from '../../domain/persistence/types';
import type { AttemptEvent } from '../../domain/math/attempt';
import { PILOT_SKILLS } from '../../content/math/derivative-applications';

export interface DashboardViewProps {
  readonly repository: PersistenceRepository;
  readonly onNavigateToStudy?: () => void;
}

export default function DashboardView({ repository, onNavigateToStudy }: DashboardViewProps) {
  const [sessions, setSessions] = useState<readonly PracticeSession[]>([]);
  const [attempts, setAttempts] = useState<readonly AttemptEvent[]>([]);
  const [schedules, setSchedules] = useState<readonly StoredReviewSchedule[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      try {
        const [sess, att, sched] = await Promise.all([
          repository.getAllSessions(),
          repository.getAttemptEvents(),
          repository.getAllReviewSchedules(),
        ]);
        if (isMounted) {
          setSessions(sess);
          setAttempts(att);
          setSchedules(sched);
          setLoading(false);
        }
      } catch {
        if (isMounted) setLoading(false);
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, [repository]);

  const now = new Date().toISOString();
  const dueSchedules = schedules.filter(
    (s) => !s.isCompleted && Date.parse(now) >= Date.parse(s.recheckDueAt),
  );

  const correctAttempts = attempts.filter((a) => a.result.status === 'scored' && a.result.totalPoints > 0);
  const accuracy = attempts.length > 0 ? Math.round((correctAttempts.length / attempts.length) * 100) : 0;

  const skillNameMap = new Map<string, string>(PILOT_SKILLS.map((s) => [s.id, s.name]));

  // Recent error tags
  const recentErrorTags: string[] = [];
  for (const a of [...attempts].reverse()) {
    if (a.response.kind === 'MCQ_SINGLE' && a.result.totalPoints === 0 && a.partEvidence) {
      for (const p of a.partEvidence) {
        if (p.diagnosticHypothesis?.tag && !recentErrorTags.includes(p.diagnosticHypothesis.tag)) {
          recentErrorTags.push(p.diagnosticHypothesis.tag);
        }
      }
    }
    if (recentErrorTags.length >= 3) break;
  }

  const navigateToStudy = () => {
    if (onNavigateToStudy) {
      onNavigateToStudy();
    } else if (typeof window !== 'undefined') {
      window.location.hash = '#study';
    }
  };

  return (
    <div className="dashboard-container" role="region" aria-label="Bảng tổng quan học tập">
      <div className="dashboard-header-notice">
        <p className="notice-badge">Bản thử nghiệm (MVP) — Chức năng đang được phát triển và hoàn thiện dữ liệu bài học.</p>
        <p className="notice-subtext">Học tập và ôn luyện Toán 12 theo chương trình GDPT 2018.</p>
      </div>

      {loading ? (
        <div className="empty-state" role="status">
          <p>Đang tải dữ liệu tổng quan...</p>
        </div>
      ) : (
        <>
          <div className="dashboard-metrics-grid">
            <div className="metric-card">
              <span className="metric-label">Phiên học</span>
              <span className="metric-value">{sessions.length}</span>
              <span className="metric-hint">Phiên đã bắt đầu</span>
            </div>
            <div className="metric-card">
              <span className="metric-label">Câu hỏi đã làm</span>
              <span className="metric-value">{attempts.length}</span>
              <span className="metric-hint">Tổng số lượt trả lời</span>
            </div>
            <div className="metric-card">
              <span className="metric-label">Tỷ lệ chính xác</span>
              <span className="metric-value">{accuracy}%</span>
              <span className="metric-hint">{correctAttempts.length} câu đúng</span>
            </div>
            <div className="metric-card">
              <span className="metric-label">Cần kiểm tra lại</span>
              <span className="metric-value" style={{ color: dueSchedules.length > 0 ? '#b91c1c' : 'inherit' }}>
                {dueSchedules.length}
              </span>
              <span className="metric-hint">Lịch ôn tập đến hạn</span>
            </div>
          </div>

          {dueSchedules.length > 0 && (
            <div className="dashboard-alert-box" role="alert">
              <h4>Nhắc nhở kiểm tra lại</h4>
              <p>Bạn có <strong>{dueSchedules.length}</strong> bài kiểm tra lại đã đến hạn ôn tập:</p>
              <ul>
                {dueSchedules.map((s) => (
                  <li key={s.skillId}>
                    {skillNameMap.get(s.skillId) || s.skillId} (Hạn: {new Date(s.recheckDueAt).toLocaleTimeString('vi-VN')} {new Date(s.recheckDueAt).toLocaleDateString('vi-VN')})
                  </li>
                ))}
              </ul>
              <button type="button" className="action-button-primary" onClick={navigateToStudy}>
                Vào mục Học tập để kiểm tra ngay
              </button>
            </div>
          )}

          {recentErrorTags.length > 0 && (
            <div className="dashboard-recommendation-box">
              <h4>Điểm cần lưu ý gần đây</h4>
              <p>Hệ thống ghi nhận một số lỗi cần củng cố trong các bài làm gần nhất:</p>
              <div className="error-tags-list">
                {recentErrorTags.map((tag) => (
                  <span key={tag} className="error-tag-chip">
                    {tag === 'misread_condition' && 'Đọc sót điều kiện bài toán'}
                    {tag === 'calculation_slip' && 'Nhầm lẫn trong tính toán / đạo hàm'}
                    {tag === 'concept_gap' && 'Chưa nắm vững định nghĩa / tính chất'}
                    {!['misread_condition', 'calculation_slip', 'concept_gap'].includes(tag) && tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="dashboard-action-banner">
            <div>
              <h3>Tiếp tục hành trình học Toán 12</h3>
              <p>Khám phá chuyên đề Ứng dụng đạo hàm để khảo sát hàm số với 15 câu hỏi mẫu kèm chẩn đoán lỗi chi tiết.</p>
            </div>
            <button type="button" className="action-button-primary" onClick={navigateToStudy}>
              {attempts.length > 0 ? 'Tiếp tục luyện tập' : 'Bắt đầu học ngay'}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
