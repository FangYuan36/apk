import assert from 'node:assert/strict';
import test from 'node:test';
import { act, createElement } from 'react';
import { createRoot } from 'react-dom/client';
import { JSDOM } from 'jsdom';
import ProgressView from './ProgressView';
import { InMemoryPersistenceRepository } from '../../infrastructure/persistence/indexeddb/indexeddbRepository';

test('ProgressView renders attempt history, error breakdown, and D-017/D-024 disclosure', async () => {
  const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
    url: 'http://localhost/#progress',
    pretendToBeVisual: true,
  });
  const globals: Record<string, unknown> = {
    window: dom.window,
    document: dom.window.document,
    navigator: dom.window.navigator,
    HTMLElement: dom.window.HTMLElement,
    Node: dom.window.Node,
    Event: dom.window.Event,
    MouseEvent: dom.window.MouseEvent,
    IS_REACT_ACT_ENVIRONMENT: true,
  };
  const previousGlobals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries(globals)) {
    previousGlobals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  }

  const repo = new InMemoryPersistenceRepository();
  await repo.saveAttemptEvent({
    id: 'att-prog-1',
    sessionId: 'sess-1',
    questionVersionRef: { questionId: 'q-math-01', version: 1, contentHash: 'sha256:abc' },
    scoringPolicyVersionRef: { id: 'pol-1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'B' },
    result: { status: 'scored', totalPoints: 0, maxPoints: 1 },
    partEvidence: [{
      partId: 'p1',
      status: 'incorrect',
      points: 0,
      maxPoints: 1,
      diagnosticHypothesis: {
        tag: 'misread_condition',
        likelyMissingStep: 'Quên xét dấu của mẫu số',
        explanation: 'Quên xét dấu của mẫu số dẫn đến kết luận sai',
        isHypothesis: true,
      },
    }],
    timestamp: '2026-11-09T09:00:00.000Z',
  });

  await repo.saveReviewSchedule({
    skillId: 'math12-der-mono',
    recheckDueAt: '2026-11-10T09:00:00.000Z',
    createdAt: '2026-11-09T09:00:00.000Z',
    isCompleted: false,
  });

  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);

  try {
    await act(async () => {
      root.render(createElement(ProgressView, { repository: repo }));
    });

    const text = container.textContent ?? '';
    assert.match(text, /Tổng bài làm/);
    assert.match(text, /D-017 \/ D-024/);
    assert.match(text, /Phân tích chẩn đoán lỗi đã gặp/);
    assert.match(text, /misread_condition/);
    assert.match(text, /Lịch sử bài làm gần đây/);
    assert.match(text, /Lịch nhắc nhở kiểm tra lại/);
    assert.match(text, /Chờ ôn tập/);
  } finally {
    await act(async () => root.unmount());
    dom.window.close();
    for (const [key, descriptor] of previousGlobals) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else Reflect.deleteProperty(globalThis, key);
    }
  }
});
