import { useEffect, useState } from 'react';
import type { PersistenceRepository, StoredReviewSchedule } from '../../domain/persistence/types';
import type { AttemptEvent } from '../../domain/math/attempt';
import { PILOT_SKILLS } from '../../content/math/derivative-applications';

export interface ProgressViewProps {
  readonly repository: PersistenceRepository;
}

export default function ProgressView({ repository }: ProgressViewProps) {
  const [attempts, setAttempts] = useState<readonly AttemptEvent[]>([]);
  const [schedules, setSchedules] = useState<readonly StoredReviewSchedule[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      try {
        const [att, sched] = await Promise.all([
          repository.getAttemptEvents(),
          repository.getAllReviewSchedules(),
        ]);
        if (isMounted) {
          setAttempts(att);
          setSchedules(sched);
          setLoading(false);
        }
      } catch {
        if (isMounted) setLoading(false);
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, [repository]);

  const skillNameMap = new Map<string, string>(PILOT_SKILLS.map((s) => [s.id, s.name]));

  // Calculate stats
  const totalAttempts = attempts.length;
  const scoredAttempts = attempts.filter((a) => a.result.status === 'scored');
  const correctAttempts = attempts.filter((a) => a.result.status === 'scored' && a.result.totalPoints > 0);
  const totalPointsEarned = attempts.reduce((sum, a) => sum + (a.result.totalPoints || 0), 0);
  const totalMaxPoints = attempts.reduce((sum, a) => sum + (a.result.maxPoints || 0), 0);
  const overallPercentage = totalMaxPoints > 0 ? Math.round((totalPointsEarned / totalMaxPoints) * 100) : 0;

  // Error frequency map
  const errorCountMap = new Map<string, number>();
  for (const a of attempts) {
    if (a.partEvidence) {
      for (const p of a.partEvidence) {
        if (p.diagnosticHypothesis?.tag) {
          const tag = p.diagnosticHypothesis.tag;
          errorCountMap.set(tag, (errorCountMap.get(tag) || 0) + 1);
        }
      }
    }
  }

  return (
    <div className="progress-container" role="region" aria-label="Báo cáo tiến độ học tập">
      <div className="dashboard-header-notice">
        <p className="notice-badge">Bản thử nghiệm (MVP) — Chức năng đang được phát triển và hoàn thiện dữ liệu bài học.</p>
        <p className="notice-subtext">Theo dõi lịch sử bài làm, chẩn đoán lỗi và lịch ôn tập định kỳ.</p>
      </div>

      <div className="disclosure-card" role="note">
        <strong>Lưu ý về tiến độ & độ thành thạo (D-017 / D-024):</strong>
        <p>
          Lịch ôn tập và nhắc nhở kiểm tra lại là cơ chế hỗ trợ ghi nhớ ngắt quãng (spaced repetition), không phải là
          mô hình bảo đảm điểm số thi hay chứng nhận thành thạo tuyệt đối. Điểm số và trạng thái phản ánh bằng chứng bài
          làm ghi nhận cục bộ trên thiết bị của bạn.
        </p>
      </div>

      {loading ? (
        <div className="empty-state" role="status">
          <p>Đang tải dữ liệu tiến độ...</p>
        </div>
      ) : totalAttempts === 0 ? (
        <div className="empty-state" role="status">
          <h3>Chưa có bài làm nào</h3>
          <p>Bạn chưa hoàn thành câu hỏi nào. Hãy chuyển sang tab <strong>Học tập</strong> để bắt đầu làm bài!</p>
        </div>
      ) : (
        <>
          <div className="progress-summary-grid">
            <div className="metric-card">
              <span className="metric-label">Tổng bài làm</span>
              <span className="metric-value">{totalAttempts}</span>
              <span className="metric-hint">{scoredAttempts.length} bài đã chấm</span>
            </div>
            <div className="metric-card">
              <span className="metric-label">Số câu đúng</span>
              <span className="metric-value">{correctAttempts.length}</span>
              <span className="metric-hint">{totalAttempts - correctAttempts.length} câu cần lưu ý</span>
            </div>
            <div className="metric-card">
              <span className="metric-label">Tổng điểm đạt được</span>
              <span className="metric-value">{totalPointsEarned} / {totalMaxPoints}</span>
              <span className="metric-hint">{overallPercentage}% tổng điểm</span>
            </div>
          </div>

          {errorCountMap.size > 0 && (
            <div className="progress-section-block">
              <h3>Phân tích chẩn đoán lỗi đã gặp</h3>
              <p className="section-description">Các dạng lỗi thường gặp trong quá trình làm bài:</p>
              <div className="error-breakdown-table">
                {Array.from(errorCountMap.entries()).map(([tag, count]) => (
                  <div key={tag} className="error-breakdown-row">
                    <span className="error-tag-name">
                      {tag === 'misread_condition' && 'Đọc sót điều kiện bài toán (misread_condition)'}
                      {tag === 'calculation_slip' && 'Nhầm lẫn tính toán / đạo hàm (calculation_slip)'}
                      {tag === 'concept_gap' && 'Lỗ hổng khái niệm / định lý (concept_gap)'}
                      {!['misread_condition', 'calculation_slip', 'concept_gap'].includes(tag) && tag}
                    </span>
                    <span className="error-count-badge">{count} lần</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="progress-section-block">
            <h3>Lịch sử bài làm gần đây</h3>
            <div className="attempt-history-list">
              {[...attempts].reverse().slice(0, 10).map((a) => (
                <div key={a.id} className="attempt-history-item">
                  <div className="attempt-meta">
                    <strong>{a.questionVersionRef.questionId} (v{a.questionVersionRef.version})</strong>
                    <span className="attempt-time">{new Date(a.timestamp).toLocaleString('vi-VN')}</span>
                  </div>
                  <div className="attempt-score">
                    <span className={`score-badge status-${a.result.status}`}>
                      {a.result.status === 'scored'
                        ? `${a.result.totalPoints} / ${a.result.maxPoints} đ`
                        : a.result.status}
                    </span>
                    {a.isDelayedRecheck && <span className="recheck-tag">Kiểm tra lại</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {schedules.length > 0 && (
            <div className="progress-section-block">
              <h3>Lịch nhắc nhở kiểm tra lại</h3>
              <div className="schedule-list">
                {schedules.map((s) => (
                  <div key={s.skillId} className="schedule-item">
                    <div>
                      <strong>{skillNameMap.get(s.skillId) || s.skillId}</strong>
                      <p className="schedule-time">
                        Hạn: {new Date(s.recheckDueAt).toLocaleString('vi-VN')}
                      </p>
                    </div>
                    <span className={`schedule-status-badge ${s.isCompleted ? 'completed' : 'pending'}`}>
                      {s.isCompleted ? 'Đã hoàn thành' : 'Chờ ôn tập'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
