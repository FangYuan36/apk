declare module 'jsdom' {
  export class JSDOM {
    constructor(
      html?: string,
      options?: {
        readonly url?: string;
        readonly pretendToBeVisual?: boolean;
      },
    );

    readonly window: {
      readonly document: Document;
      readonly navigator: Navigator;
      readonly HTMLElement: typeof HTMLElement;
      readonly Node: typeof Node;
      readonly Event: typeof Event;
      readonly MouseEvent: typeof MouseEvent;
      close(): void;
    };
  }
}
