import type {
  AttemptEvent,
  ErrorClassification,
  VerificationPolicy,
  QuestionItem,
  RecheckSchedule,
  VerificationProgress,
  StudyRecommendation,
} from '../../domain/contracts';

export type LearningJourneyStage =
  | 'diagnose'
  | 'explain'
  | 'targeted_practice'
  | 'recheck_scheduled'
  | 'recheck_active'
  | 'completed';

export interface ClockProvider {
  readonly now: () => number;
  readonly advanceTo?: (timeMs: number) => void;
}

export interface LearningSliceProps {
  readonly initialStage?: LearningJourneyStage;
  readonly questions?: readonly QuestionItem[];
  readonly clock?: ClockProvider;
  readonly defaultRecheckDelayMinutes?: number;
  readonly verificationPolicy?: VerificationPolicy;
  readonly showTestClockControls?: boolean;
  readonly onAttemptRecorded?: (attempt: AttemptEvent) => void;
  readonly initialAttempts?: readonly AttemptEvent[];
  readonly initialSessionId?: string;
  readonly simulateLoading?: boolean;
}

export interface AttemptResultSnapshot {
  readonly attempt: AttemptEvent;
  readonly question: QuestionItem;
  readonly isCorrect: boolean;
  readonly errorClassification?: ErrorClassification;
  readonly recommendation: StudyRecommendation;
  readonly previousEvidence: VerificationProgress;
  readonly currentEvidence: VerificationProgress;
}

export interface LearningSliceState {
  readonly stage: LearningJourneyStage;
  readonly sessionId: string;
  readonly attempts: readonly AttemptEvent[];
  readonly selectedOptionId: string | null;
  readonly currentQuestionIndex: number;
  readonly questionStartTimeMs: number;
  readonly latestResult: AttemptResultSnapshot | null;
  readonly recheckSchedule: RecheckSchedule | null;
  readonly validationError: string | null;
  readonly testTimeOffsetMs: number;
  readonly isLoading: boolean;
  readonly systemError: string | null;
}
