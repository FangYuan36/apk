import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { sampleQuestions, sampleTaxonomy } from '../../content/fixtures/derivative-sign';
import {
  DEFAULT_VERIFICATION_POLICY,
  deriveVerificationProgress,
  isRecheckDue,
  scheduleDelayedRecheck,
  type AttemptEvent,
  type QuestionItem,
  type RecheckSchedule,
} from '../../domain/contracts';
import {
  formatVerificationProgressVietnamese,
  getQuestionForStage,
  handleAnswerSubmission,
} from './learningSliceLogic';
import type { AttemptResultSnapshot, LearningJourneyStage, LearningSliceProps } from './types';

export default function LearningSlice({
  initialStage = 'diagnose',
  questions = sampleQuestions,
  clock,
  defaultRecheckDelayMinutes = 60,
  verificationPolicy = DEFAULT_VERIFICATION_POLICY,
  showTestClockControls = false,
  onAttemptRecorded,
  initialAttempts = [],
  initialSessionId = 'session-1',
  simulateLoading = false,
}: LearningSliceProps) {
  const getClockTime = useCallback(() => (clock ? clock.now() : Date.now()), [clock]);

  const [stage, setStage] = useState<LearningJourneyStage>(initialStage);
  const [sessionId, setSessionId] = useState<string>(initialSessionId);
  const [attempts, setAttempts] = useState<readonly AttemptEvent[]>(initialAttempts);
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [startTimeMs, setStartTimeMs] = useState<number>(getClockTime());
  const [clockRevision, setClockRevision] = useState<number>(0);
  const [latestResult, setLatestResult] = useState<AttemptResultSnapshot | null>(null);
  const [recheckSchedule, setRecheckSchedule] = useState<RecheckSchedule | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [systemError, setSystemError] = useState<string | null>(null);
  const [isLoading] = useState<boolean>(simulateLoading);

  const currentTimeMs = getClockTime();

  const currentQuestion = useMemo<QuestionItem | null>(() => {
    return getQuestionForStage(questions, stage);
  }, [questions, stage]);

  const currentVerificationProgress = useMemo(() => {
    return deriveVerificationProgress(attempts, verificationPolicy);
  }, [attempts, verificationPolicy]);

  const isRecheckReady = useMemo(() => {
    if (!recheckSchedule) return false;
    return isRecheckDue(recheckSchedule.dueAt, currentTimeMs);
  }, [recheckSchedule, currentTimeMs, clockRevision]);

  useEffect(() => {
    setStartTimeMs(getClockTime());
    setSelectedOptionId(null);
    setValidationError(null);
  }, [stage, getClockTime, clockRevision]);

  useEffect(() => {
    if (stage !== 'recheck_scheduled' || !recheckSchedule || isRecheckReady) return;
    const remainingMs = Math.max(0, Date.parse(recheckSchedule.dueAt) - getClockTime());
    const timer = window.setTimeout(
      () => setClockRevision((revision) => revision + 1),
      Math.min(remainingMs + 1, 2_147_483_647),
    );
    return () => window.clearTimeout(timer);
  }, [stage, recheckSchedule, isRecheckReady, getClockTime, clockRevision]);

  const handleOptionChange = (optionId: string) => {
    setSelectedOptionId(optionId);
    setValidationError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentQuestion) {
      setSystemError('Không tìm thấy câu hỏi để nộp.');
      return;
    }

    if (!selectedOptionId) {
      setValidationError('Vui lòng chọn một phương án trước khi nhấn nộp bài.');
      return;
    }

    try {
      const outcome = handleAnswerSubmission({
        question: currentQuestion,
        selectedOptionId,
        attempts,
        sessionId,
        isDelayedRecheck: stage === 'recheck_active',
        currentTimeMs,
        startTimeMs,
        verificationPolicy,
      });

      if (!outcome.success || !outcome.snapshot) {
        setValidationError(outcome.error || 'Lỗi khi xử lý câu trả lời.');
        return;
      }

      setAttempts(outcome.updatedAttempts);
      setLatestResult(outcome.snapshot);
      if (onAttemptRecorded) {
        onAttemptRecorded(outcome.snapshot.attempt);
      }

      setStage('explain');
    } catch (err: unknown) {
      setSystemError(err instanceof Error ? err.message : 'Đã xảy ra lỗi không xác định.');
    }
  };

  const handleContinueFromExplain = () => {
    if (!latestResult) return;

    if (stage === 'explain') {
      if (latestResult.attempt.isDelayedRecheck) {
        setStage('completed');
      } else if (latestResult.question.id.includes('diag')) {
        setStage('targeted_practice');
      } else {
        const schedule = scheduleDelayedRecheck(new Date(currentTimeMs).toISOString(), defaultRecheckDelayMinutes);
        setRecheckSchedule(schedule);
        setStage('recheck_scheduled');
      }
    }
  };

  const handleAdvanceTimeToRecheck = () => {
    if (!recheckSchedule || !showTestClockControls || !clock?.advanceTo) return;
    const dueTimeMs = Date.parse(recheckSchedule.dueAt);
    clock.advanceTo(dueTimeMs + 1000);
    setClockRevision((revision) => revision + 1);
  };

  const handleStartRecheckSession = () => {
    setSessionId('session-2');
    setStage('recheck_active');
  };

  const handleRestartJourney = () => {
    setStage('diagnose');
    setSessionId(`session-${Date.now()}`);
    setSelectedOptionId(null);
    setLatestResult(null);
    setRecheckSchedule(null);
    setValidationError(null);
    setSystemError(null);
  };

  if (isLoading) {
    return (
      <div className="learning-slice-container" role="region" aria-label="Khu vực học tập">
        <div className="learning-slice-loading" role="status">
          <p>Đang tải dữ liệu bài học...</p>
        </div>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="learning-slice-container" role="region" aria-label="Khu vực học tập">
        <div className="learning-slice-empty" role="status">
          <h3>Không có dữ liệu câu hỏi</h3>
          <p>Hiện chưa có câu hỏi mẫu nào được cấu hình cho kỹ năng này.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="learning-slice-container" role="region" aria-label="Khu vực học tập">
      {/* Top Banner & Provenance */}
      <header className="learning-slice-header">
        <div className="learning-slice-badges">
          <span className="learning-slice-badge learning-slice-badge-sample">SAMPLE / TEST ONLY</span>
          <span className="learning-slice-badge learning-slice-badge-memory">
            Lưu trữ: In-memory (Chỉ lưu trong phiên)
          </span>
        </div>
        <h2 className="learning-slice-title">
          {sampleTaxonomy.skill.name} · <span>{sampleTaxonomy.subject.name}</span>
        </h2>
        <p className="learning-slice-subtitle">
          Quy trình: Chẩn đoán → Ghi nhận lần thử → Giải thích lỗi → Luyện tập mục tiêu → Kiểm tra lại sau
        </p>
      </header>

      {/* Persistence and Scope Limitations Notice */}
      <div className="learning-slice-notice" role="note">
        <strong>Lưu ý kỹ thuật:</strong> Toàn bộ dữ liệu lần thử chỉ được lưu tạm trong bộ nhớ phiên làm việc.
        Hệ thống không giả lập lưu trữ vĩnh viễn (no fake persistence). Câu hỏi là mẫu thử nghiệm tổng hợp, không phải
        đề thi chính thức.
      </div>

      {/* System Error Banner */}
      {systemError && (
        <div className="learning-slice-error-banner" role="alert">
          <p><strong>Lỗi hệ thống:</strong> {systemError}</p>
          <button
            type="button"
            className="learning-slice-button learning-slice-button-secondary"
            onClick={() => setSystemError(null)}
          >
            Đóng thông báo
          </button>
        </div>
      )}

      {/* Journey Steps Indicator */}
      <nav className="learning-slice-steps" aria-label="Các bước học tập">
        <ol>
          <li className={stage === 'diagnose' ? 'learning-slice-step-active' : ''}>
            <span>1</span> Chẩn đoán
          </li>
          <li className={stage === 'explain' ? 'learning-slice-step-active' : ''}>
            <span>2</span> Giải thích
          </li>
          <li className={stage === 'targeted_practice' ? 'learning-slice-step-active' : ''}>
            <span>3</span> Luyện tập mục tiêu
          </li>
          <li
            className={
              stage === 'recheck_scheduled' || stage === 'recheck_active' ? 'learning-slice-step-active' : ''
            }
          >
            <span>4</span> Kiểm tra lại sau
          </li>
        </ol>
      </nav>

      {/* MAIN CONTENT AREA */}
      <main className="learning-slice-body">
        {/* STAGE: DIAGNOSE / TARGETED_PRACTICE / RECHECK_ACTIVE */}
        {(stage === 'diagnose' || stage === 'targeted_practice' || stage === 'recheck_active') && currentQuestion && (
          <section className="learning-slice-question-card" aria-labelledby="learning-slice-question-heading">
            <div className="learning-slice-question-header">
              <span className="learning-slice-tag">
                {stage === 'diagnose'
                  ? 'Giai đoạn: Chẩn đoán'
                  : stage === 'targeted_practice'
                  ? 'Giai đoạn: Luyện tập có mục tiêu'
                  : 'Giai đoạn: Kiểm tra lại sau (Phiên 2)'}
              </span>
              <span className="learning-slice-session-tag">Phiên: {sessionId}</span>
            </div>

            <h3 id="learning-slice-question-heading" className="learning-slice-prompt">
              {currentQuestion.prompt}
            </h3>

            {validationError && (
              <div className="learning-slice-validation-error" role="alert">
                {validationError}
              </div>
            )}

            <form onSubmit={handleSubmit} className="learning-slice-options-form">
              <fieldset className="learning-slice-fieldset">
                <legend className="learning-slice-sr-only">Danh sách đáp án lựa chọn</legend>
                <div className="learning-slice-options-grid">
                  {currentQuestion.options?.map((option) => (
                    <label
                      key={option.id}
                      className={`learning-slice-option-label ${
                        selectedOptionId === option.id ? 'learning-slice-option-selected' : ''
                      }`}
                    >
                      <input
                        type="radio"
                        name="question-option"
                        value={option.id}
                        checked={selectedOptionId === option.id}
                        onChange={() => handleOptionChange(option.id)}
                        className="learning-slice-option-radio"
                      />
                      <span className="learning-slice-option-marker">{option.id}</span>
                      <span className="learning-slice-option-text">{option.text}</span>
                    </label>
                  ))}
                </div>
              </fieldset>

              <div className="learning-slice-actions">
                <button type="submit" className="learning-slice-button learning-slice-button-primary">
                  Nộp câu trả lời
                </button>
              </div>
            </form>
          </section>
        )}

        {/* STAGE: EXPLAIN ERROR & RECOMMENDATION */}
        {stage === 'explain' && latestResult && (
          <section className="learning-slice-feedback-card" aria-labelledby="learning-slice-feedback-heading">
            <div
              className={`learning-slice-result-badge ${
                latestResult.isCorrect ? 'learning-slice-result-correct' : 'learning-slice-result-incorrect'
              }`}
            >
              {latestResult.isCorrect ? '✓ Chính xác!' : '✗ Chưa chính xác'}
            </div>

            <h3 id="learning-slice-feedback-heading" className="learning-slice-feedback-title">
              {latestResult.isCorrect ? 'Bạn đã trả lời đúng' : 'Phân tích bước cần củng cố'}
            </h3>

            {/* Error Classification (Separated from Correctness Assessment) */}
            {!latestResult.isCorrect && latestResult.errorClassification && (
              <div className="learning-slice-error-diagnosis" role="region" aria-label="Chẩn đoán lỗi">
                <div className="learning-slice-diagnosis-header">
                  <span className="learning-slice-tag learning-slice-tag-warning">
                    Thẻ lỗi: {latestResult.errorClassification.errorTag}
                  </span>
                  <span className="learning-slice-diagnosis-caveat">
                    (Dự đoán khả dĩ mang tính tham khảo, không phải kết luận tuyệt đối)
                  </span>
                </div>
                <p className="learning-slice-missing-step">
                  <strong>Bước có thể bị thiếu:</strong> {latestResult.errorClassification.likelyMissingStep}
                </p>
              </div>
            )}

            {/* Explanation */}
            <div className="learning-slice-explanation">
              <h4>Lời giải chi tiết</h4>
              <p>{latestResult.question.explanation}</p>
            </div>

            {/* Next Step Recommendation */}
            <div className="learning-slice-recommendation" role="region" aria-label="Đề xuất học tập">
              <h4>Đề xuất bước tiếp theo</h4>
              <p className="learning-slice-recommendation-kind">
                Loại hoạt động: <strong>{latestResult.recommendation.kind}</strong>
              </p>
              <p className="learning-slice-recommendation-reason">
                <strong>Lý do:</strong> {latestResult.recommendation.reason}
              </p>
            </div>

            <div className="learning-slice-actions">
              <button
                type="button"
                className="learning-slice-button learning-slice-button-primary"
                onClick={handleContinueFromExplain}
              >
                {latestResult.attempt.isDelayedRecheck
                  ? 'Xem tổng kết chu kỳ kiểm chứng'
                  : latestResult.question.id.includes('diag')
                  ? 'Tiếp tục: Luyện tập có mục tiêu'
                  : 'Lên lịch kiểm tra lại sau'}
              </button>
            </div>
          </section>
        )}

        {/* STAGE: DELAYED RECHECK SCHEDULED */}
        {stage === 'recheck_scheduled' && recheckSchedule && (
          <section className="learning-slice-schedule-card" aria-labelledby="learning-slice-schedule-heading">
            <div className="learning-slice-schedule-header">
              <span className="learning-slice-tag learning-slice-tag-info">Lịch kiểm chứng mẫu</span>
            </div>

            <h3 id="learning-slice-schedule-heading" className="learning-slice-schedule-title">
              Lịch kiểm tra lại sau (Delayed Recheck)
            </h3>

            <p className="learning-slice-schedule-text">
              Chu kỳ mẫu có một lần kiểm tra lại sau theo lịch đã chọn.
            </p>

            <dl className="learning-slice-schedule-details">
              <div>
                <dt>Thời gian hẹn kiểm tra:</dt>
                <dd><strong>{new Date(recheckSchedule.dueAt).toLocaleTimeString()}</strong> ({recheckSchedule.dueAt})</dd>
              </div>
              <div>
                <dt>Khoảng cách:</dt>
                <dd>{recheckSchedule.delayMinutes} phút sau phiên học</dd>
              </div>
              <div>
                <dt>Thời gian hiện tại:</dt>
                <dd>{new Date(currentTimeMs).toLocaleTimeString()} ({new Date(currentTimeMs).toISOString()})</dd>
              </div>
            </dl>

            <div className="learning-slice-notice">
              <strong>Lưu ý:</strong> Lịch chỉ điều khiển thời điểm kiểm tra lại mẫu; đây không phải kết luận về năng lực thực tế.
            </div>

            <div className="learning-slice-schedule-actions">
              {isRecheckReady ? (
                <button
                  type="button"
                  className="learning-slice-button learning-slice-button-primary"
                  onClick={handleStartRecheckSession}
                >
                  Đã đến giờ: Bắt đầu kiểm tra lại sau (Phiên 2)
                </button>
              ) : (
                <div className="learning-slice-countdown-box">
                  <p className="learning-slice-waiting-text">
                    Đang đợi đến giờ kiểm tra lại... (Chưa đến giờ)
                  </p>
                  {showTestClockControls && clock?.advanceTo && (
                    <button
                      type="button"
                      className="learning-slice-button learning-slice-button-secondary"
                      onClick={handleAdvanceTimeToRecheck}
                    >
                      Tua nhanh đồng hồ kiểm thử (+60 phút đến giờ kiểm tra)
                    </button>
                  )}
                </div>
              )}
            </div>
          </section>
        )}

        {/* STAGE: COMPLETED SUMMARY */}
        {stage === 'completed' && (
          <section className="learning-slice-summary-card" aria-labelledby="learning-slice-summary-heading">
            <h3 id="learning-slice-summary-heading" className="learning-slice-summary-title">
              Tổng kết hành trình học tập
            </h3>

            <div className="learning-slice-verification-banner">
              <span className="learning-slice-verification-label">Tiến trình kiểm chứng kỹ năng:</span>
              <strong className={`learning-slice-status-badge learning-slice-status-${currentVerificationProgress.status}`}>
                {formatVerificationProgressVietnamese(currentVerificationProgress.status)}
              </strong>
            </div>

            {currentVerificationProgress.status === 'verification_complete' ? (
              <div className="learning-slice-verification-complete-proof" role="status">
                <p>
                  <strong>Hoàn tất chu kỳ kiểm chứng mẫu.</strong>
                </p>
              </div>
            ) : (
              <div className="learning-slice-unreached-proof" role="status">
                <p>
                  <strong>Chưa hoàn tất chu kỳ kiểm chứng mẫu.</strong> Cần ít nhất {verificationPolicy.minIndependentCorrect} câu đúng độc lập qua{' '}
                  {verificationPolicy.minSessions} phiên, trong đó có kiểm tra lại đúng sau khoảng thời gian đã chọn.
                </p>
              </div>
            )}

            <p className="learning-slice-notice" role="note">
              Đây là kết quả hoàn thành chu kỳ luyện tập thử nghiệm, không phải kết luận về năng lực học tập thực tế.
            </p>

            <div className="learning-slice-actions">
              <button
                type="button"
                className="learning-slice-button learning-slice-button-primary"
                onClick={handleRestartJourney}
              >
                Bắt đầu phiên học mới
              </button>
            </div>
          </section>
        )}

        {/* EVIDENCE PANEL (IMMUTABLE ATTEMPT LOG) */}
        <aside className="learning-slice-evidence-panel" aria-labelledby="learning-slice-evidence-heading">
          <div className="learning-slice-evidence-header">
            <h4 id="learning-slice-evidence-heading">Bằng chứng kiểm chứng</h4>
            <span className={`learning-slice-status-pill learning-slice-status-${currentVerificationProgress.status}`}>
              {formatVerificationProgressVietnamese(currentVerificationProgress.status)}
            </span>
          </div>

          <div className="learning-slice-metrics-grid">
            <div className="learning-slice-metric">
              <span className="learning-slice-metric-value">{currentVerificationProgress.evidenceCount}</span>
              <span className="learning-slice-metric-label">Tổng lần thử</span>
            </div>
            <div className="learning-slice-metric">
              <span className="learning-slice-metric-value">{currentVerificationProgress.independentCorrectCount}</span>
              <span className="learning-slice-metric-label">Đúng độc lập</span>
            </div>
            <div className="learning-slice-metric">
              <span className="learning-slice-metric-value">{currentVerificationProgress.sessionCount}</span>
              <span className="learning-slice-metric-label">Số phiên</span>
            </div>
            <div className="learning-slice-metric">
              <span className="learning-slice-metric-value">{currentVerificationProgress.delayedCorrectCount}</span>
              <span className="learning-slice-metric-label">Kiểm tra lại đúng</span>
            </div>
          </div>

          <div className="learning-slice-history-list">
            <h5>Nhật ký lần thử (Append-only)</h5>
            {attempts.length === 0 ? (
              <p className="learning-slice-history-empty">Chưa có lần thử nào được ghi nhận.</p>
            ) : (
              <ol className="learning-slice-attempts-table">
                {attempts.map((att, idx) => (
                  <li key={att.id} className="learning-slice-attempt-item">
                    <span className="learning-slice-attempt-idx">#{idx + 1}</span>
                    <span className="learning-slice-attempt-session">{att.sessionId}</span>
                    <span
                      className={`learning-slice-attempt-res ${
                        att.isCorrect ? 'learning-slice-correct' : 'learning-slice-incorrect'
                      }`}
                    >
                      {att.isCorrect ? 'Đúng' : 'Sai'}
                    </span>
                    {att.isDelayedRecheck && (
                      <span className="learning-slice-attempt-recheck-tag">Delayed</span>
                    )}
                    {att.errorTag && (
                      <span className="learning-slice-attempt-error-tag">[{att.errorTag}]</span>
                    )}
                  </li>
                ))}
              </ol>
            )}
          </div>
        </aside>
      </main>
    </div>
  );
}
