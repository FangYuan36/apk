import {
  appendAttempt,
  classifyError,
  createAttemptEvent,
  DEFAULT_VERIFICATION_POLICY,
  deriveVerificationProgress,
  evaluateAnswer,
  isValidAnswerOption,
  isRecheckDue,
  recommendNextStep,
  scheduleDelayedRecheck,
  type AttemptEvent,
  type ErrorClassification,
  type VerificationPolicy,
  type QuestionItem,
  type VerificationStatus,
} from '../../domain/contracts';
import type { AttemptResultSnapshot, LearningJourneyStage } from './types';

export function getQuestionForStage(
  questions: readonly QuestionItem[],
  stage: LearningJourneyStage,
): QuestionItem | null {
  if (questions.length === 0) return null;

  switch (stage) {
    case 'diagnose':
      return questions.find((q) => q.id.includes('diag')) || questions[0] || null;
    case 'targeted_practice':
      return (
        questions.find((q) => q.id.includes('practice-01')) ||
        questions.find((q) => q.id.includes('practice')) ||
        questions[1] ||
        questions[0] ||
        null
      );
    case 'recheck_active':
      return questions.find((q) => q.id.includes('recheck')) || questions[questions.length - 1] || null;
    default:
      return null;
  }
}

export interface SubmissionParams {
  readonly question: QuestionItem;
  readonly selectedOptionId: string | null;
  readonly attempts: readonly AttemptEvent[];
  readonly sessionId: string;
  readonly isDelayedRecheck: boolean;
  readonly currentTimeMs: number;
  readonly startTimeMs: number;
  readonly verificationPolicy?: VerificationPolicy;
}

export interface SubmissionOutcome {
  readonly success: boolean;
  readonly error?: string;
  readonly updatedAttempts: readonly AttemptEvent[];
  readonly snapshot?: AttemptResultSnapshot;
}

export function handleAnswerSubmission(params: SubmissionParams): SubmissionOutcome {
  const {
    question,
    selectedOptionId,
    attempts,
    sessionId,
    isDelayedRecheck,
    currentTimeMs,
    startTimeMs,
    verificationPolicy = DEFAULT_VERIFICATION_POLICY,
  } = params;

  if (!selectedOptionId || !selectedOptionId.trim()) {
    return {
      success: false,
      error: 'Vui lòng chọn một phương án trước khi nộp bài.',
      updatedAttempts: attempts,
    };
  }

  if (!isValidAnswerOption(question, selectedOptionId)) {
    return {
      success: false,
      error: 'Đáp án không thuộc các lựa chọn hợp lệ của câu hỏi.',
      updatedAttempts: attempts,
    };
  }

  const isCorrect = evaluateAnswer(question, selectedOptionId);
  let errorClassification: ErrorClassification | undefined = undefined;
  if (!isCorrect) {
    errorClassification = classifyError(question, selectedOptionId);
  }

  const previousEvidence = deriveVerificationProgress(attempts, verificationPolicy);
  const durationMs = Math.max(0, currentTimeMs - startTimeMs);
  const attemptId = `attempt-${Date.now()}-${attempts.length + 1}-${Math.random().toString(36).slice(2, 6)}`;

  const newAttempt = createAttemptEvent({
    id: attemptId,
    questionId: question.id,
    questionVersion: question.version,
    skillIds: question.skillIds,
    sessionId,
    submittedAnswer: selectedOptionId,
    isCorrect,
    timestamp: new Date(currentTimeMs).toISOString(),
    durationMs,
    hintsUsed: 0,
    isDelayedRecheck,
    errorTag: errorClassification?.errorTag,
  });

  const updatedAttempts = appendAttempt(attempts, newAttempt);
  const currentEvidence = deriveVerificationProgress(updatedAttempts, verificationPolicy);
  const recommendation = recommendNextStep(updatedAttempts, currentEvidence);

  const snapshot: AttemptResultSnapshot = Object.freeze({
    attempt: newAttempt,
    question,
    isCorrect,
    errorClassification,
    recommendation,
    previousEvidence,
    currentEvidence,
  });

  return {
    success: true,
    updatedAttempts,
    snapshot,
  };
}

export function formatVerificationProgressVietnamese(status: VerificationStatus): string {
  switch (status) {
    case 'not_enough_data':
      return 'Chưa đủ bằng chứng';
    case 'learning':
      return 'Đang thu thập bằng chứng';
    case 'consolidating':
      return 'Đang củng cố bằng chứng';
    case 'verification_complete':
      return 'Hoàn tất chu kỳ kiểm chứng mẫu';
  }
}

export function formatStageNameVietnamese(stage: LearningJourneyStage): string {
  switch (stage) {
    case 'diagnose':
      return 'Chẩn đoán ban đầu';
    case 'explain':
      return 'Giải thích bước còn thiếu';
    case 'targeted_practice':
      return 'Luyện tập có mục tiêu';
    case 'recheck_scheduled':
      return 'Lên lịch kiểm tra lại';
    case 'recheck_active':
      return 'Kiểm tra lại sau';
    case 'completed':
      return 'Hoàn thành hành trình';
  }
}

export { isRecheckDue, scheduleDelayedRecheck };
