import assert from 'node:assert/strict';
import test from 'node:test';
import { act, createElement, type ComponentProps } from 'react';
import { createRoot } from 'react-dom/client';
import { renderToStaticMarkup } from 'react-dom/server';
import { JSDOM } from 'jsdom';
import {
  sampleQuestions,
  sampleTaxonomy,
} from '../content/fixtures/derivative-sign';
import {
  appendAttempt,
  createAttemptEvent,
  DEFAULT_VERIFICATION_POLICY,
  deriveVerificationProgress,
  evaluateAnswer,
  recommendNextStep,
  validateQuestionItem,
  validateSkillMapping,
  type AttemptEvent,
  type VerificationPolicy,
} from '../domain/contracts';
import LearningSlice from './learning-slice/LearningSlice';
import {
  formatVerificationProgressVietnamese,
  getQuestionForStage,
  handleAnswerSubmission,
  isRecheckDue,
  scheduleDelayedRecheck,
} from './learning-slice/learningSliceLogic';

test('sample taxonomy and question fixtures adhere strictly to domain contracts and sample provenance', () => {
  const taxonomyValidation = validateSkillMapping(sampleTaxonomy);
  assert.equal(taxonomyValidation.valid, true);

  assert.equal(sampleQuestions.length >= 3, true);

  for (const q of sampleQuestions) {
    const qValidation = validateQuestionItem(q);
    assert.equal(qValidation.valid, true, `Question ${q.id} failed validation: ${qValidation.errors.join(', ')}`);
    assert.match(q.prompt, /^SAMPLE \/ TEST ONLY:/);
    assert.match(q.explanation, /^SAMPLE \/ TEST ONLY:/);
    assert.equal(q.reviewStatus, 'sample_test_only');
    assert.equal(q.source.kind, 'synthetic');
    assert.deepEqual(q.skillIds, ['sample-skill-derivative-sign']);
  }
});

test('attempts are strictly append-only and immutable; subsequent attempts do not mutate prior history', () => {
  const q1 = sampleQuestions[0];
  const initialEvent = createAttemptEvent({
    id: 'att-001',
    questionId: q1.id,
    questionVersion: q1.version,
    skillIds: q1.skillIds,
    sessionId: 'session-1',
    submittedAnswer: 'A',
    isCorrect: false,
    timestamp: '2026-11-08T08:00:00.000Z',
    durationMs: 12000,
    hintsUsed: 0,
    isDelayedRecheck: false,
    errorTag: 'concept_gap',
  });

  const history1 = Object.freeze([initialEvent]);
  assert.equal(history1.length, 1);
  assert.equal(Object.isFrozen(initialEvent), true);

  const secondEvent = createAttemptEvent({
    id: 'att-002',
    questionId: q1.id,
    questionVersion: q1.version,
    skillIds: q1.skillIds,
    sessionId: 'session-1',
    submittedAnswer: 'B',
    isCorrect: true,
    timestamp: '2026-11-08T08:02:00.000Z',
    durationMs: 8000,
    hintsUsed: 0,
    isDelayedRecheck: false,
  });

  const history2 = appendAttempt(history1, secondEvent);
  assert.equal(history2.length, 2);
  assert.equal(history1.length, 1);
  assert.equal(history2[0], initialEvent);
  assert.equal(history2[1], secondEvent);
  assert.equal(Object.isFrozen(history2), true);

  assert.throws(() => {
    appendAttempt(history2, secondEvent);
  }, /duplicate attempt ID/);
});

test('fixture answer correctness is deterministic across all options', () => {
  const diag = sampleQuestions.find((q) => q.id === 'q-derivative-sign-diag-01')!;
  assert.equal(evaluateAnswer(diag, 'B'), true);
  assert.equal(evaluateAnswer(diag, 'b'), true);
  assert.equal(evaluateAnswer(diag, 'A'), false);
  assert.equal(evaluateAnswer(diag, 'C'), false);
  assert.equal(evaluateAnswer(diag, 'D'), false);
  assert.equal(evaluateAnswer(diag, ''), false);
  assert.equal(evaluateAnswer(diag, null), false);

  const practice = sampleQuestions.find((q) => q.id === 'q-derivative-sign-practice-01')!;
  assert.equal(evaluateAnswer(practice, 'C'), true);
  assert.equal(evaluateAnswer(practice, 'A'), false);

  const recheck = sampleQuestions.find((q) => q.id === 'q-derivative-sign-recheck-01')!;
  assert.equal(evaluateAnswer(recheck, 'B'), true);
  assert.equal(evaluateAnswer(recheck, 'A'), false);
});

test('error classification separates correctness from diagnosis, names likely missing step, and marks uncertainty', () => {
  const diag = sampleQuestions[0];
  const submission = handleAnswerSubmission({
    question: diag,
    selectedOptionId: 'A',
    attempts: [],
    sessionId: 'session-1',
    isDelayedRecheck: false,
    currentTimeMs: 1762588800000,
    startTimeMs: 1762588790000,
  });

  assert.equal(submission.success, true);
  assert.equal(submission.snapshot?.isCorrect, false);
  assert.ok(submission.snapshot?.errorClassification);
  assert.equal(submission.snapshot?.errorClassification?.errorTag, 'concept_gap');
  assert.equal(submission.snapshot?.errorClassification?.isUncertain, true);
  assert.match(submission.snapshot?.errorClassification?.likelyMissingStep ?? '', /Nhầm lẫn/);
  assert.equal(submission.snapshot?.attempt.isCorrect, false);
  assert.equal(submission.snapshot?.attempt.errorTag, 'concept_gap');
});

test('recommendations always expose a short reason tied to learner evidence', () => {
  const emptyRec = recommendNextStep([], deriveVerificationProgress([]));
  assert.equal(emptyRec.kind, 'diagnostic');
  assert.match(emptyRec.reason, /no attempts yet/i);

  const diag = sampleQuestions[0];
  const wrongSubmission = handleAnswerSubmission({
    question: diag,
    selectedOptionId: 'A',
    attempts: [],
    sessionId: 'session-1',
    isDelayedRecheck: false,
    currentTimeMs: 1762588800000,
    startTimeMs: 1762588790000,
  });

  const wrongRec = recommendNextStep(wrongSubmission.updatedAttempts, wrongSubmission.snapshot!.currentEvidence);
  assert.equal(wrongRec.kind, 'guided_practice');
  assert.match(wrongRec.reason, /concept/i);

  const correctSubmission = handleAnswerSubmission({
    question: diag,
    selectedOptionId: 'B',
    attempts: wrongSubmission.updatedAttempts,
    sessionId: 'session-1',
    isDelayedRecheck: false,
    currentTimeMs: 1762588900000,
    startTimeMs: 1762588850000,
  });

  const correctRec = recommendNextStep(correctSubmission.updatedAttempts, correctSubmission.snapshot!.currentEvidence);
  assert.equal(correctRec.kind, 'independent_practice');
  assert.match(correctRec.reason, /correct without hints/i);
});

test('sparse evidence does not yield "Hoàn tất chu kỳ kiểm chứng mẫu"; 0 attempts is not_enough_data, 1 correct attempt is learning', () => {
  const status0 = deriveVerificationProgress([]);
  assert.equal(status0.status, 'not_enough_data');
  assert.equal(formatVerificationProgressVietnamese(status0.status), 'Chưa đủ bằng chứng');

  const diag = sampleQuestions[0];
  const singleCorrectAttempt = createAttemptEvent({
    id: 'att-single',
    questionId: diag.id,
    questionVersion: diag.version,
    skillIds: diag.skillIds,
    sessionId: 'session-1',
    submittedAnswer: 'B',
    isCorrect: true,
    timestamp: '2026-11-08T09:00:00.000Z',
    durationMs: 10000,
    hintsUsed: 0,
    isDelayedRecheck: false,
  });

  const status1 = deriveVerificationProgress([singleCorrectAttempt]);
  assert.equal(status1.status, 'learning');
  assert.equal(formatVerificationProgressVietnamese(status1.status), 'Đang thu thập bằng chứng');
  assert.notEqual(status1.status, 'verification_complete');
});

test('multi-session verification verification: single-session or non-recheck evidence remains below "Hoàn tất chu kỳ kiểm chứng mẫu"', () => {
  const diag = sampleQuestions[0];

  const makeAttempt = (id: string, sess: string, isDelayed: boolean = false): AttemptEvent =>
    createAttemptEvent({
      id,
      questionId: diag.id,
      questionVersion: diag.version,
      skillIds: diag.skillIds,
      sessionId: sess,
      submittedAnswer: 'B',
      isCorrect: true,
      timestamp: `2026-11-08T09:0${id.slice(-1)}:00.000Z`,
      durationMs: 5000,
      hintsUsed: 0,
      isDelayedRecheck: isDelayed,
    });

  // Negative Proof 1: 3 unassisted correct attempts, but all in a single session
  const singleSessionAttempts = [
    makeAttempt('att-s1-1', 'session-1', false),
    makeAttempt('att-s1-2', 'session-1', false),
    makeAttempt('att-s1-3', 'session-1', false),
  ];
  const singleSessionEvidence = deriveVerificationProgress(singleSessionAttempts, DEFAULT_VERIFICATION_POLICY);
  assert.equal(singleSessionEvidence.independentCorrectCount, 3);
  assert.equal(singleSessionEvidence.sessionCount, 1);
  assert.equal(singleSessionEvidence.status, 'consolidating');
  assert.notEqual(singleSessionEvidence.status, 'verification_complete');

  // Negative Proof 2: 3 unassisted correct attempts across 2 sessions, but no delayed recheck
  const noRecheckAttempts = [
    makeAttempt('att-nr-1', 'session-1', false),
    makeAttempt('att-nr-2', 'session-1', false),
    makeAttempt('att-nr-3', 'session-2', false),
  ];
  const noRecheckEvidence = deriveVerificationProgress(noRecheckAttempts, DEFAULT_VERIFICATION_POLICY);
  assert.equal(noRecheckEvidence.independentCorrectCount, 3);
  assert.equal(noRecheckEvidence.sessionCount, 2);
  assert.equal(noRecheckEvidence.delayedCorrectCount, 0);
  assert.equal(noRecheckEvidence.status, 'consolidating');
  assert.notEqual(noRecheckEvidence.status, 'verification_complete');

  // Positive Proof: At least 3 unassisted correct attempts across at least 2 sessions, including at least 1 correct delayed recheck
  const verificationAttempts = [
    makeAttempt('att-m-1', 'session-1', false),
    makeAttempt('att-m-2', 'session-1', false),
    makeAttempt('att-m-3', 'session-2', true), // delayed recheck in session-2
  ];
  const verificationEvidence = deriveVerificationProgress(verificationAttempts, DEFAULT_VERIFICATION_POLICY);
  assert.equal(verificationEvidence.independentCorrectCount, 3);
  assert.equal(verificationEvidence.sessionCount, 2);
  assert.equal(verificationEvidence.delayedCorrectCount, 1);
  assert.equal(verificationEvidence.status, 'verification_complete');
  assert.equal(formatVerificationProgressVietnamese(verificationEvidence.status), 'Hoàn tất chu kỳ kiểm chứng mẫu');
});

test('supports configurable verification policy overrides without modifying domain constants', () => {
  const customPolicy: VerificationPolicy = {
    minIndependentCorrect: 2,
    minSessions: 2,
    requireDelayedRecheck: false,
  };

  const diag = sampleQuestions[0];
  const attempts = [
    createAttemptEvent({
      id: 'c-1',
      questionId: diag.id,
      questionVersion: diag.version,
      skillIds: diag.skillIds,
      sessionId: 'sess-A',
      submittedAnswer: 'B',
      isCorrect: true,
      timestamp: '2026-11-08T09:00:00.000Z',
      durationMs: 5000,
      hintsUsed: 0,
      isDelayedRecheck: false,
    }),
    createAttemptEvent({
      id: 'c-2',
      questionId: diag.id,
      questionVersion: diag.version,
      skillIds: diag.skillIds,
      sessionId: 'sess-B',
      submittedAnswer: 'B',
      isCorrect: true,
      timestamp: '2026-11-08T10:00:00.000Z',
      durationMs: 5000,
      hintsUsed: 0,
      isDelayedRecheck: false,
    }),
  ];

  assert.equal(deriveVerificationProgress(attempts, customPolicy).status, 'verification_complete');
  assert.equal(deriveVerificationProgress(attempts, DEFAULT_VERIFICATION_POLICY).status, 'consolidating');
});

test('submission recommendation uses the same custom policy evidence as displayed verification progress', () => {
  const customPolicy: VerificationPolicy = {
    minIndependentCorrect: 1,
    minSessions: 1,
    requireDelayedRecheck: false,
  };
  const outcome = handleAnswerSubmission({
    question: sampleQuestions[0],
    selectedOptionId: 'B',
    attempts: [],
    sessionId: 'session-custom',
    isDelayedRecheck: false,
    currentTimeMs: 1762588800000,
    startTimeMs: 1762588790000,
    verificationPolicy: customPolicy,
  });

  assert.equal(outcome.success, true);
  assert.equal(outcome.snapshot?.currentEvidence.status, 'verification_complete');
  assert.equal(outcome.snapshot?.recommendation.kind, 'verification_complete');
  assert.match(outcome.snapshot?.recommendation.reason ?? '', /sample verification cycle/i);
});

test('invalid options are rejected before an attempt is appended', () => {
  const before = Object.freeze<readonly AttemptEvent[]>([]);
  const outcome = handleAnswerSubmission({
    question: sampleQuestions[0],
    selectedOptionId: 'Z',
    attempts: before,
    sessionId: 'session-1',
    isDelayedRecheck: false,
    currentTimeMs: 1762588800000,
    startTimeMs: 1762588790000,
  });

  assert.equal(outcome.success, false);
  assert.match(outcome.error ?? '', /không thuộc.*lựa chọn/i);
  assert.equal(outcome.updatedAttempts, before);
  assert.equal(outcome.updatedAttempts.length, 0);
  assert.equal(outcome.snapshot, undefined);
});

test('delayed recheck scheduling and controllable clock transitions', () => {
  const baseTime = '2026-11-08T12:00:00.000Z';
  const schedule = scheduleDelayedRecheck(baseTime, 60);

  assert.equal(schedule.delayMinutes, 60);
  assert.equal(schedule.dueAt, '2026-11-08T13:00:00.000Z');

  // Clock before due time
  const simulatedTimeBefore = Date.parse('2026-11-08T12:30:00.000Z');
  assert.equal(isRecheckDue(schedule.dueAt, simulatedTimeBefore), false);

  // Clock at due time
  const simulatedTimeAt = Date.parse('2026-11-08T13:00:00.000Z');
  assert.equal(isRecheckDue(schedule.dueAt, simulatedTimeAt), true);

  // Clock after due time
  const simulatedTimeAfter = Date.parse('2026-11-08T13:15:00.000Z');
  assert.equal(isRecheckDue(schedule.dueAt, simulatedTimeAfter), true);
});

test('UI state rendering: loading, empty, and question card with sample and in-memory badges', () => {
  // Loading state
  const loadingHtml = renderToStaticMarkup(createElement(LearningSlice, { simulateLoading: true }));
  assert.match(loadingHtml, /Đang tải dữ liệu bài học/);

  // Empty state
  const emptyHtml = renderToStaticMarkup(createElement(LearningSlice, { questions: [] }));
  assert.match(emptyHtml, /Không có dữ liệu câu hỏi/);

  // Normal initial render
  const defaultHtml = renderToStaticMarkup(createElement(LearningSlice));
  assert.match(defaultHtml, /SAMPLE \/ TEST ONLY/);
  assert.match(defaultHtml, /In-memory/);
  assert.match(defaultHtml, /Đọc dấu đạo hàm/);
  assert.match(defaultHtml, /Quy trình: Chẩn đoán → Ghi nhận lần thử → Giải thích lỗi → Luyện tập mục tiêu → Kiểm tra lại sau/);
  assert.match(defaultHtml, /Nhật ký lần thử \(Append-only\)/);
  assert.match(defaultHtml, /Chưa có lần thử nào được ghi nhận/);
  assert.match(defaultHtml, /Chưa đủ bằng chứng/);
});

test('UI validation error when submitting without an option selected', () => {
  const outcome = handleAnswerSubmission({
    question: sampleQuestions[0],
    selectedOptionId: null,
    attempts: [],
    sessionId: 'session-1',
    isDelayedRecheck: false,
    currentTimeMs: 1000,
    startTimeMs: 0,
  });

  assert.equal(outcome.success, false);
  assert.match(outcome.error ?? '', /Vui lòng chọn một phương án/);
  assert.equal(outcome.updatedAttempts.length, 0);
});

test('end-to-end learning slice journey: DIAGNOSE -> EXPLAIN -> PRACTICE -> RECHECK SCHEDULE -> RECHECK ACTIVE -> COMPLETE', () => {
  // Step 1: Diagnose stage question lookup
  const diagQ = getQuestionForStage(sampleQuestions, 'diagnose')!;
  assert.ok(diagQ);
  assert.equal(diagQ.id, 'q-derivative-sign-diag-01');

  // Submit diagnostic (incorrect answer A)
  let attempts: readonly AttemptEvent[] = [];
  const res1 = handleAnswerSubmission({
    question: diagQ,
    selectedOptionId: 'A',
    attempts,
    sessionId: 'session-1',
    isDelayedRecheck: false,
    currentTimeMs: 1762588800000,
    startTimeMs: 1762588790000,
  });
  assert.equal(res1.success, true);
  attempts = res1.updatedAttempts;
  assert.equal(attempts.length, 1);
  assert.equal(attempts[0].isCorrect, false);
  assert.equal(attempts[0].errorTag, 'concept_gap');

  // Step 2: Explanation & Recommendation
  const diagRec = recommendNextStep(attempts, deriveVerificationProgress(attempts));
  assert.equal(diagRec.kind, 'guided_practice');

  // Step 3: Targeted Practice
  const practiceQ = getQuestionForStage(sampleQuestions, 'targeted_practice')!;
  assert.ok(practiceQ);
  assert.equal(practiceQ.id, 'q-derivative-sign-practice-01');

  // Submit practice (correct answer C)
  const res2 = handleAnswerSubmission({
    question: practiceQ,
    selectedOptionId: 'C',
    attempts,
    sessionId: 'session-1',
    isDelayedRecheck: false,
    currentTimeMs: 1762588900000,
    startTimeMs: 1762588850000,
  });
  assert.equal(res2.success, true);
  attempts = res2.updatedAttempts;
  assert.equal(attempts.length, 2);
  assert.equal(attempts[1].isCorrect, true);

  // Status after Session 1
  const s1Status = deriveVerificationProgress(attempts);
  assert.equal(s1Status.independentCorrectCount, 1);
  assert.equal(s1Status.status, 'consolidating'); // Gate remains incomplete.
  assert.notEqual(s1Status.status, 'verification_complete');

  // Additional practice question in Session 1 to test independent count accumulation
  const practiceQ2 = sampleQuestions.find((q) => q.id === 'q-derivative-sign-practice-02')!;
  const res3 = handleAnswerSubmission({
    question: practiceQ2,
    selectedOptionId: 'A', // correct
    attempts,
    sessionId: 'session-1',
    isDelayedRecheck: false,
    currentTimeMs: 1762588950000,
    startTimeMs: 1762588920000,
  });
  attempts = res3.updatedAttempts;
  assert.equal(attempts.length, 3);
  assert.equal(deriveVerificationProgress(attempts).independentCorrectCount, 2);
  assert.equal(deriveVerificationProgress(attempts).sessionCount, 1);
  assert.equal(deriveVerificationProgress(attempts).status, 'consolidating'); // Still consolidating!

  // Step 4: Schedule Delayed Recheck
  const schedule = scheduleDelayedRecheck('2026-11-08T10:00:00.000Z', 60);
  assert.equal(isRecheckDue(schedule.dueAt, Date.parse('2026-11-08T10:30:00.000Z')), false);
  assert.equal(isRecheckDue(schedule.dueAt, Date.parse('2026-11-08T11:00:00.000Z')), true);

  // Step 5: Delayed Recheck in Session 2
  const recheckQ = getQuestionForStage(sampleQuestions, 'recheck_active')!;
  assert.ok(recheckQ);
  assert.equal(recheckQ.id, 'q-derivative-sign-recheck-01');

  // Submit recheck (correct answer B)
  const res4 = handleAnswerSubmission({
    question: recheckQ,
    selectedOptionId: 'B',
    attempts,
    sessionId: 'session-2', // New session
    isDelayedRecheck: true,
    currentTimeMs: Date.parse(schedule.dueAt),
    startTimeMs: Date.parse(schedule.dueAt) - 15000,
  });
  assert.equal(res4.success, true);
  attempts = res4.updatedAttempts;
  assert.equal(attempts.length, 4);
  assert.equal(attempts[3].isDelayedRecheck, true);
  assert.equal(attempts[3].sessionId, 'session-2');

  // Final sample verification result
  const finalEvidence = deriveVerificationProgress(attempts);
  assert.equal(finalEvidence.independentCorrectCount, 3);
  assert.equal(finalEvidence.sessionCount, 2);
  assert.equal(finalEvidence.delayedCorrectCount, 1);
  assert.equal(finalEvidence.status, 'verification_complete');
  assert.equal(formatVerificationProgressVietnamese(finalEvidence.status), 'Hoàn tất chu kỳ kiểm chứng mẫu');

  // Test static render of the completed state with these attempts
  const completedHtml = renderToStaticMarkup(
    createElement(LearningSlice, {
      initialStage: 'completed',
      initialAttempts: attempts,
      initialSessionId: 'session-2',
    }),
  );
  assert.match(completedHtml, /Tiến trình kiểm chứng kỹ năng/);
  assert.match(completedHtml, /Hoàn tất chu kỳ kiểm chứng mẫu/);
  assert.match(completedHtml, /Đây là kết quả hoàn thành chu kỳ luyện tập thử nghiệm, không phải kết luận về năng lực học tập thực tế\./);
  assert.doesNotMatch(completedHtml, /Đã vững|thành thạo|proficiency|mastery/i);
  assert.match(completedHtml, /Tổng lần thử/);
  assert.match(completedHtml, /Đúng độc lập/);
});

interface MountedSlice {
  readonly dom: JSDOM;
  readonly container: HTMLElement;
  readonly dispose: () => Promise<void>;
}

async function mountSlice(props: ComponentProps<typeof LearningSlice> = {}): Promise<MountedSlice> {
  const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
    url: 'http://localhost/',
    pretendToBeVisual: true,
  });
  const globals: Record<string, unknown> = {
    window: dom.window,
    document: dom.window.document,
    navigator: dom.window.navigator,
    HTMLElement: dom.window.HTMLElement,
    Node: dom.window.Node,
    Event: dom.window.Event,
    MouseEvent: dom.window.MouseEvent,
    IS_REACT_ACT_ENVIRONMENT: true,
  };
  const prior = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries(globals)) {
    prior.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  }

  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);
  await act(async () => {
    root.render(createElement(LearningSlice, props));
  });

  return {
    dom,
    container,
    dispose: async () => {
      await act(async () => root.unmount());
      dom.window.close();
      for (const [key, descriptor] of prior) {
        if (descriptor) Object.defineProperty(globalThis, key, descriptor);
        else Reflect.deleteProperty(globalThis, key);
      }
    },
  };
}

function findButton(container: HTMLElement, label: string): HTMLButtonElement {
  const button = Array.from(container.querySelectorAll('button')).find((item) => item.textContent?.includes(label));
  assert.ok(button, `Expected a button containing: ${label}`);
  return button;
}

async function clickButton(container: HTMLElement, label: string): Promise<void> {
  await act(async () => findButton(container, label).click());
}

async function chooseOption(container: HTMLElement, id: string): Promise<void> {
  const input = container.querySelector<HTMLInputElement>(`input[type="radio"][value="${id}"]`);
  assert.ok(input, `Expected answer option ${id}`);
  await act(async () => input.click());
}

test('mounted React UI completes the sample verification journey through user interactions', async () => {
  let now = Date.parse('2026-11-08T12:00:00.000Z');
  const recorded: AttemptEvent[] = [];
  const clock = {
    now: () => now,
    advanceTo: (timeMs: number) => { now = timeMs; },
  };
  const view = await mountSlice({
    clock,
    showTestClockControls: true,
    defaultRecheckDelayMinutes: 60,
    onAttemptRecorded: (attempt) => recorded.push(attempt),
  });

  try {
    assert.match(view.container.textContent ?? '', /Lưu trữ: In-memory/);

    await clickButton(view.container, 'Nộp câu trả lời');
    assert.match(view.container.querySelector('[role="alert"]')?.textContent ?? '', /Vui lòng chọn/);
    assert.match(view.container.textContent ?? '', /Chưa có lần thử nào được ghi nhận/);

    await chooseOption(view.container, 'B');
    await clickButton(view.container, 'Nộp câu trả lời');
    assert.match(view.container.textContent ?? '', /Bạn đã trả lời đúng/);
    assert.match(view.container.textContent ?? '', /Lời giải chi tiết/);
    await clickButton(view.container, 'Tiếp tục: Luyện tập có mục tiêu');
    assert.match(view.container.textContent ?? '', /Giai đoạn: Luyện tập có mục tiêu/);

    await chooseOption(view.container, 'C');
    await clickButton(view.container, 'Nộp câu trả lời');
    assert.match(view.container.textContent ?? '', /Bạn đã trả lời đúng/);
    await clickButton(view.container, 'Lên lịch kiểm tra lại sau');
    assert.match(view.container.textContent ?? '', /Lịch kiểm tra lại sau/);
    assert.match(view.container.textContent ?? '', /Đang đợi đến giờ kiểm tra lại/);
    await clickButton(view.container, 'Tua nhanh đồng hồ kiểm thử');
    assert.match(view.container.textContent ?? '', /Đã đến giờ: Bắt đầu kiểm tra lại sau/);
    await clickButton(view.container, 'Đã đến giờ: Bắt đầu kiểm tra lại sau');
    assert.match(view.container.textContent ?? '', /Giai đoạn: Kiểm tra lại sau/);

    await chooseOption(view.container, 'B');
    await clickButton(view.container, 'Nộp câu trả lời');
    assert.match(view.container.textContent ?? '', /Bạn đã trả lời đúng/);
    await clickButton(view.container, 'Xem tổng kết chu kỳ kiểm chứng');

    const finalUI = view.container.textContent ?? '';
    assert.match(finalUI, /Tiến trình kiểm chứng kỹ năng/);
    assert.match(finalUI, /Hoàn tất chu kỳ kiểm chứng mẫu/);
    assert.match(finalUI, /Đây là kết quả hoàn thành chu kỳ luyện tập thử nghiệm, không phải kết luận về năng lực học tập thực tế\./);
    assert.doesNotMatch(finalUI, /Đã vững|thành thạo|proficiency|mastery/i);
    assert.equal(view.container.querySelectorAll('.learning-slice-attempts-table li').length, 3);
    assert.equal(recorded.length, 3);
  } finally {
    await view.dispose();
  }
});

test('mounted React UI shows uncertain wrong-answer diagnosis and does not expose test clock controls by default', async () => {
  const view = await mountSlice();
  try {
    assert.doesNotMatch(view.container.textContent ?? '', /Tua nhanh đồng hồ kiểm thử/);
    await chooseOption(view.container, 'A');
    await clickButton(view.container, 'Nộp câu trả lời');
    assert.match(view.container.textContent ?? '', /Chưa chính xác/);
    assert.match(view.container.querySelector('[aria-label="Chẩn đoán lỗi"]')?.textContent ?? '', /không phải kết luận tuyệt đối/);
    assert.match(view.container.textContent ?? '', /Đề xuất bước tiếp theo/);
  } finally {
    await view.dispose();
  }

  const refreshed = await mountSlice();
  try {
    assert.match(refreshed.container.textContent ?? '', /Chưa có lần thử nào được ghi nhận/);
    assert.doesNotMatch(refreshed.container.textContent ?? '', /Đã lưu lâu dài|Đã đồng bộ/);
  } finally {
    await refreshed.dispose();
  }
});

test('mounted React UI exposes loading, empty, and system-error states without recording failed submissions', async () => {
  const loading = await mountSlice({ simulateLoading: true });
  try {
    assert.match(loading.container.querySelector('[role="status"]')?.textContent ?? '', /Đang tải dữ liệu bài học/);
  } finally {
    await loading.dispose();
  }

  const empty = await mountSlice({ questions: [] });
  try {
    assert.match(empty.container.querySelector('[role="status"]')?.textContent ?? '', /Không có dữ liệu câu hỏi/);
  } finally {
    await empty.dispose();
  }

  const failed = await mountSlice({ clock: { now: () => Number.NaN } });
  try {
    await chooseOption(failed.container, 'B');
    await clickButton(failed.container, 'Nộp câu trả lời');
    assert.match(failed.container.querySelector('[role="alert"]')?.textContent ?? '', /Lỗi hệ thống/);
    assert.match(failed.container.textContent ?? '', /Chưa có lần thử nào được ghi nhận/);
  } finally {
    await failed.dispose();
  }
});
