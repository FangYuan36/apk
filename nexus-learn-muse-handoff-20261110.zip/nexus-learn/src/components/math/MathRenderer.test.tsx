import assert from 'node:assert/strict';
import test from 'node:test';
import { act, createElement } from 'react';
import { createRoot } from 'react-dom/client';
import { JSDOM } from 'jsdom';
import { MathRenderer, VariationTable } from './MathRenderer';

function setupDom() {
  const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>');
  const g = globalThis as Record<string, unknown>;
  g.window = dom.window;
  g.document = dom.window.document;
  g.HTMLElement = dom.window.HTMLElement;
  g.Node = dom.window.Node;
  g.IS_REACT_ACT_ENVIRONMENT = true;
  return dom;
}

test('MathRenderer renders inline math with accessible aria-label and semantic spans', async () => {
  const dom = setupDom();
  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);

  await act(async () => {
    root.render(
      createElement(MathRenderer, {
        math: 'f(x) = x^2 + 2x - 3',
        ariaLabel: 'Hàm số f(x)',
      }),
    );
  });

  const el = container.querySelector('.math-renderer');
  assert.ok(el, 'MathRenderer element should exist');
  assert.equal(el.getAttribute('role'), 'math');
  assert.equal(el.getAttribute('aria-label'), 'Hàm số f(x)');
  assert.equal(el.classList.contains('math-inline'), true);
});

test('MathRenderer renders display fractions and radicals correctly', async () => {
  const dom = setupDom();
  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);

  await act(async () => {
    root.render(
      createElement(MathRenderer, {
        math: '\\frac{2x+1}{x-1} + \\sqrt{x+2}',
        display: true,
      }),
    );
  });

  const el = container.querySelector('.math-display');
  assert.ok(el, 'Display container should exist');
  const frac = el.querySelector('.math-fraction');
  assert.ok(frac, 'Fraction container should exist');
  assert.equal(frac.querySelector('.math-numerator')?.textContent, '2x+1');
  assert.equal(frac.querySelector('.math-denominator')?.textContent, 'x-1');
  const rad = el.querySelector('.math-radical');
  assert.ok(rad, 'Radical container should exist');
  assert.equal(rad.querySelector('.math-radicand')?.textContent, 'x+2');
});

test('MathRenderer falls back gracefully on arbitrary or malformed input without crashing', async () => {
  const dom = setupDom();
  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);

  await assert.doesNotReject(async () => {
    await act(async () => {
      root.render(
        createElement(MathRenderer, {
          math: 'Malformed \\frac{incomplete and <script>alert("xss")</script>',
        }),
      );
    });
  });
});

test('VariationTable renders rows for x, derivative, and function with directional indicators', async () => {
  const dom = setupDom();
  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);

  await act(async () => {
    root.render(
      createElement(VariationTable, {
        title: 'Bảng biến thiên hàm số bậc ba',
        xRow: ['-\\infty', '-1', '2', '+\\infty'],
        derivativeRow: ['+', '0', '-', '0', '+'],
        functionRow: [
          { val: '-\\infty', arrow: 'up' },
          { val: '4', arrow: 'down' },
          { val: '-1', arrow: 'up' },
          { val: '+\\infty' },
        ],
      }),
    );
  });

  const table = container.querySelector('.variation-table');
  assert.ok(table, 'Variation table should render');
  const rows = table.querySelectorAll('tbody tr');
  assert.equal(rows.length, 3, 'Should render 3 rows: x, derivative, and function');
  assert.equal(rows[0].querySelector('th')?.textContent?.trim(), 'x');
  assert.ok(rows[1].querySelector('th')?.textContent?.includes('y'));
  assert.equal(rows[2].querySelector('th')?.textContent?.trim(), 'y');
});

// ==========================================
// ADVERSARIAL SECURITY & XSS MITIGATION TESTS
// ==========================================

test('Security: img with onerror is rendered as inert text and cannot create img elements', async () => {
  const dom = setupDom();
  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);

  await act(async () => {
    root.render(
      createElement(MathRenderer, {
        math: '<img src=x onerror="window.xssExecuted=true">',
      }),
    );
  });

  // Must not create any img element
  const img = container.querySelector('img');
  assert.equal(img, null, 'No <img> DOM element may be created from input');

  // Window global must remain untouched
  assert.equal((dom.window as unknown as { xssExecuted?: boolean }).xssExecuted, undefined);

  // Raw tag must remain inert text content
  assert.match(container.textContent ?? '', /<img src=x onerror="window.xssExecuted=true">/);
});

test('Security: SVG with embedded script remains inert text without creating SVG or executing script', async () => {
  const dom = setupDom();
  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);

  await act(async () => {
    root.render(
      createElement(MathRenderer, {
        math: '<svg onload="window.svgXss=true"><script>window.svgXss2=true</script></svg>',
      }),
    );
  });

  assert.equal(container.querySelector('svg'), null, 'No <svg> DOM element may be created');
  assert.equal(container.querySelector('script'), null, 'No <script> DOM element may be created');
  assert.equal((dom.window as unknown as { svgXss?: boolean }).svgXss, undefined);
  assert.equal((dom.window as unknown as { svgXss2?: boolean }).svgXss2, undefined);
});

test('Security: HTML tags inside LaTeX fractions remain inert text nodes within numerator and denominator', async () => {
  const dom = setupDom();
  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);

  await act(async () => {
    root.render(
      createElement(MathRenderer, {
        math: '\\frac{<b>dangerous-bold</b>}{<iframe src="javascript:alert(1)"></iframe>}',
      }),
    );
  });

  // No <b> or <iframe> DOM elements created
  assert.equal(container.querySelector('b'), null, 'No <b> elements created');
  assert.equal(container.querySelector('iframe'), null, 'No <iframe> elements created');

  const num = container.querySelector('.math-numerator');
  const den = container.querySelector('.math-denominator');
  assert.equal(num?.textContent, '<b>dangerous-bold</b>');
  assert.equal(den?.textContent, '<iframe src="javascript:alert(1)"></iframe>');
});

test('Security: deeply malformed nested LaTeX expressions fall back safely without crashing or throwing', async () => {
  const dom = setupDom();
  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);

  const malformedInputs = [
    '\\frac{\\frac{\\frac{1}{2}{\\frac{3}{4}}}',
    '\\sqrt[\\frac{1}{0',
    '\\frac{}{}{}{}{}{}',
    '\\left( \\right} \\left\\left\\left',
    '^{^{^{^{^{100}}}}}',
    '_{_{_{_{_{100}}}}}',
  ];

  for (const input of malformedInputs) {
    await assert.doesNotReject(async () => {
      await act(async () => {
        root.render(createElement(MathRenderer, { math: input }));
      });
    }, `Malformed input should not crash: ${input}`);
  }
});

test('Security: long inline expressions with 10,000 characters process safely without stack overflow', async () => {
  const dom = setupDom();
  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);

  const longInput = 'x + ' + '\\frac{1}{2} + '.repeat(1000) + 'y';

  await act(async () => {
    root.render(createElement(MathRenderer, { math: longInput }));
  });

  const el = container.querySelector('.math-renderer');
  assert.ok(el, 'Long expression should render without error');
  const fractions = container.querySelectorAll('.math-fraction');
  assert.equal(fractions.length, 1000, 'All 1000 fractions parsed safely');
});
