import React, { useMemo } from 'react';

export interface MathRendererProps {
  readonly math: string;
  readonly display?: boolean;
  readonly className?: string;
  readonly ariaLabel?: string;
}

/**
 * Symbol mapping for common LaTeX macros to Unicode characters.
 * These are returned as safe string text nodes.
 */
const SYMBOL_MAP: Record<string, string> = {
  '\\pm': '±',
  '\\mp': '∓',
  '\\times': '×',
  '\\div': '÷',
  '\\cdot': '·',
  '\\leq': '≤',
  '\\le': '≤',
  '\\geq': '≥',
  '\\ge': '≥',
  '\\neq': '≠',
  '\\ne': '≠',
  '\\approx': '≈',
  '\\infty': '∞',
  '\\to': '→',
  '\\rightarrow': '→',
  '\\leftarrow': '←',
  '\\nearrow': '↗',
  '\\searrow': '↘',
  '\\in': '∈',
  '\\notin': '∉',
  '\\subset': '⊂',
  '\\cup': '∪',
  '\\cap': '∩',
  '\\forall': '∀',
  '\\exists': '∃',
  '\\Delta': 'Δ',
  '\\delta': 'δ',
  '\\alpha': 'α',
  '\\beta': 'β',
  '\\gamma': 'γ',
  '\\pi': 'π',
  '\\theta': 'θ',
  '\\mathbb{R}': 'ℝ',
  '\\mathbb{N}': 'ℕ',
  '\\mathbb{Z}': 'ℤ',
  '\\mathbb{Q}': 'ℚ',
  '\\setminus': '\\',
  '\\prime': '′',
  "\\'": '′',
  '\\,': ' ',
  '\\quad': '  ',
  '\\qquad': '    ',
};

/**
 * Extracts balanced { ... } content starting at index `start`.
 */
function extractBraced(str: string, start: number): { content: string; nextIndex: number } | null {
  const openIdx = str.indexOf('{', start);
  if (openIdx === -1) return null;

  let depth = 0;
  for (let i = openIdx; i < str.length; i++) {
    if (str[i] === '{') depth++;
    else if (str[i] === '}') {
      depth--;
      if (depth === 0) {
        return {
          content: str.slice(openIdx + 1, i),
          nextIndex: i + 1,
        };
      }
    }
  }
  return null;
}

/**
 * Extracts optional balanced [ ... ] content starting at index `start`.
 */
function extractBracketed(str: string, start: number): { content: string; nextIndex: number } | null {
  let idx = start;
  while (idx < str.length && str[idx] === ' ') idx++;
  if (idx >= str.length || str[idx] !== '[') return null;

  let depth = 0;
  for (let i = idx; i < str.length; i++) {
    if (str[i] === '[') depth++;
    else if (str[i] === ']') {
      depth--;
      if (depth === 0) {
        return {
          content: str.slice(idx + 1, i),
          nextIndex: i + 1,
        };
      }
    }
  }
  return null;
}

/**
 * Safe AST parser that converts LaTeX strings directly into React elements and text nodes.
 * NEVER uses dangerouslySetInnerHTML or eval. Any HTML/SVG tags in input remain safe inert text.
 */
export function parseLatexToNodes(latex: string, keyPrefix = 'm'): React.ReactNode[] {
  if (!latex) return [];

  const nodes: React.ReactNode[] = [];
  let i = 0;
  let textBuffer = '';
  let counter = 0;

  const flushText = () => {
    if (textBuffer.length > 0) {
      nodes.push(textBuffer);
      textBuffer = '';
    }
  };

  while (i < latex.length) {
    // 1. Math Macro / Command starting with '\'
    if (latex[i] === '\\') {
      // Find command name
      const match = latex.slice(i).match(/^\\([a-zA-Z]+|\S)/);
      if (match) {
        const fullCmd = match[0];
        const cmdName = match[1];

        // 1a. Fraction: \frac{num}{den}
        if (cmdName === 'frac') {
          flushText();
          const numRes = extractBraced(latex, i + fullCmd.length);
          if (numRes) {
            const denRes = extractBraced(latex, numRes.nextIndex);
            if (denRes) {
              const nodeKey = `${keyPrefix}-frac-${counter++}`;
              nodes.push(
                React.createElement(
                  'span',
                  { key: nodeKey, className: 'math-fraction' },
                  React.createElement(
                    'span',
                    { className: 'math-numerator' },
                    ...parseLatexToNodes(numRes.content, `${nodeKey}-num`),
                  ),
                  React.createElement(
                    'span',
                    { className: 'math-denominator' },
                    ...parseLatexToNodes(denRes.content, `${nodeKey}-den`),
                  ),
                ),
              );
              i = denRes.nextIndex;
              continue;
            }
          }
        }

        // 1b. Radical: \sqrt[n]{rad} or \sqrt{rad}
        if (cmdName === 'sqrt') {
          flushText();
          let nextIdx = i + fullCmd.length;
          const rootIndexRes = extractBracketed(latex, nextIdx);
          if (rootIndexRes) {
            nextIdx = rootIndexRes.nextIndex;
          }
          const radRes = extractBraced(latex, nextIdx);
          if (radRes) {
            const nodeKey = `${keyPrefix}-rad-${counter++}`;
            nodes.push(
              React.createElement(
                'span',
                { key: nodeKey, className: 'math-radical' },
                rootIndexRes
                  ? React.createElement(
                      'sup',
                      { className: 'math-root-index' },
                      ...parseLatexToNodes(rootIndexRes.content, `${nodeKey}-idx`),
                    )
                  : null,
                React.createElement('span', { className: 'math-radical-symbol' }, '√'),
                React.createElement(
                  'span',
                  { className: 'math-radicand' },
                  ...parseLatexToNodes(radRes.content, `${nodeKey}-base`),
                ),
              ),
            );
            i = radRes.nextIndex;
            continue;
          }
        }

        // 1c. Limits: \lim_{target} or \lim
        if (cmdName === 'lim') {
          flushText();
          let afterLim = i + fullCmd.length;
          while (afterLim < latex.length && latex[afterLim] === ' ') afterLim++;
          if (latex[afterLim] === '_') {
            const limTargetRes = extractBraced(latex, afterLim + 1);
            if (limTargetRes) {
              const nodeKey = `${keyPrefix}-lim-${counter++}`;
              nodes.push(
                React.createElement(
                  'span',
                  { key: nodeKey, className: 'math-limit' },
                  React.createElement('span', { className: 'math-lim-op' }, 'lim'),
                  React.createElement(
                    'sub',
                    { className: 'math-lim-target' },
                    ...parseLatexToNodes(limTargetRes.content, `${nodeKey}-t`),
                  ),
                ),
              );
              i = limTargetRes.nextIndex;
              continue;
            }
          } else {
            nodes.push(React.createElement('span', { key: `${keyPrefix}-lim-${counter++}`, className: 'math-func' }, 'lim'));
            i = afterLim;
            continue;
          }
        }

        // 1d. Named Functions: \sin, \cos, \tan, \ln, \log, etc.
        if (['sin', 'cos', 'tan', 'cot', 'ln', 'log', 'exp', 'max', 'min'].includes(cmdName)) {
          flushText();
          nodes.push(React.createElement('span', { key: `${keyPrefix}-fn-${counter++}`, className: 'math-func' }, cmdName));
          i += fullCmd.length;
          continue;
        }

        // 1e. Symbols from map
        const mapped = SYMBOL_MAP[fullCmd] || SYMBOL_MAP[latex.slice(i, i + fullCmd.length)];
        if (mapped !== undefined) {
          textBuffer += mapped;
          i += fullCmd.length;
          continue;
        }

        // 1f. Ignored wrappers: \left, \right
        if (cmdName === 'left' || cmdName === 'right') {
          i += fullCmd.length;
          continue;
        }
      }

      // Default for unknown backslash command: emit as safe text
      textBuffer += latex[i];
      i++;
      continue;
    }

    // 2. Exponent: ^...
    if (latex[i] === '^') {
      flushText();
      const nodeKey = `${keyPrefix}-sup-${counter++}`;
      if (latex[i + 1] === '{') {
        const supRes = extractBraced(latex, i + 1);
        if (supRes) {
          nodes.push(
            React.createElement(
              'sup',
              { key: nodeKey, className: 'math-sup' },
              ...parseLatexToNodes(supRes.content, `${nodeKey}-c`),
            ),
          );
          i = supRes.nextIndex;
          continue;
        }
      } else if (i + 1 < latex.length && /[a-zA-Z0-9+-]/.test(latex[i + 1])) {
        nodes.push(
          React.createElement('sup', { key: nodeKey, className: 'math-sup' }, latex[i + 1]),
        );
        i += 2;
        continue;
      }
      textBuffer += '^';
      i++;
      continue;
    }

    // 3. Subscript: _...
    if (latex[i] === '_') {
      flushText();
      const nodeKey = `${keyPrefix}-sub-${counter++}`;
      if (latex[i + 1] === '{') {
        const subRes = extractBraced(latex, i + 1);
        if (subRes) {
          nodes.push(
            React.createElement(
              'sub',
              { key: nodeKey, className: 'math-sub' },
              ...parseLatexToNodes(subRes.content, `${nodeKey}-c`),
            ),
          );
          i = subRes.nextIndex;
          continue;
        }
      } else if (i + 1 < latex.length && /[a-zA-Z0-9+-]/.test(latex[i + 1])) {
        nodes.push(
          React.createElement('sub', { key: nodeKey, className: 'math-sub' }, latex[i + 1]),
        );
        i += 2;
        continue;
      }
      textBuffer += '_';
      i++;
      continue;
    }

    // 4. Regular characters: accumulated in textBuffer (rendered as safe text nodes)
    textBuffer += latex[i];
    i++;
  }

  flushText();
  return nodes;
}

export function MathRenderer({
  math,
  display = false,
  className = '',
  ariaLabel,
}: MathRendererProps) {
  const contentNodes = useMemo(() => {
    try {
      return parseLatexToNodes(math);
    } catch {
      // Safe non-crashing fallback: plain text node
      return [math];
    }
  }, [math]);

  const containerClasses = [
    'math-renderer',
    display ? 'math-display' : 'math-inline',
    className,
  ]
    .filter(Boolean)
    .join(' ');

  return React.createElement(
    'span',
    {
      className: containerClasses,
      role: 'math',
      'aria-label': ariaLabel || math,
      style: {
        display: display ? 'block' : 'inline-block',
        overflowX: display ? 'auto' : undefined,
        maxWidth: '100%',
        WebkitOverflowScrolling: 'touch',
      },
    },
    ...contentNodes,
  );
}

/**
 * Variation / Sign Table Component for Math (Bảng xét dấu & Bảng biến thiên)
 */
export interface VariationTableProps {
  readonly title?: string;
  readonly xRow: readonly string[];
  readonly derivativeRow: readonly string[];
  readonly functionRow?: readonly (string | { readonly val: string; readonly arrow?: 'up' | 'down' | 'flat' })[];
  readonly className?: string;
}

export function VariationTable({
  title,
  xRow,
  derivativeRow,
  functionRow,
  className = '',
}: VariationTableProps) {
  return (
    <div
      className={`variation-table-container ${className}`}
      style={{ overflowX: 'auto', maxWidth: '100%', WebkitOverflowScrolling: 'touch' }}
      role="region"
      aria-label={title || 'Bảng biến thiên / Bảng xét dấu'}
    >
      {title && <div className="variation-table-title"><strong>{title}</strong></div>}
      <table className="variation-table" style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'center' }}>
        <tbody>
          {/* Row x */}
          <tr className="row-x">
            <th scope="row" style={{ padding: '8px', borderBottom: '1px solid var(--border-color, #ccc)', width: '60px' }}>
              <em>x</em>
            </th>
            {xRow.map((val, idx) => (
              <td key={idx} style={{ padding: '8px', borderBottom: '1px solid var(--border-color, #ccc)' }}>
                <MathRenderer math={val} />
              </td>
            ))}
          </tr>
          {/* Row f'(x) */}
          <tr className="row-derivative">
            <th scope="row" style={{ padding: '8px', borderBottom: functionRow ? '1px solid var(--border-color, #ccc)' : undefined }}>
              <em>y&prime;</em>
            </th>
            {derivativeRow.map((val, idx) => (
              <td key={idx} style={{ padding: '8px', borderBottom: functionRow ? '1px solid var(--border-color, #ccc)' : undefined }}>
                <strong>{val}</strong>
              </td>
            ))}
          </tr>
          {/* Row y (if variation table) */}
          {functionRow && (
            <tr className="row-function">
              <th scope="row" style={{ padding: '12px 8px' }}>
                <em>y</em>
              </th>
              {functionRow.map((cell, idx) => {
                const val = typeof cell === 'string' ? cell : cell.val;
                const arrow = typeof cell === 'string' ? undefined : cell.arrow;
                return (
                  <td key={idx} style={{ padding: '12px 8px' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                      {arrow === 'up' && <span style={{ color: '#16a34a', fontSize: '18px' }}>↗</span>}
                      {arrow === 'down' && <span style={{ color: '#dc2626', fontSize: '18px' }}>↘</span>}
                      <MathRenderer math={val} />
                    </div>
                  </td>
                );
              })}
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default MathRenderer;
