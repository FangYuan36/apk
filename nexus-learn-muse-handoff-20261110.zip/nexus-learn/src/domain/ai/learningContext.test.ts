import assert from 'node:assert/strict';
import test from 'node:test';
import { buildAiLearningContext } from './learningContext';
import type { AttemptEvent } from '../math/attempt';

test('WP6-AI: buildAiLearningContext creates read-only, advisory student learning context without secrets', () => {
  const attempts: AttemptEvent[] = [
    {
      id: 'att-ai-1',
      sessionId: 'sess-ai-1',
      questionVersionRef: { questionId: 'math12-der-mono', version: 1, contentHash: 'sha256:abc' },
      scoringPolicyVersionRef: { id: 'pol-1', version: 1 },
      response: { kind: 'MCQ_SINGLE', optionId: 'B' },
      result: { status: 'scored', totalPoints: 0, maxPoints: 1 },
      partEvidence: [{
        partId: 'p1',
        status: 'incorrect',
        points: 0,
        maxPoints: 1,
        diagnosticHypothesis: {
          tag: 'misread_condition',
          likelyMissingStep: 'Quên xét điều kiện mẫu số khác 0',
          explanation: 'Học sinh quên xét điều kiện x khác 0',
          isHypothesis: true,
        },
      }],
      timestamp: '2026-11-09T10:00:00.000Z',
    },
    {
      id: 'att-ai-2',
      sessionId: 'sess-ai-1',
      questionVersionRef: { questionId: 'math12-der-mono', version: 1, contentHash: 'sha256:abc' },
      scoringPolicyVersionRef: { id: 'pol-1', version: 1 },
      response: { kind: 'MCQ_SINGLE', optionId: 'A' },
      result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
      partEvidence: [{
        partId: 'p1',
        status: 'correct',
        points: 1,
        maxPoints: 1,
      }],
      timestamp: '2026-11-09T10:05:00.000Z',
    },
  ];

  const skillNames = new Map([['math12-der-mono', 'Tính đơn điệu của hàm số']]);

  const context = buildAiLearningContext({
    attempts,
    activeSkillId: 'math12-der-mono',
    skillNames,
  });

  // Verify metadata & governance invariants
  assert.equal(context.subjectId, 'math');
  assert.equal(context.gradeLevel, 12);
  assert.equal(context.curriculumFramework, 'GDPT-2018');
  assert.equal(context.isAdvisoryOnly, true);
  assert.equal(context.humanReviewRequiredForPublication, true);
  assert.match(context.advisoryGovernanceNotice, /advisory drafts/);

  // Verify evidence aggregation
  assert.equal(context.studentEvidenceSummary.length, 1);
  const summary = context.studentEvidenceSummary[0];
  assert.equal(summary.skillId, 'math12-der-mono');
  assert.equal(summary.skillName, 'Tính đơn điệu của hàm số');
  assert.equal(summary.totalAttempts, 2);
  assert.equal(summary.correctAttempts, 1);
  assert.ok(summary.recentErrorTags.includes('misread_condition'));

  // Verify misconceptions
  assert.equal(context.recentMisconceptions.length, 1);
  assert.equal(context.recentMisconceptions[0].errorTag, 'misread_condition');
  assert.equal(context.recentMisconceptions[0].isHypothesis, true);

  // Object is deeply frozen / immutable
  assert.equal(Object.isFrozen(context), true);
  assert.equal(Object.isFrozen(context.studentEvidenceSummary), true);
  assert.equal(Object.isFrozen(context.recentMisconceptions), true);
});
