import type { AttemptEvent } from '../math/attempt';
import type { QuestionVersion } from '../math/question';

export interface StudentSkillEvidenceSummary {
  readonly skillId: string;
  readonly skillName?: string;
  readonly totalAttempts: number;
  readonly correctAttempts: number;
  readonly recentErrorTags: readonly string[];
  readonly lastAttemptAt?: string;
}

export interface AiLearningContext {
  readonly learnerContextVersion: '1.0';
  readonly subjectId: 'math';
  readonly gradeLevel: 12;
  readonly curriculumFramework: 'GDPT-2018';
  readonly activeSkillId?: string;
  readonly activeQuestionContext?: {
    readonly questionId: string;
    readonly questionVersion: number;
    readonly promptSnippet: string;
    readonly questionKind: string;
  };
  readonly studentEvidenceSummary: readonly StudentSkillEvidenceSummary[];
  readonly recentMisconceptions: readonly {
    readonly errorTag: string;
    readonly likelyMissingStep: string;
    readonly observedAt: string;
    readonly isHypothesis: true;
  }[];
  readonly advisoryGovernanceNotice: string;
  readonly isAdvisoryOnly: true;
  readonly humanReviewRequiredForPublication: true;
}

function deepFreeze<T>(obj: T): T {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }
  Object.freeze(obj);
  for (const key of Object.keys(obj)) {
    const val = (obj as any)[key];
    if (val !== null && typeof val === 'object' && !Object.isFrozen(val)) {
      deepFreeze(val);
    }
  }
  return obj;
}

export function buildAiLearningContext(params: {
  readonly activeQuestion?: QuestionVersion;
  readonly attempts: readonly AttemptEvent[];
  readonly activeSkillId?: string;
  readonly skillNames?: ReadonlyMap<string, string>;
  readonly questionSkillMap?: ReadonlyMap<string, readonly string[]>;
}): AiLearningContext {
  const attempts = params.attempts || [];
  const skillMap = params.skillNames || new Map<string, string>();

  // Aggregate student evidence strictly by verified skillIds
  const skillStats = new Map<string, { total: number; correct: number; errors: Set<string>; lastAt?: string }>();

  for (const att of attempts) {
    const qId = att.questionVersionRef.questionId;
    // Derive skill IDs from explicit question mapping, active question, or active skill context
    const mappedSkills = params.questionSkillMap?.get(qId) ||
      (params.activeQuestion && params.activeQuestion.questionId === qId ? params.activeQuestion.skillIds : undefined) ||
      (params.activeSkillId ? [params.activeSkillId] : undefined);

    const targetSkills = mappedSkills && mappedSkills.length > 0
      ? mappedSkills
      : (skillMap.has(qId) ? [qId] : ['unassigned-skill']);

    for (const sId of targetSkills) {
      const current = skillStats.get(sId) || { total: 0, correct: 0, errors: new Set<string>() };
      current.total += 1;
      // Strict full correctness: totalPoints === maxPoints > 0
      if (att.result.status === 'scored' && att.result.totalPoints === att.result.maxPoints && att.result.maxPoints > 0) {
        current.correct += 1;
      }
      if (att.partEvidence) {
        for (const p of att.partEvidence) {
          if (p.diagnosticHypothesis?.tag) {
            current.errors.add(p.diagnosticHypothesis.tag);
          }
        }
      }
      current.lastAt = att.timestamp;
      skillStats.set(sId, current);
    }
  }

  const studentEvidenceSummary: StudentSkillEvidenceSummary[] = Array.from(skillStats.entries()).map(
    ([sId, stat]) => ({
      skillId: sId,
      skillName: skillMap.get(sId),
      totalAttempts: stat.total,
      correctAttempts: stat.correct,
      recentErrorTags: Object.freeze(Array.from(stat.errors)),
      lastAttemptAt: stat.lastAt,
    }),
  );

  // Collect recent diagnostic hypotheses
  const recentMisconceptions: {
    readonly errorTag: string;
    readonly likelyMissingStep: string;
    readonly observedAt: string;
    readonly isHypothesis: true;
  }[] = [];

  for (const att of [...attempts].reverse()) {
    if (att.partEvidence) {
      for (const p of att.partEvidence) {
        if (p.diagnosticHypothesis) {
          recentMisconceptions.push({
            errorTag: p.diagnosticHypothesis.tag,
            likelyMissingStep: p.diagnosticHypothesis.likelyMissingStep,
            observedAt: att.timestamp,
            isHypothesis: true,
          });
        }
      }
    }
    if (recentMisconceptions.length >= 5) break;
  }

  let activeQuestionContext: AiLearningContext['activeQuestionContext'];
  if (params.activeQuestion) {
    const q = params.activeQuestion;
    activeQuestionContext = {
      questionId: q.questionId,
      questionVersion: q.version,
      promptSnippet: q.body?.prompt?.slice(0, 120) || '',
      questionKind: q.body?.kind || 'UNKNOWN',
    };
  }

  const rawContext: AiLearningContext = {
    learnerContextVersion: '1.0',
    subjectId: 'math',
    gradeLevel: 12,
    curriculumFramework: 'GDPT-2018',
    activeSkillId: params.activeSkillId,
    activeQuestionContext,
    studentEvidenceSummary,
    recentMisconceptions,
    advisoryGovernanceNotice:
      'AI outputs are advisory drafts for pedagogical assistance only. No model output is published without explicit human review approval (DECISIONS D-020, D-025).',
    isAdvisoryOnly: true,
    humanReviewRequiredForPublication: true,
  };

  return deepFreeze(rawContext);
}
