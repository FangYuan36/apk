import type { AttemptEvent, QuestionVersionRef } from '../math/attempt';

export interface PracticeSession {
  readonly id: string;
  readonly skillId: string;
  readonly startedAt: string;
  readonly endedAt?: string;
  readonly attemptIds: readonly string[];
}

export type ReviewScheduleStatus = 'pending' | 'due' | 'completed' | 'cancelled';

export interface StoredReviewSchedule {
  readonly skillId: string;
  readonly recheckDueAt: string;
  readonly createdAt: string;
  readonly isCompleted: boolean;
  readonly sourceAttemptId?: string;
  readonly sourceQuestionVersionRef?: QuestionVersionRef;
  readonly sourceSkillId?: string;
  readonly dueAt?: string;
  readonly reviewStatus?: ReviewScheduleStatus;
  readonly recheckSessionRef?: string;
  readonly completedAt?: string;
}

export interface ProgressProjection {
  readonly skillId: string;
  readonly totalAttempts: number;
  readonly correctAttempts: number;
  readonly lastAttemptAt: string;
  readonly lastScore: number;
}

export interface PersistenceRepository {
  // Practice Sessions
  saveSession(session: PracticeSession): Promise<void>;
  getSession(id: string): Promise<PracticeSession | null>;
  getAllSessions(): Promise<readonly PracticeSession[]>;

  // Attempt Events
  saveAttemptEvent(event: AttemptEvent): Promise<void>;
  getAttemptEvents(sessionId?: string): Promise<readonly AttemptEvent[]>;

  // Review Schedule
  saveReviewSchedule(schedule: StoredReviewSchedule): Promise<void>;
  getReviewSchedule(skillId: string): Promise<StoredReviewSchedule | null>;
  getAllReviewSchedules(): Promise<readonly StoredReviewSchedule[]>;

  // Progress Projection
  saveProgressProjection(projection: ProgressProjection): Promise<void>;
  getProgressProjection(skillId: string): Promise<ProgressProjection | null>;

  // Atomic Multi-Store Operation
  saveSessionAndAttempt(
    session: PracticeSession,
    event: AttemptEvent,
    schedule?: StoredReviewSchedule,
    projection?: ProgressProjection,
  ): Promise<void>;

  // Storage Type & Status
  isNativeIndexedDB(): boolean;

  // Schema & Storage Management
  getSchemaVersion(): Promise<number>;
  clearLocalData(): Promise<void>;
}
