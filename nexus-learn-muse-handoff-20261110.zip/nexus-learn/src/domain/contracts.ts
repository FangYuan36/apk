export type QuestionType = 'multiple_choice' | 'true_false' | 'short_answer';
export type Difficulty = 'introductory' | 'intermediate' | 'advanced';
export type ReviewStatus = 'draft' | 'sample_test_only' | 'verified' | 'published';

export interface Subject {
  readonly id: string;
  readonly curriculumVersionId: string;
  readonly name: string;
}

export interface Unit {
  readonly id: string;
  readonly subjectId: string;
  readonly curriculumVersionId: string;
  readonly name: string;
}

export interface Topic {
  readonly id: string;
  readonly subjectId: string;
  readonly unitId: string;
  readonly curriculumVersionId: string;
  readonly name: string;
}

export interface Skill {
  readonly id: string;
  readonly subjectId: string;
  readonly unitId: string;
  readonly topicId: string;
  readonly curriculumVersionId: string;
  readonly name: string;
}

export interface SkillMapping {
  readonly subject: Subject;
  readonly unit: Unit;
  readonly topic: Topic;
  readonly skill: Skill;
}

export function validateSkillMapping(mapping: SkillMapping): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const { subject, unit, topic, skill } = mapping;
  if (unit.subjectId !== subject.id || topic.subjectId !== subject.id || skill.subjectId !== subject.id) {
    errors.push('taxonomy nodes must follow the same subject parent chain');
  }
  if (topic.unitId !== unit.id || skill.unitId !== unit.id || skill.topicId !== topic.id) {
    errors.push('taxonomy nodes must follow the same unit and topic parent chain');
  }
  const versionIds = [subject.curriculumVersionId, unit.curriculumVersionId, topic.curriculumVersionId, skill.curriculumVersionId];
  if (new Set(versionIds).size !== 1) errors.push('all taxonomy nodes must use the same curriculum version');
  return { valid: errors.length === 0, errors };
}

export interface QuestionSource {
  readonly kind: 'synthetic' | 'licensed' | 'original' | 'official_reference';
  readonly reference: string;
  readonly issuer?: string;
  readonly sourceDate?: string;
  readonly licenseStatus?: 'synthetic' | 'original' | 'licensed' | 'open' | 'private_study' | 'unknown';
}

export interface QuestionOption {
  readonly id: string;
  readonly text: string;
  readonly distractorErrorTag?: ErrorTag;
  readonly likelyMissingStep?: string;
}

export interface QuestionItem {
  readonly id: string;
  readonly version: number;
  readonly subjectId: string;
  readonly curriculumVersionId: string;
  readonly skillIds: readonly string[];
  readonly questionType: QuestionType;
  readonly difficulty: Difficulty;
  readonly prompt: string;
  readonly options?: readonly QuestionOption[];
  readonly correctAnswer: string;
  readonly explanation: string;
  readonly source: QuestionSource;
  readonly reviewStatus: ReviewStatus;
  readonly verifiedBy?: string;
  readonly answerValidationMethod?: string;
}

export type ErrorTag =
  | 'concept_gap'
  | 'procedure_or_formula'
  | 'misread_condition'
  | 'calculation_slip'
  | 'data_interpretation'
  | 'time_or_guessing';

export interface AttemptInput {
  readonly id: string;
  readonly questionId: string;
  readonly questionVersion: number;
  readonly skillIds: readonly string[];
  readonly sessionId: string;
  readonly submittedAnswer: string | number | boolean | null;
  readonly isCorrect: boolean;
  readonly timestamp: string;
  readonly durationMs: number;
  readonly hintsUsed: number;
  readonly isDelayedRecheck: boolean;
  readonly errorTag?: ErrorTag;
}

export interface AttemptEvent extends AttemptInput {
  readonly skillIds: readonly string[];
}

export type VerificationStatus = 'not_enough_data' | 'learning' | 'consolidating' | 'verification_complete';

export interface VerificationProgress {
  readonly status: VerificationStatus;
  readonly evidenceCount: number;
  readonly independentCorrectCount: number;
  readonly sessionCount: number;
  readonly delayedCorrectCount: number;
}

export interface VerificationPolicy {
  readonly minIndependentCorrect: number;
  readonly minSessions: number;
  readonly requireDelayedRecheck: boolean;
}

export const DEFAULT_VERIFICATION_POLICY: VerificationPolicy = Object.freeze({
  minIndependentCorrect: 3,
  minSessions: 2,
  requireDelayedRecheck: true,
});

export type RecommendationKind = 'diagnostic' | 'guided_practice' | 'independent_practice' | 'verification_complete';

export interface StudyRecommendation {
  readonly kind: RecommendationKind;
  readonly reason: string;
}

export function validateQuestionItem(value: unknown): { valid: boolean; errors: string[] } {
  if (typeof value !== 'object' || value === null) {
    return { valid: false, errors: ['question must be an object'] };
  }

  const question = value as Partial<QuestionItem>;
  const errors: string[] = [];
  if (!question.id?.trim()) errors.push('id is required');
  if (!Number.isInteger(question.version) || (question.version ?? 0) < 1) errors.push('version must be a positive integer');
  if (!question.subjectId?.trim()) errors.push('subjectId is required');
  if (!question.curriculumVersionId?.trim()) errors.push('curriculumVersionId is required');
  if (!Array.isArray(question.skillIds) || question.skillIds.length === 0) errors.push('skillIds must include at least one skill');
  if (!question.prompt?.trim()) errors.push('prompt is required');
  if (!question.correctAnswer?.trim()) errors.push('correctAnswer is required');
  if (!question.explanation?.trim()) errors.push('explanation is required');
  if (!question.source?.kind || !question.source.reference?.trim()) errors.push('source provenance is required');
  if (!['multiple_choice', 'true_false', 'short_answer'].includes(question.questionType ?? '')) errors.push('questionType is invalid');
  if (!['introductory', 'intermediate', 'advanced'].includes(question.difficulty ?? '')) errors.push('difficulty is invalid');
  if (!['draft', 'sample_test_only', 'verified', 'published'].includes(question.reviewStatus ?? '')) errors.push('reviewStatus is invalid');
  if (question.reviewStatus === 'verified' || question.reviewStatus === 'published') {
    if (!question.source?.issuer?.trim()) errors.push('verified content requires a source issuer');
    if (!question.source?.sourceDate || !Number.isFinite(Date.parse(question.source.sourceDate))) errors.push('verified content requires a valid source date');
    if (!question.source?.licenseStatus || question.source.licenseStatus === 'unknown') errors.push('verified content requires a reviewed rights status');
    if (!question.verifiedBy?.trim()) errors.push('verified content requires a human reviewer');
    if (!question.answerValidationMethod?.trim()) errors.push('verified content requires an answer validation method');
  }

  return { valid: errors.length === 0, errors };
}

export function createAttemptEvent(input: AttemptInput): AttemptEvent {
  if (!input.id.trim() || !input.questionId.trim() || !input.sessionId.trim()) {
    throw new Error('attempt, question, and session IDs are required');
  }
  if (!Number.isInteger(input.questionVersion) || input.questionVersion < 1) {
    throw new Error('questionVersion must be a positive integer');
  }
  if (input.skillIds.length === 0 || input.skillIds.some((skillId) => !skillId.trim())) {
    throw new Error('attempt must reference at least one skill');
  }
  if (!Number.isFinite(Date.parse(input.timestamp))) throw new Error('timestamp must be a valid date');
  if (!Number.isFinite(input.durationMs) || input.durationMs < 0) throw new Error('durationMs must be non-negative');
  if (!Number.isInteger(input.hintsUsed) || input.hintsUsed < 0) throw new Error('hintsUsed must be a non-negative integer');

  return Object.freeze({ ...input, skillIds: Object.freeze([...input.skillIds]) });
}

export function appendAttempt(history: readonly AttemptEvent[], next: AttemptEvent): readonly AttemptEvent[] {
  if (history.some((event) => event.id === next.id)) throw new Error(`duplicate attempt ID: ${next.id}`);
  return Object.freeze([...history, next]);
}

export function deriveVerificationProgress(
  attempts: readonly AttemptEvent[],
  policy: VerificationPolicy = DEFAULT_VERIFICATION_POLICY,
): VerificationProgress {
  const independentCorrect = attempts.filter((item) => item.isCorrect && item.hintsUsed === 0);
  const sessions = new Set(attempts.map((item) => item.sessionId));
  const delayedCorrectCount = independentCorrect.filter((item) => item.isDelayedRecheck).length;
  const independentSessions = new Set(independentCorrect.map((item) => item.sessionId));
  const delayedRequirementMet = !policy.requireDelayedRecheck || delayedCorrectCount > 0;
  const status: VerificationStatus = attempts.length === 0
    ? 'not_enough_data'
    : independentCorrect.length >= policy.minIndependentCorrect && independentSessions.size >= policy.minSessions && delayedRequirementMet
      ? 'verification_complete'
      : attempts.length < 2
        ? 'learning'
        : 'consolidating';

  return Object.freeze({
    status,
    evidenceCount: attempts.length,
    independentCorrectCount: independentCorrect.length,
    sessionCount: sessions.size,
    delayedCorrectCount,
  });
}

const errorReasons: Record<ErrorTag, string> = {
  concept_gap: 'A recent attempt suggests a missing concept; review the prerequisite before trying independently.',
  procedure_or_formula: 'A recent attempt suggests the procedure or formula needs guided practice.',
  misread_condition: 'A recent attempt suggests the question condition was misread; practise identifying the given condition first.',
  calculation_slip: 'A recent attempt suggests a calculation slip; practise the same skill with a check step.',
  data_interpretation: 'A recent attempt suggests the graph or data interpretation step needs practice.',
  time_or_guessing: 'A recent attempt suggests time pressure or guessing; try a short, untimed guided question first.',
};

export function recommendNextStep(
  attempts: readonly AttemptEvent[],
  progress: VerificationProgress,
): StudyRecommendation {
  if (attempts.length === 0) {
    return Object.freeze({ kind: 'diagnostic', reason: 'There are no attempts yet, so a short diagnostic is the next useful step.' });
  }

  const latest = attempts[attempts.length - 1];
  if (!latest.isCorrect && latest.errorTag) {
    return Object.freeze({ kind: 'guided_practice', reason: errorReasons[latest.errorTag] });
  }

  if (progress.status === 'verification_complete') {
    return Object.freeze({
      kind: 'verification_complete',
      reason: 'The sample verification cycle is complete under the configured evidence policy.',
    });
  }
  if (latest.isCorrect && latest.hintsUsed === 0) {
    return Object.freeze({ kind: 'independent_practice', reason: 'The latest answer was correct without hints; try a new question to gather more evidence.' });
  }
  return Object.freeze({ kind: 'guided_practice', reason: 'The current evidence is limited; use a guided question and check the missing step.' });
}

export function isValidAnswerOption(
  question: QuestionItem,
  submittedAnswer: string | number | boolean | null,
): boolean {
  if (submittedAnswer === null || submittedAnswer === undefined) return false;
  const normalized = String(submittedAnswer).trim().toUpperCase();
  if (!normalized) return false;

  if (question.options?.length) {
    return question.options.some((option) => option.id.trim().toUpperCase() === normalized);
  }

  return question.questionType === 'short_answer' && typeof submittedAnswer === 'string';
}

export function evaluateAnswer(question: QuestionItem, submittedAnswer: string | number | boolean | null): boolean {
  if (submittedAnswer === null || submittedAnswer === undefined) return false;
  if (!String(submittedAnswer).trim()) return false;
  if (!isValidAnswerOption(question, submittedAnswer)) {
    throw new Error('submittedAnswer is not a valid option for this question');
  }
  return String(submittedAnswer).trim().toUpperCase() === question.correctAnswer.trim().toUpperCase();
}

export interface ErrorClassification {
  readonly errorTag: ErrorTag;
  readonly likelyMissingStep: string;
  readonly isUncertain: boolean;
  readonly explanation: string;
}

export function classifyError(
  question: QuestionItem,
  submittedAnswer: string | number | boolean | null,
): ErrorClassification {
  const norm = submittedAnswer !== null && submittedAnswer !== undefined ? String(submittedAnswer).trim().toUpperCase() : '';
  const matchedOption = question.options?.find((opt) => opt.id.trim().toUpperCase() === norm);

  if (matchedOption?.distractorErrorTag) {
    return Object.freeze({
      errorTag: matchedOption.distractorErrorTag,
      likelyMissingStep: matchedOption.likelyMissingStep || 'Xác định chưa chính xác bước đọc dấu trên bảng hoặc đồ thị.',
      isUncertain: true,
      explanation: question.explanation,
    });
  }

  return Object.freeze({
    errorTag: 'concept_gap',
    likelyMissingStep: 'Có khả năng chưa nắm rõ khái niệm cơ bản về dấu đạo hàm và tính đơn điệu.',
    isUncertain: true,
    explanation: question.explanation,
  });
}

export interface RecheckSchedule {
  readonly scheduledAt: string;
  readonly delayMinutes: number;
  readonly dueAt: string;
}

export function scheduleDelayedRecheck(baseTimeIso: string, delayMinutes: number = 60): RecheckSchedule {
  const baseMs = Date.parse(baseTimeIso);
  if (!Number.isFinite(baseMs)) {
    throw new Error('baseTimeIso must be a valid ISO date string');
  }
  const dueMs = baseMs + delayMinutes * 60 * 1000;
  return Object.freeze({
    scheduledAt: new Date(baseMs).toISOString(),
    delayMinutes,
    dueAt: new Date(dueMs).toISOString(),
  });
}

export function isRecheckDue(dueAtIso: string, currentMs: number): boolean {
  const dueMs = Date.parse(dueAtIso);
  return Number.isFinite(dueMs) && currentMs >= dueMs;
}
