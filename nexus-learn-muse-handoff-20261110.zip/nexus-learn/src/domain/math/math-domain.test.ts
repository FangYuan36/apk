import assert from 'node:assert/strict';
import test from 'node:test';
import { InMemoryPersistenceRepository } from '../../infrastructure/persistence/indexeddb/indexeddbRepository';
import {
  createCurriculumVersion,
  createSubject,
  createTopic,
  createSkill,
  validateTaxonomyChain,
  createQuestionSkillMapping,
  createSourceAsset,
  createLicenseRecord,
  isLicenseValidAt,
  createReviewRecord,
  createPublicationRecord,
  createQuestion,
  createQuestionVersion,
  createSuccessorQuestionVersion,
  createSolutionVersion,
  createDiagnosticHypothesis,
  validateQuestionBody,
  isValidCanonicalDecimalString,
  createScoringPolicyVersion,
  validateScoringPolicyVersion,
  createAttemptEvent,
  appendAttemptEvent,
  validateAttemptEvent,
  type AttemptEvent,
  scoreQuestionVersion,
  computeQuestionContentHash,
  canonicalSerialize,
  validatePublication,
  validateReviewerAuthorization,
  type McqSingleBody,
  type TrueFalseClusterBody,
  type ShortNumericBody,
  type ReviewerAuthorizationEvidence,
} from './index';

test('WP1-INV-1: Question identity and QuestionVersion are separated; successor v2 does not alter v1', () => {
  const q = createQuestion({ id: 'q-math-001', latestVersion: 1 });
  assert.equal(q.id, 'q-math-001');
  assert.equal(q.latestVersion, 1);

  const v1 = createQuestionVersion({
    questionId: q.id,
    version: 1,
    status: 'draft',
    contentHash: 'sha256:hash-v1',
    curriculumVersionId: 'curriculum-2025-v1',
    skillIds: ['skill-derivative-sign'],
    sourceAssetIds: ['src-001'],
    licenseRecordIds: ['lic-001'],
    body: {
      kind: 'MCQ_SINGLE',
      prompt: 'Tìm khoảng đồng biến của hàm số f(x).',
      options: [
        { id: 'A', text: '(-∞, 0)' },
        { id: 'B', text: '(0, 2)' },
        { id: 'C', text: '(2, +∞)' },
        { id: 'D', text: '(-1, 1)' },
      ],
      correctOptionId: 'B',
    },
  });

  assert.equal(v1.version, 1);
  assert.equal(v1.contentHash, 'sha256:hash-v1');
  assert.equal(Object.isFrozen(v1), true);
  assert.equal(Object.isFrozen(v1.body), true);

  const v2 = createSuccessorQuestionVersion(v1, {
    contentHash: 'sha256:hash-v2',
    status: 'in_review',
    body: {
      kind: 'MCQ_SINGLE',
      prompt: 'Tìm khoảng đồng biến của hàm số f(x) (đã chuẩn hóa đề).',
      options: [
        { id: 'A', text: '(-∞, 0)' },
        { id: 'B', text: '(0, 2)' },
        { id: 'C', text: '(2, +∞)' },
        { id: 'D', text: '(-1, 1)' },
      ],
      correctOptionId: 'B',
    },
  });

  assert.equal(v2.version, 2);
  assert.equal(v2.contentHash, 'sha256:hash-v2');
  assert.equal(v1.version, 1);
  assert.equal(v1.contentHash, 'sha256:hash-v1');
  assert.equal(v1.body.prompt, 'Tìm khoảng đồng biến của hàm số f(x).');

  assert.throws(() => {
    createSuccessorQuestionVersion(v1, { contentHash: 'sha256:hash-v1' });
  }, /successor question version must have a new contentHash/i);
});

test('WP1-INV-2: Question families enforce structural invariants (4 MCQ options, 4 T/F statements, finite canonical decimal)', () => {
  // MCQ_SINGLE requires exactly 4 options
  const validMcq: McqSingleBody = {
    kind: 'MCQ_SINGLE',
    prompt: 'Chọn mệnh đề đúng',
    options: [
      { id: 'A', text: 'Opt A' },
      { id: 'B', text: 'Opt B' },
      { id: 'C', text: 'Opt C' },
      { id: 'D', text: 'Opt D' },
    ],
    correctOptionId: 'A',
  };
  assert.equal(validateQuestionBody(validMcq).valid, true);

  // Rejects 3 options
  const invalidMcq3 = { ...validMcq, options: validMcq.options.slice(0, 3) };
  assert.equal(validateQuestionBody(invalidMcq3).valid, false);
  assert.match(validateQuestionBody(invalidMcq3).errors[0], /exactly 4 options/);

  // Rejects duplicate option IDs
  const invalidMcqDup = {
    ...validMcq,
    options: [
      { id: 'A', text: 'Opt A' },
      { id: 'A', text: 'Opt Duplicate' },
      { id: 'C', text: 'Opt C' },
      { id: 'D', text: 'Opt D' },
    ],
  };
  assert.equal(validateQuestionBody(invalidMcqDup).valid, false);
  assert.match(validateQuestionBody(invalidMcqDup).errors[0], /duplicate.*option/i);

  // Rejects correctOptionId not in options
  const invalidMcqKey = { ...validMcq, correctOptionId: 'Z' };
  assert.equal(validateQuestionBody(invalidMcqKey).valid, false);
  assert.match(validateQuestionBody(invalidMcqKey).errors[0], /must match one of the option ids/);

  // TRUE_FALSE_CLUSTER requires exactly 4 statements
  const validCluster: TrueFalseClusterBody = {
    kind: 'TRUE_FALSE_CLUSTER',
    prompt: 'Xét tính đúng sai của các mệnh đề sau:',
    statements: [
      { id: 's1', prompt: 'Hàm số đồng biến trên (0, 1)', correctValue: true, skillIds: ['skill-a'] },
      { id: 's2', prompt: 'Hàm số có cực đại tại x = 0', correctValue: false, skillIds: ['skill-b'] },
      { id: 's3', prompt: 'Giá trị lớn nhất là 3', correctValue: true, skillIds: ['skill-c', 'skill-d'] },
      { id: 's4', prompt: 'Đồ thị cắt trục hoành tại 2 điểm', correctValue: false, skillIds: ['skill-a'] },
    ],
  };
  assert.equal(validateQuestionBody(validCluster).valid, true);

  // Rejects 2 statements
  const invalidCluster2 = { ...validCluster, statements: validCluster.statements.slice(0, 2) };
  assert.equal(validateQuestionBody(invalidCluster2).valid, false);
  assert.match(validateQuestionBody(invalidCluster2).errors[0], /exactly 4 statements/);

  // Rejects statement with empty skillIds
  const invalidClusterSkill = {
    ...validCluster,
    statements: [
      validCluster.statements[0],
      validCluster.statements[1],
      validCluster.statements[2],
      { id: 's4', prompt: 'Stmt 4', correctValue: true, skillIds: [] },
    ],
  };
  assert.equal(validateQuestionBody(invalidClusterSkill).valid, false);
  assert.match(validateQuestionBody(invalidClusterSkill).errors[0], /at least one valid skillId/);

  // SHORT_NUMERIC requires valid canonical decimal
  const validNum: ShortNumericBody = {
    kind: 'SHORT_NUMERIC',
    prompt: 'Tính giá trị cực tiểu của hàm số.',
    correctDecimal: '-1.25',
  };
  assert.equal(validateQuestionBody(validNum).valid, true);

  // Rejects malformed, non-finite, scientific notation
  for (const badDec of ['-1,25', 'NaN', 'Infinity', '1e3', 'abc', '1.2.3', '']) {
    const invalidNum = { ...validNum, correctDecimal: badDec };
    assert.equal(validateQuestionBody(invalidNum).valid, false);
  }
});

test('WP1-INV-3: Numeric answer keys require canonical decimal strings; tolerance belongs to policy', () => {
  assert.equal(isValidCanonicalDecimalString('0'), true);
  assert.equal(isValidCanonicalDecimalString('42'), true);
  assert.equal(isValidCanonicalDecimalString('-1.25'), true);
  assert.equal(isValidCanonicalDecimalString('3.14159'), true);
  assert.equal(isValidCanonicalDecimalString('-0.001'), true);

  // Commas or spaces belong to input normalization at scoring time, not the canonical answer key
  assert.equal(isValidCanonicalDecimalString('-1,25'), false);
  assert.equal(isValidCanonicalDecimalString(' 1.25 '), false);
  assert.equal(isValidCanonicalDecimalString('1e5'), false);
  assert.equal(isValidCanonicalDecimalString('NaN'), false);
  assert.equal(isValidCanonicalDecimalString('Infinity'), false);

  // Policy holds the tolerance configuration
  const policy = createScoringPolicyVersion({
    id: 'sample-practice-v1',
    version: 1,
    status: 'proposed',
    mcqSingle: { pointsCorrect: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    trueFalseCluster: { pointsPerCorrectStatement: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    shortNumeric: {
      pointsCorrect: 1,
      pointsIncorrect: 0,
      pointsEmpty: 0,
      absoluteTolerance: '0.01',
      relativeTolerance: '0',
      decimalSeparators: [',', '.'],
      groupingSeparators: [],
      allowExponent: false,
    },
  });
  assert.equal(policy.shortNumeric.absoluteTolerance, '0.01');
  assert.equal(Object.isFrozen(policy), true);
  assert.equal(Object.isFrozen(policy.shortNumeric), true);
});

test('WP1-INV-4: Taxonomy and skill mappings reject missing or cross-version IDs', () => {
  const curr = createCurriculumVersion({
    id: 'curriculum-2025-v1',
    name: 'Chương trình GDPT 2018 (Chuẩn 2025)',
    source: 'Bộ GD&ĐT',
    status: 'reference_only',
    effectiveYear: 2025,
  });

  const subj = createSubject({ id: 'math', curriculumVersionId: curr.id, name: 'Toán học' });
  const top = createTopic({ id: 'derivatives', subjectId: subj.id, curriculumVersionId: curr.id, name: 'Ứng dụng đạo hàm' });
  const skl = createSkill({ id: 'skill-monotonicity', subjectId: subj.id, topicId: top.id, curriculumVersionId: curr.id, name: 'Đồng biến nghịch biến' });

  assert.equal(validateTaxonomyChain({ curriculum: curr, subject: subj, topic: top, skill: skl }).valid, true);

  // Mismatched curriculum version ID
  const crossVersionTopic = createTopic({ id: 'top-v2', subjectId: subj.id, curriculumVersionId: 'curriculum-other-v2', name: 'Topic' });
  const resultCross = validateTaxonomyChain({ curriculum: curr, subject: subj, topic: crossVersionTopic, skill: skl });
  assert.equal(resultCross.valid, false);
  assert.match(resultCross.errors[0], /does not match curriculum/);

  // QuestionSkillMapping validation
  const mapping = createQuestionSkillMapping({
    questionId: 'q-001',
    questionVersion: 1,
    partId: 's1',
    skillId: skl.id,
    curriculumVersionId: curr.id,
    weight: 1.5,
  });
  assert.equal(mapping.partId, 's1');
  assert.equal(mapping.weight, 1.5);
  assert.equal(Object.isFrozen(mapping), true);

  assert.throws(() => {
    createQuestionSkillMapping({ questionId: '', questionVersion: 1, skillId: 's', curriculumVersionId: 'c' });
  }, /questionId must be a non-empty string/);
});

test('WP1-INV-5 & 6: AttemptEvent requires version refs; payloads are deeply immutable; append preserves history', () => {
  const event1 = createAttemptEvent({
    id: 'att-001',
    sessionId: 'sess-001',
    questionVersionRef: {
      questionId: 'q-math-001',
      version: 1,
      contentHash: 'sha256:hash-v1',
    },
    scoringPolicyVersionRef: {
      id: 'sample-practice-v1',
      version: 1,
    },
    response: {
      kind: 'MCQ_SINGLE',
      optionId: 'B',
    },
    result: {
      status: 'scored',
      totalPoints: 1,
      maxPoints: 1,
    },
    partEvidence: [
      {
        partId: 'question',
        status: 'correct',
        points: 1,
        maxPoints: 1,
        skillIds: ['skill-monotonicity'],
      },
    ],
    timestamp: '2026-11-08T10:00:00.000Z',
  });

  assert.equal(Object.isFrozen(event1), true);
  assert.equal(Object.isFrozen(event1.questionVersionRef), true);
  assert.equal(Object.isFrozen(event1.scoringPolicyVersionRef), true);
  assert.equal(Object.isFrozen(event1.response), true);
  assert.equal(Object.isFrozen(event1.result), true);
  assert.equal(Object.isFrozen(event1.partEvidence), true);
  assert.equal(Object.isFrozen(event1.partEvidence[0].skillIds), true);

  const history1 = Object.freeze([event1]);
  assert.equal(history1.length, 1);

  const event2 = createAttemptEvent({
    id: 'att-002',
    sessionId: 'sess-001',
    questionVersionRef: {
      questionId: 'q-math-001',
      version: 2,
      contentHash: 'sha256:hash-v2',
    },
    scoringPolicyVersionRef: {
      id: 'sample-practice-v1',
      version: 1,
    },
    response: {
      kind: 'MCQ_SINGLE',
      optionId: 'A',
    },
    result: {
      status: 'scored',
      totalPoints: 0,
      maxPoints: 1,
    },
    partEvidence: [
      {
        partId: 'question',
        status: 'incorrect',
        points: 0,
        maxPoints: 1,
        skillIds: ['skill-monotonicity'],
      },
    ],
    timestamp: '2026-11-08T10:05:00.000Z',
  });

  const history2 = appendAttemptEvent(history1, event2);
  assert.equal(history2.length, 2);
  assert.equal(history1.length, 1);
  assert.deepEqual(history2[0], event1);
  assert.deepEqual(history2[1], event2);
  assert.equal(Object.isFrozen(history2), true);

  // Rejects duplicate event ID
  assert.throws(() => {
    appendAttemptEvent(history2, event1);
  }, /duplicate attempt ID/i);
});

test('WP1-INV-7: Diagnostic hypothesis is an evidence record with isHypothesis: true, not a mastery conclusion', () => {
  const hyp = createDiagnosticHypothesis({
    tag: 'misread_interval',
    likelyMissingStep: 'Nhầm lẫn khoảng đồng biến với khoảng nghịch biến',
    explanation: 'f\'(x) > 0 tương ứng với hàm số đồng biến.',
  });

  assert.equal(hyp.tag, 'misread_interval');
  assert.equal(hyp.isHypothesis, true);
  assert.equal(Object.isFrozen(hyp), true);
  // Ensured that hypothesis contains no mastery claims or score mutations
  assert.equal((hyp as any).masteryStatus, undefined);
});

test('WP1-INV-8: Source, license, review, publication, and solution are distinct records with IDs/version/hash references', () => {
  const source = createSourceAsset({
    id: 'src-nexus-orig-01',
    provenanceKind: 'original',
    reference: 'Đề bài tự biên soạn cho mục đích thử nghiệm NEXUS LEARN',
    issuer: 'NEXUS Content Team',
  });
  assert.equal(source.provenanceKind, 'original');
  assert.equal(Object.isFrozen(source), true);

  const license = createLicenseRecord({
    id: 'lic-nexus-orig-01',
    status: 'original',
    validThrough: null, // perpetual
  });
  assert.equal(license.status, 'original');
  assert.equal(isLicenseValidAt(license, '2026-11-08T00:00:00.000Z'), true);

  const expiredLicense = createLicenseRecord({
    id: 'lic-expired',
    status: 'licensed',
    validThrough: '2026-11-01T00:00:00.000Z',
  });
  assert.equal(isLicenseValidAt(expiredLicense, '2026-11-08T00:00:00.000Z'), false);

  const review = createReviewRecord({
    id: 'rev-001',
    questionId: 'q-math-001',
    questionVersion: 1,
    reviewedContentHash: 'sha256:hash-v1',
    decision: 'approved',
    reviewerId: 'reviewer-math-lead',
  });
  assert.equal(review.decision, 'approved');
  assert.equal(review.reviewedContentHash, 'sha256:hash-v1');
  assert.equal(Object.isFrozen(review), true);

  const publication = createPublicationRecord({
    questionId: 'q-math-001',
    questionVersion: 1,
    contentHash: 'sha256:hash-v1',
    publishedBy: 'lead-editor',
  });
  assert.equal(publication.questionVersion, 1);
  assert.equal(publication.contentHash, 'sha256:hash-v1');
  assert.equal(Object.isFrozen(publication), true);

  const solution = createSolutionVersion({
    id: 'sol-001',
    questionId: 'q-math-001',
    questionVersion: 1,
    explanation: 'SAMPLE / TEST ONLY: Lời giải chi tiết.',
    steps: ['Bước 1: Tính đạo hàm f\'(x)', 'Bước 2: Lập bảng xét dấu', 'Bước 3: Kết luận khoảng đồng biến'],
  });
  assert.equal(solution.questionVersion, 1);
  assert.equal(solution.steps?.length, 3);
  assert.equal(Object.isFrozen(solution), true);
  assert.equal(Object.isFrozen(solution.steps), true);
});

test('WP1-INV-9: Attempt pinning preserves exact references across question & policy successor versions', () => {
  const originalAttempt = createAttemptEvent({
    id: 'att-pinned-01',
    sessionId: 'session-recheck-01',
    questionVersionRef: {
      questionId: 'q-pinned',
      version: 1,
      contentHash: 'sha256:pinned-v1',
    },
    scoringPolicyVersionRef: {
      id: 'policy-math-v1',
      version: 1,
    },
    response: {
      kind: 'SHORT_NUMERIC',
      value: '-1.25',
    },
    result: {
      status: 'scored',
      totalPoints: 1,
      maxPoints: 1,
    },
    partEvidence: [
      {
        partId: 'numeric',
        status: 'correct',
        points: 1,
        maxPoints: 1,
      },
    ],
    timestamp: '2026-11-08T08:00:00.000Z',
  });

  // Imagine question evolves to v2 and policy evolves to v2
  const qV2Ref = { questionId: 'q-pinned', version: 2, contentHash: 'sha256:pinned-v2' };
  const policyV2Ref = { id: 'policy-math-v1', version: 2 };

  // Original attempt still references v1 of question and v1 of policy
  assert.equal(originalAttempt.questionVersionRef.version, 1);
  assert.equal(originalAttempt.questionVersionRef.contentHash, 'sha256:pinned-v1');
  assert.equal(originalAttempt.scoringPolicyVersionRef.version, 1);
  assert.notDeepEqual(originalAttempt.questionVersionRef, qV2Ref);
  assert.notDeepEqual(originalAttempt.scoringPolicyVersionRef, policyV2Ref);
});

test('WP2-SCORING: True/False cluster reconciles part points with totalPoints and includes bonus in maxPoints', () => {
  const clusterQ = {
    questionId: 'q-tf-bonus',
    version: 1,
    contentHash: 'sha256:tf-bonus',
    body: {
      kind: 'TRUE_FALSE_CLUSTER' as const,
      statements: [
        { id: 's1', prompt: 'one', correctValue: true, skillIds: ['sk1'] },
        { id: 's2', prompt: 'two', correctValue: false, skillIds: ['sk2'] },
        { id: 's3', prompt: 'three', correctValue: true, skillIds: ['sk1'] },
        { id: 's4', prompt: 'four', correctValue: false, skillIds: ['sk2'] },
      ] as const,
    },
  };

  const policyWithBonus = createScoringPolicyVersion({
    id: 'policy-bonus',
    version: 1,
    status: 'proposed',
    mcqSingle: { pointsCorrect: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    trueFalseCluster: { pointsPerCorrectStatement: 1, pointsIncorrect: 0, pointsEmpty: 0, allCorrectBonus: 2 },
    shortNumeric: {
      pointsCorrect: 1,
      pointsIncorrect: 0,
      pointsEmpty: 0,
      absoluteTolerance: '0.01',
      relativeTolerance: '0',
      decimalSeparators: ['.'],
      groupingSeparators: [],
      allowExponent: false,
    },
  });

  // Partially correct (2 correct)
  const partialRes = scoreQuestionVersion(
    clusterQ,
    { kind: 'TRUE_FALSE_CLUSTER', answers: { s1: true, s2: false, s3: false, s4: true } },
    policyWithBonus,
  );
  assert.equal(partialRes.status, 'scored');
  assert.equal(partialRes.totalPoints, 2);
  assert.equal(partialRes.maxPoints, 6); // 4 + 2 bonus
  assert.equal(partialRes.parts.reduce((s, p) => s + p.points, 0), partialRes.totalPoints);
  assert.ok(partialRes.totalPoints <= partialRes.maxPoints);

  // Fully correct (all 4 correct -> awards bonus, points distributed to parts)
  const fullRes = scoreQuestionVersion(
    clusterQ,
    { kind: 'TRUE_FALSE_CLUSTER', answers: { s1: true, s2: false, s3: true, s4: false } },
    policyWithBonus,
  );
  assert.equal(fullRes.status, 'scored');
  assert.equal(fullRes.totalPoints, 6);
  assert.equal(fullRes.maxPoints, 6);
  assert.equal(fullRes.parts.reduce((s, p) => s + p.points, 0), 6);
  assert.ok(fullRes.totalPoints <= fullRes.maxPoints);
});

test('WP2-SCORING: True/False cluster returns invalid for malformed or unknown statement answers', () => {
  const clusterQ = {
    questionId: 'q-tf-test',
    version: 1,
    contentHash: 'sha256:tf-test',
    body: {
      kind: 'TRUE_FALSE_CLUSTER' as const,
      statements: [
        { id: 's1', prompt: 'one', correctValue: true, skillIds: ['sk1'] },
        { id: 's2', prompt: 'two', correctValue: false, skillIds: ['sk2'] },
        { id: 's3', prompt: 'three', correctValue: true, skillIds: ['sk1'] },
        { id: 's4', prompt: 'four', correctValue: false, skillIds: ['sk2'] },
      ] as const,
    },
  };

  const policy = createScoringPolicyVersion({
    id: 'policy-std',
    version: 1,
    status: 'proposed',
    mcqSingle: { pointsCorrect: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    trueFalseCluster: { pointsPerCorrectStatement: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    shortNumeric: {
      pointsCorrect: 1,
      pointsIncorrect: 0,
      pointsEmpty: 0,
      absoluteTolerance: '0.01',
      relativeTolerance: '0',
      decimalSeparators: ['.'],
      groupingSeparators: [],
      allowExponent: false,
    },
  });

  // Unknown statement ID in answers
  const unknownKey = scoreQuestionVersion(
    clusterQ,
    { kind: 'TRUE_FALSE_CLUSTER', answers: { s1: true, s999: false } },
    policy,
  );
  assert.equal(unknownKey.status, 'invalid');

  // Invalid value (string instead of boolean/null)
  const invalidVal = scoreQuestionVersion(
    clusterQ,
    { kind: 'TRUE_FALSE_CLUSTER', answers: { s1: 'true' as unknown as boolean } },
    policy,
  );
  assert.equal(invalidVal.status, 'invalid');
});

test('WP2-SCORING: Short numeric supports scientific notation when allowExponent is true and rejects when false', () => {
  const numQ = {
    questionId: 'q-exp',
    version: 1,
    contentHash: 'sha256:exp',
    body: { kind: 'SHORT_NUMERIC' as const, prompt: 'Prompt', correctDecimal: '1500' },
  };

  const policyExpAllowed = createScoringPolicyVersion({
    id: 'policy-exp',
    version: 1,
    status: 'proposed',
    mcqSingle: { pointsCorrect: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    trueFalseCluster: { pointsPerCorrectStatement: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    shortNumeric: {
      pointsCorrect: 1,
      pointsIncorrect: 0,
      pointsEmpty: 0,
      absoluteTolerance: '0.01',
      relativeTolerance: '0',
      decimalSeparators: ['.'],
      groupingSeparators: [],
      allowExponent: true,
    },
  });

  const policyExpForbidden = createScoringPolicyVersion({
    ...policyExpAllowed,
    shortNumeric: { ...policyExpAllowed.shortNumeric, allowExponent: false },
  });

  // When allowed, '1.5e3' scores 1 point
  assert.equal(
    scoreQuestionVersion(numQ, { kind: 'SHORT_NUMERIC', value: '1.5e3' }, policyExpAllowed).status,
    'scored',
  );
  assert.equal(
    scoreQuestionVersion(numQ, { kind: 'SHORT_NUMERIC', value: '1.5e3' }, policyExpAllowed).totalPoints,
    1,
  );

  // When forbidden, '1.5e3' returns 'invalid'
  assert.equal(
    scoreQuestionVersion(numQ, { kind: 'SHORT_NUMERIC', value: '1.5e3' }, policyExpForbidden).status,
    'invalid',
  );
});

test('WP2-SCORING: Short numeric combines absolute and relative tolerance boundaries correctly', () => {
  const numQ = {
    questionId: 'q-tol',
    version: 1,
    contentHash: 'sha256:tol',
    body: { kind: 'SHORT_NUMERIC' as const, prompt: 'Prompt', correctDecimal: '100' },
  };

  // 1% relative tolerance on 100 means [99, 101]
  const policyRel = createScoringPolicyVersion({
    id: 'policy-rel',
    version: 1,
    status: 'proposed',
    mcqSingle: { pointsCorrect: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    trueFalseCluster: { pointsPerCorrectStatement: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    shortNumeric: {
      pointsCorrect: 1,
      pointsIncorrect: 0,
      pointsEmpty: 0,
      absoluteTolerance: '0',
      relativeTolerance: '0.01',
      decimalSeparators: ['.'],
      groupingSeparators: [],
      allowExponent: false,
    },
  });

  assert.equal(scoreQuestionVersion(numQ, { kind: 'SHORT_NUMERIC', value: '101' }, policyRel).totalPoints, 1);
  assert.equal(scoreQuestionVersion(numQ, { kind: 'SHORT_NUMERIC', value: '99' }, policyRel).totalPoints, 1);
  assert.equal(scoreQuestionVersion(numQ, { kind: 'SHORT_NUMERIC', value: '101.01' }, policyRel).totalPoints, 0);
  assert.equal(scoreQuestionVersion(numQ, { kind: 'SHORT_NUMERIC', value: '98.99' }, policyRel).totalPoints, 0);
});

test('WP2-HARDENING: computeQuestionContentHash adversarial tests (prompt number, answer, solution, mapping, diagnostic, key order, cyclic & non-finite)', () => {
  const baseQuestion = {
    questionId: 'q-hash-test',
    version: 1,
    curriculumVersionId: 'curr-1',
    skillIds: ['skill-monotonicity'],
    solutionVersionId: 'sol-1',
    body: {
      kind: 'MCQ_SINGLE' as const,
      prompt: 'Hàm số y = x^3 - 3x^2 + 2 đồng biến trên khoảng nào?',
      options: [
        {
          id: 'A',
          text: '(0; 2)',
          diagnosticHypothesis: {
            tag: 'nham_nghich_bien',
            likelyMissingStep: 'Quên đổi dấu đạo hàm',
            explanation: 'f\'(x) < 0',
            isHypothesis: true as const,
          },
        },
        { id: 'B', text: '(2; +∞)' },
        { id: 'C', text: '(-∞; 0)' },
        { id: 'D', text: 'R' },
      ],
      correctOptionId: 'B',
    },
  };

  const baseHash = computeQuestionContentHash(baseQuestion);
  assert.match(baseHash, /^sha256:[a-f0-9]{64}$/);

  // 1. Đổi một số trong câu hỏi -> hash thay đổi
  const changedPromptQuestion = {
    ...baseQuestion,
    body: { ...baseQuestion.body, prompt: 'Hàm số y = x^3 - 6x^2 + 2 đồng biến trên khoảng nào?' },
  };
  assert.notEqual(computeQuestionContentHash(changedPromptQuestion), baseHash);

  // 2. Đổi đáp án -> hash thay đổi
  const changedAnswerQuestion = {
    ...baseQuestion,
    body: { ...baseQuestion.body, correctOptionId: 'C' },
  };
  assert.notEqual(computeQuestionContentHash(changedAnswerQuestion), baseHash);

  // 3. Đổi solution -> hash thay đổi
  const changedSolutionQuestion = {
    ...baseQuestion,
    solutionVersionId: 'sol-2-revised',
  };
  assert.notEqual(computeQuestionContentHash(changedSolutionQuestion), baseHash);

  // 4. Đổi statement mapping -> hash thay đổi
  const changedSkillMappingQuestion = {
    ...baseQuestion,
    skillIds: ['skill-extrema'],
  };
  assert.notEqual(computeQuestionContentHash(changedSkillMappingQuestion), baseHash);

  // 5. Đổi diagnostic mapping -> hash thay đổi
  const changedDiagnosticQuestion = {
    ...baseQuestion,
    body: {
      ...baseQuestion.body,
      options: [
        {
          id: 'A',
          text: '(0; 2)',
          diagnosticHypothesis: {
            tag: 'khac_nham_lan',
            likelyMissingStep: 'Nhầm lẫn bảng xét dấu',
            explanation: 'f\'(x) âm',
            isHypothesis: true as const,
          },
        },
        baseQuestion.body.options[1],
        baseQuestion.body.options[2],
        baseQuestion.body.options[3],
      ] as any,
    },
  };
  assert.notEqual(computeQuestionContentHash(changedDiagnosticQuestion), baseHash);

  // 6. Đổi thứ tự object keys không làm hash thay đổi
  const reorderedKeysQuestion = {
    body: {
      correctOptionId: 'B',
      options: [
        {
          text: '(0; 2)',
          id: 'A',
          diagnosticHypothesis: {
            explanation: 'f\'(x) < 0',
            likelyMissingStep: 'Quên đổi dấu đạo hàm',
            tag: 'nham_nghich_bien',
            isHypothesis: true as const,
          },
        },
        { text: '(2; +∞)', id: 'B' },
        { text: '(-∞; 0)', id: 'C' },
        { text: 'R', id: 'D' },
      ],
      prompt: 'Hàm số y = x^3 - 3x^2 + 2 đồng biến trên khoảng nào?',
      kind: 'MCQ_SINGLE' as const,
    },
    solutionVersionId: 'sol-1',
    skillIds: ['skill-monotonicity'],
    curriculumVersionId: 'curr-1',
    version: 1,
    questionId: 'q-hash-test',
  };
  assert.equal(computeQuestionContentHash(reorderedKeysQuestion), baseHash);

  // 7. Non-finite values and cyclic references must be rejected
  assert.throws(() => {
    canonicalSerialize({ val: NaN });
  }, /non-finite/i);
  assert.throws(() => {
    canonicalSerialize({ val: Infinity });
  }, /non-finite/i);

  const cyclic: any = {};
  cyclic.self = cyclic;
  assert.throws(() => {
    canonicalSerialize(cyclic);
  }, /cyclic/i);
});

test('WP2-HARDENING: Reviewer authorization evidence and subject-scope verification', () => {
  const testBody = {
    kind: 'MCQ_SINGLE' as const,
    prompt: 'Auth test prompt',
    options: [{ id: 'A', text: 'Opt A' }, { id: 'B', text: 'Opt B' }, { id: 'C', text: 'Opt C' }, { id: 'D', text: 'Opt D' }],
    correctOptionId: 'A',
  };
  const testSol = { id: 'sol-1', questionId: 'q-auth-pub', questionVersion: 1, explanation: 'Auth test explanation' };
  const testHash = computeQuestionContentHash({
    questionId: 'q-auth-pub',
    version: 1,
    body: testBody,
    curriculumVersionId: 'curr-1',
    skillIds: ['skill-1'],
    solutionVersionId: 'sol-1',
    solution: testSol,
  });

  const version = {
    questionId: 'q-auth-pub',
    version: 1,
    status: 'approved',
    contentHash: testHash,
    curriculumVersionId: 'curr-1',
    skillIds: ['skill-1'],
    sourceAssetIds: ['src-1'],
    licenseRecordIds: ['lic-1'],
    solutionVersionId: 'sol-1',
    body: testBody,
  };

  const validEvidence: ReviewerAuthorizationEvidence = {
    reviewerId: 'prof-math-01',
    authorizedSubjectIds: ['math'],
    authorizedCurriculumVersionIds: ['curr-1'],
    status: 'active',
    validFrom: '2026-01-01T00:00:00.000Z',
    validThrough: '2026-12-31T23:59:59.999Z',
  };

  const baseContext = {
    now: '2026-11-08T12:00:00.000Z',
    curriculumVersionIds: ['curr-1'],
    skillIds: ['skill-1'],
    sourceAssets: [{ id: 'src-1', provenanceKind: 'original' as const, reference: 'original-notes' }],
    licenses: [{ id: 'lic-1', status: 'original' as const, validThrough: null, allowedOperations: ['publish'] }],
    solutions: [testSol],
    publicationRecords: [],
  };

  // 1. Arbitrary reviewerId without evidence or registry MUST fail closed
  const arbitraryReviewerCtx = {
    ...baseContext,
    reviews: [{
      id: 'rev-1',
      questionId: 'q-auth-pub',
      questionVersion: 1,
      reviewedContentHash: testHash,
      decision: 'approved',
      reviewerId: 'unverified-user-999',
    }],
  };
  const arbitraryRes = validatePublication(version, arbitraryReviewerCtx);
  assert.equal(arbitraryRes.eligible, false);
  assert.match(arbitraryRes.errors.join('; '), /Reviewer 'unverified-user-999' lacks accredited ReviewerAuthorizationEvidence/);

  // 2. Valid active reviewer in registry PASSES
  const validRegistryCtx = {
    ...baseContext,
    reviewerRegistry: [validEvidence],
    reviews: [{
      id: 'rev-1',
      questionId: 'q-auth-pub',
      questionVersion: 1,
      reviewedContentHash: testHash,
      decision: 'approved',
      reviewerId: 'prof-math-01',
    }],
  };
  assert.equal(validatePublication(version, validRegistryCtx).eligible, true);

  // 3. Reviewer unauthorized for subject FAILS
  const wrongSubjectEvidence: ReviewerAuthorizationEvidence = {
    ...validEvidence,
    authorizedSubjectIds: ['physics', 'chemistry'],
  };
  const wrongSubjectCtx = {
    ...baseContext,
    reviewerRegistry: [wrongSubjectEvidence],
    reviews: [{
      id: 'rev-1',
      questionId: 'q-auth-pub',
      questionVersion: 1,
      reviewedContentHash: testHash,
      decision: 'approved',
      reviewerId: 'prof-math-01',
    }],
  };
  assert.equal(validatePublication(version, wrongSubjectCtx).eligible, false);

  // 4. Suspended reviewer FAILS
  const suspendedEvidence: ReviewerAuthorizationEvidence = {
    ...validEvidence,
    status: 'suspended',
  };
  const suspendedCtx = {
    ...baseContext,
    reviewerRegistry: [suspendedEvidence],
    reviews: [{
      id: 'rev-1',
      questionId: 'q-auth-pub',
      questionVersion: 1,
      reviewedContentHash: testHash,
      decision: 'approved',
      reviewerId: 'prof-math-01',
    }],
  };
  assert.equal(validatePublication(version, suspendedCtx).eligible, false);

  // 5. Expired reviewer authorization FAILS
  const expiredEvidence: ReviewerAuthorizationEvidence = {
    ...validEvidence,
    validThrough: '2026-05-01T00:00:00.000Z',
  };
  const expiredCtx = {
    ...baseContext,
    reviewerRegistry: [expiredEvidence],
    reviews: [{
      id: 'rev-1',
      questionId: 'q-auth-pub',
      questionVersion: 1,
      reviewedContentHash: testHash,
      decision: 'approved',
      reviewerId: 'prof-math-01',
    }],
  };
  assert.equal(validatePublication(version, expiredCtx).eligible, false);
});

test('WP2-HARDENING: Source and license validation rejects unknown, restricted, and expired licenses', () => {
  const now = '2026-11-08T12:00:00.000Z';

  // Unknown or restricted status is always invalid
  const unknownLic = createLicenseRecord({ id: 'lic-u', status: 'unknown', validThrough: null });
  const restrictedLic = createLicenseRecord({ id: 'lic-r', status: 'restricted', validThrough: null });
  assert.equal(isLicenseValidAt(unknownLic, now), false);
  assert.equal(isLicenseValidAt(restrictedLic, now), false);

  // Future validFrom is not yet valid
  const futureLic = {
    id: 'lic-f',
    status: 'licensed' as const,
    validFrom: '2026-12-01T00:00:00.000Z',
    validThrough: '2027-12-01T00:00:00.000Z',
  };
  assert.equal(isLicenseValidAt(futureLic, now), false);

  // Past validThrough is expired
  const expiredLic = createLicenseRecord({
    id: 'lic-exp',
    status: 'licensed',
    validThrough: '2026-10-01T00:00:00.000Z',
  });
  assert.equal(isLicenseValidAt(expiredLic, now), false);

  // Valid licensed record
  const activeLic = {
    id: 'lic-act',
    status: 'licensed' as const,
    validFrom: '2026-01-01T00:00:00.000Z',
    validThrough: '2026-12-31T23:59:59.999Z',
  };
  assert.equal(isLicenseValidAt(activeLic, now), true);
});

test('WP2-HARDENING: Numeric policy & scoring runtime validation catches NaN, Infinity, negative values, and distinguishes error categories', () => {
  const validMcq = {
    questionId: 'q-score-test',
    version: 1,
    contentHash: 'sha256:score',
    body: {
      kind: 'MCQ_SINGLE' as const,
      prompt: 'Prompt',
      options: [
        { id: 'A', text: 'Opt A' },
        { id: 'B', text: 'Opt B' },
        { id: 'C', text: 'Opt C' },
        { id: 'D', text: 'Opt D' },
      ],
      correctOptionId: 'B',
    },
  };

  const validPolicy = {
    id: 'pol-valid',
    version: 1,
    status: 'proposed' as const,
    mcqSingle: { pointsCorrect: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    trueFalseCluster: { pointsPerCorrectStatement: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    shortNumeric: {
      pointsCorrect: 1,
      pointsIncorrect: 0,
      pointsEmpty: 0,
      absoluteTolerance: '0.01',
      relativeTolerance: '0',
      decimalSeparators: ['.'],
      groupingSeparators: [],
      allowExponent: false,
    },
  };

  // 1. Policy with NaN points returns policy_invalid
  const nanPolicy = {
    ...validPolicy,
    mcqSingle: { ...validPolicy.mcqSingle, pointsCorrect: NaN },
  };
  const nanResult = scoreQuestionVersion(validMcq, { kind: 'MCQ_SINGLE', optionId: 'B' }, nanPolicy);
  assert.equal(nanResult.status, 'invalid');
  assert.equal(nanResult.errorCategory, 'policy_invalid');
  assert.equal(nanResult.totalPoints, 0);

  // 2. Policy with negative tolerance returns policy_invalid
  const negTolPolicy = {
    ...validPolicy,
    shortNumeric: { ...validPolicy.shortNumeric, absoluteTolerance: '-0.01' },
  };
  const negTolResult = scoreQuestionVersion(validMcq, { kind: 'MCQ_SINGLE', optionId: 'B' }, negTolPolicy);
  assert.equal(negTolResult.status, 'invalid');
  assert.equal(negTolResult.errorCategory, 'policy_invalid');

  // 3. Invalid question returns question_invalid
  const invalidQResult = scoreQuestionVersion(null, { kind: 'MCQ_SINGLE', optionId: 'B' }, validPolicy);
  assert.equal(invalidQResult.status, 'invalid');
  assert.equal(invalidQResult.errorCategory, 'question_invalid');

  // 4. Invalid answer returns answer_invalid
  const invalidAnsResult = scoreQuestionVersion(validMcq, { kind: 'MCQ_SINGLE', optionId: 'UNKNOWN_OPTION' }, validPolicy);
  assert.equal(invalidAnsResult.status, 'invalid');
  assert.equal(invalidAnsResult.errorCategory, 'answer_invalid');

  // 5. Invariant: totalPoints <= maxPoints holds and sum of parts equals totalPoints
  const validResult = scoreQuestionVersion(validMcq, { kind: 'MCQ_SINGLE', optionId: 'B' }, validPolicy);
  assert.equal(validResult.status, 'scored');
  assert.ok(validResult.totalPoints <= validResult.maxPoints);
  assert.equal(validResult.totalPoints, validResult.parts.reduce((s, p) => s + p.points, 0));
});

test('WP2-HARDENING: Deep immutability prevents mutation of question versions and attempt event history', () => {
  const rawOptions = [
    { id: 'A', text: 'Alpha' },
    { id: 'B', text: 'Beta' },
    { id: 'C', text: 'Gamma' },
    { id: 'D', text: 'Delta' },
  ];
  const rawSkillIds = ['skill-1'];

  const qv = createQuestionVersion({
    questionId: 'q-immut',
    version: 1,
    status: 'draft',
    contentHash: 'sha256:immut',
    curriculumVersionId: 'curr-1',
    skillIds: rawSkillIds,
    sourceAssetIds: ['src-1'],
    licenseRecordIds: ['lic-1'],
    body: {
      kind: 'MCQ_SINGLE',
      prompt: 'Original Prompt',
      options: rawOptions as any,
      correctOptionId: 'B',
    },
  });

  // Mutating original input array should NOT mutate QuestionVersion
  rawOptions[0].text = 'MUTATED';
  rawSkillIds.push('skill-mutated');

  assert.equal((qv.body as any).options[0].text, 'Alpha');
  assert.equal(qv.skillIds.length, 1);
  assert.equal(qv.skillIds[0], 'skill-1');

  // Attempting to mutate qv directly must throw in strict mode
  assert.throws(() => {
    (qv as any).questionId = 'hacked';
  }, TypeError);
  assert.throws(() => {
    (qv.body as any).prompt = 'hacked';
  }, TypeError);

  // Attempt history immutability
  const originalEvent = createAttemptEvent({
    id: 'att-immut-1',
    sessionId: 'sess-1',
    questionVersionRef: { questionId: 'q-immut', version: 1, contentHash: 'sha256:immut' },
    scoringPolicyVersionRef: { id: 'pol-1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'B' },
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [{ partId: 'question', status: 'correct', points: 1, maxPoints: 1 }],
    timestamp: '2026-11-08T12:00:00.000Z',
  });

  const history: AttemptEvent[] = [originalEvent];
  const appended = appendAttemptEvent(history, originalEvent === history[0] ? { ...originalEvent, id: 'att-immut-2' } : originalEvent);

  assert.equal(appended.length, 2);

  // Attempting to mutate stored event must throw TypeError
  assert.throws(() => {
    (appended[0] as any).id = 'mutated-id';
  }, TypeError);
  assert.throws(() => {
    (appended[0].questionVersionRef as any).questionId = 'mutated-qid';
  }, TypeError);
});

test('WP0-A: computeQuestionContentHash accounts for actual SolutionVersion content', () => {
  const baseQ = {
    questionId: 'q-sol-hash',
    version: 1,
    curriculumVersionId: 'curr-1',
    skillIds: ['skill-1'],
    solutionVersionId: 'sol-v1',
    solution: {
      id: 'sol-v1',
      explanation: 'Giai thich goc',
      steps: ['Buoc 1: dao ham', 'Buoc 2: lap bang'],
      keyPoints: ['Diem cuc tri'],
    },
    body: {
      kind: 'SHORT_NUMERIC' as const,
      prompt: 'Tim gia tri',
      correctDecimal: '5.5',
    },
  };

  const baseHash = computeQuestionContentHash(baseQ);
  assert.ok(baseHash.startsWith('sha256:'));

  // 1. Changing explanation changes hash
  const changedExp = {
    ...baseQ,
    solution: { ...baseQ.solution, explanation: 'Giai thich da sua doi' },
  };
  assert.notEqual(computeQuestionContentHash(changedExp), baseHash);

  // 2. Changing steps changes hash
  const changedSteps = {
    ...baseQ,
    solution: { ...baseQ.solution, steps: ['Buoc 1 sua'] },
  };
  assert.notEqual(computeQuestionContentHash(changedSteps), baseHash);

  // 3. Changing keyPoints changes hash
  const changedKP = {
    ...baseQ,
    solution: { ...baseQ.solution, keyPoints: ['Diem khac'] },
  };
  assert.notEqual(computeQuestionContentHash(changedKP), baseHash);

  // 4. Reordered keys in solution yields same hash
  const reorderedSol = {
    ...baseQ,
    solution: {
      keyPoints: ['Diem cuc tri'],
      explanation: 'Giai thich goc',
      steps: ['Buoc 1: dao ham', 'Buoc 2: lap bang'],
      id: 'sol-v1',
    },
  };
  assert.equal(computeQuestionContentHash(reorderedSol), baseHash);

  // 5. Stale review with old hash cannot publish mutated solution
  const draftQ = {
    questionId: 'q-sol-hash',
    version: 1,
    status: 'approved' as const,
    contentHash: baseHash,
    curriculumVersionId: 'curr-1',
    skillIds: ['skill-1'],
    sourceAssetIds: ['src-1'],
    licenseRecordIds: ['lic-1'],
    solutionVersionId: 'sol-v1',
    body: baseQ.body,
  };
  const ctxWithOldReview = {
    now: '2026-11-09T00:00:00.000Z',
    curriculumVersionIds: ['curr-1'],
    skillIds: ['skill-1'],
    sourceAssets: [{ id: 'src-1', provenanceKind: 'original', reference: 'ref-1' }],
    licenses: [{ id: 'lic-1', status: 'original', validThrough: null }],
    solutions: [{ id: 'sol-v1', questionId: 'q-sol-hash', questionVersion: 1, explanation: 'Giai thich da sua doi' }],
    reviews: [{
      id: 'rev-1',
      questionId: 'q-sol-hash',
      questionVersion: 1,
      reviewedContentHash: baseHash, // Reviewed with original solution!
      decision: 'approved',
      reviewerId: 'qualified-reviewer',
    }],
    publicationRecords: [],
  };
  const pubRes = validatePublication(draftQ, ctxWithOldReview);
  assert.equal(pubRes.eligible, false);
  assert.match(pubRes.errors.join('; '), /does not match computed content hash/);
});

test('WP0-C: License validation rejects malformed dates, inverted intervals, and unauthorized operations', () => {
  // 1. Inverted interval validFrom > validThrough throws
  assert.throws(() => {
    createLicenseRecord({
      id: 'lic-inv',
      status: 'licensed',
      validFrom: '2026-12-01T00:00:00.000Z',
      validThrough: '2026-01-01T00:00:00.000Z',
    });
  }, /validFrom cannot be later than validThrough/);

  // 2. Malformed date string throws
  assert.throws(() => {
    createLicenseRecord({
      id: 'lic-bad-date',
      status: 'licensed',
      validThrough: 'invalid-iso-date',
    });
  }, /valid ISO date string/);

  // 3. Operation filtering
  const licWithOps = createLicenseRecord({
    id: 'lic-ops',
    status: 'licensed',
    validThrough: '2027-01-01T00:00:00.000Z',
    allowedOperations: ['read', 'practice'],
  });
  const now = '2026-11-09T00:00:00.000Z';
  assert.equal(isLicenseValidAt(licWithOps, now, 'practice'), true);
  assert.equal(isLicenseValidAt(licWithOps, now, 'publish'), false);
});

test('WP0-D: createScoringPolicyVersion and validateScoringPolicyVersion reject NaN, Infinity, and negative numbers', () => {
  const validBase = {
    id: 'pol-test-d',
    version: 1,
    status: 'proposed' as const,
    mcqSingle: { pointsCorrect: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    trueFalseCluster: { pointsPerCorrectStatement: 1, pointsIncorrect: 0, pointsEmpty: 0, allCorrectBonus: 0 },
    shortNumeric: {
      pointsCorrect: 1,
      pointsIncorrect: 0,
      pointsEmpty: 0,
      absoluteTolerance: '0.01',
      relativeTolerance: '0',
      decimalSeparators: ['.'],
      groupingSeparators: [],
      allowExponent: false,
    },
  };

  // NaN pointsCorrect rejected at constructor
  assert.throws(() => {
    createScoringPolicyVersion({
      ...validBase,
      mcqSingle: { ...validBase.mcqSingle, pointsCorrect: NaN },
    });
  }, /pointsCorrect must be a finite non-negative number/);

  // Infinity points rejected at constructor
  assert.throws(() => {
    createScoringPolicyVersion({
      ...validBase,
      trueFalseCluster: { ...validBase.trueFalseCluster, pointsPerCorrectStatement: Infinity },
    });
  }, /pointsPerCorrectStatement must be a finite non-negative number/);

  // Negative points rejected at constructor
  assert.throws(() => {
    createScoringPolicyVersion({
      ...validBase,
      shortNumeric: { ...validBase.shortNumeric, pointsIncorrect: -1 },
    });
  }, /pointsIncorrect must be a finite non-negative number/);

  // Negative tolerance rejected at constructor
  assert.throws(() => {
    createScoringPolicyVersion({
      ...validBase,
      shortNumeric: { ...validBase.shortNumeric, absoluteTolerance: '-0.5' },
    });
  }, /absoluteTolerance must be a non-negative finite canonical decimal string/);
});

test('WP0-F: appendAttemptEvent deep clones nested objects even if input is shallow-frozen', () => {
  const nestedResponse = { kind: 'MCQ_SINGLE' as const, optionId: 'B' };
  const nestedResult = { status: 'scored' as const, totalPoints: 1, maxPoints: 1 };
  const nestedEvidence = [{ partId: 'question', status: 'correct' as const, points: 1, maxPoints: 1 }];

  // Outer object is frozen, but nested objects are mutable
  const shallowFrozenEvent = Object.freeze({
    id: 'att-shallow-freeze',
    sessionId: 'sess-test',
    questionVersionRef: { questionId: 'q-1', version: 1, contentHash: 'sha256:abc' },
    scoringPolicyVersionRef: { id: 'pol-1', version: 1 },
    response: nestedResponse,
    result: nestedResult,
    partEvidence: nestedEvidence,
    timestamp: '2026-11-09T00:00:00.000Z',
  });

  const history = appendAttemptEvent([], shallowFrozenEvent as any);
  assert.equal(history.length, 1);

  // Mutating original nested input objects after append
  (nestedResponse as any).optionId = 'MUTATED_OPTION';
  (nestedResult as any).totalPoints = 999;
  (nestedEvidence as any)[0].status = 'incorrect';

  // Stored history must remain completely unaffected
  assert.equal((history[0].response as any).optionId, 'B');
  assert.equal(history[0].result.totalPoints, 1);
  assert.equal(history[0].partEvidence[0].status, 'correct');

  // Stored nested objects are also frozen
  assert.equal(Object.isFrozen(history[0].response), true);
  assert.equal(Object.isFrozen(history[0].result), true);
  assert.equal(Object.isFrozen(history[0].partEvidence[0]), true);

  // Re-appending with same ID throws duplicate error
  assert.throws(() => {
    appendAttemptEvent(history, shallowFrozenEvent as any);
  }, /Duplicate attempt ID/);
});

test('WP0-A: canonicalSerialize rejects keys that collide after Unicode NFC normalization', () => {
  // \u00e9 is precomposed é (NFC)
  // e\u0301 is decomposed e + combining acute (NFD)
  const collidingObject = {
    '\u00e9': 1,
    'e\u0301': 2,
  };
  assert.throws(() => {
    canonicalSerialize(collidingObject);
  }, /Duplicate object key .* after Unicode NFC normalization/);
});

test('WP0-A: validatePublication binds strictly to context solution and ignores caller-supplied solution override', () => {
  const version = {
    questionId: 'q-ctx-sol',
    version: 1,
    status: 'approved' as const,
    contentHash: 'placeholder',
    curriculumVersionId: 'curr-1',
    skillIds: ['skill-1'],
    sourceAssetIds: ['src-1'],
    licenseRecordIds: ['lic-1'],
    solutionVersionId: 'sol-trusted-v1',
    body: {
      kind: 'MCQ_SINGLE' as const,
      prompt: 'Test prompt',
      options: [{ id: 'A', text: 'Opt A' }, { id: 'B', text: 'Opt B' }, { id: 'C', text: 'Opt C' }, { id: 'D', text: 'Opt D' }],
      correctOptionId: 'A',
    },
    solution: {
      id: 'sol-trusted-v1',
      explanation: 'Fake adversarial explanation',
      steps: ['Fake step'],
      keyPoints: ['Fake keypoint'],
    },
  };

  const trustedContextSol = {
    id: 'sol-trusted-v1',
    questionId: 'q-ctx-sol',
    questionVersion: 1,
    explanation: 'Actual trusted context explanation',
    steps: ['Actual trusted step'],
    keyPoints: ['Actual trusted keypoint'],
  };

  const trustedHash = computeQuestionContentHash({
    questionId: version.questionId,
    version: version.version,
    curriculumVersionId: version.curriculumVersionId,
    skillIds: version.skillIds,
    solutionVersionId: version.solutionVersionId,
    solution: trustedContextSol,
    body: version.body,
  });

  const validContext = {
    now: '2026-11-08T00:00:00.000Z',
    curriculumVersionIds: ['curr-1'],
    skillIds: ['skill-1'],
    sourceAssets: [{ id: 'src-1', provenanceKind: 'original' as const, reference: 'test-ref' }],
    licenses: [{ id: 'lic-1', status: 'original' as const, validThrough: null, allowedOperations: ['publish'] }],
    solutions: [trustedContextSol],
    reviews: [{
      id: 'rev-1',
      questionId: 'q-ctx-sol',
      questionVersion: 1,
      reviewedContentHash: trustedHash,
      decision: 'approved' as const,
      reviewerId: 'reviewer-math-01',
    }],
    reviewerRegistry: [{
      reviewerId: 'reviewer-math-01',
      authorizedSubjectIds: ['math'],
      authorizedCurriculumVersionIds: ['curr-1'],
      validFrom: '2026-01-01T00:00:00.000Z',
      validThrough: '2027-01-01T00:00:00.000Z',
      status: 'active' as const,
    }],
    publicationRecords: [],
  };

  // With the matching hash, publication succeeds because validator used trustedContextSol and ignored version.solution!
  const validRes = validatePublication({ ...version, contentHash: trustedHash }, validContext);
  assert.equal(validRes.eligible, true);

  // Missing context solution fails closed
  const noSolCtx = { ...validContext, solutions: [] };
  const noSolRes = validatePublication({ ...version, contentHash: trustedHash }, noSolCtx);
  assert.equal(noSolRes.eligible, false);
  assert.match(noSolRes.errors.join('; '), /Matching SolutionVersion .* is required in context/);

  // Empty explanation in context solution fails closed
  const emptyExpCtx = {
    ...validContext,
    solutions: [{ ...trustedContextSol, explanation: '   ' }],
  };
  const emptyExpRes = validatePublication({ ...version, contentHash: trustedHash }, emptyExpCtx);
  assert.equal(emptyExpRes.eligible, false);
  assert.match(emptyExpRes.errors.join('; '), /must provide a non-empty explanation/);
});

test('WP0-B: validateReviewerAuthorization comprehensively validates scope, status, dates, and registry', () => {
  const reviewer = {
    reviewerId: 'rev-math-01',
    authorizedSubjectIds: ['math'],
    authorizedCurriculumVersionIds: ['curr-v1'],
    validFrom: '2026-01-01T00:00:00.000Z',
    validThrough: '2026-12-31T23:59:59.999Z',
    status: 'active' as const,
  };

  const ctx = {
    subjectId: 'math',
    curriculumVersionId: 'curr-v1',
    now: '2026-11-08T00:00:00.000Z',
    reviewerRegistry: [reviewer],
  };

  // 1. Valid authorization succeeds
  assert.equal(validateReviewerAuthorization('rev-math-01', ctx).authorized, true);

  // 2. Inactive status fails
  assert.equal(
    validateReviewerAuthorization('rev-math-01', {
      ...ctx,
      reviewerRegistry: [{ ...reviewer, status: 'suspended' as const }],
    }).authorized,
    false,
  );

  // 3. Subject mismatch fails
  assert.equal(
    validateReviewerAuthorization('rev-math-01', {
      ...ctx,
      subjectId: 'physics',
    }).authorized,
    false,
  );

  // 4. Curriculum mismatch fails
  assert.equal(
    validateReviewerAuthorization('rev-math-01', {
      ...ctx,
      curriculumVersionId: 'curr-other',
    }).authorized,
    false,
  );

  // 5. Expired date fails
  assert.equal(
    validateReviewerAuthorization('rev-math-01', {
      ...ctx,
      now: '2027-01-01T00:00:00.000Z',
    }).authorized,
    false,
  );

  // 6. Not yet active date fails
  assert.equal(
    validateReviewerAuthorization('rev-math-01', {
      ...ctx,
      now: '2025-12-31T23:59:59.999Z',
    }).authorized,
    false,
  );

  // 7. Malformed dates fail closed
  assert.equal(
    validateReviewerAuthorization('rev-math-01', {
      ...ctx,
      reviewerRegistry: [{ ...reviewer, validThrough: 'not-a-valid-date' }],
    }).authorized,
    false,
  );

  // 8. Bare reviewer ID without registry entry fails
  assert.equal(
    validateReviewerAuthorization('rev-math-01', {
      ...ctx,
      reviewerRegistry: [],
    }).authorized,
    false,
  );
});

test('WP0-C: validatePublication requires publish operation for licensed status and valid provenanceKind', () => {
  const testBody = {
    kind: 'MCQ_SINGLE' as const,
    prompt: 'Rights test prompt',
    options: [{ id: 'A', text: 'Opt A' }, { id: 'B', text: 'Opt B' }, { id: 'C', text: 'Opt C' }, { id: 'D', text: 'Opt D' }],
    correctOptionId: 'A',
  };
  const testSol = { id: 'sol-1', questionId: 'q-rights', questionVersion: 1, explanation: 'Rights test explanation' };
  const testHash = computeQuestionContentHash({
    questionId: 'q-rights',
    version: 1,
    body: testBody,
    curriculumVersionId: 'curr-1',
    skillIds: ['skill-1'],
    solutionVersionId: 'sol-1',
    solution: testSol,
  });

  const version = {
    questionId: 'q-rights',
    version: 1,
    status: 'approved' as const,
    contentHash: testHash,
    curriculumVersionId: 'curr-1',
    skillIds: ['skill-1'],
    sourceAssetIds: ['src-1'],
    licenseRecordIds: ['lic-1'],
    solutionVersionId: 'sol-1',
    body: testBody,
  };

  const baseContext = {
    now: '2026-11-08T00:00:00.000Z',
    curriculumVersionIds: ['curr-1'],
    skillIds: ['skill-1'],
    sourceAssets: [{ id: 'src-1', provenanceKind: 'original' as const, reference: 'test-notes' }],
    licenses: [{
      id: 'lic-1',
      status: 'licensed' as const,
      validThrough: '2027-01-01T00:00:00.000Z',
      allowedOperations: ['practice', 'read'],
    }],
    solutions: [testSol],
    reviews: [{
      id: 'rev-1',
      questionId: 'q-rights',
      questionVersion: 1,
      reviewedContentHash: testHash,
      decision: 'approved' as const,
      reviewerId: 'rev-1',
    }],
    reviewerRegistry: [{
      reviewerId: 'rev-1',
      authorizedSubjectIds: ['math'],
      authorizedCurriculumVersionIds: ['curr-1'],
      validFrom: '2026-01-01T00:00:00.000Z',
      validThrough: '2027-01-01T00:00:00.000Z',
      status: 'active' as const,
    }],
    publicationRecords: [],
  };

  // Fails because 'publish' operation is not in allowedOperations
  assert.equal(validatePublication(version, baseContext).eligible, false);

  // Succeeds when 'publish' is explicitly allowed
  const allowedCtx = {
    ...baseContext,
    licenses: [{
      ...baseContext.licenses[0],
      allowedOperations: ['practice', 'read', 'publish'],
    }],
  };
  assert.equal(validatePublication(version, allowedCtx).eligible, true);

  // Missing provenanceKind fails
  const missingProvCtx = {
    ...allowedCtx,
    sourceAssets: [{ id: 'src-1', reference: 'test-notes' }],
  };
  assert.equal(validatePublication(version, missingProvCtx).eligible, false);
});

test('WP0-D: validateScoringPolicyVersion enforces total score bounds and required fields (no T/F 8/4 bug)', () => {
  const basePolicy = {
    id: 'pol-bounds',
    version: 1,
    status: 'proposed' as const,
    mcqSingle: { pointsCorrect: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    trueFalseCluster: { pointsPerCorrectStatement: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    shortNumeric: {
      pointsCorrect: 1,
      pointsIncorrect: 0,
      pointsEmpty: 0,
      absoluteTolerance: '0.01',
      relativeTolerance: '0',
      decimalSeparators: ['.'],
      groupingSeparators: [],
      allowExponent: false,
    },
  };

  // 1. Missing allowExponent rejected
  const noExp = {
    ...basePolicy,
    shortNumeric: { ...basePolicy.shortNumeric, allowExponent: undefined },
  };
  assert.equal(validateScoringPolicyVersion(noExp).valid, false);

  // 2. Missing groupingSeparators rejected
  const noGrouping = {
    ...basePolicy,
    shortNumeric: { ...basePolicy.shortNumeric, groupingSeparators: undefined },
  };
  assert.equal(validateScoringPolicyVersion(noGrouping).valid, false);

  // 3. T/F policy where pointsIncorrect > pointsPerCorrectStatement (the 8/4 bug probe) is REJECTED
  const tfBugPolicy = {
    ...basePolicy,
    trueFalseCluster: {
      pointsPerCorrectStatement: 1,
      pointsIncorrect: 2,
      pointsEmpty: 0,
    },
  };
  const tfVal = validateScoringPolicyVersion(tfBugPolicy);
  assert.equal(tfVal.valid, false);
  assert.match(tfVal.error ?? '', /pointsIncorrect cannot exceed pointsPerCorrectStatement/);

  // 4. MCQ policy where pointsIncorrect > pointsCorrect is REJECTED
  const mcqBugPolicy = {
    ...basePolicy,
    mcqSingle: { pointsCorrect: 1, pointsIncorrect: 2, pointsEmpty: 0 },
  };
  assert.equal(validateScoringPolicyVersion(mcqBugPolicy).valid, false);

  // 5. ShortNumeric policy where pointsIncorrect > pointsCorrect is REJECTED
  const numBugPolicy = {
    ...basePolicy,
    shortNumeric: { ...basePolicy.shortNumeric, pointsCorrect: 1, pointsIncorrect: 2 },
  };
  assert.equal(validateScoringPolicyVersion(numBugPolicy).valid, false);
});

test('WP0-F: validateAttemptEvent and appendAttemptEvent enforce complete schema and reject malformed input', () => {
  // Missing questionVersionRef fields
  const malformedRef = {
    id: 'att-mal',
    sessionId: 'sess-1',
    questionVersionRef: { questionId: 'q-1' },
    scoringPolicyVersionRef: { id: 'pol-1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'A' },
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [],
    timestamp: '2026-11-08T00:00:00.000Z',
  };
  assert.equal(validateAttemptEvent(malformedRef).valid, false);
  assert.throws(() => appendAttemptEvent([], malformedRef as any), /Invalid AttemptEvent/);

  // Missing response kind
  const malformedResp = {
    id: 'att-mal-2',
    sessionId: 'sess-1',
    questionVersionRef: { questionId: 'q-1', version: 1, contentHash: 'sha256:abc' },
    scoringPolicyVersionRef: { id: 'pol-1', version: 1 },
    response: {},
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [],
    timestamp: '2026-11-08T00:00:00.000Z',
  };
  assert.equal(validateAttemptEvent(malformedResp).valid, false);
  assert.throws(() => appendAttemptEvent([], malformedResp as any), /Invalid AttemptEvent/);

  // Invalid timestamp
  const malformedTs = {
    id: 'att-mal-3',
    sessionId: 'sess-1',
    questionVersionRef: { questionId: 'q-1', version: 1, contentHash: 'sha256:abc' },
    scoringPolicyVersionRef: { id: 'pol-1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'A' },
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [],
    timestamp: 'invalid-date-string',
  };
  assert.equal(validateAttemptEvent(malformedTs).valid, false);
  assert.throws(() => appendAttemptEvent([], malformedTs as any), /Invalid AttemptEvent/);
});

test('WP0-A-ADV: Publication rejects missing body or sparse solution explanation even with declared contentHash', () => {
  const versionNoBody = {
    questionId: 'q-no-body',
    version: 1,
    status: 'approved' as const,
    contentHash: 'sha256:declared-hash',
    curriculumVersionId: 'curr-1',
    skillIds: ['skill-1'],
    sourceAssetIds: ['src-1'],
    licenseRecordIds: ['lic-1'],
    solutionVersionId: 'sol-1',
  };
  const ctx = {
    now: '2026-11-08T00:00:00.000Z',
    curriculumVersionIds: ['curr-1'],
    skillIds: ['skill-1'],
    sourceAssets: [{ id: 'src-1', provenanceKind: 'original' as const, reference: 'test-ref' }],
    licenses: [{ id: 'lic-1', status: 'original' as const, validThrough: null, allowedOperations: ['publish'] }],
    solutions: [{ id: 'sol-1', questionId: 'q-no-body', questionVersion: 1, explanation: 'Valid explanation' }],
    reviews: [{
      id: 'rev-1',
      questionId: 'q-no-body',
      questionVersion: 1,
      reviewedContentHash: 'sha256:declared-hash',
      decision: 'approved' as const,
      reviewerId: 'prof-math-01',
    }],
    reviewerRegistry: [{
      reviewerId: 'prof-math-01',
      authorizedSubjectIds: ['math'],
      authorizedCurriculumVersionIds: ['curr-1'],
      validFrom: '2026-01-01T00:00:00.000Z',
      validThrough: '2027-01-01T00:00:00.000Z',
      status: 'active' as const,
    }],
  };
  const resNoBody = validatePublication(versionNoBody, ctx);
  assert.equal(resNoBody.eligible, false);
  assert.match(resNoBody.errors.join('; '), /Question version body is required/);
});

test('WP0-B-ADV: validateReviewerAuthorization strictly rejects non-ISO dates, missing curriculum, and out-of-bounds intervals', () => {
  const reviewer: ReviewerAuthorizationEvidence = {
    reviewerId: 'rev-iso',
    authorizedSubjectIds: ['math'],
    authorizedCurriculumVersionIds: ['curr-1'],
    status: 'active',
    validFrom: '2026-01-01T00:00:00.000Z',
    validThrough: '2027-01-01T00:00:00.000Z',
  };
  const ctx = {
    subjectId: 'math',
    curriculumVersionId: 'curr-1',
    now: '2026-06-01T00:00:00.000Z',
  };

  // Missing authorizedCurriculumVersionIds fails closed
  const noCurriculumReviewer = { ...reviewer, authorizedCurriculumVersionIds: [] };
  assert.equal(
    validateReviewerAuthorization('rev-iso', { ...ctx, reviewerRegistry: [noCurriculumReviewer] }).authorized,
    false,
  );

  // Non-ISO date format rejected
  const nonIsoReviewer = { ...reviewer, validFrom: '2026/01/01' };
  assert.equal(
    validateReviewerAuthorization('rev-iso', { ...ctx, reviewerRegistry: [nonIsoReviewer] }).authorized,
    false,
  );

  // validFrom later than validThrough rejected
  const invertedDates = { ...reviewer, validFrom: '2027-01-01T00:00:00.000Z', validThrough: '2026-01-01T00:00:00.000Z' };
  assert.equal(
    validateReviewerAuthorization('rev-iso', { ...ctx, reviewerRegistry: [invertedDates] }).authorized,
    false,
  );
});

test('WP0-C-ADV: Rights validation enforces commercialUseAllowed and attributionRequired', () => {
  const body = {
    kind: 'MCQ_SINGLE' as const,
    prompt: 'P',
    options: [{ id: 'A', text: 'A' }, { id: 'B', text: 'B' }, { id: 'C', text: 'C' }, { id: 'D', text: 'D' }],
    correctOptionId: 'A',
  };
  const sol = { id: 'sol-1', questionId: 'q-lic', questionVersion: 1, explanation: 'Exp' };
  const hash = computeQuestionContentHash({
    questionId: 'q-lic',
    version: 1,
    body,
    curriculumVersionId: 'curr-1',
    skillIds: ['skill-1'],
    solutionVersionId: 'sol-1',
    solution: sol,
  });

  const version = {
    questionId: 'q-lic',
    version: 1,
    status: 'approved' as const,
    contentHash: hash,
    curriculumVersionId: 'curr-1',
    skillIds: ['skill-1'],
    sourceAssetIds: ['src-1'],
    licenseRecordIds: ['lic-1'],
    solutionVersionId: 'sol-1',
    body,
  };

  const baseCtx = {
    now: '2026-06-01T00:00:00.000Z',
    curriculumVersionIds: ['curr-1'],
    skillIds: ['skill-1'],
    sourceAssets: [{ id: 'src-1', provenanceKind: 'licensed' as const, reference: 'license-doc-123' }],
    licenses: [{
      id: 'lic-1',
      status: 'licensed' as const,
      validThrough: '2027-01-01T00:00:00.000Z',
      allowedOperations: ['publish'],
      commercialUseAllowed: false,
    }],
    solutions: [sol],
    reviews: [{
      id: 'rev-1',
      questionId: 'q-lic',
      questionVersion: 1,
      reviewedContentHash: hash,
      decision: 'approved' as const,
      reviewerId: 'rev-math',
    }],
    reviewerRegistry: [{
      reviewerId: 'rev-math',
      authorizedSubjectIds: ['math'],
      authorizedCurriculumVersionIds: ['curr-1'],
      validFrom: '2026-01-01T00:00:00.000Z',
      validThrough: '2027-01-01T00:00:00.000Z',
      status: 'active' as const,
    }],
  };

  // Disallowed commercial use fails
  const comRes = validatePublication(version, baseCtx);
  assert.equal(comRes.eligible, false);
  assert.match(comRes.errors.join('; '), /restricts commercial use/);

  // Attribution required without issuer or attribution notes fails
  const attrCtx = {
    ...baseCtx,
    licenses: [{
      ...baseCtx.licenses[0],
      commercialUseAllowed: true,
      attributionRequired: true,
    }],
  };
  const attrRes = validatePublication(version, attrCtx);
  assert.equal(attrRes.eligible, false);
  assert.match(attrRes.errors.join('; '), /requires attribution/);
});

test('WP0-D-ADV: Scoring policy rejects overflow derived maxima and scorer rejects invalid part points', () => {
  // Overflow in trueFalseCluster pointsPerCorrectStatement
  const overflowPolicy = {
    id: 'pol-overflow',
    version: 1,
    status: 'proposed' as const,
    mcqSingle: { pointsCorrect: 1, pointsIncorrect: 0, pointsEmpty: 0 },
    trueFalseCluster: {
      pointsPerCorrectStatement: Number.MAX_VALUE,
      pointsIncorrect: 0,
      pointsEmpty: 0,
      allCorrectBonus: 0,
    },
    shortNumeric: {
      pointsCorrect: 1,
      pointsIncorrect: 0,
      pointsEmpty: 0,
      absoluteTolerance: '0.01',
      relativeTolerance: '0',
      decimalSeparators: ['.'],
      groupingSeparators: [','],
      allowExponent: false,
    },
  };
  const val = validateScoringPolicyVersion(overflowPolicy);
  assert.equal(val.valid, false);
  assert.match(val.error ?? '', /finite non-negative|exceeds safe finite limits/);
});

test('WP0-F-ADV: validateAttemptEvent and appendAttemptEvent enforce strict bounds, normalization, and reconciliation', () => {
  const validEvent = {
    id: 'att-valid-1',
    sessionId: 'sess-1',
    questionVersionRef: { questionId: 'q-1', version: 1, contentHash: 'sha256:abc' },
    scoringPolicyVersionRef: { id: 'pol-1', version: 1 },
    response: { kind: 'MCQ_SINGLE' as const, optionId: 'A' },
    result: { status: 'scored' as const, totalPoints: 1, maxPoints: 1 },
    partEvidence: [{ partId: 'p1', status: 'correct' as const, points: 1, maxPoints: 1 }],
    timestamp: '2026-11-08T00:00:00.000Z',
  };
  assert.equal(validateAttemptEvent(validEvent).valid, true);

  // Whitespace-padded ID is rejected
  const untrimmedEvent = { ...validEvent, id: ' att-valid-1 ' };
  assert.equal(validateAttemptEvent(untrimmedEvent).valid, false);
  assert.match(validateAttemptEvent(untrimmedEvent).error ?? '', /non-empty trimmed string/);

  // Append rejects normalized duplicate even if caller attempts whitespace padding
  const history = appendAttemptEvent([], validEvent);
  assert.throws(() => {
    appendAttemptEvent(history, untrimmedEvent as any);
  }, /Duplicate attempt ID/);

  // TRUE_FALSE_CLUSTER with string answer is rejected
  const tfStringAns = {
    ...validEvent,
    id: 'att-tf-str',
    response: {
      kind: 'TRUE_FALSE_CLUSTER' as const,
      answers: { st1: 'true' as any },
    },
  };
  assert.equal(validateAttemptEvent(tfStringAns).valid, false);
  assert.match(validateAttemptEvent(tfStringAns).error ?? '', /must be boolean or null/);

  // totalPoints > maxPoints is rejected
  const overflowResult = {
    ...validEvent,
    id: 'att-overflow',
    result: { status: 'scored' as const, totalPoints: 99, maxPoints: 1 },
    partEvidence: [{ partId: 'p1', status: 'correct' as const, points: 99, maxPoints: 1 }],
  };
  assert.equal(validateAttemptEvent(overflowResult).valid, false);
  assert.match(validateAttemptEvent(overflowResult).error ?? '', /cannot exceed maxPoints/);

  // sum of partEvidence does not reconcile with totalPoints is rejected
  const unreconciled = {
    ...validEvent,
    id: 'att-unreconciled',
    result: { status: 'scored' as const, totalPoints: 1, maxPoints: 1 },
    partEvidence: [{ partId: 'p1', status: 'correct' as const, points: 0, maxPoints: 1 }],
  };
  assert.equal(validateAttemptEvent(unreconciled).valid, false);
  assert.match(validateAttemptEvent(unreconciled).error ?? '', /must equal sum of partEvidence/);
});

test('WP0-F-ADV-PERSISTENCE: InMemoryPersistenceRepository rejects invalid AttemptEvent at write boundaries', async () => {
  const repo = new InMemoryPersistenceRepository();
  const invalidEvent = {
    id: 'att-invalid',
    sessionId: 'sess-1',
    questionVersionRef: { questionId: 'q-1', version: 1, contentHash: 'sha256:abc' },
    scoringPolicyVersionRef: { id: 'pol-1', version: 1 },
    response: { kind: 'MCQ_SINGLE' as const, optionId: 'A' },
    result: { status: 'scored' as const, totalPoints: 999, maxPoints: 1 },
    partEvidence: [],
    timestamp: '2026-11-08T00:00:00.000Z',
  };

  await assert.rejects(async () => {
    await repo.saveAttemptEvent(invalidEvent as any);
  }, /Corrupted or invalid attempt event record/);

  await assert.rejects(async () => {
    await repo.saveSessionAndAttempt(
      { id: 'sess-1', skillId: 'skill-1', startedAt: '2026-11-08T00:00:00.000Z', attemptIds: [] },
      invalidEvent as any,
    );
  }, /Corrupted or invalid attempt event record/);

  // Storage remains empty
  const events = await repo.getAttemptEvents();
  assert.equal(events.length, 0);
});
