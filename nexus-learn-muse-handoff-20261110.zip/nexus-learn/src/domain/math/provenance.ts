export type ProvenanceKind = 'original' | 'synthetic' | 'reference' | 'licensed';

export interface SourceAsset {
  readonly id: string;
  readonly provenanceKind: ProvenanceKind;
  readonly reference: string;
  readonly issuer?: string;
  readonly sourceDate?: string;
  readonly ingestedAt?: string;
  readonly notes?: string;
}

export type LicenseStatus = 'original' | 'synthetic' | 'licensed' | 'open' | 'restricted' | 'unknown';

export interface LicenseRecord {
  readonly id: string;
  readonly status: LicenseStatus;
  readonly validFrom?: string | null;
  readonly validThrough: string | null;
  readonly terms?: string;
  readonly grantee?: string;
  readonly allowedOperations?: readonly string[];
  readonly attributionRequired?: boolean;
  readonly commercialUseAllowed?: boolean;
}

export type ReviewDecision = 'approved' | 'rejected' | 'in_review';

export interface ReviewRecord {
  readonly id: string;
  readonly questionId: string;
  readonly questionVersion: number;
  readonly reviewedContentHash: string;
  readonly decision: ReviewDecision;
  readonly reviewerId: string;
  readonly reviewedAt: string;
  readonly notes?: string;
}

export interface PublicationRecord {
  readonly id?: string;
  readonly questionId: string;
  readonly questionVersion: number;
  readonly contentHash: string;
  readonly publishedAt: string;
  readonly publishedBy: string;
}

const ISO_TIMESTAMP_REGEX = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/;

export function isValidIsoDateString(iso: unknown): boolean {
  if (typeof iso !== 'string' || !ISO_TIMESTAMP_REGEX.test(iso)) return false;
  const ms = Date.parse(iso);
  if (!Number.isFinite(ms)) return false;
  const d = new Date(ms);
  const normalizedInput = iso.includes('.') ? iso : iso.replace('Z', '.000Z');
  return d.toISOString() === normalizedInput;
}

export function createSourceAsset(input: {
  readonly id: string;
  readonly provenanceKind: ProvenanceKind;
  readonly reference: string;
  readonly issuer?: string;
  readonly sourceDate?: string;
  readonly ingestedAt?: string;
  readonly notes?: string;
}): SourceAsset {
  if (!input.id?.trim()) throw new Error('SourceAsset id must be non-empty');
  if (!['original', 'synthetic', 'reference', 'licensed'].includes(input.provenanceKind)) {
    throw new Error(`Invalid provenanceKind: ${input.provenanceKind}`);
  }
  if (!input.reference?.trim()) throw new Error('SourceAsset reference must be non-empty');

  return Object.freeze({
    id: input.id.trim(),
    provenanceKind: input.provenanceKind,
    reference: input.reference.trim(),
    issuer: input.issuer?.trim(),
    sourceDate: input.sourceDate?.trim(),
    ingestedAt: input.ingestedAt || new Date().toISOString(),
    notes: input.notes?.trim(),
  });
}

export function createLicenseRecord(input: {
  readonly id: string;
  readonly status: LicenseStatus;
  readonly validThrough: string | null;
  readonly validFrom?: string | null;
  readonly terms?: string;
  readonly grantee?: string;
  readonly allowedOperations?: readonly string[];
  readonly attributionRequired?: boolean;
  readonly commercialUseAllowed?: boolean;
}): LicenseRecord {
  if (!input.id?.trim()) throw new Error('LicenseRecord id must be non-empty');
  if (!['original', 'synthetic', 'licensed', 'open', 'restricted', 'unknown'].includes(input.status)) {
    throw new Error(`Invalid LicenseStatus: ${input.status}`);
  }
  if (input.validThrough !== null && (!isValidIsoDateString(input.validThrough))) {
    throw new Error('LicenseRecord validThrough must be null or a valid ISO date string');
  }
  if (input.validFrom !== undefined && input.validFrom !== null && (!isValidIsoDateString(input.validFrom))) {
    throw new Error('LicenseRecord validFrom must be null or a valid ISO date string');
  }
  if (input.validFrom && input.validThrough && isValidIsoDateString(input.validFrom) && isValidIsoDateString(input.validThrough)) {
    if (Date.parse(input.validFrom) > Date.parse(input.validThrough)) {
      throw new Error('LicenseRecord validFrom cannot be later than validThrough');
    }
  }

  return Object.freeze({
    id: input.id.trim(),
    status: input.status,
    validFrom: input.validFrom ?? null,
    validThrough: input.validThrough,
    terms: input.terms?.trim(),
    grantee: input.grantee?.trim(),
    allowedOperations: input.allowedOperations ? Object.freeze([...input.allowedOperations]) : undefined,
    attributionRequired: input.attributionRequired,
    commercialUseAllowed: input.commercialUseAllowed,
  });
}

export function isLicenseValidAt(license: LicenseRecord, timestampIso: string, operation?: string): boolean {
  if (!license || !license.status) return false;
  if (license.status === 'unknown' || license.status === 'restricted') return false;
  if (!['original', 'licensed', 'synthetic', 'open'].includes(license.status)) return false;

  if (!isValidIsoDateString(timestampIso)) return false;
  const targetMs = Date.parse(timestampIso);

  if (license.validFrom !== undefined && license.validFrom !== null) {
    if (!isValidIsoDateString(license.validFrom)) return false;
    const fromMs = Date.parse(license.validFrom);
    if (targetMs < fromMs) return false;
  }

  if (license.validThrough !== null && license.validThrough !== undefined) {
    if (!isValidIsoDateString(license.validThrough)) return false;
    const expiryMs = Date.parse(license.validThrough);
    if (targetMs > expiryMs) return false;
  }

  if (operation) {
    if (!Array.isArray(license.allowedOperations) || !license.allowedOperations.includes(operation)) {
      return false;
    }
  }

  return true;
}

export function createReviewRecord(input: {
  readonly id: string;
  readonly questionId: string;
  readonly questionVersion: number;
  readonly reviewedContentHash: string;
  readonly decision: ReviewDecision;
  readonly reviewerId: string;
  readonly reviewedAt?: string;
  readonly notes?: string;
}): ReviewRecord {
  if (!input.id?.trim()) throw new Error('ReviewRecord id must be non-empty');
  if (!input.questionId?.trim()) throw new Error('ReviewRecord questionId must be non-empty');
  if (!Number.isInteger(input.questionVersion) || input.questionVersion < 1) {
    throw new Error('ReviewRecord questionVersion must be a positive integer');
  }
  if (!input.reviewedContentHash?.trim()) throw new Error('ReviewRecord reviewedContentHash must be non-empty');
  if (!['approved', 'rejected', 'in_review'].includes(input.decision)) {
    throw new Error(`Invalid ReviewDecision: ${input.decision}`);
  }
  if (!input.reviewerId?.trim()) throw new Error('ReviewRecord reviewerId must be non-empty');
  const reviewedAt = input.reviewedAt || new Date().toISOString();
  if (!Number.isFinite(Date.parse(reviewedAt))) {
    throw new Error('ReviewRecord reviewedAt must be a valid ISO date string');
  }

  return Object.freeze({
    id: input.id.trim(),
    questionId: input.questionId.trim(),
    questionVersion: input.questionVersion,
    reviewedContentHash: input.reviewedContentHash.trim(),
    decision: input.decision,
    reviewerId: input.reviewerId.trim(),
    reviewedAt,
    notes: input.notes?.trim(),
  });
}

export function createPublicationRecord(input: {
  readonly id?: string;
  readonly questionId: string;
  readonly questionVersion: number;
  readonly contentHash: string;
  readonly publishedAt?: string;
  readonly publishedBy: string;
}): PublicationRecord {
  if (!input.questionId?.trim()) throw new Error('PublicationRecord questionId must be non-empty');
  if (!Number.isInteger(input.questionVersion) || input.questionVersion < 1) {
    throw new Error('PublicationRecord questionVersion must be a positive integer');
  }
  if (!input.contentHash?.trim()) throw new Error('PublicationRecord contentHash must be non-empty');
  if (!input.publishedBy?.trim()) throw new Error('PublicationRecord publishedBy must be non-empty');
  const publishedAt = input.publishedAt || new Date().toISOString();
  if (!Number.isFinite(Date.parse(publishedAt))) {
    throw new Error('PublicationRecord publishedAt must be a valid ISO date string');
  }

  return Object.freeze({
    id: input.id?.trim(),
    questionId: input.questionId.trim(),
    questionVersion: input.questionVersion,
    contentHash: input.contentHash.trim(),
    publishedAt,
    publishedBy: input.publishedBy.trim(),
  });
}
