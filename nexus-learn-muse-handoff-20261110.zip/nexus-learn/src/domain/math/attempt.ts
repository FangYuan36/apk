import type { DiagnosticHypothesis } from './question';

export interface QuestionVersionRef {
  readonly questionId: string;
  readonly version: number;
  readonly contentHash: string;
}

export interface ScoringPolicyVersionRef {
  readonly id: string;
  readonly version: number;
}

export type PartScoringStatus = 'correct' | 'incorrect' | 'empty' | 'invalid';

export interface PartEvidence {
  readonly partId: string;
  readonly status: PartScoringStatus;
  readonly points: number;
  readonly maxPoints: number;
  readonly skillIds?: readonly string[];
  readonly diagnosticHypothesis?: DiagnosticHypothesis;
}

export type ScoreStatus = 'scored' | 'empty' | 'invalid';

export interface ScoreResultSummary {
  readonly status: ScoreStatus;
  readonly totalPoints: number;
  readonly maxPoints: number;
  readonly parts?: readonly PartEvidence[];
}

export type McqAttemptResponse = {
  readonly kind: 'MCQ_SINGLE';
  readonly optionId: string | null;
};

export type TfClusterAttemptResponse = {
  readonly kind: 'TRUE_FALSE_CLUSTER';
  readonly answers: Readonly<Record<string, boolean | null>>;
};

export type ShortNumericAttemptResponse = {
  readonly kind: 'SHORT_NUMERIC';
  readonly value: string | null;
};

export type AttemptResponse = McqAttemptResponse | TfClusterAttemptResponse | ShortNumericAttemptResponse;

export interface AttemptEvent {
  readonly id: string;
  readonly sessionId: string;
  readonly questionVersionRef: QuestionVersionRef;
  readonly scoringPolicyVersionRef: ScoringPolicyVersionRef;
  readonly response: AttemptResponse;
  readonly result: ScoreResultSummary;
  readonly partEvidence: readonly PartEvidence[];
  readonly timestamp: string;
  readonly durationMs?: number;
  readonly hintsUsed?: number;
  readonly isDelayedRecheck?: boolean;
}

export interface AttemptEventInput {
  readonly id: string;
  readonly sessionId: string;
  readonly questionVersionRef: QuestionVersionRef;
  readonly scoringPolicyVersionRef: ScoringPolicyVersionRef;
  readonly response: AttemptResponse;
  readonly result: ScoreResultSummary;
  readonly partEvidence: readonly PartEvidence[];
  readonly timestamp: string;
  readonly durationMs?: number;
  readonly hintsUsed?: number;
  readonly isDelayedRecheck?: boolean;
}

export function deepCloneAndFreeze<T>(obj: T, seen = new Map<unknown, unknown>()): Readonly<T> {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }
  if (seen.has(obj)) {
    return seen.get(obj) as Readonly<T>;
  }
  if (Array.isArray(obj)) {
    const arrCopy: unknown[] = [];
    seen.set(obj, arrCopy);
    for (const item of obj) {
      arrCopy.push(deepCloneAndFreeze(item, seen));
    }
    return Object.freeze(arrCopy) as unknown as Readonly<T>;
  }
  const objCopy: Record<string, unknown> = {};
  seen.set(obj, objCopy);
  for (const [key, val] of Object.entries(obj)) {
    objCopy[key] = deepCloneAndFreeze(val, seen);
  }
  return Object.freeze(objCopy) as unknown as Readonly<T>;
}

export function validateAttemptEvent(event: unknown): { readonly valid: boolean; readonly error?: string } {
  if (!event || typeof event !== 'object') {
    return { valid: false, error: 'AttemptEvent must be a non-null object' };
  }
  const e = event as Partial<AttemptEvent>;

  // id & sessionId
  if (!e.id || typeof e.id !== 'string' || e.id !== e.id.trim()) {
    return { valid: false, error: 'AttemptEvent id must be a non-empty trimmed string' };
  }
  if (!e.sessionId || typeof e.sessionId !== 'string' || e.sessionId !== e.sessionId.trim()) {
    return { valid: false, error: 'AttemptEvent sessionId must be a non-empty trimmed string' };
  }

  // questionVersionRef
  if (!e.questionVersionRef || typeof e.questionVersionRef !== 'object') {
    return { valid: false, error: 'AttemptEvent must include a valid questionVersionRef object' };
  }
  const qRef = e.questionVersionRef;
  if (!qRef.questionId || typeof qRef.questionId !== 'string' || !qRef.questionId.trim()) {
    return { valid: false, error: 'questionVersionRef questionId must be a non-empty string' };
  }
  if (typeof qRef.version !== 'number' || !Number.isInteger(qRef.version) || qRef.version < 1) {
    return { valid: false, error: 'questionVersionRef version must be a positive integer' };
  }
  if (!qRef.contentHash || typeof qRef.contentHash !== 'string' || !qRef.contentHash.trim()) {
    return { valid: false, error: 'questionVersionRef contentHash must be a non-empty string' };
  }

  // scoringPolicyVersionRef
  if (!e.scoringPolicyVersionRef || typeof e.scoringPolicyVersionRef !== 'object') {
    return { valid: false, error: 'AttemptEvent must include a valid scoringPolicyVersionRef object' };
  }
  const pRef = e.scoringPolicyVersionRef;
  if (!pRef.id || typeof pRef.id !== 'string' || !pRef.id.trim()) {
    return { valid: false, error: 'scoringPolicyVersionRef id must be a non-empty string' };
  }
  if (typeof pRef.version !== 'number' || !Number.isInteger(pRef.version) || pRef.version < 1) {
    return { valid: false, error: 'scoringPolicyVersionRef version must be a positive integer' };
  }

  // response
  if (!e.response || typeof e.response !== 'object') {
    return { valid: false, error: 'AttemptEvent response must be a non-null object' };
  }
  const resp = e.response;
  if (!resp.kind || !['MCQ_SINGLE', 'TRUE_FALSE_CLUSTER', 'SHORT_NUMERIC'].includes(resp.kind)) {
    return { valid: false, error: `Invalid attempt response kind: '${(resp as any).kind}'` };
  }
  if (resp.kind === 'MCQ_SINGLE') {
    if (resp.optionId !== null && typeof resp.optionId !== 'string') {
      return { valid: false, error: 'MCQ_SINGLE response optionId must be a string or null' };
    }
  } else if (resp.kind === 'TRUE_FALSE_CLUSTER') {
    if (!resp.answers || typeof resp.answers !== 'object') {
      return { valid: false, error: 'TRUE_FALSE_CLUSTER response answers must be an object' };
    }
    for (const [key, val] of Object.entries(resp.answers)) {
      if (typeof val !== 'boolean' && val !== null) {
        return { valid: false, error: `TRUE_FALSE_CLUSTER statement '${key}' answer must be boolean or null` };
      }
    }
  } else if (resp.kind === 'SHORT_NUMERIC') {
    if (resp.value !== null && typeof resp.value !== 'string') {
      return { valid: false, error: 'SHORT_NUMERIC response value must be a string or null' };
    }
  }

  // result
  if (!e.result || typeof e.result !== 'object') {
    return { valid: false, error: 'AttemptEvent result must be a non-null object' };
  }
  const res = e.result;
  if (res.status === 'invalid') {
    return { valid: false, error: "AttemptEvent cannot store a result with 'invalid' status" };
  }
  if (!res.status || !['scored', 'empty'].includes(res.status)) {
    return { valid: false, error: `Invalid result status: '${res.status}'` };
  }
  if (typeof res.totalPoints !== 'number' || !Number.isFinite(res.totalPoints) || res.totalPoints < 0) {
    return { valid: false, error: 'result totalPoints must be a finite non-negative number' };
  }
  if (typeof res.maxPoints !== 'number' || !Number.isFinite(res.maxPoints) || res.maxPoints < 0) {
    return { valid: false, error: 'result maxPoints must be a finite non-negative number' };
  }
  if (res.totalPoints > res.maxPoints) {
    return { valid: false, error: `result totalPoints (${res.totalPoints}) cannot exceed maxPoints (${res.maxPoints})` };
  }
  if (res.status === 'empty' && res.totalPoints !== 0) {
    return { valid: false, error: 'Empty AttemptEvent must have totalPoints of 0' };
  }

  // partEvidence
  if (!Array.isArray(e.partEvidence)) {
    return { valid: false, error: 'AttemptEvent partEvidence must be an array' };
  }
  if (res.status === 'scored' && e.partEvidence.length === 0) {
    return { valid: false, error: 'Scored AttemptEvent must include non-empty partEvidence' };
  }
  for (const p of e.partEvidence) {
    if (!p || typeof p !== 'object') {
      return { valid: false, error: 'partEvidence entries must be non-null objects' };
    }
    if (!p.partId || typeof p.partId !== 'string' || !p.partId.trim()) {
      return { valid: false, error: 'partEvidence partId must be a non-empty string' };
    }
    if (p.status === 'invalid') {
      return { valid: false, error: `partEvidence '${p.partId}' cannot have 'invalid' status in stored AttemptEvent` };
    }
    if (!p.status || !['correct', 'incorrect', 'empty'].includes(p.status)) {
      return { valid: false, error: `Invalid partEvidence status: '${p.status}'` };
    }
    if (typeof p.points !== 'number' || !Number.isFinite(p.points) || p.points < 0) {
      return { valid: false, error: 'partEvidence points must be a finite non-negative number' };
    }
    if (typeof p.maxPoints !== 'number' || !Number.isFinite(p.maxPoints) || p.maxPoints < 0) {
      return { valid: false, error: 'partEvidence maxPoints must be a finite non-negative number' };
    }
    if (p.points > p.maxPoints) {
      return { valid: false, error: `partEvidence '${p.partId}' points (${p.points}) cannot exceed maxPoints (${p.maxPoints})` };
    }
  }

  if (e.partEvidence.length > 0) {
    const partSum = e.partEvidence.reduce((sum, p) => sum + p.points, 0);
    if (Math.abs(partSum - res.totalPoints) > 1e-6) {
      return { valid: false, error: `result totalPoints (${res.totalPoints}) must equal sum of partEvidence points (${partSum})` };
    }
    const maxPartSum = e.partEvidence.reduce((sum, p) => sum + p.maxPoints, 0);
    if (Math.abs(maxPartSum - res.maxPoints) > 1e-6) {
      return { valid: false, error: `result maxPoints (${res.maxPoints}) must equal sum of partEvidence maxPoints (${maxPartSum})` };
    }
  }

  // timestamp
  if (!e.timestamp || typeof e.timestamp !== 'string' || !e.timestamp.trim() || !Number.isFinite(Date.parse(e.timestamp))) {
    return { valid: false, error: 'AttemptEvent timestamp must be a valid ISO date string' };
  }

  // Optional fields
  if (e.durationMs !== undefined && (typeof e.durationMs !== 'number' || !Number.isFinite(e.durationMs) || e.durationMs < 0)) {
    return { valid: false, error: 'AttemptEvent durationMs must be a finite non-negative number' };
  }
  if (e.hintsUsed !== undefined && (typeof e.hintsUsed !== 'number' || !Number.isInteger(e.hintsUsed) || e.hintsUsed < 0)) {
    return { valid: false, error: 'AttemptEvent hintsUsed must be a non-negative integer' };
  }
  if (e.isDelayedRecheck !== undefined && typeof e.isDelayedRecheck !== 'boolean') {
    return { valid: false, error: 'AttemptEvent isDelayedRecheck must be a boolean' };
  }

  return { valid: true };
}

export function createAttemptEvent(input: AttemptEventInput): AttemptEvent {
  const validation = validateAttemptEvent(input);
  if (!validation.valid) {
    throw new Error(`Invalid AttemptEvent: ${validation.error}`);
  }

  return deepCloneAndFreeze({
    id: input.id.trim(),
    sessionId: input.sessionId.trim(),
    questionVersionRef: {
      questionId: input.questionVersionRef.questionId.trim(),
      version: input.questionVersionRef.version,
      contentHash: input.questionVersionRef.contentHash.trim(),
    },
    scoringPolicyVersionRef: {
      id: input.scoringPolicyVersionRef.id.trim(),
      version: input.scoringPolicyVersionRef.version,
    },
    response: input.response,
    result: input.result,
    partEvidence: input.partEvidence || [],
    timestamp: input.timestamp,
    durationMs: input.durationMs,
    hintsUsed: input.hintsUsed,
    isDelayedRecheck: input.isDelayedRecheck,
  }) as AttemptEvent;
}

export function appendAttemptEvent(
  history: readonly AttemptEvent[],
  event: AttemptEvent,
): readonly AttemptEvent[] {
  if (!Array.isArray(history)) {
    throw new Error('history must be an array');
  }
  if (!event || typeof event !== 'object' || !event.id || typeof event.id !== 'string') {
    throw new Error('Invalid AttemptEvent: AttemptEvent id must be a non-empty trimmed string');
  }
  const normalizedId = event.id.trim();
  if (history.some((e) => e.id.trim() === normalizedId)) {
    throw new Error(`Duplicate attempt ID: '${event.id}'`);
  }
  const validation = validateAttemptEvent(event);
  if (!validation.valid) {
    throw new Error(`Invalid AttemptEvent: ${validation.error}`);
  }
  const snapshot = deepCloneAndFreeze(event) as AttemptEvent;
  return Object.freeze([...history, snapshot]);
}
