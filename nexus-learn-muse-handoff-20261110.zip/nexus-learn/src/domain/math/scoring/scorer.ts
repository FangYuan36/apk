import type {
  QuestionVersion,
  McqSingleBody,
  TrueFalseClusterBody,
  ShortNumericBody,
} from '../question';
import type { ScoringPolicyVersion } from '../scoring-policy';
import { validateScoringPolicyVersion } from '../scoring-policy';
import type {
  AttemptResponse,
  PartEvidence,
  ScoreResultSummary,
  ScoreStatus,
} from '../attempt';

export type ScoringErrorCategory =
  | 'answer_invalid'
  | 'question_invalid'
  | 'policy_invalid'
  | 'execution_error';

export interface ScoreResult extends ScoreResultSummary {
  readonly status: ScoreStatus;
  readonly totalPoints: number;
  readonly maxPoints: number;
  readonly parts: readonly PartEvidence[];
  readonly errorCategory?: ScoringErrorCategory;
  readonly errorMessage?: string;
}

function getFracLength(decimalStr: string): number {
  const parts = decimalStr.split('.');
  return parts.length > 1 ? parts[1].length : 0;
}

function parseDecimalToBigInt(str: string, scale: number): bigint {
  const isNegative = str.startsWith('-');
  const unsigned = isNegative ? str.slice(1) : str;
  const [intPart, fracPart = ''] = unsigned.split('.');
  const paddedFrac = fracPart.padEnd(scale, '0').slice(0, scale);
  const fullStr = intPart + paddedFrac;
  const val = BigInt(fullStr);
  return isNegative ? -val : val;
}

function bigintAbs(val: bigint): bigint {
  return val < 0n ? -val : val;
}

/**
 * Converts a scientific notation string (e.g. 1.25e2, -1e-2) to a canonical decimal string
 * without using JavaScript IEEE 754 Number() arithmetic.
 */
function scientificToCanonicalDecimal(str: string): string | null {
  const match = str.match(/^(-?)(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE]([+-]?\d+))$/);
  if (!match) return null;

  const isNeg = str.startsWith('-');
  const unsigned = isNeg ? str.slice(1) : str;
  const [base, expStr] = unsigned.split(/[eE]/);
  const exp = parseInt(expStr, 10);
  if (!Number.isSafeInteger(exp) || Math.abs(exp) > 100) return null;

  const [intPart, fracPart = ''] = base.split('.');
  const sign = isNeg ? '-' : '';

  if (exp === 0) {
    return sign + intPart + (fracPart ? '.' + fracPart : '');
  }

  if (exp > 0) {
    if (exp >= fracPart.length) {
      const zeros = '0'.repeat(exp - fracPart.length);
      const res = (intPart + fracPart + zeros).replace(/^0+/, '') || '0';
      return sign + res;
    } else {
      const newInt = (intPart + fracPart.slice(0, exp)).replace(/^0+/, '') || '0';
      const newFrac = fracPart.slice(exp);
      return sign + newInt + '.' + newFrac;
    }
  } else {
    const shift = -exp;
    const combined = intPart + fracPart;
    if (shift >= intPart.length) {
      const zeros = '0'.repeat(shift - intPart.length);
      const res = '0.' + zeros + combined;
      return sign + res;
    } else {
      const newInt = intPart.slice(0, intPart.length - shift);
      const newFrac = intPart.slice(intPart.length - shift) + fracPart;
      return sign + newInt + '.' + newFrac;
    }
  }
}

function scoreMcq(
  body: McqSingleBody,
  response: AttemptResponse,
  policy: ScoringPolicyVersion,
  skillIds: readonly string[],
): ScoreResult {
  const maxPoints = policy.mcqSingle.pointsCorrect;
  const hasSkills = Array.isArray(skillIds) && skillIds.length > 0;

  if (response.kind !== 'MCQ_SINGLE') {
    return Object.freeze({
      status: 'invalid',
      totalPoints: 0,
      maxPoints,
      errorCategory: 'answer_invalid',
      parts: Object.freeze([
        Object.freeze({
          partId: 'question',
          status: 'invalid',
          points: 0,
          maxPoints,
          ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
        }),
      ]),
    });
  }

  const optionId = response.optionId;

  if (optionId === null) {
    return Object.freeze({
      status: 'empty',
      totalPoints: policy.mcqSingle.pointsEmpty,
      maxPoints,
      parts: Object.freeze([
        Object.freeze({
          partId: 'question',
          status: 'empty',
          points: policy.mcqSingle.pointsEmpty,
          maxPoints,
          ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
        }),
      ]),
    });
  }

  const selectedOption = body.options.find((opt) => opt.id === optionId);
  if (!selectedOption) {
    return Object.freeze({
      status: 'invalid',
      totalPoints: 0,
      maxPoints,
      errorCategory: 'answer_invalid',
      parts: Object.freeze([
        Object.freeze({
          partId: 'question',
          status: 'invalid',
          points: 0,
          maxPoints,
          ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
        }),
      ]),
    });
  }

  const isCorrect = optionId === body.correctOptionId;
  const points = isCorrect ? policy.mcqSingle.pointsCorrect : policy.mcqSingle.pointsIncorrect;
  const status: ScoreStatus = 'scored';

  return Object.freeze({
    status,
    totalPoints: points,
    maxPoints,
    parts: Object.freeze([
      Object.freeze({
        partId: 'question',
        status: isCorrect ? 'correct' : 'incorrect',
        points,
        maxPoints,
        ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
        ...(!isCorrect && selectedOption.diagnosticHypothesis
          ? { diagnosticHypothesis: selectedOption.diagnosticHypothesis }
          : {}),
      }),
    ]),
  });
}

function scoreTrueFalseCluster(
  body: TrueFalseClusterBody,
  response: AttemptResponse,
  policy: ScoringPolicyVersion,
): ScoreResult {
  const ptsPerCorrect = policy.trueFalseCluster.pointsPerCorrectStatement;
  const bonus = policy.trueFalseCluster.allCorrectBonus ?? 0;
  const statementCount = body.statements.length;
  // maxPoints must include all possible bonuses
  const maxPoints = ptsPerCorrect * statementCount + bonus;

  if (response.kind !== 'TRUE_FALSE_CLUSTER' || typeof response.answers !== 'object' || response.answers === null) {
    return Object.freeze({
      status: 'invalid',
      totalPoints: 0,
      maxPoints,
      errorCategory: 'answer_invalid',
      parts: Object.freeze(
        body.statements.map((st) =>
          Object.freeze({
            partId: st.id,
            status: 'invalid',
            points: 0,
            maxPoints: ptsPerCorrect,
            skillIds: Object.freeze([...st.skillIds]),
          }),
        ),
      ),
    });
  }

  const answers = response.answers;

  // Validate answer format: keys must be known statements, values must be boolean or null/undefined
  const statementIds = new Set(body.statements.map((s) => s.id));
  for (const [key, val] of Object.entries(answers)) {
    if (!statementIds.has(key)) {
      return Object.freeze({
        status: 'invalid',
        totalPoints: 0,
        maxPoints,
        errorCategory: 'answer_invalid',
        parts: Object.freeze(
          body.statements.map((st) =>
            Object.freeze({
              partId: st.id,
              status: 'invalid',
              points: 0,
              maxPoints: ptsPerCorrect,
              skillIds: Object.freeze([...st.skillIds]),
            }),
          ),
        ),
      });
    }
    if (typeof val !== 'boolean' && val !== null && val !== undefined) {
      return Object.freeze({
        status: 'invalid',
        totalPoints: 0,
        maxPoints,
        errorCategory: 'answer_invalid',
        parts: Object.freeze(
          body.statements.map((st) =>
            Object.freeze({
              partId: st.id,
              status: 'invalid',
              points: 0,
              maxPoints: ptsPerCorrect,
              skillIds: Object.freeze([...st.skillIds]),
            }),
          ),
        ),
      });
    }
  }

  let allEmpty = true;
  let allCorrect = true;

  // Pre-calculate whether all are correct to reconcile part points with bonus
  for (const st of body.statements) {
    const ans = answers[st.id];
    if (ans === null || ans === undefined) {
      allCorrect = false;
    } else {
      allEmpty = false;
      if (ans !== st.correctValue) {
        allCorrect = false;
      }
    }
  }

  // Bonus share per statement if all correct
  const bonusPerPart = allCorrect && bonus > 0 ? bonus / statementCount : 0;

  const parts: PartEvidence[] = body.statements.map((st) => {
    const ans = answers[st.id];
    if (ans === null || ans === undefined) {
      return Object.freeze({
        partId: st.id,
        status: 'empty',
        points: policy.trueFalseCluster.pointsEmpty,
        maxPoints: ptsPerCorrect + (bonus > 0 ? bonus / statementCount : 0),
        skillIds: Object.freeze([...st.skillIds]),
      });
    }

    if (ans === st.correctValue) {
      const partPoints = ptsPerCorrect + bonusPerPart;
      return Object.freeze({
        partId: st.id,
        status: 'correct',
        points: partPoints,
        maxPoints: ptsPerCorrect + (bonus > 0 ? bonus / statementCount : 0),
        skillIds: Object.freeze([...st.skillIds]),
      });
    } else {
      const ptsInc = policy.trueFalseCluster.pointsIncorrect;
      return Object.freeze({
        partId: st.id,
        status: 'incorrect',
        points: ptsInc,
        maxPoints: ptsPerCorrect + (bonus > 0 ? bonus / statementCount : 0),
        skillIds: Object.freeze([...st.skillIds]),
        diagnosticHypothesis: st.diagnosticHypothesis,
      });
    }
  });

  // Validate part points and reconcile total points strictly as sum of parts without silent clamping
  for (const p of parts) {
    if (!Number.isFinite(p.points) || p.points < 0 || p.points > p.maxPoints + 1e-9) {
      return Object.freeze({
        status: 'invalid',
        totalPoints: 0,
        maxPoints,
        errorCategory: 'execution_error',
        errorMessage: `Scoring execution error: part '${p.partId}' points (${p.points}) exceed maxPoints (${p.maxPoints})`,
        parts: Object.freeze(parts.map((part) => Object.freeze({ ...part, status: 'invalid', points: 0 }))),
      });
    }
  }

  const rawTotal = parts.reduce((sum, p) => sum + p.points, 0);
  if (!Number.isFinite(rawTotal) || rawTotal < 0 || rawTotal > maxPoints + 1e-9) {
    return Object.freeze({
      status: 'invalid',
      totalPoints: 0,
      maxPoints,
      errorCategory: 'execution_error',
      errorMessage: `Scoring execution error: total points (${rawTotal}) exceed maxPoints (${maxPoints})`,
      parts: Object.freeze(parts.map((part) => Object.freeze({ ...part, status: 'invalid', points: 0 }))),
    });
  }

  const totalPoints = rawTotal;
  const overallStatus: ScoreStatus = allEmpty ? 'empty' : 'scored';

  return Object.freeze({
    status: overallStatus,
    totalPoints,
    maxPoints,
    parts: Object.freeze(parts),
  });
}

function scoreShortNumeric(
  body: ShortNumericBody,
  response: AttemptResponse,
  policy: ScoringPolicyVersion,
  skillIds: readonly string[],
): ScoreResult {
  const maxPoints = policy.shortNumeric.pointsCorrect;
  const hasSkills = Array.isArray(skillIds) && skillIds.length > 0;

  if (response.kind !== 'SHORT_NUMERIC') {
    return Object.freeze({
      status: 'invalid',
      totalPoints: 0,
      maxPoints,
      errorCategory: 'answer_invalid',
      parts: Object.freeze([
        Object.freeze({
          partId: 'question',
          status: 'invalid',
          points: 0,
          maxPoints,
          ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
        }),
      ]),
    });
  }

  const rawVal = response.value;

  if (rawVal === null || rawVal === undefined || rawVal === '') {
    return Object.freeze({
      status: 'empty',
      totalPoints: policy.shortNumeric.pointsEmpty,
      maxPoints,
      parts: Object.freeze([
        Object.freeze({
          partId: 'question',
          status: 'empty',
          points: policy.shortNumeric.pointsEmpty,
          maxPoints,
          ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
        }),
      ]),
    });
  }

  // Reject spaces, NaN, Infinity
  if (
    rawVal.includes(' ') ||
    rawVal === 'NaN' ||
    rawVal === 'Infinity' ||
    rawVal === '-Infinity'
  ) {
    return Object.freeze({
      status: 'invalid',
      totalPoints: 0,
      maxPoints,
      errorCategory: 'answer_invalid',
      parts: Object.freeze([
        Object.freeze({
          partId: 'question',
          status: 'invalid',
          points: 0,
          maxPoints,
          ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
        }),
      ]),
    });
  }

  // Exponent validation
  const hasExponent = rawVal.includes('e') || rawVal.includes('E');
  if (hasExponent && !policy.shortNumeric.allowExponent) {
    return Object.freeze({
      status: 'invalid',
      totalPoints: 0,
      maxPoints,
      errorCategory: 'answer_invalid',
      parts: Object.freeze([
        Object.freeze({
          partId: 'question',
          status: 'invalid',
          points: 0,
          maxPoints,
          ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
        }),
      ]),
    });
  }

  // Check for disallowed grouping separators
  const disallowedGroupSeps = policy.shortNumeric.groupingSeparators || [];
  for (const gSep of disallowedGroupSeps) {
    if (rawVal.includes(gSep)) {
      return Object.freeze({
        status: 'invalid',
        totalPoints: 0,
        maxPoints,
        errorCategory: 'answer_invalid',
        parts: Object.freeze([
          Object.freeze({
            partId: 'question',
            status: 'invalid',
            points: 0,
            maxPoints,
            ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
          }),
        ]),
      });
    }
  }

  // Normalize decimal separators
  const allowedDecSeps = policy.shortNumeric.decimalSeparators || ['.'];
  let normalized = rawVal;
  let decCount = 0;
  for (const sep of allowedDecSeps) {
    let pos = normalized.indexOf(sep);
    while (pos !== -1) {
      decCount++;
      pos = normalized.indexOf(sep, pos + 1);
    }
  }

  if (decCount > 1) {
    return Object.freeze({
      status: 'invalid',
      totalPoints: 0,
      maxPoints,
      parts: Object.freeze([
        Object.freeze({
          partId: 'question',
          status: 'invalid',
          points: 0,
          maxPoints,
          ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
        }),
      ]),
    });
  }

  if (decCount === 1) {
    for (const sep of allowedDecSeps) {
      if (sep !== '.') {
        normalized = normalized.split(sep).join('.');
      }
    }
  }

  // If input has exponent and allowExponent is true, convert to canonical decimal string
  if (hasExponent && policy.shortNumeric.allowExponent) {
    const converted = scientificToCanonicalDecimal(normalized);
    if (!converted) {
      return Object.freeze({
        status: 'invalid',
        totalPoints: 0,
        maxPoints,
        parts: Object.freeze([
          Object.freeze({
            partId: 'question',
            status: 'invalid',
            points: 0,
            maxPoints,
            ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
          }),
        ]),
      });
    }
    normalized = converted;
  }

  // Validate normalized decimal format
  if (!/^-?(?:0|[1-9]\d*)(?:\.\d+)?$/.test(normalized)) {
    return Object.freeze({
      status: 'invalid',
      totalPoints: 0,
      maxPoints,
      parts: Object.freeze([
        Object.freeze({
          partId: 'question',
          status: 'invalid',
          points: 0,
          maxPoints,
          ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
        }),
      ]),
    });
  }

  // Exact BigInt decimal comparison
  const correct = body.correctDecimal;
  const absTol = policy.shortNumeric.absoluteTolerance;
  const relTol = policy.shortNumeric.relativeTolerance;

  const maxFrac = Math.max(
    getFracLength(normalized),
    getFracLength(correct),
    getFracLength(absTol),
    getFracLength(relTol),
  ) + 4;

  const candBig = parseDecimalToBigInt(normalized, maxFrac);
  const corrBig = parseDecimalToBigInt(correct, maxFrac);
  const absTolBig = parseDecimalToBigInt(absTol, maxFrac);
  const relTolBig = parseDecimalToBigInt(relTol, maxFrac);

  const diff = bigintAbs(candBig - corrBig);
  let isWithinTolerance = diff <= absTolBig;

  if (!isWithinTolerance && relTolBig > 0n) {
    const scaleFactor = 10n ** BigInt(maxFrac);
    if (diff * scaleFactor <= relTolBig * bigintAbs(corrBig)) {
      isWithinTolerance = true;
    }
  }

  const points = isWithinTolerance
    ? policy.shortNumeric.pointsCorrect
    : policy.shortNumeric.pointsIncorrect;

  return Object.freeze({
    status: 'scored',
    totalPoints: points,
    maxPoints,
    parts: Object.freeze([
      Object.freeze({
        partId: 'question',
        status: isWithinTolerance ? 'correct' : 'incorrect',
        points,
        maxPoints,
        ...(hasSkills ? { skillIds: Object.freeze([...skillIds]) } : {}),
        ...(!isWithinTolerance && body.diagnosticHypothesis
          ? { diagnosticHypothesis: body.diagnosticHypothesis }
          : {}),
      }),
    ]),
  });
}

export function scoreQuestionVersion(
  questionVersion: unknown,
  response: unknown,
  scoringPolicyVersion: unknown,
): ScoreResult {
  try {
    // 1. Validate scoring policy
    const policyValidation = validateScoringPolicyVersion(scoringPolicyVersion);
    if (!policyValidation.valid) {
      return Object.freeze({
        status: 'invalid',
        totalPoints: 0,
        maxPoints: 0,
        parts: Object.freeze([]),
        errorCategory: 'policy_invalid',
        errorMessage: policyValidation.error,
      });
    }

    const qv = questionVersion as QuestionVersion;
    const resp = response as AttemptResponse;
    const policy = scoringPolicyVersion as ScoringPolicyVersion;

    // 2. Validate question version format
    if (!qv || typeof qv !== 'object' || !qv.body?.kind) {
      return Object.freeze({
        status: 'invalid',
        totalPoints: 0,
        maxPoints: 0,
        parts: Object.freeze([]),
        errorCategory: 'question_invalid',
        errorMessage: 'Invalid question version structure or missing body',
      });
    }

    const skillIds = qv.skillIds || [];

    switch (qv.body.kind) {
      case 'MCQ_SINGLE':
        return scoreMcq(qv.body, resp, policy, skillIds);
      case 'TRUE_FALSE_CLUSTER':
        return scoreTrueFalseCluster(qv.body, resp, policy);
      case 'SHORT_NUMERIC':
        return scoreShortNumeric(qv.body, resp, policy, skillIds);
      default:
        return Object.freeze({
          status: 'invalid',
          totalPoints: 0,
          maxPoints: 0,
          parts: Object.freeze([]),
          errorCategory: 'question_invalid',
          errorMessage: `Unknown question kind: '${(qv.body as any)?.kind}'`,
        });
    }
  } catch (err: unknown) {
    return Object.freeze({
      status: 'invalid',
      totalPoints: 0,
      maxPoints: 0,
      parts: Object.freeze([]),
      errorCategory: 'execution_error',
      errorMessage: (err as Error)?.message || 'Scoring execution error',
    });
  }
}
