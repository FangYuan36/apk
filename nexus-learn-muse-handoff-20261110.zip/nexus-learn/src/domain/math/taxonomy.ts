export type TaxonomyStatus = 'proposed' | 'reference_only' | 'official_approved';

export interface CurriculumVersion {
  readonly id: string;
  readonly name: string;
  readonly source: string;
  readonly status: TaxonomyStatus;
  readonly effectiveYear?: number;
  readonly createdAt: string;
}

export interface Subject {
  readonly id: string;
  readonly curriculumVersionId: string;
  readonly name: string;
  readonly code?: string;
}

export interface Topic {
  readonly id: string;
  readonly subjectId: string;
  readonly curriculumVersionId: string;
  readonly name: string;
  readonly description?: string;
}

export interface Skill {
  readonly id: string;
  readonly subjectId: string;
  readonly topicId: string;
  readonly curriculumVersionId: string;
  readonly name: string;
  readonly description?: string;
}

export interface TaxonomyChain {
  readonly curriculum: CurriculumVersion;
  readonly subject: Subject;
  readonly topic: Topic;
  readonly skill: Skill;
}

export interface QuestionSkillMapping {
  readonly questionId: string;
  readonly questionVersion: number;
  readonly partId?: string;
  readonly skillId: string;
  readonly curriculumVersionId: string;
  readonly weight?: number;
}

export function createCurriculumVersion(input: {
  readonly id: string;
  readonly name: string;
  readonly source: string;
  readonly status: TaxonomyStatus;
  readonly effectiveYear?: number;
  readonly createdAt?: string;
}): CurriculumVersion {
  if (!input.id || !input.id.trim()) {
    throw new Error('CurriculumVersion id must be a non-empty string');
  }
  if (!input.name || !input.name.trim()) {
    throw new Error('CurriculumVersion name must be a non-empty string');
  }
  if (!input.source || !input.source.trim()) {
    throw new Error('CurriculumVersion source must be a non-empty string');
  }
  const createdAt = input.createdAt || new Date().toISOString();
  if (!Number.isFinite(Date.parse(createdAt))) {
    throw new Error('CurriculumVersion createdAt must be a valid ISO date string');
  }
  return Object.freeze({
    id: input.id.trim(),
    name: input.name.trim(),
    source: input.source.trim(),
    status: input.status,
    effectiveYear: input.effectiveYear,
    createdAt,
  });
}

export function createSubject(input: {
  readonly id: string;
  readonly curriculumVersionId: string;
  readonly name: string;
  readonly code?: string;
}): Subject {
  if (!input.id?.trim() || !input.curriculumVersionId?.trim() || !input.name?.trim()) {
    throw new Error('Subject requires non-empty id, curriculumVersionId, and name');
  }
  return Object.freeze({
    id: input.id.trim(),
    curriculumVersionId: input.curriculumVersionId.trim(),
    name: input.name.trim(),
    code: input.code?.trim(),
  });
}

export function createTopic(input: {
  readonly id: string;
  readonly subjectId: string;
  readonly curriculumVersionId: string;
  readonly name: string;
  readonly description?: string;
}): Topic {
  if (!input.id?.trim() || !input.subjectId?.trim() || !input.curriculumVersionId?.trim() || !input.name?.trim()) {
    throw new Error('Topic requires non-empty id, subjectId, curriculumVersionId, and name');
  }
  return Object.freeze({
    id: input.id.trim(),
    subjectId: input.subjectId.trim(),
    curriculumVersionId: input.curriculumVersionId.trim(),
    name: input.name.trim(),
    description: input.description?.trim(),
  });
}

export function createSkill(input: {
  readonly id: string;
  readonly subjectId: string;
  readonly topicId: string;
  readonly curriculumVersionId: string;
  readonly name: string;
  readonly description?: string;
}): Skill {
  if (
    !input.id?.trim() ||
    !input.subjectId?.trim() ||
    !input.topicId?.trim() ||
    !input.curriculumVersionId?.trim() ||
    !input.name?.trim()
  ) {
    throw new Error('Skill requires non-empty id, subjectId, topicId, curriculumVersionId, and name');
  }
  return Object.freeze({
    id: input.id.trim(),
    subjectId: input.subjectId.trim(),
    topicId: input.topicId.trim(),
    curriculumVersionId: input.curriculumVersionId.trim(),
    name: input.name.trim(),
    description: input.description?.trim(),
  });
}

export function validateTaxonomyChain(chain: TaxonomyChain): { readonly valid: boolean; readonly errors: readonly string[] } {
  const errors: string[] = [];
  const { curriculum, subject, topic, skill } = chain;

  if (subject.curriculumVersionId !== curriculum.id) {
    errors.push(`Subject curriculumVersionId '${subject.curriculumVersionId}' does not match curriculum '${curriculum.id}'`);
  }
  if (topic.curriculumVersionId !== curriculum.id) {
    errors.push(`Topic curriculumVersionId '${topic.curriculumVersionId}' does not match curriculum '${curriculum.id}'`);
  }
  if (skill.curriculumVersionId !== curriculum.id) {
    errors.push(`Skill curriculumVersionId '${skill.curriculumVersionId}' does not match curriculum '${curriculum.id}'`);
  }
  if (topic.subjectId !== subject.id) {
    errors.push(`Topic subjectId '${topic.subjectId}' does not match subject '${subject.id}'`);
  }
  if (skill.subjectId !== subject.id) {
    errors.push(`Skill subjectId '${skill.subjectId}' does not match subject '${subject.id}'`);
  }
  if (skill.topicId !== topic.id) {
    errors.push(`Skill topicId '${skill.topicId}' does not match topic '${topic.id}'`);
  }

  return Object.freeze({
    valid: errors.length === 0,
    errors: Object.freeze(errors),
  });
}

export function createQuestionSkillMapping(input: {
  readonly questionId: string;
  readonly questionVersion: number;
  readonly partId?: string;
  readonly skillId: string;
  readonly curriculumVersionId: string;
  readonly weight?: number;
}): QuestionSkillMapping {
  if (!input.questionId?.trim()) throw new Error('questionId must be a non-empty string');
  if (!Number.isInteger(input.questionVersion) || input.questionVersion < 1) {
    throw new Error('questionVersion must be a positive integer');
  }
  if (!input.skillId?.trim()) throw new Error('skillId must be a non-empty string');
  if (!input.curriculumVersionId?.trim()) throw new Error('curriculumVersionId must be a non-empty string');
  if (input.weight !== undefined && (typeof input.weight !== 'number' || input.weight < 0)) {
    throw new Error('weight must be a non-negative number');
  }

  return Object.freeze({
    questionId: input.questionId.trim(),
    questionVersion: input.questionVersion,
    partId: input.partId?.trim(),
    skillId: input.skillId.trim(),
    curriculumVersionId: input.curriculumVersionId.trim(),
    weight: input.weight ?? 1,
  });
}
