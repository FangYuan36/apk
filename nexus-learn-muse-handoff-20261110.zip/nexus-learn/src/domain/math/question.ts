export type QuestionFamilyKind = 'MCQ_SINGLE' | 'TRUE_FALSE_CLUSTER' | 'SHORT_NUMERIC';

export type QuestionLifecycleStatus =
  | 'draft'
  | 'in_review'
  | 'approved'
  | 'published'
  | 'superseded'
  | 'archived';

export interface DiagnosticHypothesis {
  readonly tag: string;
  readonly likelyMissingStep: string;
  readonly explanation: string;
  readonly isHypothesis: true;
}

export interface McqOption {
  readonly id: string;
  readonly text: string;
  readonly diagnosticHypothesis?: DiagnosticHypothesis;
}

export interface McqSingleBody {
  readonly kind: 'MCQ_SINGLE';
  readonly prompt: string;
  readonly options: readonly [McqOption, McqOption, McqOption, McqOption];
  readonly correctOptionId: string;
}

export interface TfStatement {
  readonly id: string;
  readonly prompt: string;
  readonly correctValue: boolean;
  readonly skillIds: readonly string[];
  readonly diagnosticHypothesis?: DiagnosticHypothesis;
}

export interface TrueFalseClusterBody {
  readonly kind: 'TRUE_FALSE_CLUSTER';
  readonly prompt?: string;
  readonly statements: readonly [TfStatement, TfStatement, TfStatement, TfStatement];
}

export interface ShortNumericBody {
  readonly kind: 'SHORT_NUMERIC';
  readonly prompt: string;
  readonly correctDecimal: string;
  readonly unit?: string;
  readonly diagnosticHypothesis?: DiagnosticHypothesis;
}

export type QuestionBody = McqSingleBody | TrueFalseClusterBody | ShortNumericBody;

export interface Question {
  readonly id: string;
  readonly createdAt: string;
  readonly latestVersion: number;
}

export interface QuestionVersion {
  readonly questionId: string;
  readonly version: number;
  readonly status: QuestionLifecycleStatus;
  readonly contentHash: string;
  readonly curriculumVersionId: string;
  readonly skillIds: readonly string[];
  readonly sourceAssetIds: readonly string[];
  readonly licenseRecordIds: readonly string[];
  readonly solutionVersionId?: string;
  readonly body: QuestionBody;
}

export interface SolutionVersion {
  readonly id: string;
  readonly questionId: string;
  readonly questionVersion: number;
  readonly explanation: string;
  readonly steps?: readonly string[];
  readonly keyPoints?: readonly string[];
}

export function deepCloneAndFreeze<T>(obj: T, seen = new Map<unknown, unknown>()): Readonly<T> {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }
  if (seen.has(obj)) {
    return seen.get(obj) as Readonly<T>;
  }
  if (Array.isArray(obj)) {
    const arrCopy: unknown[] = [];
    seen.set(obj, arrCopy);
    for (const item of obj) {
      arrCopy.push(deepCloneAndFreeze(item, seen));
    }
    return Object.freeze(arrCopy) as unknown as Readonly<T>;
  }
  const objCopy: Record<string, unknown> = {};
  seen.set(obj, objCopy);
  for (const [key, val] of Object.entries(obj)) {
    objCopy[key] = deepCloneAndFreeze(val, seen);
  }
  return Object.freeze(objCopy) as unknown as Readonly<T>;
}

export function isValidCanonicalDecimalString(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  if (!value) return false;
  if (!/^-?(?:0|[1-9]\d*)(?:\.\d+)?$/.test(value)) return false;
  // Disallow negative zero representations (-0, -0.0, -0.00, etc.)
  if (/^-0(?:\.0+)?$/.test(value)) return false;
  return true;
}

export function createDiagnosticHypothesis(input: {
  readonly tag: string;
  readonly likelyMissingStep: string;
  readonly explanation: string;
}): DiagnosticHypothesis {
  if (!input.tag?.trim()) throw new Error('DiagnosticHypothesis tag must be non-empty');
  if (!input.likelyMissingStep?.trim()) throw new Error('DiagnosticHypothesis likelyMissingStep must be non-empty');
  if (!input.explanation?.trim()) throw new Error('DiagnosticHypothesis explanation must be non-empty');

  return Object.freeze({
    tag: input.tag.trim(),
    likelyMissingStep: input.likelyMissingStep.trim(),
    explanation: input.explanation.trim(),
    isHypothesis: true as const,
  });
}

export function createQuestion(input: {
  readonly id: string;
  readonly createdAt?: string;
  readonly latestVersion?: number;
}): Question {
  if (!input.id?.trim()) throw new Error('Question id must be non-empty');
  const createdAt = input.createdAt || new Date().toISOString();
  if (!Number.isFinite(Date.parse(createdAt))) throw new Error('createdAt must be a valid ISO date string');
  const latestVersion = input.latestVersion ?? 1;
  if (!Number.isInteger(latestVersion) || latestVersion < 1) {
    throw new Error('latestVersion must be a positive integer');
  }

  return Object.freeze({
    id: input.id.trim(),
    createdAt,
    latestVersion,
  });
}

export function validateQuestionBody(body: unknown): { readonly valid: boolean; readonly errors: readonly string[] } {
  if (typeof body !== 'object' || body === null) {
    return { valid: false, errors: ['Question body must be an object'] };
  }

  const errors: string[] = [];
  const b = body as Partial<QuestionBody>;

  if (b.kind === 'MCQ_SINGLE') {
    const mcq = b as Partial<McqSingleBody>;
    if (!mcq.prompt?.trim()) errors.push('MCQ_SINGLE requires non-empty prompt');
    if (!Array.isArray(mcq.options) || mcq.options.length !== 4) {
      errors.push('MCQ_SINGLE requires exactly 4 options');
    } else {
      const optionIds = new Set<string>();
      for (const opt of mcq.options) {
        if (!opt?.id?.trim()) errors.push('MCQ option requires non-empty id');
        else if (optionIds.has(opt.id.trim())) errors.push(`Duplicate MCQ option id: '${opt.id}'`);
        else optionIds.add(opt.id.trim());
        if (typeof opt?.text !== 'string' || !opt.text.trim()) {
          errors.push(`MCQ option '${opt?.id}' requires non-empty text`);
        }
      }
      if (!mcq.correctOptionId?.trim()) {
        errors.push('MCQ_SINGLE requires non-empty correctOptionId');
      } else if (!optionIds.has(mcq.correctOptionId.trim())) {
        errors.push(`MCQ correctOptionId '${mcq.correctOptionId}' must match one of the option ids`);
      }
    }
  } else if (b.kind === 'TRUE_FALSE_CLUSTER') {
    const cluster = b as Partial<TrueFalseClusterBody>;
    if (!Array.isArray(cluster.statements) || cluster.statements.length !== 4) {
      errors.push('TRUE_FALSE_CLUSTER requires exactly 4 statements');
    } else {
      const statementIds = new Set<string>();
      for (const st of cluster.statements) {
        if (!st?.id?.trim()) errors.push('Statement requires non-empty id');
        else if (statementIds.has(st.id.trim())) errors.push(`Duplicate statement id: '${st.id}'`);
        else statementIds.add(st.id.trim());
        if (typeof st?.prompt !== 'string' || !st.prompt.trim()) {
          errors.push(`Statement '${st?.id}' requires non-empty prompt`);
        }
        if (typeof st?.correctValue !== 'boolean') {
          errors.push(`Statement '${st?.id}' requires boolean correctValue`);
        }
        if (!Array.isArray(st?.skillIds) || st.skillIds.length === 0 || st.skillIds.some((s: string) => !s?.trim())) {
          errors.push(`Statement '${st?.id}' requires at least one valid skillId`);
        }
      }
    }
  } else if (b.kind === 'SHORT_NUMERIC') {
    const num = b as Partial<ShortNumericBody>;
    if (!num.prompt?.trim()) errors.push('SHORT_NUMERIC requires non-empty prompt');
    if (!isValidCanonicalDecimalString(num.correctDecimal)) {
      errors.push(`SHORT_NUMERIC correctDecimal must be a finite canonical decimal string: '${num.correctDecimal}'`);
    }
  } else {
    errors.push(`Unknown or missing QuestionBody kind: '${b.kind}'`);
  }

  return Object.freeze({
    valid: errors.length === 0,
    errors: Object.freeze(errors),
  });
}

export function createQuestionVersion(input: {
  readonly questionId: string;
  readonly version: number;
  readonly status: QuestionLifecycleStatus;
  readonly contentHash: string;
  readonly curriculumVersionId: string;
  readonly skillIds: readonly string[];
  readonly sourceAssetIds: readonly string[];
  readonly licenseRecordIds: readonly string[];
  readonly solutionVersionId?: string;
  readonly body: QuestionBody;
}): QuestionVersion {
  if (!input.questionId?.trim()) throw new Error('QuestionVersion questionId must be non-empty');
  if (!Number.isInteger(input.version) || input.version < 1) {
    throw new Error('QuestionVersion version must be a positive integer');
  }
  if (!['draft', 'in_review', 'approved', 'published', 'superseded', 'archived'].includes(input.status)) {
    throw new Error(`Invalid QuestionLifecycleStatus: ${input.status}`);
  }
  if (!input.contentHash?.trim()) throw new Error('QuestionVersion contentHash must be non-empty');
  if (!input.curriculumVersionId?.trim()) throw new Error('QuestionVersion curriculumVersionId must be non-empty');
  if (!Array.isArray(input.skillIds) || input.skillIds.length === 0 || input.skillIds.some((s) => !s?.trim())) {
    throw new Error('QuestionVersion skillIds must contain at least one valid skillId');
  }
  if (!Array.isArray(input.sourceAssetIds) || input.sourceAssetIds.length === 0) {
    throw new Error('QuestionVersion sourceAssetIds must contain at least one source asset reference');
  }
  if (!Array.isArray(input.licenseRecordIds) || input.licenseRecordIds.length === 0) {
    throw new Error('QuestionVersion licenseRecordIds must contain at least one license record reference');
  }

  const bodyValidation = validateQuestionBody(input.body);
  if (!bodyValidation.valid) {
    throw new Error(`Invalid question body: ${bodyValidation.errors.join('; ')}`);
  }

  const frozenBody = deepCloneAndFreeze(input.body) as QuestionBody;

  return deepCloneAndFreeze({
    questionId: input.questionId.trim(),
    version: input.version,
    status: input.status,
    contentHash: input.contentHash.trim(),
    curriculumVersionId: input.curriculumVersionId.trim(),
    skillIds: input.skillIds.map((s) => s.trim()),
    sourceAssetIds: input.sourceAssetIds.map((s) => s.trim()),
    licenseRecordIds: input.licenseRecordIds.map((s) => s.trim()),
    solutionVersionId: input.solutionVersionId?.trim(),
    body: frozenBody,
  }) as QuestionVersion;
}

export function createSuccessorQuestionVersion(
  current: QuestionVersion,
  updates: {
    readonly contentHash: string;
    readonly body?: QuestionBody;
    readonly status?: QuestionLifecycleStatus;
    readonly solutionVersionId?: string;
    readonly skillIds?: readonly string[];
    readonly sourceAssetIds?: readonly string[];
    readonly licenseRecordIds?: readonly string[];
    readonly curriculumVersionId?: string;
  },
): QuestionVersion {
  if (updates.contentHash === current.contentHash) {
    throw new Error('Successor question version must have a new contentHash');
  }

  return createQuestionVersion({
    questionId: current.questionId,
    version: current.version + 1,
    status: updates.status ?? 'draft',
    contentHash: updates.contentHash,
    curriculumVersionId: updates.curriculumVersionId ?? current.curriculumVersionId,
    skillIds: updates.skillIds ?? current.skillIds,
    sourceAssetIds: updates.sourceAssetIds ?? current.sourceAssetIds,
    licenseRecordIds: updates.licenseRecordIds ?? current.licenseRecordIds,
    solutionVersionId: updates.solutionVersionId ?? current.solutionVersionId,
    body: updates.body ?? current.body,
  });
}

export function createSolutionVersion(input: {
  readonly id: string;
  readonly questionId: string;
  readonly questionVersion: number;
  readonly explanation: string;
  readonly steps?: readonly string[];
  readonly keyPoints?: readonly string[];
}): SolutionVersion {
  if (!input.id?.trim()) throw new Error('SolutionVersion id must be non-empty');
  if (!input.questionId?.trim()) throw new Error('SolutionVersion questionId must be non-empty');
  if (!Number.isInteger(input.questionVersion) || input.questionVersion < 1) {
    throw new Error('SolutionVersion questionVersion must be a positive integer');
  }
  if (!input.explanation?.trim()) throw new Error('SolutionVersion explanation must be non-empty');

  return deepCloneAndFreeze({
    id: input.id.trim(),
    questionId: input.questionId.trim(),
    questionVersion: input.questionVersion,
    explanation: input.explanation.trim(),
    steps: input.steps ? [...input.steps] : undefined,
    keyPoints: input.keyPoints ? [...input.keyPoints] : undefined,
  }) as SolutionVersion;
}
