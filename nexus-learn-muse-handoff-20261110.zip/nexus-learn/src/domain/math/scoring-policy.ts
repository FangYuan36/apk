import { isValidCanonicalDecimalString } from './question';

export type ScoringPolicyStatus = 'proposed' | 'approved' | 'superseded';

export interface McqPolicy {
  readonly pointsCorrect: number;
  readonly pointsIncorrect: number;
  readonly pointsEmpty: number;
}

export interface TfClusterPolicy {
  readonly pointsPerCorrectStatement: number;
  readonly pointsIncorrect: number;
  readonly pointsEmpty: number;
  readonly allCorrectBonus?: number;
}

export interface ShortNumericPolicy {
  readonly pointsCorrect: number;
  readonly pointsIncorrect: number;
  readonly pointsEmpty: number;
  readonly absoluteTolerance: string;
  readonly relativeTolerance: string;
  readonly decimalSeparators: readonly string[];
  readonly groupingSeparators: readonly string[];
  readonly allowExponent: boolean;
}

export interface ScoringPolicyVersion {
  readonly id: string;
  readonly version: number;
  readonly status: ScoringPolicyStatus;
  readonly description?: string;
  readonly mcqSingle: McqPolicy;
  readonly trueFalseCluster: TfClusterPolicy;
  readonly shortNumeric: ShortNumericPolicy;
}

export function validateScoringPolicyVersion(policy: unknown): { readonly valid: boolean; readonly error?: string } {
  if (!policy || typeof policy !== 'object') {
    return { valid: false, error: 'Scoring policy must be an object' };
  }
  const p = policy as Partial<ScoringPolicyVersion>;
  if (!p.id || typeof p.id !== 'string' || !p.id.trim()) {
    return { valid: false, error: 'Scoring policy id must be a non-empty string' };
  }
  if (typeof p.version !== 'number' || !Number.isInteger(p.version) || p.version < 1) {
    return { valid: false, error: 'Scoring policy version must be a positive integer' };
  }
  if (!p.status || !['proposed', 'approved', 'superseded'].includes(p.status)) {
    return { valid: false, error: `Invalid ScoringPolicyStatus: '${p.status}'` };
  }
  const isFiniteNonNegative = (val: unknown): boolean =>
    typeof val === 'number' && Number.isFinite(val) && !Number.isNaN(val) && val >= 0 && val <= 1_000_000_000;

  // MCQ
  if (!p.mcqSingle || typeof p.mcqSingle !== 'object') {
    return { valid: false, error: 'Scoring policy must define mcqSingle object' };
  }
  if (!isFiniteNonNegative(p.mcqSingle.pointsCorrect)) {
    return { valid: false, error: 'mcqSingle pointsCorrect must be a finite non-negative number' };
  }
  if (!isFiniteNonNegative(p.mcqSingle.pointsIncorrect)) {
    return { valid: false, error: 'mcqSingle pointsIncorrect must be a finite non-negative number' };
  }
  if (!isFiniteNonNegative(p.mcqSingle.pointsEmpty)) {
    return { valid: false, error: 'mcqSingle pointsEmpty must be a finite non-negative number' };
  }
  if (p.mcqSingle.pointsIncorrect > p.mcqSingle.pointsCorrect) {
    return { valid: false, error: 'mcqSingle pointsIncorrect cannot exceed pointsCorrect' };
  }
  if (p.mcqSingle.pointsEmpty > p.mcqSingle.pointsCorrect) {
    return { valid: false, error: 'mcqSingle pointsEmpty cannot exceed pointsCorrect' };
  }

  // T/F
  if (!p.trueFalseCluster || typeof p.trueFalseCluster !== 'object') {
    return { valid: false, error: 'Scoring policy must define trueFalseCluster object' };
  }
  if (!isFiniteNonNegative(p.trueFalseCluster.pointsPerCorrectStatement)) {
    return { valid: false, error: 'trueFalseCluster pointsPerCorrectStatement must be a finite non-negative number' };
  }
  if (!isFiniteNonNegative(p.trueFalseCluster.pointsIncorrect)) {
    return { valid: false, error: 'trueFalseCluster pointsIncorrect must be a finite non-negative number' };
  }
  if (!isFiniteNonNegative(p.trueFalseCluster.pointsEmpty)) {
    return { valid: false, error: 'trueFalseCluster pointsEmpty must be a finite non-negative number' };
  }
  if (p.trueFalseCluster.pointsIncorrect > p.trueFalseCluster.pointsPerCorrectStatement) {
    return { valid: false, error: 'trueFalseCluster pointsIncorrect cannot exceed pointsPerCorrectStatement' };
  }
  if (p.trueFalseCluster.pointsEmpty > p.trueFalseCluster.pointsPerCorrectStatement) {
    return { valid: false, error: 'trueFalseCluster pointsEmpty cannot exceed pointsPerCorrectStatement' };
  }
  if (p.trueFalseCluster.allCorrectBonus !== undefined && !isFiniteNonNegative(p.trueFalseCluster.allCorrectBonus)) {
    return { valid: false, error: 'trueFalseCluster allCorrectBonus must be a finite non-negative number' };
  }
  const tfPts = p.trueFalseCluster.pointsPerCorrectStatement;
  const tfBonus = p.trueFalseCluster.allCorrectBonus ?? 0;
  const derivedTfMax = tfPts * 4 + tfBonus;
  if (!Number.isFinite(derivedTfMax) || derivedTfMax > Number.MAX_SAFE_INTEGER || derivedTfMax > 1_000_000_000) {
    return { valid: false, error: 'trueFalseCluster derived maximum points exceeds safe finite limits' };
  }

  // Short Numeric
  if (!p.shortNumeric || typeof p.shortNumeric !== 'object') {
    return { valid: false, error: 'Scoring policy must define shortNumeric object' };
  }
  if (!isFiniteNonNegative(p.shortNumeric.pointsCorrect)) {
    return { valid: false, error: 'shortNumeric pointsCorrect must be a finite non-negative number' };
  }
  if (!isFiniteNonNegative(p.shortNumeric.pointsIncorrect)) {
    return { valid: false, error: 'shortNumeric pointsIncorrect must be a finite non-negative number' };
  }
  if (!isFiniteNonNegative(p.shortNumeric.pointsEmpty)) {
    return { valid: false, error: 'shortNumeric pointsEmpty must be a finite non-negative number' };
  }
  if (p.shortNumeric.pointsIncorrect > p.shortNumeric.pointsCorrect) {
    return { valid: false, error: 'shortNumeric pointsIncorrect cannot exceed pointsCorrect' };
  }
  if (p.shortNumeric.pointsEmpty > p.shortNumeric.pointsCorrect) {
    return { valid: false, error: 'shortNumeric pointsEmpty cannot exceed pointsCorrect' };
  }
  if (typeof p.shortNumeric.absoluteTolerance !== 'string' || !isValidCanonicalDecimalString(p.shortNumeric.absoluteTolerance) || p.shortNumeric.absoluteTolerance.startsWith('-')) {
    return { valid: false, error: 'shortNumeric absoluteTolerance must be a non-negative finite canonical decimal string' };
  }
  if (typeof p.shortNumeric.relativeTolerance !== 'string' || !isValidCanonicalDecimalString(p.shortNumeric.relativeTolerance) || p.shortNumeric.relativeTolerance.startsWith('-')) {
    return { valid: false, error: 'shortNumeric relativeTolerance must be a non-negative finite canonical decimal string' };
  }
  if (!Array.isArray(p.shortNumeric.decimalSeparators) || p.shortNumeric.decimalSeparators.length === 0 || !p.shortNumeric.decimalSeparators.every((s) => typeof s === 'string' && s.length > 0)) {
    return { valid: false, error: 'shortNumeric decimalSeparators must be an array of non-empty strings' };
  }
  if (!Array.isArray(p.shortNumeric.groupingSeparators) || !p.shortNumeric.groupingSeparators.every((s) => typeof s === 'string')) {
    return { valid: false, error: 'shortNumeric groupingSeparators must be an array of strings' };
  }
  if (typeof p.shortNumeric.allowExponent !== 'boolean') {
    return { valid: false, error: 'shortNumeric allowExponent must be a boolean' };
  }

  return { valid: true };
}

export function createScoringPolicyVersion(input: {
  readonly id: string;
  readonly version: number;
  readonly status: ScoringPolicyStatus;
  readonly description?: string;
  readonly mcqSingle: McqPolicy;
  readonly trueFalseCluster: TfClusterPolicy;
  readonly shortNumeric: ShortNumericPolicy;
}): ScoringPolicyVersion {
  const validation = validateScoringPolicyVersion(input);
  if (!validation.valid) {
    throw new Error(`Invalid ScoringPolicyVersion: ${validation.error}`);
  }

  return Object.freeze({
    id: input.id.trim(),
    version: input.version,
    status: input.status,
    description: input.description?.trim(),
    mcqSingle: Object.freeze({ ...input.mcqSingle }),
    trueFalseCluster: Object.freeze({ ...input.trueFalseCluster }),
    shortNumeric: Object.freeze({
      ...input.shortNumeric,
      decimalSeparators: Object.freeze([...input.shortNumeric.decimalSeparators]),
      groupingSeparators: Object.freeze([...(input.shortNumeric.groupingSeparators || [])]),
    }),
  });
}
