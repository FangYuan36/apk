import { createHash } from 'node:crypto';
import type { QuestionVersion, QuestionBody, SolutionVersion } from '../question';
import { validateQuestionBody } from '../question';
import { isLicenseValidAt, isValidIsoDateString, type LicenseRecord } from '../provenance';

export interface ReviewerAuthorizationEvidence {
  readonly reviewerId: string;
  readonly authorizedSubjectIds: readonly string[];
  readonly authorizedCurriculumVersionIds?: readonly string[];
  readonly validFrom: string;
  readonly validThrough: string;
  readonly status: 'active' | 'suspended' | 'revoked' | string;
}

export interface ReviewerAuthorizationContext {
  readonly subjectId?: string;
  readonly curriculumVersionId?: string;
  readonly now?: string;
  readonly reviewerRegistry?: readonly ReviewerAuthorizationEvidence[];
}

export interface ReviewerAuthorizationResult {
  readonly authorized: boolean;
  readonly errors: readonly string[];
}

export interface PublicationContext {
  readonly now: string;
  readonly curriculumVersionIds: readonly string[];
  readonly skillIds: readonly string[];
  readonly subjectId?: string;
  readonly sourceAssets: readonly {
    readonly id: string;
    readonly provenanceKind?: string;
    readonly reference?: string;
    readonly issuer?: string;
    readonly notes?: string;
  }[];
  readonly licenses: readonly (LicenseRecord | {
    readonly id: string;
    readonly status: string;
    readonly validThrough: string | null;
    readonly validFrom?: string | null;
    readonly allowedOperations?: readonly string[];
    readonly attributionRequired?: boolean;
    readonly commercialUseAllowed?: boolean;
  })[];
  readonly solutions: readonly (SolutionVersion | {
    readonly id: string;
    readonly questionId: string;
    readonly questionVersion: number;
    readonly explanation?: string;
    readonly steps?: readonly string[];
    readonly keyPoints?: readonly string[];
  })[];
  readonly reviews: readonly {
    readonly id: string;
    readonly questionId: string;
    readonly questionVersion: number;
    readonly reviewedContentHash: string;
    readonly decision: string;
    readonly reviewerId: string;
    readonly authorizationEvidence?: ReviewerAuthorizationEvidence;
  }[];
  readonly reviewerRegistry?: readonly ReviewerAuthorizationEvidence[];
  readonly publicationRecords: readonly {
    readonly questionId: string;
    readonly questionVersion: number;
    readonly contentHash?: string;
  }[];
  readonly existingContentHashes?: readonly string[];
}

export interface PublicationValidationResult {
  readonly eligible: boolean;
  readonly errors: readonly string[];
}

const ISO_TIMESTAMP_REGEX = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/;

export function validateReviewerAuthorization(
  reviewerId: string,
  context: ReviewerAuthorizationContext,
): ReviewerAuthorizationResult {
  const errors: string[] = [];
  const trimmedId = typeof reviewerId === 'string' ? reviewerId.trim() : '';
  if (!trimmedId) {
    return Object.freeze({
      authorized: false,
      errors: Object.freeze(['Missing or empty reviewer ID']),
    });
  }

  const registry = context?.reviewerRegistry;
  if (!Array.isArray(registry) || registry.length === 0) {
    return Object.freeze({
      authorized: false,
      errors: Object.freeze([`Reviewer '${trimmedId}' lacks accredited ReviewerAuthorizationEvidence: no registry entries available`]),
    });
  }

  const entry = registry.find((r) => r && r.reviewerId === trimmedId);
  if (!entry) {
    return Object.freeze({
      authorized: false,
      errors: Object.freeze([`Reviewer '${trimmedId}' lacks accredited ReviewerAuthorizationEvidence in registry`]),
    });
  }

  if (entry.status !== 'active') {
    errors.push(`Reviewer '${trimmedId}' authorization status is '${entry.status}'; must be 'active'`);
  }

  const targetSubject = context?.subjectId || 'math';
  if (!Array.isArray(entry.authorizedSubjectIds) || !entry.authorizedSubjectIds.includes(targetSubject)) {
    errors.push(`Reviewer '${trimmedId}' is not authorized for subject '${targetSubject}'`);
  }

  if (!Array.isArray(entry.authorizedCurriculumVersionIds) || entry.authorizedCurriculumVersionIds.length === 0) {
    errors.push(`Reviewer '${trimmedId}' lacks mandatory authorizedCurriculumVersionIds`);
  } else if (context?.curriculumVersionId && !entry.authorizedCurriculumVersionIds.includes(context.curriculumVersionId)) {
    errors.push(
      `Reviewer '${trimmedId}' is not authorized for curriculum version '${context.curriculumVersionId}'`,
    );
  }

  const nowIso = context?.now || new Date().toISOString();
  const isNowValid = isValidIsoDateString(nowIso);
  if (!isNowValid) {
    errors.push(`Invalid reference timestamp '${context?.now}'`);
  }
  const nowMs = isNowValid ? Date.parse(nowIso) : NaN;

  const isFromValid = isValidIsoDateString(entry.validFrom);
  if (!isFromValid) {
    errors.push(`Reviewer '${trimmedId}' authorization validFrom date '${entry.validFrom}' is invalid`);
  }
  const isThroughValid = isValidIsoDateString(entry.validThrough);
  if (!isThroughValid) {
    errors.push(`Reviewer '${trimmedId}' authorization validThrough date '${entry.validThrough}' is invalid`);
  }

  const fromMs = isFromValid ? Date.parse(entry.validFrom) : NaN;
  const throughMs = isThroughValid ? Date.parse(entry.validThrough) : NaN;

  if (Number.isFinite(fromMs) && Number.isFinite(throughMs) && fromMs > throughMs) {
    errors.push(`Reviewer '${trimmedId}' authorization validFrom cannot be later than validThrough`);
  }

  if (Number.isFinite(nowMs) && Number.isFinite(fromMs) && nowMs < fromMs) {
    errors.push(`Reviewer '${trimmedId}' authorization is not yet active at '${nowIso}'`);
  }
  if (Number.isFinite(nowMs) && Number.isFinite(throughMs) && nowMs > throughMs) {
    errors.push(`Reviewer '${trimmedId}' authorization has expired at '${nowIso}'`);
  }

  return Object.freeze({
    authorized: errors.length === 0,
    errors: Object.freeze(errors),
  });
}

const ALLOWED_LICENSE_STATUSES = new Set(['original', 'licensed', 'open']);
const ALLOWED_PROVENANCE_KINDS = new Set(['original', 'licensed', 'synthetic', 'public_domain']);

/**
 * Recursively serializes arbitrary values into a deterministic canonical JSON string.
 * - Object keys are sorted alphabetically at every level.
 * - Array element order is strictly preserved.
 * - String values are normalized using Unicode NFC.
 * - Rejects non-finite numbers (NaN, Infinity, -Infinity).
 * - Rejects undefined, functions, and symbols.
 * - Detects and rejects cyclic references.
 */
export function canonicalSerialize(val: unknown, seen = new Set<unknown>()): string {
  if (val === null) return 'null';
  if (typeof val === 'boolean') return val ? 'true' : 'false';
  if (typeof val === 'number') {
    if (!Number.isFinite(val)) {
      throw new Error(`Cannot canonicalize non-finite number: ${val}`);
    }
    return JSON.stringify(val);
  }
  if (typeof val === 'string') {
    return JSON.stringify(val.normalize('NFC'));
  }
  if (typeof val === 'bigint') {
    return JSON.stringify(val.toString());
  }
  if (typeof val === 'undefined' || typeof val === 'function' || typeof val === 'symbol') {
    throw new Error(`Cannot canonicalize unsupported type: ${typeof val}`);
  }
  if (typeof val === 'object') {
    if (seen.has(val)) {
      throw new Error('Cyclic reference detected during canonical serialization');
    }
    seen.add(val);
    try {
      if (Array.isArray(val)) {
        const elements = val.map((item) => canonicalSerialize(item, seen));
        return `[${elements.join(',')}]`;
      }
      const record = val as Record<string, unknown>;
      const rawKeys = Object.keys(record);
      const seenNormalizedKeys = new Set<string>();
      const normalizedEntries: { normKey: string; originalKey: string }[] = [];
      for (const k of rawKeys) {
        const normKey = k.normalize('NFC');
        if (seenNormalizedKeys.has(normKey)) {
          throw new Error(`Duplicate object key '${normKey}' after Unicode NFC normalization`);
        }
        seenNormalizedKeys.add(normKey);
        normalizedEntries.push({ normKey, originalKey: k });
      }
      normalizedEntries.sort((a, b) => (a.normKey < b.normKey ? -1 : a.normKey > b.normKey ? 1 : 0));
      const entries: string[] = [];
      for (const { normKey, originalKey: k } of normalizedEntries) {
        if (record[k] === undefined) {
          throw new Error(`Undefined property '${k}' cannot be canonically serialized`);
        }
        entries.push(`${JSON.stringify(normKey)}:${canonicalSerialize(record[k], seen)}`);
      }
      return `{${entries.join(',')}}`;
    } finally {
      seen.delete(val);
    }
  }
  throw new Error(`Unsupported type: ${typeof val}`);
}

/**
 * Computes canonical SHA-256 hash from question content.
 * Keys are sorted recursively, arrays keep order, and strings are normalized.
 * Status, timestamps, and self contentHash are explicitly excluded.
 */
export function computeQuestionContentHash(qv: {
  readonly questionId: string;
  readonly version: number;
  readonly body?: QuestionBody | unknown;
  readonly curriculumVersionId?: string;
  readonly skillIds?: readonly string[];
  readonly solutionVersionId?: string;
  readonly solution?: {
    readonly id?: string;
    readonly explanation?: string;
    readonly steps?: readonly string[];
    readonly keyPoints?: readonly string[];
  } | unknown;
}): string {
  if (!qv || typeof qv !== 'object') {
    throw new Error('computeQuestionContentHash requires a valid question object');
  }
  const payload: Record<string, unknown> = {
    questionId: qv.questionId,
    version: qv.version,
    curriculumVersionId: qv.curriculumVersionId || '',
    skillIds: [...(qv.skillIds || [])],
    solutionVersionId: qv.solutionVersionId || '',
  };
  if (qv.solution && typeof qv.solution === 'object') {
    const sol = qv.solution as Record<string, unknown>;
    const solPayload: Record<string, unknown> = {};
    if (sol.explanation !== undefined) solPayload.explanation = sol.explanation;
    if (sol.steps !== undefined) solPayload.steps = sol.steps;
    if (sol.keyPoints !== undefined) solPayload.keyPoints = sol.keyPoints;
    payload.solution = solPayload;
  }
  if (qv.body) {
    payload.body = qv.body;
  }
  const serialized = canonicalSerialize(payload);
  return 'sha256:' + createHash('sha256').update(serialized).digest('hex');
}

export function validatePublication(
  questionVersion: unknown,
  context: unknown,
): PublicationValidationResult {
  const qv = questionVersion as Partial<QuestionVersion>;
  const ctx = context as Partial<PublicationContext>;
  const errors: string[] = [];

  if (!qv) {
    return Object.freeze({ eligible: false, errors: Object.freeze(['Missing question version']) });
  }

  // 1. Status must be approved
  if (qv.status !== 'approved') {
    errors.push(`Question status must be 'approved' to publish; found '${qv.status}'`);
  }

  // 2. Question body & content hash validation
  let computedHash: string | undefined;
  if (!qv.body) {
    errors.push('Question version body is required to validate publication content');
  } else {
    const bodyValidation = validateQuestionBody(qv.body);
    if (!bodyValidation.valid) {
      errors.push(...bodyValidation.errors);
    }
  }

  // Resolve matching SolutionVersion strictly from context.solutions
  // Caller-supplied qv.solution is NEVER trusted or preferred
  const matchingSol = ctx.solutions?.find(
    (s) =>
      s.id === qv.solutionVersionId &&
      s.questionId === qv.questionId &&
      s.questionVersion === qv.version,
  );

  if (!matchingSol) {
    errors.push(`Matching SolutionVersion '${qv.solutionVersionId}' is required in context to validate publication content`);
  } else if (typeof matchingSol.explanation !== 'string' || !matchingSol.explanation.trim()) {
    errors.push(`Matching SolutionVersion '${matchingSol.id}' must provide a non-empty explanation`);
  }

  const solForHash = matchingSol && typeof matchingSol.explanation === 'string' && matchingSol.explanation.trim()
    ? {
        id: matchingSol.id,
        explanation: matchingSol.explanation,
        ...(matchingSol.steps ? { steps: matchingSol.steps } : {}),
        ...(matchingSol.keyPoints ? { keyPoints: matchingSol.keyPoints } : {}),
      }
    : undefined;

  if (qv.body && solForHash && qv.questionId && qv.version) {
    computedHash = computeQuestionContentHash({
      questionId: qv.questionId,
      version: qv.version,
      body: qv.body,
      curriculumVersionId: qv.curriculumVersionId,
      skillIds: qv.skillIds,
      solutionVersionId: qv.solutionVersionId,
      solution: solForHash,
    });

    if (typeof qv.contentHash !== 'string' || !qv.contentHash.trim()) {
      errors.push('Question version must have a non-empty declared contentHash to publish');
    } else if (!/^sha256:[0-9a-f]{64}$/.test(qv.contentHash.trim())) {
      errors.push(`Declared contentHash '${qv.contentHash}' is malformed; must be a valid sha256: hex string`);
    } else if (qv.contentHash !== computedHash) {
      errors.push(`Declared contentHash '${qv.contentHash}' does not match computed content hash '${computedHash}'`);
    }
  } else if (typeof qv.contentHash !== 'string' || !qv.contentHash.trim()) {
    errors.push('Question version must have a non-empty declared contentHash to publish');
  } else if (!/^sha256:[0-9a-f]{64}$/.test(qv.contentHash.trim())) {
    errors.push(`Declared contentHash '${qv.contentHash}' is malformed; must be a valid sha256: hex string`);
  }

  // 3. Curriculum check
  if (!qv.curriculumVersionId || !ctx.curriculumVersionIds?.includes(qv.curriculumVersionId)) {
    errors.push(`Curriculum version '${qv.curriculumVersionId}' is not recognized in context`);
  }

  // 4. Skill check
  if (!Array.isArray(qv.skillIds) || qv.skillIds.length === 0) {
    errors.push('Question version must reference at least one skill');
  } else if (!ctx.skillIds || ctx.skillIds.length === 0) {
    errors.push('Context has no available skills');
  } else {
    for (const sid of qv.skillIds) {
      if (!ctx.skillIds.includes(sid)) {
        errors.push(`Skill '${sid}' is not recognized in context`);
      }
    }
  }

  // 5. Source assets check: non-empty, exists in context, allowed provenance kind, non-empty reference
  if (!Array.isArray(qv.sourceAssetIds) || qv.sourceAssetIds.length === 0) {
    errors.push('Question version must reference at least one source asset');
  } else {
    for (const said of qv.sourceAssetIds) {
      const found = ctx.sourceAssets?.find((sa) => sa.id === said);
      if (!found) {
        errors.push(`Source asset '${said}' is missing in context`);
      } else {
        if (!found.reference?.trim()) {
          errors.push(`Source asset '${said}' has missing or empty reference`);
        }
        if (!found.provenanceKind || !ALLOWED_PROVENANCE_KINDS.has(found.provenanceKind)) {
          errors.push(`Source asset '${said}' has missing or invalid provenanceKind '${found.provenanceKind}'`);
        }
      }
    }
  }

  // 6. Licenses check: non-empty, allowed status whitelist, valid at now
  if (!Array.isArray(qv.licenseRecordIds) || qv.licenseRecordIds.length === 0) {
    errors.push('Question version must reference at least one license record');
  } else {
    const now = ctx.now || new Date().toISOString();
    for (const licId of qv.licenseRecordIds) {
      const lic = ctx.licenses?.find((l) => l.id === licId);
      if (!lic) {
        errors.push(`License record '${licId}' is missing in context`);
      } else {
        if (!ALLOWED_LICENSE_STATUSES.has(lic.status)) {
          errors.push(`License record '${licId}' has disallowed or invalid status '${lic.status}'`);
        }
        const isValid = isLicenseValidAt(lic as LicenseRecord, now, 'publish');
        if (!isValid) {
          errors.push(`License record '${licId}' is not valid for 'publish' operation or has expired at '${now}'`);
        }
        if (lic.commercialUseAllowed !== true) {
          errors.push(`License record '${licId}' lacks explicit commercialUseAllowed: true permission; ineligible for publication`);
        }
        if (lic.attributionRequired === true) {
          for (const said of (qv.sourceAssetIds || [])) {
            const foundSa = ctx.sourceAssets?.find((sa) => sa.id === said);
            if (!foundSa || !foundSa.issuer?.trim() || !foundSa.reference?.trim()) {
              errors.push(`License '${licId}' requires attribution, but source asset '${said}' lacks required issuer or reference evidence`);
            }
          }
        }
      }
    }
  }

  // 7. Solution check
  if (!qv.solutionVersionId) {
    errors.push('Question version must reference a solutionVersionId');
  } else {
    const matchingSolution = ctx.solutions?.find(
      (s) =>
        s.id === qv.solutionVersionId &&
        s.questionId === qv.questionId &&
        s.questionVersion === qv.version,
    );
    if (!matchingSolution) {
      errors.push(`No matching solution found for '${qv.solutionVersionId}'`);
    } else {
      if (matchingSolution.explanation !== undefined && (typeof matchingSolution.explanation !== 'string' || !matchingSolution.explanation.trim())) {
        errors.push(`Solution '${matchingSolution.id}' explanation must be a non-empty string`);
      }
    }
  }

  // 8. Human review & reviewer authorization check
  const expectedHash = computedHash || qv.contentHash;
  const approvedReview = ctx.reviews?.find(
    (r) =>
      r.questionId === qv.questionId &&
      r.questionVersion === qv.version &&
      r.decision === 'approved' &&
      r.reviewedContentHash === expectedHash &&
      Boolean(r.reviewerId?.trim()),
  );

  if (!approvedReview) {
    errors.push(
      `No valid approved human review found matching contentHash '${expectedHash}' for version ${qv.version}`,
    );
  } else {
    const reviewerId = approvedReview.reviewerId.trim();
    // Do not trust review-attached self-asserted evidence.
    // Validate reviewer authorization exclusively via context.reviewerRegistry.
    const authResult = validateReviewerAuthorization(reviewerId, {
      subjectId: ctx.subjectId || 'math',
      curriculumVersionId: qv.curriculumVersionId,
      now: ctx.now,
      reviewerRegistry: ctx.reviewerRegistry,
    });
    if (!authResult.authorized) {
      errors.push(...authResult.errors);
    }
  }

  // 9. Duplicate publication check
  const duplicatePub = ctx.publicationRecords?.some(
    (pr) =>
      (pr.questionId === qv.questionId && pr.questionVersion === qv.version) ||
      (qv.contentHash && pr.contentHash === qv.contentHash),
  );
  if (duplicatePub) {
    errors.push(`Question version ${qv.questionId}@${qv.version} is already recorded as published`);
  }

  // 10. Existing content hash check
  if (qv.contentHash && ctx.existingContentHashes?.includes(qv.contentHash)) {
    errors.push(`Content hash '${qv.contentHash}' has already been published in another record`);
  }

  return Object.freeze({
    eligible: errors.length === 0,
    errors: Object.freeze(errors),
  });
}
