import assert from 'node:assert/strict';
import test from 'node:test';
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import App from '../App';
import { findTestFiles } from '../../scripts/test-discovery.mjs';
import {
  appendAttempt,
  classifyError,
  createAttemptEvent,
  deriveVerificationProgress,
  evaluateAnswer,
  isValidAnswerOption,
  isRecheckDue,
  recommendNextStep,
  scheduleDelayedRecheck,
  validateSkillMapping,
  validateQuestionItem,
  type AttemptInput,
  type AttemptEvent,
  type QuestionItem,
  type Skill,
  type Subject,
  type Topic,
  type Unit,
} from './contracts';

const question: QuestionItem = {
  id: 'q-sample-01',
  version: 1,
  subjectId: 'math',
  curriculumVersionId: 'sample-curriculum-v1',
  skillIds: ['derivative-sign'],
  questionType: 'multiple_choice',
  difficulty: 'introductory',
  options: [
    { id: 'A', text: 'Option A' },
    { id: 'B', text: 'Option B' },
  ],
  prompt: 'SAMPLE / TEST ONLY: Which interval has a positive derivative?',
  correctAnswer: 'B',
  explanation: 'SAMPLE / TEST ONLY: Read the sign of the derivative.',
  source: { kind: 'synthetic', reference: 'fixture:contracts-test' },
  reviewStatus: 'sample_test_only',
};

const taxonomy = {
  subject: { id: 'math', curriculumVersionId: 'sample-curriculum-v1', name: 'Toán học' } satisfies Subject,
  unit: { id: 'functions', subjectId: 'math', curriculumVersionId: 'sample-curriculum-v1', name: 'Hàm số' } satisfies Unit,
  topic: { id: 'derivatives', subjectId: 'math', unitId: 'functions', curriculumVersionId: 'sample-curriculum-v1', name: 'Đạo hàm' } satisfies Topic,
  skill: { id: 'derivative-sign', subjectId: 'math', unitId: 'functions', topicId: 'derivatives', curriculumVersionId: 'sample-curriculum-v1', name: 'Đọc dấu đạo hàm' } satisfies Skill,
};

function attempt(id: string, sessionId: string, overrides: Partial<AttemptInput> = {}): AttemptEvent {
  return createAttemptEvent({
    id,
    questionId: question.id,
    questionVersion: question.version,
    skillIds: question.skillIds,
    sessionId,
    submittedAnswer: 'B',
    isCorrect: true,
    timestamp: `2026-11-07T10:00:${id.slice(-2)}Z`,
    durationMs: 15000,
    hintsUsed: 0,
    isDelayedRecheck: false,
    ...overrides,
  });
}

test('accepts a versioned question only with skill mapping and explicit synthetic provenance', () => {
  assert.equal(validateQuestionItem(question).valid, true);
  assert.deepEqual(validateQuestionItem({ ...question, skillIds: [] }).errors, ['skillIds must include at least one skill']);
  assert.equal(validateQuestionItem({ ...question, source: undefined }).valid, false);
  assert.equal(validateQuestionItem({ ...question, reviewStatus: 'official' }).valid, false);
});

test('validates the versioned Subject to Unit to Topic to Skill parent chain', () => {
  assert.equal(validateSkillMapping(taxonomy).valid, true);
  assert.deepEqual(
    validateSkillMapping({ ...taxonomy, skill: { ...taxonomy.skill, curriculumVersionId: 'other-curriculum-v1' } }).errors,
    ['all taxonomy nodes must use the same curriculum version'],
  );
  assert.equal(validateSkillMapping({ ...taxonomy, topic: { ...taxonomy.topic, unitId: 'other-unit' } }).valid, false);
});

test('discovers nested TypeScript feature tests and ignores non-test files', async () => {
  const root = await mkdtemp(join(tmpdir(), 'nexus-test-discovery-'));
  try {
    await mkdir(join(root, 'features', 'learning-slice'), { recursive: true });
    await writeFile(join(root, 'contracts.test.ts'), '');
    await writeFile(join(root, 'features', 'learning-slice', 'learning-slice.test.tsx'), '');
    await writeFile(join(root, 'features', 'learning-slice', 'fixture.ts'), '');
    assert.deepEqual(await findTestFiles(root), [
      join(root, 'contracts.test.ts'),
      join(root, 'features', 'learning-slice', 'learning-slice.test.tsx'),
    ]);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('requires reviewer, rights, and answer-check evidence before content is verified or published', () => {
  const verifiedQuestion = { ...question, reviewStatus: 'verified' };
  assert.equal(validateQuestionItem(verifiedQuestion).valid, false);
  assert.equal(validateQuestionItem({
    ...verifiedQuestion,
    source: { kind: 'licensed', reference: 'source:test', issuer: 'Test publisher', sourceDate: '2026-01-01', licenseStatus: 'licensed' },
    verifiedBy: 'human-reviewer-01',
    answerValidationMethod: 'independent calculation',
  }).valid, true);
});

test('creates and appends attempts without modifying earlier attempt history', () => {
  const first = attempt('attempt-01', 'session-01');
  const history = [first];
  const next = attempt('attempt-02', 'session-02', { submittedAnswer: 'A', isCorrect: false });
  const updated = appendAttempt(history, next);

  assert.equal(history.length, 1);
  assert.equal(updated.length, 2);
  assert.equal(updated[0], first);
  assert.equal(Object.isFrozen(first), true);
  assert.equal(Object.isFrozen(updated), true);
});

test('reports insufficient evidence for no attempts and one correct answer', () => {
  assert.equal(deriveVerificationProgress([]).status, 'not_enough_data');
  assert.equal(deriveVerificationProgress([attempt('attempt-01', 'session-01')]).status, 'learning');
});

test('completes the sample verification cycle only with independent evidence across sessions and a delayed recheck', () => {
  const evidence = [
    attempt('attempt-01', 'session-01'),
    attempt('attempt-02', 'session-02'),
    attempt('attempt-03', 'session-02', { isDelayedRecheck: true }),
  ];
  assert.equal(deriveVerificationProgress(evidence).status, 'verification_complete');
  assert.equal(deriveVerificationProgress(evidence).evidenceCount, 3);
});

test('uses supplied verification policy thresholds instead of embedding them in the status calculation', () => {
  const evidence = [
    attempt('attempt-01', 'session-01'),
    attempt('attempt-02', 'session-02', { isDelayedRecheck: true }),
  ];
  assert.equal(deriveVerificationProgress(evidence, { minIndependentCorrect: 2, minSessions: 2, requireDelayedRecheck: true }).status, 'verification_complete');
});

test('recommendation includes a plain reason tied to the available evidence', () => {
  const attempts = [attempt('attempt-01', 'session-01', { isCorrect: false, errorTag: 'misread_condition' })];
  const result = recommendNextStep(attempts, deriveVerificationProgress(attempts));
  assert.equal(result.kind, 'guided_practice');
  assert.match(result.reason, /condition/i);
});

test('shell provides accessible placeholder navigation without presenting fake study data', () => {
  const html = renderToStaticMarkup(createElement(App));

  assert.match(html, /aria-label="Điều hướng chính"/);
  assert.match(html, /href="#study"/);
  assert.match(html, /href="#progress"/);
  assert.match(html, /href="#settings"/);
  assert.match(html, /aria-current="page"/);
  assert.match(html, /Chức năng đang được phát triển/);
  assert.doesNotMatch(html, /learning-slice-container|SAMPLE \/ TEST ONLY/);
  assert.doesNotMatch(html, /85%|12 câu đúng|Đã vững/);
});

test('evaluates answer correctness deterministically', () => {
  assert.equal(evaluateAnswer(question, 'B'), true);
  assert.equal(evaluateAnswer(question, 'b'), true);
  assert.equal(evaluateAnswer(question, 'A'), false);
  assert.equal(evaluateAnswer(question, null), false);
  assert.equal(isValidAnswerOption(question, 'A'), true);
  assert.equal(isValidAnswerOption(question, 'Z'), false);
  assert.throws(() => evaluateAnswer(question, 'Z'), /valid option/i);
});

test('classifies error into errorTag, likely missing step, and flags uncertainty', () => {
  const qWithOptions: QuestionItem = {
    ...question,
    options: [
      { id: 'A', text: 'Option A', distractorErrorTag: 'concept_gap', likelyMissingStep: 'Missing concept step' },
      { id: 'B', text: 'Option B' },
    ],
  };

  const classified = classifyError(qWithOptions, 'A');
  assert.equal(classified.errorTag, 'concept_gap');
  assert.equal(classified.likelyMissingStep, 'Missing concept step');
  assert.equal(classified.isUncertain, true);

  const fallback = classifyError(qWithOptions, 'unknown');
  assert.equal(fallback.errorTag, 'concept_gap');
  assert.equal(fallback.isUncertain, true);
});

test('schedules delayed recheck with due time calculation and evaluates due status', () => {
  const baseTime = '2026-11-08T10:00:00.000Z';
  const schedule = scheduleDelayedRecheck(baseTime, 60);

  assert.equal(schedule.scheduledAt, baseTime);
  assert.equal(schedule.delayMinutes, 60);
  assert.equal(schedule.dueAt, '2026-11-08T11:00:00.000Z');

  const beforeDue = Date.parse('2026-11-08T10:59:59.000Z');
  const atDue = Date.parse('2026-11-08T11:00:00.000Z');
  const afterDue = Date.parse('2026-11-08T11:05:00.000Z');

  assert.equal(isRecheckDue(schedule.dueAt, beforeDue), false);
  assert.equal(isRecheckDue(schedule.dueAt, atDue), true);
  assert.equal(isRecheckDue(schedule.dueAt, afterDue), true);
});
