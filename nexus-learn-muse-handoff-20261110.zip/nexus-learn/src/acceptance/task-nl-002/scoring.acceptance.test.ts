import assert from 'node:assert/strict';
import test from 'node:test';
import * as api from '../../domain/math/index';
const acceptanceEnabled = process.env.NEXUS_NL002_ACCEPTANCE === '1';
const acceptanceTest = acceptanceEnabled ? test : test.skip;

const scorePolicy = {
  id: 'sample-practice-v1',
  version: 1,
  status: 'proposed',
  mcqSingle: { pointsCorrect: 1, pointsIncorrect: 0, pointsEmpty: 0 },
  trueFalseCluster: { pointsPerCorrectStatement: 1, pointsIncorrect: 0, pointsEmpty: 0 },
  shortNumeric: {
    pointsCorrect: 1,
    pointsIncorrect: 0,
    pointsEmpty: 0,
    absoluteTolerance: '0.01',
    relativeTolerance: '0',
    decimalSeparators: [',', '.'],
    groupingSeparators: [],
    allowExponent: false,
  },
} as const;

const mcq = {
  questionId: 'q-mcq',
  version: 1,
  contentHash: 'sha256:mcq-v1',
  body: {
    kind: 'MCQ_SINGLE',
    prompt: 'SAMPLE / TEST ONLY',
    options: [{ id: 'A', text: 'a' }, { id: 'B', text: 'b' }, { id: 'C', text: 'c' }, { id: 'D', text: 'd' }],
    correctOptionId: 'B',
  },
} as const;

const cluster = {
  questionId: 'q-tf',
  version: 1,
  contentHash: 'sha256:tf-v1',
  body: {
    kind: 'TRUE_FALSE_CLUSTER',
    statements: [
      { id: 's1', prompt: 'one', correctValue: true, skillIds: ['skill-a'] },
      { id: 's2', prompt: 'two', correctValue: false, skillIds: ['skill-b', 'skill-c'] },
      { id: 's3', prompt: 'three', correctValue: true, skillIds: ['skill-a'] },
      { id: 's4', prompt: 'four', correctValue: false, skillIds: ['skill-c'] },
    ],
  },
} as const;

const numeric = {
  questionId: 'q-num',
  version: 1,
  contentHash: 'sha256:num-v1',
  body: { kind: 'SHORT_NUMERIC', prompt: 'SAMPLE / TEST ONLY', correctDecimal: '-1.25' },
} as const;

acceptanceTest('scores an MCQ correct, incorrect, empty and rejects an unknown option', () => {
  assert.deepEqual(api.scoreQuestionVersion(mcq, { kind: 'MCQ_SINGLE', optionId: 'B' }, scorePolicy), {
    status: 'scored', totalPoints: 1, maxPoints: 1,
    parts: [{ partId: 'question', status: 'correct', points: 1, maxPoints: 1 }],
  });
  assert.equal(api.scoreQuestionVersion(mcq, { kind: 'MCQ_SINGLE', optionId: 'A' }, scorePolicy).totalPoints, 0);
  assert.equal(api.scoreQuestionVersion(mcq, { kind: 'MCQ_SINGLE', optionId: null }, scorePolicy).status, 'empty');
  assert.equal(api.scoreQuestionVersion(mcq, { kind: 'MCQ_SINGLE', optionId: 'Z' }, scorePolicy).status, 'invalid');
});

acceptanceTest('scores T/F partial credit independently and retains each statement skill mapping', () => {
  const result = api.scoreQuestionVersion(cluster, {
    kind: 'TRUE_FALSE_CLUSTER',
    answers: { s1: true, s2: false, s3: false, s4: null },
  }, scorePolicy);
  assert.equal(result.status, 'scored');
  assert.equal(result.totalPoints, 2);
  assert.equal(result.maxPoints, 4);
  assert.deepEqual(result.parts.map((part) => [part.partId, part.status, part.skillIds]), [
    ['s1', 'correct', ['skill-a']],
    ['s2', 'correct', ['skill-b', 'skill-c']],
    ['s3', 'incorrect', ['skill-a']],
    ['s4', 'empty', ['skill-c']],
  ]);
});

acceptanceTest('scores a fully correct T/F cluster at the configured maximum', () => {
  const result = api.scoreQuestionVersion(cluster, {
    kind: 'TRUE_FALSE_CLUSTER',
    answers: { s1: true, s2: false, s3: true, s4: false },
  }, scorePolicy);
  assert.equal(result.totalPoints, 4);
  assert.equal(result.maxPoints, 4);
  assert.equal(result.parts.every((part) => part.status === 'correct'), true);
});

acceptanceTest('normalizes signed decimal comma and period to the same exact numeric value', () => {
  const comma = api.scoreQuestionVersion(numeric, { kind: 'SHORT_NUMERIC', value: '-1,25' }, scorePolicy);
  const period = api.scoreQuestionVersion(numeric, { kind: 'SHORT_NUMERIC', value: '-1.25' }, scorePolicy);
  assert.equal(comma.totalPoints, 1);
  assert.equal(period.totalPoints, 1);
});

acceptanceTest('rejects ambiguous, grouped, malformed and non-finite numeric input', () => {
  for (const value of ['-1,2.5', '1,234,567', '1 234', 'NaN', 'Infinity', '1e3']) {
    assert.equal(api.scoreQuestionVersion(numeric, { kind: 'SHORT_NUMERIC', value }, scorePolicy).status, 'invalid', value);
  }
});

acceptanceTest('uses a decimal-safe inclusive tolerance boundary without false positives', () => {
  const at = (value: string) => api.scoreQuestionVersion(numeric, { kind: 'SHORT_NUMERIC', value }, scorePolicy).totalPoints;
  assert.equal(at('-1.24'), 1, 'exactly at 0.01 tolerance');
  assert.equal(at('-1.239'), 0, 'outside 0.01 tolerance');
  assert.equal(at('-1.241'), 1, 'inside 0.01 tolerance');
});

acceptanceTest('scores successor question versions without changing an old pinned result', () => {
  const first = api.scoreQuestionVersion(mcq, { kind: 'MCQ_SINGLE', optionId: 'B' }, scorePolicy);
  const successor = {
    ...mcq,
    version: 2,
    contentHash: 'sha256:mcq-v2',
    body: { ...mcq.body, correctOptionId: 'C' },
  } as const;
  const next = api.scoreQuestionVersion(successor, { kind: 'MCQ_SINGLE', optionId: 'B' }, scorePolicy);
  assert.equal(first.totalPoints, 1);
  assert.equal(next.totalPoints, 0);
  assert.equal(mcq.version, 1);
  assert.equal(mcq.contentHash, 'sha256:mcq-v1');
});

acceptanceTest('replays an attempt only with its pinned scoring policy version', () => {
  const revisedPolicy = {
    ...scorePolicy,
    version: 2,
    mcqSingle: { ...scorePolicy.mcqSingle, pointsCorrect: 2 },
  } as const;
  const original = api.scoreQuestionVersion(mcq, { kind: 'MCQ_SINGLE', optionId: 'B' }, scorePolicy);
  const replay = api.scoreQuestionVersion(mcq, { kind: 'MCQ_SINGLE', optionId: 'B' }, scorePolicy);
  const newPolicyResult = api.scoreQuestionVersion(mcq, { kind: 'MCQ_SINGLE', optionId: 'B' }, revisedPolicy);
  assert.equal(original.totalPoints, replay.totalPoints);
  assert.equal(original.totalPoints, 1);
  assert.equal(newPolicyResult.totalPoints, 2);
});

acceptanceTest('keeps the original question and policy references in append-only attempt history', () => {
  const firstResult = api.scoreQuestionVersion(mcq, { kind: 'MCQ_SINGLE', optionId: 'B' }, scorePolicy);
  const firstEvent = api.createAttemptEvent({
    id: 'attempt-1',
    sessionId: 'session-1',
    questionVersionRef: { questionId: 'q-mcq', version: 1, contentHash: 'sha256:mcq-v1' },
    scoringPolicyVersionRef: { id: 'sample-practice-v1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'B' },
    result: firstResult,
    timestamp: '2026-11-08T00:00:00.000Z',
    partEvidence: firstResult.parts,
  });
  const secondEvent = api.createAttemptEvent({
    ...firstEvent,
    id: 'attempt-2',
    questionVersionRef: { questionId: 'q-mcq', version: 2, contentHash: 'sha256:mcq-v2' },
    scoringPolicyVersionRef: { id: 'sample-practice-v1', version: 2 },
  });
  const history = [firstEvent];
  const appended = api.appendAttemptEvent(history, secondEvent);
  assert.equal(history.length, 1);
  assert.deepEqual(appended[0], firstEvent);
  assert.deepEqual(firstEvent.questionVersionRef, { questionId: 'q-mcq', version: 1, contentHash: 'sha256:mcq-v1' });
  assert.deepEqual(firstEvent.scoringPolicyVersionRef, { id: 'sample-practice-v1', version: 1 });
  assert.equal(Object.isFrozen(firstEvent.questionVersionRef), true);
  assert.throws(() => api.appendAttemptEvent(appended, firstEvent), /duplicate/i);
});

acceptanceTest('blocks publication without exact-hash human review and eligible license evidence', () => {
  const draft = {
    questionId: 'q-publish', version: 1, status: 'in_review', contentHash: 'sha256:publish-v1',
    curriculumVersionId: 'curriculum-v1', skillIds: ['skill-a'],
    sourceAssetIds: ['source-a'], licenseRecordIds: ['license-a'],
    solutionVersionId: 'solution-v1',
  };
  const context = {
    now: '2026-11-08T00:00:00.000Z',
    curriculumVersionIds: ['curriculum-v1'], skillIds: ['skill-a'],
    sourceAssets: [{ id: 'source-a', provenanceKind: 'original', reference: 'created-for-nexus' }],
    licenses: [{ id: 'license-a', status: 'original', validThrough: null }],
    solutions: [{ id: 'solution-v1', questionId: 'q-publish', questionVersion: 1 }],
    reviews: [], publicationRecords: [],
  };
  assert.equal(api.validatePublication(draft, context).eligible, false);
  const reviewed = {
    ...context,
    reviews: [{ id: 'review-1', questionId: 'q-publish', questionVersion: 1,
      reviewedContentHash: 'sha256:stale', decision: 'approved', reviewerId: 'qualified-reviewer' }],
  };
  assert.equal(api.validatePublication(draft, reviewed).eligible, false);
  const notApproved = {
    ...context,
    reviews: [{ id: 'review-1', questionId: 'q-publish', questionVersion: 1,
      reviewedContentHash: 'sha256:publish-v1', decision: 'in_review', reviewerId: 'qualified-reviewer' }],
  };
  assert.equal(api.validatePublication(draft, notApproved).eligible, false);
});

acceptanceTest('rejects expired, missing and duplicate publication evidence', () => {
  const version = {
    questionId: 'q-publish', version: 1, status: 'approved', contentHash: 'sha256:publish-v1',
    curriculumVersionId: 'curriculum-v1', skillIds: ['skill-a'], sourceAssetIds: ['source-a'],
    licenseRecordIds: ['license-a'], solutionVersionId: 'solution-v1',
  };
  const validContext = {
    now: '2026-11-08T00:00:00.000Z', curriculumVersionIds: ['curriculum-v1'], skillIds: ['skill-a'],
    sourceAssets: [{ id: 'source-a', provenanceKind: 'original', reference: 'created-for-nexus' }],
    licenses: [{ id: 'license-a', status: 'original', validThrough: null }],
    solutions: [{ id: 'solution-v1', questionId: 'q-publish', questionVersion: 1 }],
    reviews: [{ id: 'review-1', questionId: 'q-publish', questionVersion: 1,
      reviewedContentHash: 'sha256:publish-v1', decision: 'approved', reviewerId: 'fixture-reviewer-math' }],
    reviewerRegistry: [{
      reviewerId: 'fixture-reviewer-math',
      authorizedSubjectIds: ['math'],
      authorizedCurriculumVersionIds: ['curriculum-v1'],
      validFrom: '2026-01-01T00:00:00.000Z',
      validThrough: '2027-01-01T00:00:00.000Z',
      status: 'active',
    }],
    publicationRecords: [],
  };
  assert.equal(api.validatePublication(version, {
    ...validContext,
    licenses: [{ id: 'license-a', status: 'licensed', validThrough: '2026-11-07T23:59:59.999Z' }],
  }).eligible, false);
  assert.equal(api.validatePublication(version, { ...validContext, licenses: [] }).eligible, false);
  assert.equal(api.validatePublication(version, {
    ...validContext,
    publicationRecords: [{ questionId: 'q-publish', questionVersion: 1, contentHash: 'sha256:publish-v1' }],
  }).eligible, false);
  assert.equal(api.validatePublication(version, {
    ...validContext,
    skillIds: [],
  }).eligible, false);
  assert.equal(api.validatePublication(version, {
    ...validContext,
    existingContentHashes: ['sha256:publish-v1'],
  }).eligible, false);
  assert.equal(api.validatePublication({ ...version, status: 'in_review' }, validContext).eligible, false);

  const review = validContext.reviews[0];
  const validEvidence = validContext.reviewerRegistry[0];
  const authorizationContext = {
    subjectId: 'math',
    curriculumVersionId: 'curriculum-v1',
    now: validContext.now,
    reviewerRegistry: validContext.reviewerRegistry,
  };
  assert.equal(api.validatePublication(version, {
    ...validContext,
    reviewerRegistry: [],
    reviews: [{ ...review, reviewerId: 'qualified-reviewer' }],
  }).eligible, false, 'a bare qualified-reviewer ID is not authorization evidence');
  assert.equal(api.validatePublication(version, {
    ...validContext,
    reviewerRegistry: [],
    reviews: [{ ...review, authorizationEvidence: validEvidence }],
  }).eligible, false, 'review-attached self-asserted evidence is not trusted');
  assert.equal(api.validateReviewerAuthorization('fixture-reviewer-math', authorizationContext).authorized, true,
    'explicit injected test registry evidence authorizes only the matching scope');
  assert.equal(api.validateReviewerAuthorization('qualified-reviewer', {
    ...authorizationContext, reviewerRegistry: [],
  }).authorized, false, 'a bare reviewer ID without authority record is rejected');
  assert.equal(api.validateReviewerAuthorization('fixture-reviewer-math', {
    ...authorizationContext,
    reviewerRegistry: [{ ...validEvidence, authorizedSubjectIds: ['physics'] }],
  }).authorized, false, 'authorization must cover the question subject');
  assert.equal(api.validateReviewerAuthorization('fixture-reviewer-math', {
    ...authorizationContext,
    reviewerRegistry: [{ ...validEvidence, authorizedCurriculumVersionIds: ['other-curriculum'] }],
  }).authorized, false, 'authorization must cover the curriculum version');
  assert.equal(api.validateReviewerAuthorization('fixture-reviewer-math', {
    ...authorizationContext,
    reviewerRegistry: [{ ...validEvidence, validFrom: 'not-a-date' }],
  }).authorized, false, 'malformed authority dates fail closed');
  assert.equal(api.validateReviewerAuthorization('fixture-reviewer-math', {
    ...authorizationContext,
    reviewerRegistry: [{ ...validEvidence, validThrough: '2026-11-07T23:59:59.999Z' }],
  }).authorized, false, 'expired authority is rejected');
});
