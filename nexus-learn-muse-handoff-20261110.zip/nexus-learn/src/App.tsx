import { useEffect, useState, useMemo } from 'react';
import MathLearningView from './features/learning-core/MathLearningView';
import DashboardView from './features/dashboard/DashboardView';
import ProgressView from './features/progress/ProgressView';
import { createPersistenceRepository, type PersistenceRepository } from './infrastructure/persistence/indexeddb/indexeddbRepository';

const sections = [
  { id: 'dashboard', label: 'Tổng quan' },
  { id: 'study', label: 'Học tập' },
  { id: 'progress', label: 'Tiến độ' },
  { id: 'settings', label: 'Cài đặt' },
] as const;

type SectionId = (typeof sections)[number]['id'];

function sectionFromHash(): SectionId {
  if (typeof window === 'undefined') return 'dashboard';
  const hash = window.location.hash.slice(1);
  return sections.some((section) => section.id === hash) ? hash as SectionId : 'dashboard';
}

function Placeholder({ title, description }: { title: string; description: string }) {
  return (
    <div className="empty-state" role="status" aria-label={title}>
      <span className="empty-icon" aria-hidden="true">…</span>
      <div>
        <h3>Chức năng đang được phát triển</h3>
        <p>{description}</p>
      </div>
    </div>
  );
}

export default function App({ repository: injectedRepo }: { readonly repository?: PersistenceRepository } = {}) {
  const [activeSection, setActiveSection] = useState(sectionFromHash);
  const repo = useMemo(() => injectedRepo || createPersistenceRepository(), [injectedRepo]);

  useEffect(() => {
    const syncSection = () => setActiveSection(sectionFromHash());
    window.addEventListener('hashchange', syncSection);
    return () => window.removeEventListener('hashchange', syncSection);
  }, []);

  return (
    <div className="app-shell">
      <a className="skip-link" href="#main">Bỏ qua điều hướng</a>
      <header className="site-header">
        <a className="brand" href="#dashboard" aria-label="NEXUS LEARN — Tổng quan">
          <span className="brand-mark" aria-hidden="true">N</span>
          <span>NEXUS <strong>LEARN</strong></span>
        </a>
        <nav aria-label="Điều hướng chính">
          {sections.map((section) => {
            const active = section.id === activeSection;
            return (
              <a
                key={section.id}
                href={`#${section.id}`}
                className={active ? 'nav-active' : undefined}
                aria-current={active ? 'page' : undefined}
                onClick={() => setActiveSection(section.id)}
              >
                {section.label}
              </a>
            );
          })}
        </nav>
      </header>

      <main id="main">
        {activeSection === 'dashboard' && (
          <section id="dashboard" className="content-section" aria-labelledby="dashboard-title">
            <div className="section-heading">
              <div><p className="eyebrow">TỔNG QUAN</p><h1 id="dashboard-title">Tổng quan</h1></div>
            </div>
            <DashboardView repository={repo} onNavigateToStudy={() => setActiveSection('study')} />
          </section>
        )}

        {activeSection === 'study' && (
          <section id="study" className="content-section" aria-labelledby="study-title">
            <div className="section-heading">
              <div><p className="eyebrow">HỌC TẬP</p><h1 id="study-title">Học tập</h1></div>
            </div>
            <MathLearningView repository={repo} />
          </section>
        )}

        {activeSection === 'progress' && (
          <section id="progress" className="content-section progress-section" aria-labelledby="progress-title">
            <div className="section-heading">
              <div><p className="eyebrow">TIẾN ĐỘ</p><h1 id="progress-title">Tiến độ</h1></div>
            </div>
            <ProgressView repository={repo} />
          </section>
        )}

        {activeSection === 'settings' && (
          <section id="settings" className="content-section settings-section" aria-labelledby="settings-title">
            <div className="section-heading">
              <div><p className="eyebrow">CÀI ĐẶT</p><h1 id="settings-title">Cài đặt</h1></div>
            </div>
            <Placeholder
              title="Cài đặt"
              description="Chưa có hồ sơ, tùy chọn hoặc thiết lập nào được tạo. Khu vực này sẽ được triển khai sau."
            />
          </section>
        )}
      </main>

      <footer><span>NEXUS LEARN</span><span>Bản dựng cá nhân · Lưu trữ cục bộ thiết bị (IndexedDB khi khả dụng / Bộ nhớ phiên tạm thời) · Không lưu máy chủ/đám mây</span></footer>
    </div>
  );
}
