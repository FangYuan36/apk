import assert from 'node:assert/strict';
import test from 'node:test';
import { act, createElement } from 'react';
import { createRoot } from 'react-dom/client';
import { JSDOM } from 'jsdom';
import App from './App';

const pages = [
  { id: 'dashboard', label: 'Tổng quan', heading: 'Tổng quan' },
  { id: 'study', label: 'Học tập', heading: 'Học tập' },
  { id: 'progress', label: 'Tiến độ', heading: 'Tiến độ' },
  { id: 'settings', label: 'Cài đặt', heading: 'Cài đặt' },
] as const;

test('navigation opens the selected area, updates active state, and only study mounts LearningSlice', async () => {
  const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
    url: 'http://localhost/#dashboard',
    pretendToBeVisual: true,
  });
  const globals: Record<string, unknown> = {
    window: dom.window,
    document: dom.window.document,
    navigator: dom.window.navigator,
    HTMLElement: dom.window.HTMLElement,
    Node: dom.window.Node,
    Event: dom.window.Event,
    MouseEvent: dom.window.MouseEvent,
    IS_REACT_ACT_ENVIRONMENT: true,
  };
  const previousGlobals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries(globals)) {
    previousGlobals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  }

  const container = dom.window.document.querySelector<HTMLElement>('#root')!;
  const root = createRoot(container);
  try {
    await act(async () => root.render(createElement(App)));

    for (const page of pages) {
      const link = Array.from(container.querySelectorAll<HTMLAnchorElement>('nav a'))
        .find((item) => item.getAttribute('href') === `#${page.id}`);
      assert.ok(link, `Navigation link for ${page.label} should exist`);

      await act(async () => {
        link.click();
        await new Promise((resolve) => setTimeout(resolve, 0));
      });

      const renderedSections = container.querySelectorAll('main#main > section');
      assert.equal(renderedSections.length, 1, `${page.label} should render one area at a time`);
      assert.equal(renderedSections[0].id, page.id);
      assert.equal(renderedSections[0].querySelector('h1, h2')?.textContent, page.heading);
      assert.equal(link.getAttribute('aria-current'), 'page');
      assert.equal(link.classList.contains('nav-active'), true);
      assert.equal(container.querySelectorAll('nav a[aria-current="page"]').length, 1);

      if (page.id === 'study') {
        assert.equal(container.querySelectorAll('.learning-slice-container').length, 1);
        assert.match(container.textContent ?? '', /SAMPLE \/ TEST ONLY/);
        assert.doesNotMatch(container.textContent ?? '', /Chức năng đang được phát triển/);
      } else {
        assert.equal(container.querySelectorAll('.learning-slice-container').length, 0);
        assert.match(renderedSections[0].textContent ?? '', /Chức năng đang được phát triển/);
        assert.doesNotMatch(renderedSections[0].textContent ?? '', /SAMPLE \/ TEST ONLY/);
      }
    }
  } finally {
    await act(async () => root.unmount());
    dom.window.close();
    for (const [key, descriptor] of previousGlobals) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else Reflect.deleteProperty(globalThis, key);
    }
  }
});
