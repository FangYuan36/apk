import assert from 'node:assert/strict';
import test from 'node:test';
import { InMemoryPersistenceRepository } from './indexeddbRepository';
import type { PracticeSession, StoredReviewSchedule, ProgressProjection } from '../../../domain/persistence/types';
import type { AttemptEvent } from '../../../domain/math/attempt';

test('InMemoryPersistenceRepository stores and retrieves practice sessions', async () => {
  const repo = new InMemoryPersistenceRepository();
  const session: PracticeSession = {
    id: 'sess-001',
    skillId: 'math-derivative-sign',
    startedAt: '2026-11-08T10:00:00.000Z',
    attemptIds: ['att-1', 'att-2'],
  };

  await repo.saveSession(session);
  const retrieved = await repo.getSession('sess-001');
  assert.deepEqual(retrieved, session);

  const all = await repo.getAllSessions();
  assert.equal(all.length, 1);
  assert.deepEqual(all[0], session);
});

test('InMemoryPersistenceRepository saves attempts and rejects duplicates idempotently', async () => {
  const repo = new InMemoryPersistenceRepository();
  const event: AttemptEvent = {
    id: 'att-001',
    sessionId: 'sess-001',
    questionVersionRef: { questionId: 'q1', version: 1, contentHash: 'sha:1' },
    scoringPolicyVersionRef: { id: 'p1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'A' },
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [{ partId: 'question', status: 'correct', points: 1, maxPoints: 1 }],
    timestamp: '2026-11-08T10:05:00.000Z',
  };

  await repo.saveAttemptEvent(event);
  const events = await repo.getAttemptEvents('sess-001');
  assert.equal(events.length, 1);
  assert.deepEqual(events[0], event);

  // Rejection of duplicate ID
  await assert.rejects(
    async () => repo.saveAttemptEvent(event),
    /Duplicate attempt event ID/,
  );
});

test('InMemoryPersistenceRepository manages review schedules and progress projections', async () => {
  const repo = new InMemoryPersistenceRepository();
  const schedule: StoredReviewSchedule = {
    skillId: 'math-derivative-sign',
    recheckDueAt: '2026-11-09T10:00:00.000Z',
    createdAt: '2026-11-08T10:00:00.000Z',
    isCompleted: false,
  };
  const projection: ProgressProjection = {
    skillId: 'math-derivative-sign',
    totalAttempts: 5,
    correctAttempts: 4,
    lastAttemptAt: '2026-11-08T10:15:00.000Z',
    lastScore: 1,
  };

  await repo.saveReviewSchedule(schedule);
  await repo.saveProgressProjection(projection);

  assert.deepEqual(await repo.getReviewSchedule('math-derivative-sign'), schedule);
  assert.deepEqual(await repo.getProgressProjection('math-derivative-sign'), projection);

  // Clear data
  await repo.clearLocalData();
  assert.equal(await repo.getReviewSchedule('math-derivative-sign'), null);
  assert.equal(await repo.getProgressProjection('math-derivative-sign'), null);
  assert.equal((await repo.getAllSessions()).length, 0);
  assert.equal((await repo.getAttemptEvents()).length, 0);
});

test('InMemoryPersistenceRepository performs atomic saveSessionAndAttempt with duplicate rollback', async () => {
  const repo = new InMemoryPersistenceRepository();
  const session: PracticeSession = {
    id: 'sess-atomic',
    skillId: 'math-derivative-sign',
    startedAt: '2026-11-08T10:00:00.000Z',
    attemptIds: ['att-atomic-1'],
  };
  const event1: AttemptEvent = {
    id: 'att-atomic-1',
    sessionId: 'sess-atomic',
    questionVersionRef: { questionId: 'q1', version: 1, contentHash: 'sha:1' },
    scoringPolicyVersionRef: { id: 'p1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'A' },
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [{ partId: 'question', status: 'correct', points: 1, maxPoints: 1 }],
    timestamp: '2026-11-08T10:05:00.000Z',
  };

  await repo.saveSessionAndAttempt(session, event1);
  assert.equal((await repo.getAllSessions()).length, 1);
  assert.equal((await repo.getAttemptEvents()).length, 1);

  // Attempting duplicate event ID in atomic transaction must reject
  await assert.rejects(
    async () => repo.saveSessionAndAttempt({ ...session, id: 'sess-atomic-2' }, event1),
    /Duplicate attempt event ID/,
  );
  // Second session was not saved
  assert.equal(await repo.getSession('sess-atomic-2'), null);
});

test('InMemoryPersistenceRepository supports schema versioning and rejects invalid schema migrations', async () => {
  const repo = new InMemoryPersistenceRepository();
  assert.equal(await repo.getSchemaVersion(), 1);

  // Upgrade schema version
  await repo.migrateSchema(2);
  assert.equal(await repo.getSchemaVersion(), 2);

  // Reject downgrade
  await assert.rejects(
    async () => repo.migrateSchema(1),
    /Cannot migrate schema from version 2 to 1/,
  );
});

test('InMemoryPersistenceRepository rejects corrupt records before modifying state', async () => {
  const repo = new InMemoryPersistenceRepository();

  await assert.rejects(
    async () => repo.saveSession(null as any),
    /Corrupted or invalid session record/,
  );
  await assert.rejects(
    async () => repo.saveSession({ id: '', skillId: '', startedAt: '', attemptIds: [] }),
    /Corrupted or invalid session record/,
  );
  await assert.rejects(
    async () => repo.saveAttemptEvent({} as any),
    /Corrupted or invalid attempt event record/,
  );
  await assert.rejects(
    async () => repo.saveReviewSchedule({} as any),
    /Corrupted or invalid review schedule record/,
  );

  // Ensure state remains empty
  assert.equal((await repo.getAllSessions()).length, 0);
  assert.equal((await repo.getAttemptEvents()).length, 0);
});

test('InMemoryPersistenceRepository handles missing records gracefully without throwing', async () => {
  const repo = new InMemoryPersistenceRepository();

  assert.equal(await repo.getSession('missing-session-id'), null);
  assert.deepEqual(await repo.getAttemptEvents('missing-session-id'), []);
  assert.equal(await repo.getReviewSchedule('missing-skill-id'), null);
  assert.equal(await repo.getProgressProjection('missing-skill-id'), null);
});

test('InMemoryPersistenceRepository recovers cleanly after an aborted/failed write transaction', async () => {
  const repo = new InMemoryPersistenceRepository();
  const session1: PracticeSession = {
    id: 'sess-recover-1',
    skillId: 'math-derivative-sign',
    startedAt: '2026-11-08T10:00:00.000Z',
    attemptIds: ['att-rec-1'],
  };
  const event1: AttemptEvent = {
    id: 'att-rec-1',
    sessionId: 'sess-recover-1',
    questionVersionRef: { questionId: 'q1', version: 1, contentHash: 'sha:1' },
    scoringPolicyVersionRef: { id: 'p1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'A' },
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [{ partId: 'question', status: 'correct', points: 1, maxPoints: 1 }],
    timestamp: '2026-11-08T10:05:00.000Z',
  };

  await repo.saveSessionAndAttempt(session1, event1);
  assert.equal((await repo.getAllSessions()).length, 1);
  assert.equal((await repo.getAttemptEvents()).length, 1);

  // Trigger failed atomic write (corrupt event)
  await assert.rejects(
    async () => repo.saveSessionAndAttempt({ ...session1, id: 'sess-corrupt' }, null as any),
    /Corrupted or invalid attempt event record in atomic write/,
  );

  // Prior state preserved
  assert.equal((await repo.getAllSessions()).length, 1);
  assert.equal(await repo.getSession('sess-corrupt'), null);

  // Subsequent valid write succeeds cleanly (recovery verified)
  const session2: PracticeSession = {
    id: 'sess-recover-2',
    skillId: 'math-derivative-sign',
    startedAt: '2026-11-08T10:10:00.000Z',
    attemptIds: ['att-rec-2'],
  };
  const event2: AttemptEvent = {
    id: 'att-rec-2',
    sessionId: 'sess-recover-2',
    questionVersionRef: { questionId: 'q2', version: 1, contentHash: 'sha:2' },
    scoringPolicyVersionRef: { id: 'p1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'B' },
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [{ partId: 'question', status: 'correct', points: 1, maxPoints: 1 }],
    timestamp: '2026-11-08T10:15:00.000Z',
  };

  await repo.saveSessionAndAttempt(session2, event2);
  assert.equal((await repo.getAllSessions()).length, 2);
  assert.equal((await repo.getAttemptEvents()).length, 2);
});

test('PersistenceRepository clearly distinguishes between Native IndexedDB and In-Memory Adapter', () => {
  const inMemory = new InMemoryPersistenceRepository();
  assert.equal(inMemory.isNativeIndexedDB(), false, 'InMemory adapter must report false for native IndexedDB');
});

test('InMemoryPersistenceRepository rejects invalid domain events and supports clean clearLocalData', async () => {
  const repo = new InMemoryPersistenceRepository();

  const invalidPointsEvent: AttemptEvent = {
    id: 'att-inv-pts',
    sessionId: 'sess-001',
    questionVersionRef: { questionId: 'q1', version: 1, contentHash: 'sha:1' },
    scoringPolicyVersionRef: { id: 'p1', version: 1 },
    response: { kind: 'MCQ_SINGLE', optionId: 'A' },
    result: { status: 'scored', totalPoints: 10, maxPoints: 1 },
    partEvidence: [{ partId: 'question', status: 'correct', points: 10, maxPoints: 1 }],
    timestamp: '2026-11-08T10:05:00.000Z',
  };

  await assert.rejects(
    async () => repo.saveAttemptEvent(invalidPointsEvent),
    /cannot exceed maxPoints/,
  );

  // Valid write
  const validEvent: AttemptEvent = {
    ...invalidPointsEvent,
    id: 'att-valid-pts',
    result: { status: 'scored', totalPoints: 1, maxPoints: 1 },
    partEvidence: [{ partId: 'question', status: 'correct', points: 1, maxPoints: 1 }],
  };
  await repo.saveAttemptEvent(validEvent);
  assert.equal((await repo.getAttemptEvents()).length, 1);

  // Clear local data resets state
  await repo.clearLocalData();
  assert.equal((await repo.getAttemptEvents()).length, 0);
  assert.equal((await repo.getAllSessions()).length, 0);
});
