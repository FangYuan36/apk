import type {
  PersistenceRepository,
  PracticeSession,
  StoredReviewSchedule,
  ProgressProjection,
} from '../../../domain/persistence/types';
import { validateAttemptEvent, type AttemptEvent } from '../../../domain/math/attempt';

const DB_NAME = 'nexus-learn-storage';
const DB_VERSION = 1;

export class InMemoryPersistenceRepository implements PersistenceRepository {
  private sessions: Map<string, PracticeSession> = new Map();
  private attemptEvents: Map<string, AttemptEvent> = new Map();
  private reviewSchedules: Map<string, StoredReviewSchedule> = new Map();
  private progressProjections: Map<string, ProgressProjection> = new Map();
  private schemaVersion: number = DB_VERSION;

  isNativeIndexedDB(): boolean {
    return false;
  }

  async getSchemaVersion(): Promise<number> {
    return this.schemaVersion;
  }

  async migrateSchema(targetVersion: number): Promise<void> {
    if (!Number.isInteger(targetVersion) || targetVersion < this.schemaVersion) {
      throw new Error(`Cannot migrate schema from version ${this.schemaVersion} to ${targetVersion}`);
    }
    this.schemaVersion = targetVersion;
  }

  async saveSession(session: PracticeSession): Promise<void> {
    if (!session || typeof session !== 'object' || !session.id?.trim() || !session.skillId?.trim() || !Array.isArray(session.attemptIds)) {
      throw new Error('Corrupted or invalid session record');
    }
    this.sessions.set(session.id, Object.freeze({ ...session }));
  }

  async getSession(id: string): Promise<PracticeSession | null> {
    if (!id || typeof id !== 'string') return null;
    const s = this.sessions.get(id);
    return s ? Object.freeze({ ...s }) : null;
  }

  async getAllSessions(): Promise<readonly PracticeSession[]> {
    return Object.freeze(Array.from(this.sessions.values()));
  }

  async saveAttemptEvent(event: AttemptEvent): Promise<void> {
    const validation = validateAttemptEvent(event);
    if (!validation.valid) {
      throw new Error(`Corrupted or invalid attempt event record: ${validation.error}`);
    }
    const normalizedId = event.id.trim();
    if (this.attemptEvents.has(normalizedId)) {
      throw new Error(`Duplicate attempt event ID: '${event.id}'`);
    }
    this.attemptEvents.set(normalizedId, Object.freeze({ ...event }));
  }

  async getAttemptEvents(sessionId?: string): Promise<readonly AttemptEvent[]> {
    const all = Array.from(this.attemptEvents.values());
    if (!sessionId) {
      return Object.freeze(all);
    }
    return Object.freeze(all.filter((e) => e.sessionId === sessionId));
  }

  async saveReviewSchedule(schedule: StoredReviewSchedule): Promise<void> {
    if (!schedule || typeof schedule !== 'object' || !schedule.skillId?.trim() || !schedule.recheckDueAt?.trim()) {
      throw new Error('Corrupted or invalid review schedule record');
    }
    this.reviewSchedules.set(schedule.skillId, Object.freeze({ ...schedule }));
  }

  async getReviewSchedule(skillId: string): Promise<StoredReviewSchedule | null> {
    if (!skillId || typeof skillId !== 'string') return null;
    const s = this.reviewSchedules.get(skillId);
    return s ? Object.freeze({ ...s }) : null;
  }

  async getAllReviewSchedules(): Promise<readonly StoredReviewSchedule[]> {
    return Object.freeze(Array.from(this.reviewSchedules.values()));
  }

  async saveProgressProjection(projection: ProgressProjection): Promise<void> {
    if (!projection || typeof projection !== 'object' || !projection.skillId?.trim()) {
      throw new Error('Corrupted or invalid progress projection record');
    }
    this.progressProjections.set(projection.skillId, Object.freeze({ ...projection }));
  }

  async getProgressProjection(skillId: string): Promise<ProgressProjection | null> {
    if (!skillId || typeof skillId !== 'string') return null;
    const p = this.progressProjections.get(skillId);
    return p ? Object.freeze({ ...p }) : null;
  }

  async saveSessionAndAttempt(
    session: PracticeSession,
    event: AttemptEvent,
    schedule?: StoredReviewSchedule,
    projection?: ProgressProjection,
  ): Promise<void> {
    // 1. Validation
    if (!session || typeof session !== 'object' || !session.id?.trim() || !session.skillId?.trim() || !Array.isArray(session.attemptIds)) {
      throw new Error('Corrupted or invalid session record in atomic write');
    }
    const eventValidation = validateAttemptEvent(event);
    if (!eventValidation.valid) {
      throw new Error(`Corrupted or invalid attempt event record in atomic write: ${eventValidation.error}`);
    }
    if (schedule && (!schedule.skillId?.trim() || !schedule.recheckDueAt?.trim())) {
      throw new Error('Corrupted or invalid review schedule record in atomic write');
    }
    const normalizedEventId = event.id.trim();
    if (this.attemptEvents.has(normalizedEventId)) {
      throw new Error(`Duplicate attempt event ID: '${event.id}'`);
    }

    // 2. Snapshot current state for transaction rollback
    const priorSession = this.sessions.get(session.id);
    const priorSchedule = schedule ? this.reviewSchedules.get(schedule.skillId) : undefined;
    const priorProjection = projection ? this.progressProjections.get(projection.skillId) : undefined;

    try {
      this.sessions.set(session.id, Object.freeze({ ...session }));
      this.attemptEvents.set(normalizedEventId, Object.freeze({ ...event }));
      if (schedule) {
        this.reviewSchedules.set(schedule.skillId, Object.freeze({ ...schedule }));
      }
      if (projection) {
        this.progressProjections.set(projection.skillId, Object.freeze({ ...projection }));
      }
    } catch (err: unknown) {
      // Rollback on failure
      if (priorSession) this.sessions.set(session.id, priorSession);
      else this.sessions.delete(session.id);
      this.attemptEvents.delete(event.id);
      if (schedule) {
        if (priorSchedule) this.reviewSchedules.set(schedule.skillId, priorSchedule);
        else this.reviewSchedules.delete(schedule.skillId);
      }
      if (projection) {
        if (priorProjection) this.progressProjections.set(projection.skillId, priorProjection);
        else this.progressProjections.delete(projection.skillId);
      }
      throw err;
    }
  }

  async clearLocalData(): Promise<void> {
    this.sessions.clear();
    this.attemptEvents.clear();
    this.reviewSchedules.clear();
    this.progressProjections.clear();
  }
}

export class NativeIndexedDBRepository implements PersistenceRepository {
  private dbPromise: Promise<IDBDatabase> | null = null;

  isNativeIndexedDB(): boolean {
    return true;
  }

  private getDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
      if (typeof window === 'undefined' || !window.indexedDB) {
        reject(new Error('IndexedDB is not available in this environment'));
        return;
      }

      const request = window.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains('sessions')) {
          db.createObjectStore('sessions', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('attempt_events')) {
          const store = db.createObjectStore('attempt_events', { keyPath: 'id' });
          store.createIndex('sessionId', 'sessionId', { unique: false });
        }
        if (!db.objectStoreNames.contains('review_schedules')) {
          db.createObjectStore('review_schedules', { keyPath: 'skillId' });
        }
        if (!db.objectStoreNames.contains('progress_projections')) {
          db.createObjectStore('progress_projections', { keyPath: 'skillId' });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('Failed to open IndexedDB'));
    });

    return this.dbPromise;
  }

  async saveSession(session: PracticeSession): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('sessions', 'readwrite');
      const store = tx.objectStore('sessions');
      store.put(session);

      tx.oncomplete = () => resolve();
      tx.onerror = () => {
        if (tx.error?.name === 'QuotaExceededError') {
          reject(new Error(`Storage quota exceeded while saving session: ${tx.error.message}`));
        } else {
          reject(tx.error || new Error('Transaction failed'));
        }
      };
      tx.onabort = () => reject(tx.error || new Error('Transaction aborted'));
    });
  }

  async getSession(id: string): Promise<PracticeSession | null> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('sessions', 'readonly');
      const store = tx.objectStore('sessions');
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async getAllSessions(): Promise<readonly PracticeSession[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('sessions', 'readonly');
      const store = tx.objectStore('sessions');
      const req = store.getAll();
      req.onsuccess = () => resolve(Object.freeze(req.result || []));
      req.onerror = () => reject(req.error);
    });
  }

  async saveAttemptEvent(event: AttemptEvent): Promise<void> {
    const validation = validateAttemptEvent(event);
    if (!validation.valid) {
      throw new Error(`Corrupted or invalid attempt event record: ${validation.error}`);
    }
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('attempt_events', 'readwrite');
      const store = tx.objectStore('attempt_events');
      let constraintError = false;

      const req = store.add(event);
      req.onerror = () => {
        if (req.error?.name === 'ConstraintError') {
          constraintError = true;
        }
      };

      tx.oncomplete = () => resolve();
      tx.onerror = () => {
        if (constraintError) {
          reject(new Error(`Duplicate attempt event ID: '${event.id}'`));
        } else if (tx.error?.name === 'QuotaExceededError') {
          reject(new Error(`Storage quota exceeded while saving attempt: ${tx.error.message}`));
        } else {
          reject(tx.error || new Error('Transaction failed'));
        }
      };
      tx.onabort = () => {
        if (constraintError) {
          reject(new Error(`Duplicate attempt event ID: '${event.id}'`));
        } else {
          reject(tx.error || new Error('Transaction aborted'));
        }
      };
    });
  }

  async getAttemptEvents(sessionId?: string): Promise<readonly AttemptEvent[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('attempt_events', 'readonly');
      const store = tx.objectStore('attempt_events');
      let req: IDBRequest;
      if (sessionId) {
        const index = store.index('sessionId');
        req = index.getAll(sessionId);
      } else {
        req = store.getAll();
      }
      req.onsuccess = () => resolve(Object.freeze(req.result || []));
      req.onerror = () => reject(req.error);
    });
  }

  async saveReviewSchedule(schedule: StoredReviewSchedule): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('review_schedules', 'readwrite');
      const store = tx.objectStore('review_schedules');
      store.put(schedule);

      tx.oncomplete = () => resolve();
      tx.onerror = () => {
        if (tx.error?.name === 'QuotaExceededError') {
          reject(new Error(`Storage quota exceeded while saving review schedule: ${tx.error.message}`));
        } else {
          reject(tx.error || new Error('Transaction failed'));
        }
      };
      tx.onabort = () => reject(tx.error || new Error('Transaction aborted'));
    });
  }

  async getReviewSchedule(skillId: string): Promise<StoredReviewSchedule | null> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('review_schedules', 'readonly');
      const store = tx.objectStore('review_schedules');
      const req = store.get(skillId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async getAllReviewSchedules(): Promise<readonly StoredReviewSchedule[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('review_schedules', 'readonly');
      const store = tx.objectStore('review_schedules');
      const req = store.getAll();
      req.onsuccess = () => resolve(Object.freeze(req.result || []));
      req.onerror = () => reject(req.error);
    });
  }

  async saveProgressProjection(projection: ProgressProjection): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('progress_projections', 'readwrite');
      const store = tx.objectStore('progress_projections');
      store.put(projection);

      tx.oncomplete = () => resolve();
      tx.onerror = () => {
        if (tx.error?.name === 'QuotaExceededError') {
          reject(new Error(`Storage quota exceeded while saving progress projection: ${tx.error.message}`));
        } else {
          reject(tx.error || new Error('Transaction failed'));
        }
      };
      tx.onabort = () => reject(tx.error || new Error('Transaction aborted'));
    });
  }

  async getProgressProjection(skillId: string): Promise<ProgressProjection | null> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('progress_projections', 'readonly');
      const store = tx.objectStore('progress_projections');
      const req = store.get(skillId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async saveSessionAndAttempt(
    session: PracticeSession,
    event: AttemptEvent,
    schedule?: StoredReviewSchedule,
    projection?: ProgressProjection,
  ): Promise<void> {
    const eventValidation = validateAttemptEvent(event);
    if (!eventValidation.valid) {
      throw new Error(`Corrupted or invalid attempt event record in atomic write: ${eventValidation.error}`);
    }
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(
        ['sessions', 'attempt_events', 'review_schedules', 'progress_projections'],
        'readwrite',
      );
      let constraintError = false;

      // 1. Save session
      tx.objectStore('sessions').put(session);

      // 2. Add attempt (fails atomically if duplicate ID)
      const attemptReq = tx.objectStore('attempt_events').add(event);
      attemptReq.onerror = () => {
        if (attemptReq.error?.name === 'ConstraintError') {
          constraintError = true;
        }
      };

      // 3. Save review schedule if present
      if (schedule) {
        tx.objectStore('review_schedules').put(schedule);
      }

      // 4. Save progress projection if present
      if (projection) {
        tx.objectStore('progress_projections').put(projection);
      }

      tx.oncomplete = () => resolve();
      tx.onerror = () => {
        if (constraintError) {
          reject(new Error(`Duplicate attempt event ID: '${event.id}'`));
        } else if (tx.error?.name === 'QuotaExceededError') {
          reject(new Error(`Storage quota exceeded during atomic transaction: ${tx.error.message}`));
        } else {
          reject(tx.error || new Error('Atomic transaction failed'));
        }
      };
      tx.onabort = () => {
        if (constraintError) {
          reject(new Error(`Duplicate attempt event ID: '${event.id}'`));
        } else {
          reject(tx.error || new Error('Atomic transaction aborted'));
        }
      };
    });
  }

  async getSchemaVersion(): Promise<number> {
    return DB_VERSION;
  }

  async clearLocalData(): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(
        ['sessions', 'attempt_events', 'review_schedules', 'progress_projections'],
        'readwrite',
      );
      tx.objectStore('sessions').clear();
      tx.objectStore('attempt_events').clear();
      tx.objectStore('review_schedules').clear();
      tx.objectStore('progress_projections').clear();

      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error('Failed to clear local data'));
      tx.onabort = () => reject(tx.error || new Error('Clear transaction aborted'));
    });
  }
}

export type { PersistenceRepository };

export function createPersistenceRepository(): PersistenceRepository {
  if (typeof window !== 'undefined' && typeof window.indexedDB !== 'undefined') {
    return new NativeIndexedDBRepository();
  }
  return new InMemoryPersistenceRepository();
}
