# NEXUS LEARN

NEXUS LEARN is a personal-first learning coach for Vietnamese high-school students. Its intended learning loop is: diagnose a skill gap, classify the likely error, explain the missing step, practise, recheck later, and update the evidence for that skill.

## Project status

The repository bootstrap produced a verified minimal shell and domain-contract baseline. The responsive shell is navigation-only; its sections are explicitly marked as not implemented. It has no learner accounts, saved data, questions, scoring, or backend integration. The first skill-level vertical slice is queued for AGY and is not yet claimed.

See [PROJECT_STATUS.md](PROJECT_STATUS.md), [TASKS.md](TASKS.md), and [docs/TRACEABILITY.md](docs/TRACEABILITY.md) for current evidence and the AGY handoff.

## Run locally

Requirements: Node.js 22 or newer (the inspected environment was Node 26.13.0) and npm. On the Android shared-storage mount, the runner stages the source in Termux's private temporary directory because Android cannot execute/load native dependencies from `/sdcard`.

```sh
npm run test
npm run build
npm run dev
```

The runner installs the locked dependencies into `$PREFIX/tmp/nexus-learn-runtime` on first use, then copies the current source there before each command. A successful build copies `dist/` back into this workspace. Open the Vite URL printed by `npm run dev` on the same device. Changes made while the dev server is running require restarting it so the latest source is staged.

## Canonical design documents

- [Product requirements](docs/PRD.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Data model](docs/DATABASE.md)
- [Testing strategy](docs/TESTING.md)
- [Architecture decisions](DECISIONS.md)
- [Dated competitor research](docs/research/COMPETITOR_RESEARCH.md)
