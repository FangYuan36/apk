# AGENT HUB V1 — ANDROID / TERMUX
Hệ thống điều phối Agent chạy cục bộ trong môi trường Linux Termux trên Android.

---

## 1. Cấu trúc thư mục

```
agent-hub/
├── AGENTS.md               # Kiến trúc, nguyên tắc phối hợp & ranh giới của từng agent
├── rqcodex.txt             # Prompt đặc tả nhiệm vụ duy nhất đang giao/chờ worker
├── chung.txt               # Nhật ký trao đổi ngắn gọn giữa Codex, Agy và DeepSeek
├── logagy.txt              # Nhật ký sự kiện thực tế của Agy (kế hoạch, quyết định, kết quả)
├── logds.txt               # Nhật ký sự kiện API của DeepSeek (đã che giấu secret)
├── task_state.json         # Trạng thái tác vụ hiện tại (NEW, CLAIMED, RUNNING, REVIEW, DONE, BLOCKED)
├── processed_tasks.jsonl   # Lịch sử các task ID đã được claim hoặc hoàn thành (chống xử lý trùng)
├── bridge.py               # Module điều phối trung tâm, quản lý trạng thái và locking
├── deepseek_client.py      # Client kết nối DeepSeek API (timeout, retry, masking)
├── config.example.json     # Cấu hình mẫu (không chứa secret thật)
├── README.md               # Hướng dẫn vận hành chi tiết
└── tests/                  # Bộ kiểm thử tự động ngoại tuyến (offline)
    ├── test_bridge.py
    ├── test_deepseek.py
    └── run_all_tests.py
```

---

## 2. Quy trình làm việc 2 Tab Termux

### Tab 2 — Codex (Giao tiếp với Chủ nhân & Review)
1. Nhận yêu cầu từ người dùng, làm rõ yêu cầu, xác định phạm vi.
2. Ghi prompt vào `rqcodex.txt` theo đúng định dạng chuẩn:
   ```
   TASK_ID: TASK-0001
   GOAL: <Mục tiêu cụ thể>
   SCOPE: <Phạm vi file/thư mục được phép sửa>
   ACCEPTANCE_CRITERIA: <Tiêu chí kiểm thử/nghiệm thu bắt buộc>
   STOP_CONDITION: <Điều kiện dừng, ví dụ: kiểm thử pass>
   ```
3. Theo dõi tiến trình qua `chung.txt` và `task_state.json`.
4. Khi task chuyển sang trạng thái `REVIEW`, kiểm tra diff và kết quả kiểm thử.
5. Nếu đạt yêu cầu, chạy lệnh nghiệm thu `done`.

### Tab 1 — Agy CLI / Worker (Coder Chính)
1. Đọc và nhận task mới từ bridge:
   ```bash
   cd /sdcard/collab/agent-hub
   python3 bridge.py parse
   python3 bridge.py claim TASK-0001 --worker-id agy-worker-1
   ```
2. Chuyển sang trạng thái chạy:
   ```bash
   python3 bridge.py start TASK-0001 --worker-id agy-worker-1
   ```
3. Thực hiện sửa đổi trong phạm vi `SCOPE`, kiểm thử thực tế.
4. Ghi nhận nhật ký vào `logagy.txt`.
5. Nộp kết quả nghiệm thu:
   ```bash
   python3 bridge.py review TASK-0001 --summary "Đã hoàn thành các tiêu chí nghiệm thu"
   ```

---

## 3. Quản lý DeepSeek API (Coder Cộng tác)
- API key được đọc từ biến môi trường `DEEPSEEK_API_KEY`:
  ```bash
  export DEEPSEEK_API_KEY="sk-..."
  ```
- Nếu không có key, hệ thống hoạt động ở chế độ Offline/Mock mà không gây lỗi crash ứng dụng.
- Toàn bộ secret được tự động che giấu (mask) trước khi ghi vào `logds.txt`.

---

## 4. Cách khởi động và vận hành Bridge thủ công

Tất cả lệnh chạy trong thư mục `/sdcard/collab/agent-hub`:

1. **Xem trạng thái hiện tại:**
   ```bash
   python3 bridge.py status
   ```

2. **Khảo sát prompt trong rqcodex.txt:**
   ```bash
   python3 bridge.py parse
   ```

3. **Claim task:**
   ```bash
   python3 bridge.py claim <TASK_ID> --worker-id agy-worker-1
   ```

4. **Bắt đầu xử lý (RUNNING):**
   ```bash
   python3 bridge.py start <TASK_ID> --worker-id agy-worker-1
   ```

5. **Nộp kết quả để Codex review:**
   ```bash
   python3 bridge.py review <TASK_ID> --summary "Tóm tắt kết quả"
   ```

6. **Xác nhận nghiệm thu (DONE):**
   ```bash
   python3 bridge.py done <TASK_ID> --criteria-met --summary "Xác nhận đạt tất cả tiêu chí"
   ```

7. **Báo lỗi khi thực thi (hỗ trợ tối đa 2 lần retry tự động):**
   ```bash
   python3 bridge.py fail <TASK_ID> --error "Mô tả lỗi"
   ```

---

## 5. Cách dừng Bridge an toàn

Để dừng bridge mà không làm gián đoạn hoặc hỏng file trạng thái:
1. **Gửi tín hiệu dừng:**
   ```bash
   python3 bridge.py stop
   ```
   Lệnh này tạo file cờ `.stop`. Worker sẽ hoàn tất chu kỳ hiện tại và thoát an toàn.
2. **Khôi phục trạng thái sẵn sàng sau khi dừng:**
   ```bash
   python3 bridge.py clear-stop
   ```

---

## 6. Chạy kiểm thử tự động (Offline Test Suite)

Bộ kiểm thử hoàn toàn chạy ngoại tuyến, không cần internet và không ghi đè dữ liệu thực:

```bash
cd /sdcard/collab/agent-hub
python3 tests/run_all_tests.py
```
