#!/usr/bin/env python3
"""
bridge.py — Task coordinator and state manager for Agent Hub V1.
Features:
- State machine: NEW -> CLAIMED -> RUNNING -> REVIEW -> DONE
- Error handling: BLOCKED on unrecoverable error or max retries (2) exceeded.
- Anti-looping: DONE tasks are never reprocessed even if prompt remains in rqcodex.txt.
- Concurrency control: Atomic file lock ensures single worker ownership.
- Fault tolerance: Recovers from corrupted task_state.json without losing processed_tasks.jsonl.
- Safe stopping: Responds to .stop flag file and SIGINT/SIGTERM.
"""

import os
import sys
import json
import time
import signal
import hashlib
from typing import Dict, Any, Optional, Tuple, List

# Core Statuses
STATUS_IDLE = "IDLE"
STATUS_NEW = "NEW"
STATUS_CLAIMED = "CLAIMED"
STATUS_RUNNING = "RUNNING"
STATUS_REVIEW = "REVIEW"
STATUS_DONE = "DONE"
STATUS_BLOCKED = "BLOCKED"

VALID_TRANSITIONS = {
    STATUS_IDLE: [STATUS_NEW],
    STATUS_NEW: [STATUS_CLAIMED, STATUS_BLOCKED],
    STATUS_CLAIMED: [STATUS_RUNNING, STATUS_BLOCKED],
    STATUS_RUNNING: [STATUS_REVIEW, STATUS_BLOCKED, STATUS_RUNNING],  # Self-transition on retry
    STATUS_REVIEW: [STATUS_DONE, STATUS_RUNNING, STATUS_BLOCKED],
    STATUS_DONE: [],
    STATUS_BLOCKED: [STATUS_CLAIMED]  # Manual unblock
}

MAX_AUTO_RETRIES = 2


class BridgeError(Exception):
    """Base error for Bridge operations."""
    pass


class TaskAlreadyClaimedError(BridgeError):
    pass


class TaskAlreadyDoneError(BridgeError):
    pass


class InvalidStateTransitionError(BridgeError):
    pass


class AcceptanceCriteriaNotMetError(BridgeError):
    pass


class TaskLock:
    """Atomic file-based lock using O_CREAT | O_EXCL (compatible with Android FUSE)."""
    def __init__(self, lock_file_path: str, timeout: float = 0.0):
        self.lock_file_path = lock_file_path
        self.timeout = timeout
        self.fd = None

    def acquire(self, owner_info: str = "") -> bool:
        start_time = time.time()
        while True:
            try:
                self.fd = os.open(self.lock_file_path, os.O_CREAT | os.O_EXCL | os.O_RDWR)
                payload = f"pid={os.getpid()};owner={owner_info};ts={time.time()}\n"
                os.write(self.fd, payload.encode("utf-8"))
                return True
            except FileExistsError:
                if self.timeout <= 0 or (time.time() - start_time) >= self.timeout:
                    return False
                time.sleep(0.05)

    def release(self) -> None:
        if self.fd is not None:
            try:
                os.close(self.fd)
            except OSError:
                pass
            self.fd = None
        if os.path.exists(self.lock_file_path):
            try:
                os.remove(self.lock_file_path)
            except OSError:
                pass

    def __enter__(self):
        if not self.acquire():
            raise TaskAlreadyClaimedError(f"Could not acquire lock {self.lock_file_path}")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()


class AgentHubBridge:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
        self.rqcodex_path = os.path.join(self.base_dir, "rqcodex.txt")
        self.task_state_path = os.path.join(self.base_dir, "task_state.json")
        self.processed_tasks_path = os.path.join(self.base_dir, "processed_tasks.jsonl")
        self.chung_path = os.path.join(self.base_dir, "chung.txt")
        self.logagy_path = os.path.join(self.base_dir, "logagy.txt")
        self.logds_path = os.path.join(self.base_dir, "logds.txt")
        self.stop_flag_path = os.path.join(self.base_dir, ".stop")
        self.lock_file_path = os.path.join(self.base_dir, ".bridge.lock")
        self.should_stop = False

    def now_iso(self) -> str:
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    def log_chung(self, task_id: str, sender: str, recipient: str, message: str) -> None:
        """Log short interaction between Codex, Agy, and DeepSeek."""
        entry = f"[{self.now_iso()}] [{task_id}] [{sender} -> {recipient}]: {message.strip()}\n"
        with open(self.chung_path, "a", encoding="utf-8") as f:
            f.write(entry)

    def log_agy(
        self,
        task_id: str,
        event_type: str,
        plan: str = "",
        decision: str = "",
        files_changed: str = "[]",
        commands_run: str = "[]",
        result: str = "",
        error: str = "None"
    ) -> None:
        """Log structured Agy operational events."""
        entry = (
            f"[{self.now_iso()}] [{task_id}] [{event_type}]\n"
            f"PLAN: {plan.strip()}\n"
            f"DECISION: {decision.strip()}\n"
            f"FILES_CHANGED: {files_changed.strip()}\n"
            f"COMMANDS_RUN: {commands_run.strip()}\n"
            f"RESULT: {result.strip()}\n"
            f"ERROR: {error.strip()}\n"
            f"---\n"
        )
        with open(self.logagy_path, "a", encoding="utf-8") as f:
            f.write(entry)

    # ---------------- State and History Management ----------------

    def load_processed_tasks(self) -> Dict[str, Dict[str, Any]]:
        """Reads processed_tasks.jsonl returning a mapping of task_id to its record."""
        history = {}
        if not os.path.exists(self.processed_tasks_path):
            return history

        with open(self.processed_tasks_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                    tid = record.get("task_id")
                    if tid:
                        history[tid] = record
                except json.JSONDecodeError:
                    continue
        return history

    def append_processed_task(self, task_id: str, status: str, worker: Optional[str], details: Optional[Dict[str, Any]] = None) -> None:
        """Appends a task record to processed_tasks.jsonl and flushes to disk."""
        record = {
            "task_id": task_id,
            "status": status,
            "worker": worker,
            "timestamp": self.now_iso(),
            "details": details or {}
        }
        line = json.dumps(record, ensure_ascii=False) + "\n"
        with open(self.processed_tasks_path, "a", encoding="utf-8") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())

    def get_initial_state(self) -> Dict[str, Any]:
        return {
            "task_id": None,
            "status": STATUS_IDLE,
            "worker": None,
            "retry_count": 0,
            "max_retries": MAX_AUTO_RETRIES,
            "last_error": None,
            "prompt_hash": None,
            "created_at": None,
            "updated_at": self.now_iso(),
            "claimed_at": None,
            "started_at": None,
            "completed_at": None,
            "acceptance_criteria_met": False,
            "result_summary": None
        }

    def load_task_state(self) -> Dict[str, Any]:
        """
        Loads task_state.json.
        If corrupted, creates a backup and resets to a safe baseline without deleting history.
        """
        if not os.path.exists(self.task_state_path):
            return self.get_initial_state()

        try:
            with open(self.task_state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
                if not isinstance(state, dict) or "status" not in state:
                    raise ValueError("Invalid state format")
                return state
        except (json.JSONDecodeError, ValueError) as e:
            # Safely isolate corrupt file
            backup_path = f"{self.task_state_path}.corrupt.{int(time.time())}"
            try:
                os.rename(self.task_state_path, backup_path)
            except OSError:
                pass
            fallback = self.get_initial_state()
            fallback["last_error"] = f"Recovered from corrupted state. Backup saved to {os.path.basename(backup_path)}"
            self.save_task_state(fallback)
            self.log_agy(
                task_id="SYSTEM",
                event_type="STATE_CORRUPTION_DETECTED",
                plan="Reset to safe default IDLE state",
                decision="Preserve history and isolate corrupted state file",
                result=f"Backed up to {backup_path}",
                error=str(e)
            )
            return fallback

    def save_task_state(self, state: Dict[str, Any]) -> None:
        """Atomically saves task_state.json with fsync to prevent mid-write corruption."""
        state["updated_at"] = self.now_iso()
        temp_path = f"{self.task_state_path}.tmp.{os.getpid()}"
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_path, self.task_state_path)

    # ---------------- Prompt Parsing ----------------

    def parse_rqcodex(self) -> Optional[Dict[str, str]]:
        """
        Parses rqcodex.txt.
        Prompt MUST have TASK_ID, GOAL, SCOPE, ACCEPTANCE_CRITERIA, STOP_CONDITION.
        """
        if not os.path.exists(self.rqcodex_path):
            return None

        with open(self.rqcodex_path, "r", encoding="utf-8") as f:
            content = f.read().strip()

        if not content:
            return None

        task_info = {
            "task_id": "",
            "goal": "",
            "scope": "",
            "acceptance_criteria": "",
            "stop_condition": "",
            "raw_prompt": content,
            "prompt_hash": hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]
        }

        current_key = None
        current_lines = []

        def flush_key():
            if current_key and current_lines:
                task_info[current_key] = "\n".join(current_lines).strip()
                current_lines.clear()

        for line in content.splitlines():
            s = line.strip()
            if s.startswith("TASK_ID:"):
                flush_key()
                task_info["task_id"] = s.replace("TASK_ID:", "").strip()
                current_key = None
            elif s.startswith("GOAL:"):
                flush_key()
                current_key = "goal"
                current_lines.append(s.replace("GOAL:", "").strip())
            elif s.startswith("SCOPE:"):
                flush_key()
                current_key = "scope"
                current_lines.append(s.replace("SCOPE:", "").strip())
            elif s.startswith("ACCEPTANCE_CRITERIA:"):
                flush_key()
                current_key = "acceptance_criteria"
                current_lines.append(s.replace("ACCEPTANCE_CRITERIA:", "").strip())
            elif s.startswith("STOP_CONDITION:"):
                flush_key()
                current_key = "stop_condition"
                current_lines.append(s.replace("STOP_CONDITION:", "").strip())
            else:
                if current_key:
                    current_lines.append(line)
        flush_key()

        if not task_info["task_id"]:
            # Fallback regex search for task pattern like TASK-XXXX
            import re
            m = re.search(r'\b(TASK-[0-9A-Za-z_-]+)\b', content)
            if m:
                task_info["task_id"] = m.group(1)

        return task_info if task_info["task_id"] else None

    # ---------------- Task Operations ----------------

    def claim_task(self, task_id: str, worker_id: str) -> bool:
        """
        Claims a new task for worker_id.
        Enforces:
        - Atomic lock across processes.
        - Already DONE tasks in history are rejected.
        - Existing active claims by another worker are rejected.
        - State is flushed to disk before returning.
        """
        lock = TaskLock(self.lock_file_path)
        if not lock.acquire(owner_info=worker_id):
            raise TaskAlreadyClaimedError(f"Another process holds the bridge lock")

        try:
            # 1. Check history
            history = self.load_processed_tasks()
            if task_id in history and history[task_id].get("status") == STATUS_DONE:
                raise TaskAlreadyDoneError(f"Task {task_id} is already DONE in processed_tasks.jsonl")

            # 2. Check current state
            state = self.load_task_state()
            if state["task_id"] == task_id:
                if state["status"] in (STATUS_CLAIMED, STATUS_RUNNING):
                    if state.get("worker") and state.get("worker") != worker_id:
                        raise TaskAlreadyClaimedError(
                            f"Task {task_id} is already claimed by {state.get('worker')}"
                        )
                elif state["status"] == STATUS_DONE:
                    raise TaskAlreadyDoneError(f"Task {task_id} is already marked DONE in task_state.json")

            # 3. Transition to CLAIMED
            state["task_id"] = task_id
            state["status"] = STATUS_CLAIMED
            state["worker"] = worker_id
            state["retry_count"] = 0
            state["last_error"] = None
            state["claimed_at"] = self.now_iso()
            state["acceptance_criteria_met"] = False
            state["result_summary"] = None

            # 4. Flush to disk immediately
            self.save_task_state(state)
            self.append_processed_task(task_id, STATUS_CLAIMED, worker_id)

            self.log_agy(
                task_id=task_id,
                event_type="TASK_CLAIMED",
                plan=f"Worker {worker_id} claimed {task_id}",
                decision="Claim flushed to disk prior to worker execution",
                result="Status changed to CLAIMED"
            )
            self.log_chung(task_id, sender="Bridge", recipient="Codex", message=f"Task {task_id} claimed by {worker_id}")
            return True
        finally:
            lock.release()

    def start_running(self, task_id: str, worker_id: str) -> None:
        """Transitions state to RUNNING."""
        state = self.load_task_state()
        if state["task_id"] != task_id:
            raise BridgeError(f"Task mismatch: expected {state['task_id']}, got {task_id}")
        if state["status"] not in (STATUS_CLAIMED, STATUS_RUNNING):
            raise InvalidStateTransitionError(f"Cannot transition to RUNNING from {state['status']}")
        if state.get("worker") != worker_id:
            raise BridgeError(f"Worker mismatch: task owned by {state.get('worker')}")

        state["status"] = STATUS_RUNNING
        state["started_at"] = state.get("started_at") or self.now_iso()
        self.save_task_state(state)
        self.append_processed_task(task_id, STATUS_RUNNING, worker_id)

        self.log_agy(
            task_id=task_id,
            event_type="TASK_STARTED",
            plan=f"Worker {worker_id} started execution of {task_id}",
            decision="Worker active",
            result="Status changed to RUNNING"
        )

    def submit_for_review(self, task_id: str, worker_id: str, summary: str) -> None:
        """Transitions state to REVIEW for Codex to verify."""
        state = self.load_task_state()
        if state["task_id"] != task_id:
            raise BridgeError(f"Task mismatch: expected {state['task_id']}, got {task_id}")
        if state["status"] != STATUS_RUNNING:
            raise InvalidStateTransitionError(f"Cannot transition to REVIEW from {state['status']}")
        if state.get("worker") != worker_id:
            raise BridgeError(f"Worker mismatch: task owned by {state.get('worker')}")

        state["status"] = STATUS_REVIEW
        state["result_summary"] = summary
        self.save_task_state(state)
        self.append_processed_task(task_id, STATUS_REVIEW, worker_id, {"summary": summary})

        self.log_agy(
            task_id=task_id,
            event_type="TASK_REVIEW_SUBMITTED",
            plan="Execution complete, awaiting Codex review",
            decision="Results prepared and acceptance criteria verified locally",
            result=summary
        )
        self.log_chung(task_id, sender="Agy", recipient="Codex", message=f"Ready for review: {summary}")

    def mark_done(self, task_id: str, criteria_met: bool, summary: str) -> None:
        """
        Marks task as DONE.
        Enforces that acceptance criteria are met and actual results are provided.
        """
        if not criteria_met:
            raise AcceptanceCriteriaNotMetError("Cannot mark task DONE when acceptance criteria are not met")
        if not summary or not summary.strip():
            raise BridgeError("Cannot mark task DONE without an actual result summary")

        state = self.load_task_state()
        if state["task_id"] != task_id:
            raise BridgeError(f"Task mismatch: expected {state['task_id']}, got {task_id}")
        if state["status"] not in (STATUS_REVIEW, STATUS_RUNNING):
            raise InvalidStateTransitionError(f"Cannot transition to DONE from {state['status']}")

        state["status"] = STATUS_DONE
        state["acceptance_criteria_met"] = True
        state["result_summary"] = summary
        state["completed_at"] = self.now_iso()
        self.save_task_state(state)
        self.append_processed_task(task_id, STATUS_DONE, state.get("worker"), {"summary": summary})

        self.log_agy(
            task_id=task_id,
            event_type="TASK_DONE",
            plan="Task finalized and verified",
            decision="Criteria met confirmed",
            result=summary
        )
        self.log_chung(task_id, sender="Codex", recipient="All", message=f"Task {task_id} completed and accepted: {summary}")

    def handle_error(self, task_id: str, error_message: str, recoverable: bool = True) -> str:
        """
        Handles worker errors.
        Auto-retries up to MAX_AUTO_RETRIES times.
        Once retries are exhausted or on unrecoverable error, transitions to BLOCKED.
        """
        state = self.load_task_state()
        if state["task_id"] != task_id:
            raise BridgeError(f"Task mismatch: expected {state['task_id']}, got {task_id}")

        retry_count = state.get("retry_count", 0) + 1
        state["retry_count"] = retry_count
        state["last_error"] = error_message

        if not recoverable or retry_count > MAX_AUTO_RETRIES:
            new_status = STATUS_BLOCKED
            state["status"] = new_status
            decision = f"Max retries ({MAX_AUTO_RETRIES}) exceeded or unrecoverable error. Moving to BLOCKED."
        else:
            new_status = STATUS_RUNNING  # Eligible for retry
            decision = f"Recoverable error. Retry attempt {retry_count}/{MAX_AUTO_RETRIES}."

        self.save_task_state(state)
        self.append_processed_task(
            task_id,
            new_status,
            state.get("worker"),
            {"error": error_message, "retry_count": retry_count, "recoverable": recoverable}
        )

        self.log_agy(
            task_id=task_id,
            event_type="TASK_ERROR",
            plan="Error recorded",
            decision=decision,
            result=f"New status: {new_status}",
            error=error_message
        )
        self.log_chung(
            task_id=task_id,
            sender="Bridge",
            recipient="Codex",
            message=f"Task error: {error_message} (status: {new_status}, retry: {retry_count}/{MAX_AUTO_RETRIES})"
        )
        return new_status

    # ---------------- Stop and Lifecycle Checks ----------------

    def check_stop_requested(self) -> bool:
        """Check if .stop sentinel file exists or stop signal received."""
        if self.should_stop:
            return True
        if os.path.exists(self.stop_flag_path):
            self.should_stop = True
            return True
        return False

    def request_stop(self) -> None:
        """Create .stop flag to request graceful stop."""
        with open(self.stop_flag_path, "w", encoding="utf-8") as f:
            f.write(f"stop_requested_at={self.now_iso()}\n")
        self.should_stop = True

    def clear_stop(self) -> None:
        if os.path.exists(self.stop_flag_path):
            try:
                os.remove(self.stop_flag_path)
            except OSError:
                pass
        self.should_stop = False

    def check_bridge_restart(self) -> None:
        """
        Examines state on bridge start.
        Enforces:
        - Interrupted tasks are NOT marked DONE.
        - Finished tasks are NOT rerun.
        - State is left intact for inspection or orderly retry.
        """
        state = self.load_task_state()
        history = self.load_processed_tasks()

        tid = state.get("task_id")
        status = state.get("status")

        if not tid or status == STATUS_IDLE:
            return

        if status == STATUS_DONE:
            # Task is already done; nothing to rerun
            return

        if status in (STATUS_CLAIMED, STATUS_RUNNING):
            # Process was interrupted mid-turn.
            # Do NOT mark DONE!
            self.log_agy(
                task_id=tid,
                event_type="INTERRUPTED_SESSION_DETECTED",
                plan="Bridge restarted while task was in progress",
                decision="Preserving interrupted status without marking DONE or auto-clearing",
                result=f"Retaining status {status} for task {tid}",
                error="Process interrupted prior to completion"
            )


# ---------------- CLI Interface ----------------

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Agent Hub Bridge CLI")
    subparsers = parser.add_subparsers(dest="command")

    # status
    subparsers.add_parser("status", help="Show current task status")

    # parse
    subparsers.add_parser("parse", help="Parse rqcodex.txt")

    # claim
    claim_p = subparsers.add_parser("claim", help="Claim a task")
    claim_p.add_argument("task_id", help="Task ID to claim")
    claim_p.add_argument("--worker-id", default="agy-worker-1", help="Worker ID")

    # start
    start_p = subparsers.add_parser("start", help="Start running a claimed task")
    start_p.add_argument("task_id", help="Task ID")
    start_p.add_argument("--worker-id", default="agy-worker-1", help="Worker ID")

    # review
    rev_p = subparsers.add_parser("review", help="Submit task for review")
    rev_p.add_argument("task_id", help="Task ID")
    rev_p.add_argument("--worker-id", default="agy-worker-1", help="Worker ID")
    rev_p.add_argument("--summary", required=True, help="Result summary")

    # done
    done_p = subparsers.add_parser("done", help="Mark task as DONE")
    done_p.add_argument("task_id", help="Task ID")
    done_p.add_argument("--criteria-met", action="store_true", help="Confirm acceptance criteria met")
    done_p.add_argument("--summary", required=True, help="Final verified result summary")

    # fail
    fail_p = subparsers.add_parser("fail", help="Report task failure")
    fail_p.add_argument("task_id", help="Task ID")
    fail_p.add_argument("--error", required=True, help="Error message")
    fail_p.add_argument("--unrecoverable", action="store_true", help="Mark as unrecoverable error")

    # stop
    subparsers.add_parser("stop", help="Request graceful stop")
    subparsers.add_parser("clear-stop", help="Clear stop sentinel")

    args = parser.parse_args()
    bridge = AgentHubBridge()

    if args.command == "status":
        state = bridge.load_task_state()
        history = bridge.load_processed_tasks()
        print(f"Current State: {json.dumps(state, indent=2)}")
        print(f"Processed Tasks Count: {len(history)}")

    elif args.command == "parse":
        parsed = bridge.parse_rqcodex()
        if parsed:
            print(f"Detected Task: {json.dumps(parsed, indent=2)}")
        else:
            print("No valid task found in rqcodex.txt")

    elif args.command == "claim":
        bridge.claim_task(args.task_id, args.worker_id)
        print(f"Successfully claimed {args.task_id} for {args.worker_id}")

    elif args.command == "start":
        bridge.start_running(args.task_id, args.worker_id)
        print(f"Task {args.task_id} is now RUNNING")

    elif args.command == "review":
        bridge.submit_for_review(args.task_id, args.worker_id, args.summary)
        print(f"Task {args.task_id} is now in REVIEW")

    elif args.command == "done":
        bridge.mark_done(args.task_id, args.criteria_met, args.summary)
        print(f"Task {args.task_id} is now DONE")

    elif args.command == "fail":
        new_status = bridge.handle_error(args.task_id, args.error, recoverable=not args.unrecoverable)
        print(f"Task {args.task_id} failed. New status: {new_status}")

    elif args.command == "stop":
        bridge.request_stop()
        print("Stop flag created (.stop). Bridge will stop gracefully.")

    elif args.command == "clear-stop":
        bridge.clear_stop()
        print("Stop flag cleared.")

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
