NEXUS LEARN — AGENT ENGINEERING RULES

1. Project Mission

Build NEXUS LEARN as a production-quality, data-driven adaptive examination preparation platform.

The application must provide real educational functionality, persistent learning records, accurate examination scoring, explainable learning analytics, and controlled AI-assisted operations.

Do not optimize for the appearance of completion. Optimize for verified functionality.

2. Source of Truth

The following files are authoritative:

- "docs/PRD.md"
- "docs/ARCHITECTURE.md"
- "docs/DATABASE.md"
- "docs/API.md"
- "docs/SECURITY.md"
- "docs/TESTING.md"
- "docs/ACCEPTANCE.md"
- "PROJECT_STATUS.md"

If implementation conflicts with these documents, identify the conflict before changing behavior.

Never silently invent requirements.

3. Engineering Principles

- Use modular architecture.
- Keep business logic outside UI components.
- Use typed interfaces and validated schemas.
- Use database migrations.
- Use versioned questions and exam blueprints.
- Preserve immutable answer event history.
- Implement idempotent write operations.
- Use deterministic scoring for objective questions.
- Protect answer keys from client access.
- Enforce authorization on the backend.
- Keep AI providers behind an adapter layer.
- Make core examination functionality independent of AI availability.

4. Anti-Vibe-Coding Rules

Never:

- Create fake buttons or placeholder functionality presented as complete.
- Hardcode dashboard statistics as real user data.
- Use mock services in production paths.
- Ignore errors or suppress failed tests.
- Generate arbitrary database structures.
- Put secrets in frontend code.
- Give AI unrestricted database access.
- Modify historical exam results silently.
- Mark a task complete without verification.
- Replace real implementation with static screenshots or decorative UI.

5. Development Workflow

For each task:

1. Read relevant project documentation.
2. Inspect existing implementation.
3. Identify dependencies and affected modules.
4. Write an implementation plan.
5. Define acceptance tests.
6. Implement the smallest complete change.
7. Run relevant tests.
8. Run regression tests.
9. Review security implications.
10. Update documentation.
11. Record completion evidence.
12. Update "PROJECT_STATUS.md".

Do not begin unrelated implementation while a critical task is unresolved.

6. Testing Requirements

Every business-critical feature must have:

- Unit tests.
- Integration tests where applicable.
- End-to-end tests for critical user flows.
- Error-path tests.
- Authorization tests.

Critical flows include:

- Authentication.
- Exam generation.
- Answer autosave.
- Exam submission.
- Scoring.
- Learning analytics.
- Daily missions.
- AI tool permissions.

7. AI Requirements

AI is an application service, not the source of truth.

- Retrieve actual user data before making personal learning claims.
- Attach evidence references to analytics.
- State sample size and uncertainty.
- Never fabricate official examination requirements.
- Never claim unverified questions are official.
- Never expose answer keys before submission.
- Never modify original learning events.
- Require explicit authorization for sensitive changes.
- Validate all tool inputs and outputs.

8. Content Quality

Every published question must have:

- Subject and curriculum mapping.
- Question type.
- Difficulty classification.
- Correct answer.
- Explanation or scoring rationale.
- Source attribution or explicit original-content designation.
- Verification status.
- Version identifier.

A generated question must not become an official-simulation question until it passes the configured verification workflow.

9. Collaboration

Agents must communicate through:

- Task IDs.
- File ownership.
- Implementation reports.
- Audit reports.
- Test evidence.
- Documented decisions.

Do not overwrite another agent's unfinished work.

10. Completion Standard

A feature is complete only when:

- The implementation exists.
- The real user flow works.
- Data persists correctly.
- Relevant tests pass.
- Authorization is verified.
- Error handling works.
- Documentation is updated.
- Acceptance criteria are satisfied.

Report unfinished work honestly.

11. Final Rule

When uncertain, inspect, test, document and ask for clarification.

Do not guess, conceal uncertainty or manufacture completion.
