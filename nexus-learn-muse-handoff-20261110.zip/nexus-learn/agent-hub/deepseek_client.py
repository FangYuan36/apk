#!/usr/bin/env python3
"""
deepseek_client.py — DeepSeek API Client for Agent Hub V1
Features:
- Configurable timeout and retry limit (max 2 retries for recoverable errors).
- Sensitive data masking (API key, Authorization headers, Bearer tokens).
- Graceful offline mode: does not crash when API key is missing.
- Structured event logging to logds.txt.
- Clean separation: never modifies codebase directly.
"""

import os
import re
import json
import time
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, List, Tuple

DEFAULT_API_BASE = "https://api.deepseek.com/v1"
DEFAULT_MODEL = "deepseek-coder"
DEFAULT_TIMEOUT = 60
DEFAULT_MAX_RETRIES = 2
MAX_LOG_PAYLOAD_CHARS = 4000

KEY_MASK_REGEX = re.compile(r'(sk-[A-Za-z0-9_-]{8})[A-Za-z0-9_-]+([A-Za-z0-9_-]{4})')
BEARER_MASK_REGEX = re.compile(r'(Bearer\s+)[A-Za-z0-9_\-\.]{8,}', re.IGNORECASE)


def mask_sensitive(text: str) -> str:
    """Mask API keys, bearer tokens, and secrets in strings."""
    if not isinstance(text, str):
        text = str(text)
    # Mask OpenAI / DeepSeek style sk- keys
    text = KEY_MASK_REGEX.sub(r'\1...[MASKED]...\2', text)
    # Mask Bearer tokens
    text = BEARER_MASK_REGEX.sub(r'\1[MASKED_TOKEN]', text)
    return text


class DeepSeekClientError(Exception):
    """Base exception for DeepSeek client."""
    def __init__(self, message: str, recoverable: bool = False, status_code: Optional[int] = None):
        super().__init__(mask_sensitive(message))
        self.message = mask_sensitive(message)
        self.recoverable = recoverable
        self.status_code = status_code


class MissingApiKeyError(DeepSeekClientError):
    """Raised when an API call is made without an API key configured."""
    def __init__(self):
        super().__init__(
            "DeepSeek API key is not configured. Set the DEEPSEEK_API_KEY environment variable.",
            recoverable=False
        )


class DeepSeekClient:
    def __init__(
        self,
        api_key: Optional[str] = None,
        api_base: Optional[str] = None,
        model: Optional[str] = None,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        log_file: Optional[str] = None,
        transport_mock=None  # Used for deterministic offline tests
    ):
        self.api_key = api_key or os.environ.get("DEEPSEEK_API_KEY", "").strip() or None
        self.api_base = (api_base or os.environ.get("DEEPSEEK_API_BASE") or DEFAULT_API_BASE).rstrip('/')
        self.model = model or DEFAULT_MODEL
        self.timeout = timeout
        self.max_retries = max_retries
        self.log_file = log_file or os.path.join(os.path.dirname(os.path.abspath(__file__)), "logds.txt")
        self._transport_mock = transport_mock

    def is_configured(self) -> bool:
        """Check if an API key is present."""
        return bool(self.api_key)

    def _log_event(
        self,
        task_id: str,
        event_type: str,
        request_summary: str,
        decision: str,
        response_summary: str,
        error: str = "None"
    ) -> None:
        """Append sanitized event to logds.txt."""
        if not self.log_file:
            return

        timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        entry = (
            f"[{timestamp}] [{task_id}] [{event_type}]\n"
            f"REQUEST_SUMMARY: {mask_sensitive(request_summary[:MAX_LOG_PAYLOAD_CHARS])}\n"
            f"DECISION: {mask_sensitive(decision)}\n"
            f"RESPONSE_SUMMARY: {mask_sensitive(response_summary[:MAX_LOG_PAYLOAD_CHARS])}\n"
            f"ERROR: {mask_sensitive(error)}\n"
            f"---\n"
        )
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(entry)
        except OSError:
            pass

    def request_chat(
        self,
        messages: List[Dict[str, str]],
        task_id: str = "NO-TASK",
        temperature: float = 0.2,
        max_tokens: int = 4096
    ) -> Dict[str, Any]:
        """
        Send a chat completion request to DeepSeek.
        Retries up to max_retries times for recoverable errors (5xx, timeouts, 429).
        Fails fast on 4xx authentication or client errors.
        """
        if not self.is_configured() and self._transport_mock is None:
            raise MissingApiKeyError()

        url = f"{self.api_base}/chat/completions"
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        encoded_data = json.dumps(payload).encode("utf-8")

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key or 'MOCK_KEY'}",
            "User-Agent": "AgentHub/1.0"
        }

        attempts = 0
        last_error = None

        while attempts <= self.max_retries:
            attempts += 1
            start_time = time.time()
            try:
                # If mock transport is provided (testing), use it
                if self._transport_mock is not None:
                    response_dict = self._transport_mock(url=url, payload=payload, headers=headers)
                else:
                    req = urllib.request.Request(url, data=encoded_data, headers=headers, method="POST")
                    with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                        resp_bytes = resp.read()
                        response_dict = json.loads(resp_bytes.decode("utf-8"))

                # Log successful event
                content = ""
                if "choices" in response_dict and len(response_dict["choices"]) > 0:
                    choice = response_dict["choices"][0]
                    content = choice.get("message", {}).get("content", "")

                self._log_event(
                    task_id=task_id,
                    event_type="API_SUCCESS",
                    request_summary=f"model={self.model}, msgs={len(messages)}, attempt={attempts}",
                    decision="Received valid completion from DeepSeek",
                    response_summary=content[:500] if content else "Empty content"
                )
                return response_dict

            except urllib.error.HTTPError as e:
                code = e.code
                error_body = ""
                try:
                    error_body = e.read().decode("utf-8", errors="replace")
                except Exception:
                    pass

                # Check if recoverable
                recoverable = code in (429, 500, 502, 503, 504)
                last_error = DeepSeekClientError(
                    f"HTTP {code}: {error_body[:200]}",
                    recoverable=recoverable,
                    status_code=code
                )

                self._log_event(
                    task_id=task_id,
                    event_type="API_HTTP_ERROR",
                    request_summary=f"model={self.model}, attempt={attempts}",
                    decision=f"HTTP {code} encountered (recoverable={recoverable})",
                    response_summary="None",
                    error=str(last_error)
                )

                if not recoverable or attempts > self.max_retries:
                    raise last_error

                # Backoff before retry
                time.sleep(1.0 * attempts)

            except (urllib.error.URLError, TimeoutError, OSError) as e:
                last_error = DeepSeekClientError(
                    f"Network or timeout error: {str(e)}",
                    recoverable=True
                )
                self._log_event(
                    task_id=task_id,
                    event_type="API_NETWORK_ERROR",
                    request_summary=f"model={self.model}, attempt={attempts}",
                    decision="Network/timeout encountered, retrying if quota permits",
                    response_summary="None",
                    error=str(last_error)
                )

                if attempts > self.max_retries:
                    raise last_error

                time.sleep(1.0 * attempts)

            except Exception as e:
                last_error = DeepSeekClientError(
                    f"Unexpected error: {str(e)}",
                    recoverable=False
                )
                self._log_event(
                    task_id=task_id,
                    event_type="API_UNEXPECTED_ERROR",
                    request_summary=f"model={self.model}, attempt={attempts}",
                    decision="Unrecoverable error occurred",
                    response_summary="None",
                    error=str(last_error)
                )
                raise last_error

        if last_error:
            raise last_error
        raise DeepSeekClientError("Max retries exceeded with unknown failure", recoverable=False)


if __name__ == "__main__":
    import sys
    print("DeepSeek Client Module")
    client = DeepSeekClient()
    print(f"Configured: {client.is_configured()}")
    if not client.is_configured():
        print("Note: DEEPSEEK_API_KEY is not set. Offline mode is active.")
