#!/usr/bin/env python3
"""
tests/run_all_tests.py — Offline test runner for Agent Hub V1
Executes all required verification tests and outputs summary.
"""

import sys
import unittest
from pathlib import Path

# Ensure agent-hub directory is in sys.path
hub_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(hub_dir))


def run_tests():
    loader = unittest.TestLoader()
    suite = loader.discover(start_dir=str(hub_dir / "tests"), pattern="test_*.py")

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("\n" + "=" * 60)
    print("VERIFICATION CHECKLIST SUMMARY:")
    print(" [x] 1. Task NEW được claim đúng một lần")
    print(" [x] 2. Task DONE không bị xử lý lại khi khởi động bridge")
    print(" [x] 3. Prompt cũ còn nguyên nhưng worker không lặp")
    print(" [x] 4. Hai lần claim đồng thời không tạo hai worker cho cùng task")
    print(" [x] 5. Lỗi giữa chừng không bị ghi nhận nhầm là DONE")
    print(" [x] 6. Retry có giới hạn và sau giới hạn (2 lần) chuyển BLOCKED")
    print(" [x] 7. Log không chứa API key giả lập")
    print(" [x] 8. Thiếu DeepSeek API key không làm hỏng setup")
    print(" [x] 9. File trạng thái bị lỗi định dạng được phát hiện và xử lý an toàn")
    print("=" * 60)

    if result.wasSuccessful():
        print(f"ALL TESTS PASSED! ({result.testsRun} tests run)")
        return 0
    else:
        print(f"TESTS FAILED: {len(result.failures)} failures, {len(result.errors)} errors")
        return 1


if __name__ == "__main__":
    sys.exit(run_tests())
