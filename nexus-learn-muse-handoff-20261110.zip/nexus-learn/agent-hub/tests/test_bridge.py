#!/usr/bin/env python3
"""
tests/test_bridge.py — Offline test suite for AgentHubBridge
Verifies:
1. Task NEW claimed exactly once.
2. Task DONE not reprocessed on bridge restart.
3. Old prompt in rqcodex.txt does not cause worker loop.
4. Two concurrent claims do not create two workers for same task.
5. Mid-execution failure is not mistakenly recorded as DONE.
6. Retry limit (max 2) triggers BLOCKED state.
7. Corrupted task_state.json is safely isolated without wiping history.
"""

import os
import sys
import json
import shutil
import tempfile
import unittest
import multiprocessing
from pathlib import Path

# Add parent directory to import bridge
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bridge import (
    AgentHubBridge,
    TaskLock,
    TaskAlreadyClaimedError,
    TaskAlreadyDoneError,
    AcceptanceCriteriaNotMetError,
    STATUS_IDLE,
    STATUS_NEW,
    STATUS_CLAIMED,
    STATUS_RUNNING,
    STATUS_REVIEW,
    STATUS_DONE,
    STATUS_BLOCKED
)


class TestBridge(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp(prefix="agent_hub_test_")
        self.bridge = AgentHubBridge(base_dir=self.test_dir)
        # Create empty initial files
        with open(self.bridge.chung_path, "w") as f:
            f.write("# chung\n")
        with open(self.bridge.logagy_path, "w") as f:
            f.write("# logagy\n")

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_1_new_task_claimed_exactly_once(self):
        """1. Task NEW được claim đúng một lần."""
        prompt = (
            "TASK_ID: TASK-0001\n"
            "GOAL: Implement feature X\n"
            "SCOPE: src/x.py\n"
            "ACCEPTANCE_CRITERIA: Unit test passes\n"
            "STOP_CONDITION: All tests green\n"
        )
        with open(self.bridge.rqcodex_path, "w", encoding="utf-8") as f:
            f.write(prompt)

        parsed = self.bridge.parse_rqcodex()
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed["task_id"], "TASK-0001")

        # Worker 1 claims task
        claimed = self.bridge.claim_task("TASK-0001", worker_id="worker-1")
        self.assertTrue(claimed)

        # Verify state on disk immediately
        state = self.bridge.load_task_state()
        self.assertEqual(state["task_id"], "TASK-0001")
        self.assertEqual(state["status"], STATUS_CLAIMED)
        self.assertEqual(state["worker"], "worker-1")

        # Second worker attempts to claim same task -> must fail
        with self.assertRaises(TaskAlreadyClaimedError):
            self.bridge.claim_task("TASK-0001", worker_id="worker-2")

        # Confirm owner is still worker-1
        state_after = self.bridge.load_task_state()
        self.assertEqual(state_after["worker"], "worker-1")

    def test_2_done_task_not_reprocessed_on_restart(self):
        """2. Task DONE không bị xử lý lại khi khởi động bridge."""
        self.bridge.claim_task("TASK-0002", worker_id="worker-1")
        self.bridge.start_running("TASK-0002", worker_id="worker-1")
        self.bridge.submit_for_review("TASK-0002", worker_id="worker-1", summary="Implemented")
        self.bridge.mark_done("TASK-0002", criteria_met=True, summary="Verified")

        # Restart bridge
        new_bridge = AgentHubBridge(base_dir=self.test_dir)
        new_bridge.check_bridge_restart()

        state = new_bridge.load_task_state()
        self.assertEqual(state["status"], STATUS_DONE)
        self.assertEqual(state["task_id"], "TASK-0002")

        # Attempt to claim DONE task must raise TaskAlreadyDoneError
        with self.assertRaises(TaskAlreadyDoneError):
            new_bridge.claim_task("TASK-0002", worker_id="worker-1")

    def test_3_old_prompt_does_not_cause_worker_loop(self):
        """3. Prompt cũ còn nguyên nhưng worker không lặp."""
        prompt = (
            "TASK_ID: TASK-0003\n"
            "GOAL: Finish setup\n"
            "SCOPE: root\n"
            "ACCEPTANCE_CRITERIA: Done\n"
            "STOP_CONDITION: Exit\n"
        )
        with open(self.bridge.rqcodex_path, "w", encoding="utf-8") as f:
            f.write(prompt)

        # Complete the task
        self.bridge.claim_task("TASK-0003", worker_id="worker-1")
        self.bridge.start_running("TASK-0003", worker_id="worker-1")
        self.bridge.submit_for_review("TASK-0003", worker_id="worker-1", summary="Setup done")
        self.bridge.mark_done("TASK-0003", criteria_met=True, summary="Setup verified")

        # Prompt remains untouched in rqcodex.txt
        with open(self.bridge.rqcodex_path, "r", encoding="utf-8") as f:
            content = f.read()
        self.assertIn("TASK-0003", content)

        # Worker cycles again: parses rqcodex.txt
        parsed = self.bridge.parse_rqcodex()
        tid = parsed["task_id"]
        history = self.bridge.load_processed_tasks()

        # Anti-loop check: if tid in history and history[tid].get("status") == STATUS_DONE -> skip
        self.assertIn(tid, history)
        self.assertEqual(history[tid]["status"], STATUS_DONE)

        # Claim attempt is blocked
        with self.assertRaises(TaskAlreadyDoneError):
            self.bridge.claim_task(tid, worker_id="worker-1")

    def test_4_concurrent_claims_prevent_two_workers(self):
        """4. Hai lần claim đồng thời không tạo hai worker cho cùng task."""
        import subprocess

        # Using subprocess to test true cross-process concurrency
        script = f"""
import sys
sys.path.insert(0, {repr(str(Path(__file__).resolve().parent.parent))})
from bridge import AgentHubBridge
b = AgentHubBridge(base_dir={repr(self.test_dir)})
try:
    b.claim_task('TASK-0004', worker_id=sys.argv[1])
    print('SUCCESS')
except Exception as e:
    print(type(e).__name__)
"""
        p1 = subprocess.Popen([sys.executable, "-c", script, "w1"], stdout=subprocess.PIPE, text=True)
        p2 = subprocess.Popen([sys.executable, "-c", script, "w2"], stdout=subprocess.PIPE, text=True)

        out1, _ = p1.communicate(timeout=5)
        out2, _ = p2.communicate(timeout=5)

        results = [out1.strip(), out2.strip()]

        # Exactly one must succeed, one must fail with TaskAlreadyClaimedError
        self.assertEqual(results.count("SUCCESS"), 1, f"Results: {results}")
        self.assertEqual(results.count("TaskAlreadyClaimedError"), 1, f"Results: {results}")

    def test_5_interrupted_task_not_recorded_as_done(self):
        """5. Lỗi giữa chừng không bị ghi nhận nhầm là DONE."""
        self.bridge.claim_task("TASK-0005", worker_id="worker-1")
        self.bridge.start_running("TASK-0005", worker_id="worker-1")

        # Simulate bridge / worker sudden termination during execution
        # Bridge restarts
        restarted_bridge = AgentHubBridge(base_dir=self.test_dir)
        restarted_bridge.check_bridge_restart()

        state = restarted_bridge.load_task_state()
        self.assertNotEqual(state["status"], STATUS_DONE)
        self.assertEqual(state["status"], STATUS_RUNNING)
        self.assertFalse(state["acceptance_criteria_met"])

        # Marking DONE without acceptance criteria must raise error
        with self.assertRaises(AcceptanceCriteriaNotMetError):
            restarted_bridge.mark_done("TASK-0005", criteria_met=False, summary="")

    def test_6_retry_limit_to_blocked(self):
        """6. Retry có giới hạn và sau giới hạn (2 lần) chuyển BLOCKED."""
        self.bridge.claim_task("TASK-0006", worker_id="worker-1")
        self.bridge.start_running("TASK-0006", worker_id="worker-1")

        # Retry 1
        st1 = self.bridge.handle_error("TASK-0006", "Transient network timeout", recoverable=True)
        self.assertEqual(st1, STATUS_RUNNING)
        state1 = self.bridge.load_task_state()
        self.assertEqual(state1["retry_count"], 1)

        # Retry 2
        st2 = self.bridge.handle_error("TASK-0006", "Transient 503 error", recoverable=True)
        self.assertEqual(st2, STATUS_RUNNING)
        state2 = self.bridge.load_task_state()
        self.assertEqual(state2["retry_count"], 2)

        # Attempt 3 exceeds max retries (2) -> must transition to BLOCKED
        st3 = self.bridge.handle_error("TASK-0006", "Third failure", recoverable=True)
        self.assertEqual(st3, STATUS_BLOCKED)
        state3 = self.bridge.load_task_state()
        self.assertEqual(state3["status"], STATUS_BLOCKED)
        self.assertEqual(state3["retry_count"], 3)
        self.assertEqual(state3["last_error"], "Third failure")

    def test_9_corrupt_state_recovery_preserves_history(self):
        """9. File trạng thái bị lỗi định dạng được phát hiện và xử lý an toàn, không tự xóa lịch sử."""
        # Record some processed tasks in history
        self.bridge.append_processed_task("TASK-0001", STATUS_DONE, "worker-1", {"summary": "Done"})
        self.bridge.append_processed_task("TASK-0002", STATUS_DONE, "worker-1", {"summary": "Done"})

        # Deliberately corrupt task_state.json with malformed JSON
        with open(self.bridge.task_state_path, "w", encoding="utf-8") as f:
            f.write('{"status": "RUNNING", "task_id": "TASK-0003", corrupted... TRUNCATED!')

        # Load task state
        recovered_state = self.bridge.load_task_state()
        self.assertEqual(recovered_state["status"], STATUS_IDLE)
        self.assertIn("Recovered from corrupted state", recovered_state.get("last_error", ""))

        # Verify history in processed_tasks.jsonl was NOT wiped
        history = self.bridge.load_processed_tasks()
        self.assertEqual(len(history), 2)
        self.assertIn("TASK-0001", history)
        self.assertIn("TASK-0002", history)

        # Check backup file exists
        corrupt_backups = [f for f in os.listdir(self.test_dir) if "corrupt" in f]
        self.assertTrue(len(corrupt_backups) > 0)


if __name__ == "__main__":
    unittest.main()
