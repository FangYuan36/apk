#!/usr/bin/env python3
"""
tests/test_deepseek.py — Offline test suite for DeepSeekClient
Verifies:
7. Log không chứa API key giả lập (Masking of sensitive keys).
8. Thiếu DeepSeek API key không làm hỏng setup.
"""

import os
import sys
import shutil
import tempfile
import unittest
from pathlib import Path

# Add parent directory to import deepseek_client
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from deepseek_client import (
    DeepSeekClient,
    MissingApiKeyError,
    DeepSeekClientError,
    mask_sensitive
)


class TestDeepSeekClient(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp(prefix="ds_test_")
        self.log_file = os.path.join(self.test_dir, "logds.txt")

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_8_missing_api_key_does_not_crash_setup(self):
        """8. Thiếu DeepSeek API key không làm hỏng setup."""
        # Unset env var if any
        old_env = os.environ.pop("DEEPSEEK_API_KEY", None)
        try:
            client = DeepSeekClient(api_key=None, log_file=self.log_file)
            self.assertFalse(client.is_configured())

            # Attempting request raises MissingApiKeyError gracefully without unhandled crashes
            with self.assertRaises(MissingApiKeyError):
                client.request_chat([{"role": "user", "content": "hello"}])
        finally:
            if old_env is not None:
                os.environ["DEEPSEEK_API_KEY"] = old_env

    def test_7_log_does_not_contain_mock_api_key(self):
        """7. Log không chứa API key giả lập."""
        fake_secret_key = "sk-abcdef1234567890secretkeyvalue9999"

        # Mock transport that returns a successful mock response
        def mock_transport(url, payload, headers):
            return {
                "choices": [{
                    "message": {
                        "role": "assistant",
                        "content": "Analysis: suggestions and patches with Bearer token masked"
                    }
                }]
            }

        client = DeepSeekClient(
            api_key=fake_secret_key,
            log_file=self.log_file,
            transport_mock=mock_transport
        )
        self.assertTrue(client.is_configured())

        # Perform chat request
        resp = client.request_chat(
            messages=[{"role": "user", "content": "Propose patch"}],
            task_id="TASK-0007"
        )
        self.assertIn("choices", resp)

        # Inspect logds.txt
        with open(self.log_file, "r", encoding="utf-8") as f:
            log_contents = f.read()

        # The actual raw secret key MUST NOT appear anywhere in the log
        self.assertNotIn(fake_secret_key, log_contents)

        # Verify masking function directly
        raw_msg = f"Failed with Authorization: Bearer {fake_secret_key}"
        masked_msg = mask_sensitive(raw_msg)
        self.assertNotIn(fake_secret_key, masked_msg)
        self.assertIn("[MASKED", masked_msg)


if __name__ == "__main__":
    unittest.main()
