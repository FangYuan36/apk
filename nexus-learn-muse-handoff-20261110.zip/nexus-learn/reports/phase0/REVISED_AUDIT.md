# NEXUS LEARN Phase 0 — Revised Audit Findings

**Auditor:** Codex, Chief Architect/Technical Coordinator (self-audit; not independent)<br>
**Review date:** 2026-11-06<br>
**Scope:** Original Phase 0 documents, prior Codex findings, and audit requirements in the project owner's current instruction. The referenced new Independent Technical Auditor report was not present as a workspace file or included verbatim in the message; findings below therefore map the explicit requirements supplied here and do not pretend to quote that report.<br>
**Independent review:** Not yet completed. See `AGY_AUDIT.md`.

## Findings and classification

### P0-A — Independent audit provenance and approval chain missing

- **Severity:** HIGH
- **Classification:** CONFIRMED
- **Evidence:** Previous `PROJECT_STATUS.md` and `reports/phase0/AGY_AUDIT.md` state Codex self-review and unsuccessful AGY attempts, but no procedure required a distinct execution/context, read-only access to source, model/version/time/scope capture, or project-owner final approval.
- **Problem / impact:** A self-audit or agent summary could be misrepresented as independent assurance; no traceable reviewer provenance.
- **Correction:** Define separate auditor run, read-only source/CI access, required metadata and report, explicit failure state, and owner-only acceptance in `docs/AGENT_WORKFLOW.md` and `PROJECT_STATUS.md`.
- **Verification:** Confirm workflow explicitly rejects self-review as independent and stores auditor metadata; successful future report must name source commit and actual execution. Current AGY timeouts remain blocker.

### P0-B — CI gates and machine evidence were unspecified

- **Severity:** CRITICAL
- **Classification:** CONFIRMED
- **Evidence:** Prior `docs/TESTING.md` listed test layers but no required lint/type/unit/integration/security/migration/build CI gates, branch-protection behavior, commit/run identifiers, or rule that AGY self-report is not test evidence.
- **Problem / impact:** A task could be called verified without reproducible execution against the submitted commit.
- **Correction:** Add required gates, exact-commit artifact contract, rerun-on-change rule, and phase-1 tool selection in `docs/OPERATIONS.md`, `docs/TESTING.md`, `docs/AGENT_WORKFLOW.md`.
- **Verification:** Future pipeline must produce a passing artifact per required job, commit SHA and run ID; skipped/failing job blocks `CI_VERIFIED`.

### P0-C — Task approval, retry, escalation and file-scope controls missing

- **Severity:** HIGH
- **Classification:** CONFIRMED
- **Evidence:** Prior Agent Hub was CLI-driven with simple NEW/CLAIMED/RUNNING/REVIEW/DONE states; Phase 0 documents had milestones but no required task file allowlist/denylist, dependencies, rollback, retry limit, escalation, or explicit approval/review state sequence.
- **Problem / impact:** Work could start without owner approval, modify unrelated files, repeat failed fixes indefinitely, or accept an executor's own result.
- **Correction:** Define requested PLANNED→APPROVED→IN_PROGRESS→IMPLEMENTED→CI_VERIFIED→CODEX_REVIEW→AUDITOR_REVIEW→ACCEPTED sequence, REJECTED→FIX_REQUIRED loop, two-round default, escalation, task contract and owner gate in `docs/AGENT_WORKFLOW.md`.
- **Verification:** Workflow acceptance checks exact transitions, owner approval, file allowlist enforcement, retry exhaustion and escalation records.

### P0-D — Minor privacy, AI governance, and database enforcement details incomplete

- **Severity:** CRITICAL
- **Classification:** PARTIALLY_CONFIRMED
- **Evidence:** Existing `docs/SECURITY.md` already covered tenant isolation, AI tools, provenance, secrets and generic privacy review. It did not specify minors, learner data access/deletion, current-law verification, AI output validation, rate/cost limits, secret-store policy, or database privilege/trigger enforcement. Licensing was present as evidence but did not have a complete publication review workflow.
- **Problem / impact:** Sensitive learner data and licensed content could be collected/shared/published without a defined review gate; “immutable” may rely only on application code.
- **Correction:** Add `docs/PRIVACY.md`, `docs/AI_GOVERNANCE.md`; strengthen DB/API/security acceptance for DB-enforced immutability, human review of AI drafts, tool/output boundaries, cost/rate controls, current primary-source legal review and deletion/access process.
- **Verification:** Before pilot, show role/trigger mutation rejection, tenant tests, AI injection/output/rate/cost tests, content rights/review evidence, and current dated legal review. No compliance conclusion is made here.

### P0-E — Exam timing/recovery/security and load behavior underspecified

- **Severity:** CRITICAL
- **Classification:** CONFIRMED
- **Evidence:** Prior API specified idempotency and event cutoff in broad terms but not server-authoritative timer/deadline, client drift, network recovery, unacknowledged answers, offline answer-key exposure, or concurrent exam traffic.
- **Problem / impact:** Client clock or reconnect races could alter deadlines/results; offline caching could expose answers; traffic spikes could drop submissions.
- **Correction:** Specify server time, atomic close/cutoff, idempotent submit, canonical recovery, pending acknowledgment UI, disabled offline exam writes, answer-key projections and owner-approved concurrency/load targets in API, architecture, testing and `docs/OPERATIONS.md`.
- **Verification:** Future integration/E2E/load tests cover client drift, submit race/retry, dropped network, recovery sequence, no answer-key exposure, and approved concurrency target.

### P0-F — Learning-method decision lacked evidence-based comparison

- **Severity:** HIGH
- **Classification:** CONFIRMED
- **Evidence:** Existing PRD said adaptive policy unresolved; it did not compare BKT, IRT, FSRS, and heuristic requirements, reliability, cold-start, sample evidence, interpretability, compute and validation approach.
- **Problem / impact:** A method could be selected by preference despite incompatible event data or misleading cold-start behavior.
- **Correction:** Add comparison/evaluation protocol in `docs/AI_GOVERNANCE.md`, traceability and architecture; select no method until actual data and labels are audited. Keep abstaining baseline and owner-approved thresholds.
- **Verification:** Decision record must include data inventory, held-out evaluation, calibration, subgroup/drift checks, cost, cold-start coverage, and owner approval before learner exposure.

### P0-G — Source verification/publishing was not a roadmap gate for AI-generated items

- **Severity:** HIGH
- **Classification:** CONFIRMED
- **Evidence:** Prior content module mentioned provenance and publication, but no explicit rule prevented the generation principal from verifying/publishing its output or required source/answer/scoring review at exact hash.
- **Problem / impact:** AI could self-assert a wrong answer or publish content without rights or independent validation.
- **Correction:** Add source-management and human-review gates before/parallel to exam engine; generation creates draft only; reviewer and publisher roles are distinct; immutable hash binds review to version.
- **Verification:** Authorization tests prove AI principal cannot review/publish; publication without approved source/license and exact-hash human review is rejected.

### P0-H — Requirement-to-implementation-to-test traceability absent

- **Severity:** HIGH
- **Classification:** CONFIRMED
- **Evidence:** Existing acceptance table listed modules, but no matrix mapped each critical product/security requirement through architecture, schema, API, implementation owner/path, test artifact and acceptance criterion.
- **Problem / impact:** Requirements could be omitted in implementation or accepted without evidence.
- **Correction:** Add `docs/TRACEABILITY.md` with stable requirement IDs and planned module owners; require actual paths and commit/CI artifact before marking implemented/verified.
- **Verification:** Every matrix row has acceptance and test evidence slots; task approval gate rejects requirements without exact files/commands/artifacts.

## Preserved decisions

The modular monolith, preferred stack, versioned curricula/blueprints/questions, append-only answers, deterministic scoring, AI-independent core flow, configurable exam year/subject, no Phase 1 code in this task, and no unsupported official 2027 claims remain intact. No BKT/IRT/FSRS/heuristic choice or legal compliance claim is made.
