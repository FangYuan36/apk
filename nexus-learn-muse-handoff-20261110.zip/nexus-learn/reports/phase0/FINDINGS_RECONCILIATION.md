# NEXUS LEARN Phase 0 — Findings Reconciliation

**Status:** Codex evidence reconciliation complete; AGY comparison unavailable.<br>
**Important:** `CONFIRMED` below means Codex verified the document defect against the cited text. It does **not** mean AGY agreed. AGY returned no usable findings before its CLI review timed out; therefore there are no AGY finding IDs to compare, no disagreements to invent, and no claim of agent consensus.

## Finding disposition

| ID | Codex finding | Reconciliation class | AGY comparison | Disposition |
|---|---|---|---|---|
| C-01 | Answer events not bound to exact session item/question version | CONFIRMED | Unavailable | Add immutable session items and composite integrity constraints. |
| C-02 | Dependent owner IDs can disagree with parent session | CONFIRMED | Unavailable | Derive owner or constrain parent/child owner equality. |
| C-03 | Multi-curriculum question/topic cardinality not modeled | CONFIRMED | Unavailable | Add explicit profile compatibility/topic mapping. |
| C-04 | Same idempotency key/different payload behavior undefined | CONFIRMED | Unavailable | Persist canonical request fingerprint and return conflict on mismatch. |
| C-05 | Practice API response has no explicit answer-key disclosure boundary | CONFIRMED | Unavailable | Separate learner/scoring projections and gate review fields until allowed. |
| C-06 | Adaptive cold-start/low-evidence behavior unspecified | CONFIRMED | Unavailable | Add no-unsupported-claim fallback; owner decides thresholds/policy. |
| C-07 | Submit/answer concurrency ordering not specified | PARTIALLY_CONFIRMED | Unavailable | Existing text calls for stable cutoff and notes post-submit policy unresolved, but lacks transaction outcome; specify OPEN→SUBMITTED serialization. |
| C-08 | Candidate offline success metric conflicts with deferred offline writes | CONFIRMED | Unavailable | Separate offline from AI-degraded requirements and defer offline writes. |
| C-09 | Operational pilot gate lacks measurable evidence/targets | CONFIRMED | Unavailable | Require owner-approved targets and staging evidence, without inventing values. |
| C-10 | UI topic-practice flow cannot be created by blueprint-only API/model | CONFIRMED | Unavailable | Add practice session kind and immutable item snapshot alongside exams. |
| C-11 | Score rows do not specify unanswered items | CONFIRMED | Unavailable | Cover every session item; selected answer event nullable; points follow versioned policy. |
| C-12 | Question publish route does not identify exact version | CONFIRMED | Unavailable | Publish exact version ID and verify reviewed content hash. |

No finding is classified `DISAGREED`: there is no returned AGY position to disagree with. No finding is classified `NEEDS_HUMAN_DECISION` merely because it is a confirmed documentation defect. The owner decisions below are separately gated.

## Human decisions / implementation gates

| Decision | Classification | Owner | Gate |
|---|---|---|---|
| Initial curriculum, authoritative exam sources and 2027 rules | NEEDS_HUMAN_DECISION | Project owner | Before any official-alignment claim or blueprint publication as official. |
| Question types, normalization, partial credit, unanswered-item points and correction/re-score policy | NEEDS_HUMAN_DECISION | Project owner | Before M1 locks scoring fixtures or M4 implementation. |
| Adaptive-policy thresholds, confidence/recency rules | NEEDS_HUMAN_DECISION | Project owner | Thresholds before production recommendations; safe low-evidence fallback can be implemented without a numeric threshold. |
| Authentication/account recovery and editor/admin role policy | NEEDS_HUMAN_DECISION | Project owner | Before M2 identity implementation. |
| Learner privacy, retention/deletion, age/consent, AI provider sharing, residency | NEEDS_HUMAN_DECISION | Project owner, with qualified privacy/legal reviewer where needed | Before real learner data or provider transmission. |
| Offline capability and conflict/replay semantics | NEEDS_HUMAN_DECISION | Project owner | Offline answer writes remain disabled until decision and tests. |
| Hosting, RPO/RTO, monitoring/alert owner and incident contacts | NEEDS_HUMAN_DECISION | Project owner / named operations owner | Before pilot readiness. |

## Review limitation

The second reviewer CLI was configured with a distinct AGY model in sandbox/plan mode and confirmed through progress output that it read the ten files. It did not return a completed analysis before the 120-second print timeout. That partial execution is not independent audit evidence. See `AGY_AUDIT.md` for exact capability discovery and errors.
