# NEXUS LEARN Phase 0 — Correction Plan

**Prepared by:** Codex<br>
**Approval:** Codex approves this document-only correction plan for execution by Codex. AGY is not authorized to edit because its independent review did not complete.<br>
**Scope:** Correct confirmed design-document gaps while preserving product scope. No application implementation.

## Planned corrections

| Finding | Files | Exact correction | Verification |
|---|---|---|---|
| C-01, C-10 | `docs/DATABASE.md`, `docs/API.md`, `docs/ARCHITECTURE.md`, `docs/ACCEPTANCE.md` | Add discriminated exam/practice sessions and immutable `session_items`; bind each item to an exact question version; exam items additionally bind to an item in the pinned blueprint. Require answers to reference the session item. | Database/API acceptance criteria require wrong-session, wrong-blueprint, and wrong-version associations to fail. |
| C-02 | `docs/DATABASE.md`, `docs/SECURITY.md`, `docs/TESTING.md` | Specify owner consistency via a parent-derived ownership rule or composite unique/FK constraints; prefer deriving dependent ownership where possible. | Negative DB association tests and two-user authorization tests. |
| C-03 | `docs/DATABASE.md`, `docs/ACCEPTANCE.md` | Define explicit many-profile compatibility and profile-scoped topic relationships with immutable/effective semantics. | Multi-profile fixture and invalid cross-profile topic tests. |
| C-04 | `docs/API.md`, `docs/DATABASE.md`, `docs/TESTING.md` | Define canonical request hash semantics for idempotency: same key+same payload returns original; same key+different payload returns `IDEMPOTENCY_CONFLICT`. | API contract tests for retry and conflicting reuse. |
| C-05 | `docs/API.md`, `docs/SECURITY.md`, `docs/TESTING.md`, `docs/ACCEPTANCE.md` | Separate learner practice DTO from scoring/editor data; state answer-key disclosure only in authorized review after submit. | Schema/authorization tests assert hidden fields are omitted before allowed review. |
| C-06 | `docs/PRD.md`, `docs/ARCHITECTURE.md`, `docs/ACCEPTANCE.md`, `docs/TESTING.md`, `DECISIONS.md` | Document cold-start/low-evidence behavior as no unsupported proficiency claim and a neutral practice option; leave thresholds/policy to owner decision. | Tests for zero/sparse/stale/mixed-provenance evidence. |
| C-07, C-11 | `docs/API.md`, `docs/DATABASE.md`, `docs/TESTING.md`, `docs/ACCEPTANCE.md` | Specify session OPEN→SUBMITTED serialization, final event cutoff, reject writes after close, and complete score rows including unanswered session items. Keep scoring-specific unanswered/partial-credit values owner-gated. | Concurrency and empty/partial submission fixtures. |
| C-08 | `docs/PRD.md`, `docs/ARCHITECTURE.md`, `docs/UI_UX.md`, `docs/TESTING.md`, `DECISIONS.md` | Remove implied MVP offline write success; state AI-degraded online flows are required, while offline scope remains an explicit decision/deferred capability. | Cross-document review; no offline-write acceptance claim remains. |
| C-09 | `docs/ARCHITECTURE.md`, `docs/TESTING.md`, `docs/ACCEPTANCE.md`, `DECISIONS.md` | Make health/alert/restore evidence a pilot gate, with RPO/RTO and hosting targets explicitly owner-approved rather than invented. | Staging exercise against owner-approved targets; unapproved targets remain a gate. |
| C-12 | `docs/API.md`, `docs/TESTING.md`, `docs/ACCEPTANCE.md` | Address question publication by logical question and exact version ID, and verify the reviewed content hash. | Reject foreign/stale versions and prove concurrent drafts cannot change the published target. |

## Preserved decisions and gates

## Phase 0 plan revision corrections

| Revised finding | Files | Correction | Verification |
|---|---|---|---|
| P0-A | `docs/AGENT_WORKFLOW.md`, `PROJECT_STATUS.md`, `reports/phase0/AGY_AUDIT.md` | Require fresh-context, read-only independent review; record tool/model/version/time/scope/commit; distinguish timeout from PASS; owner alone accepts. | Inspect exact workflow and future report metadata; present AGY result remains incomplete. |
| P0-B | `docs/OPERATIONS.md`, `docs/TESTING.md`, `docs/AGENT_WORKFLOW.md` | Define required lint, typing, unit, integration, security, migration, build and E2E CI gates, exact-commit artifacts, and rerun rule. | Documentation consistency check now; future branch-protection/CI output required. |
| P0-C | `docs/AGENT_WORKFLOW.md` | Add requested task state machine, two-round default retry cap, escalation and mandatory scope/acceptance/test/rollback contract. | State transition and required-field review; implementation deferred. |
| P0-D | `docs/PRIVACY.md`, `docs/AI_GOVERNANCE.md`, `docs/SECURITY.md`, `docs/DATABASE.md`, `docs/API.md`, `docs/ACCEPTANCE.md` | Add minor privacy/access/deletion and current-law gate; AI allowlist/output/rate/cost/secrets; human AI-content verification; DB-enforced immutability. | Future DB role, privacy, security, AI abuse and publication tests; no legal claim. |
| P0-E | `docs/OPERATIONS.md`, `docs/ARCHITECTURE.md`, `docs/API.md`, `docs/TESTING.md`, `docs/ACCEPTANCE.md` | Define server-authoritative time, idempotent submit/cutoff, recovery, network pending state, no offline exam write, answer-key protection and owner-gated traffic targets. | Future drift/race/network/recovery/answer exposure/load tests. |
| P0-F | `docs/AI_GOVERNANCE.md`, `docs/ARCHITECTURE.md`, `docs/TRACEABILITY.md`, `DECISIONS.md` | Compare BKT/IRT/FSRS/heuristics on actual data and validation dimensions; choose none until evidence and owner approval. | Dated data inventory and held-out evaluation required before exposing learner recommendations. |
| P0-G | `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/API.md`, `docs/AI_GOVERNANCE.md`, `docs/ACCEPTANCE.md` | Move source verification/publishing before or alongside exam engine; AI only drafts; independent human reviews exact hash/source/answer/scoring. | Permission and publish-gate tests required before acceptance. |
| P0-H | `docs/TRACEABILITY.md`, `docs/AGENT_WORKFLOW.md` | Map each requirement through design/schema/API/planned implementation/test/acceptance; require exact paths and evidence before approval. | Check every matrix row and planned evidence links; application paths remain TBD before Phase 1. |

The new auditor report cited by the project owner was not available as a file or verbatim text in this workspace/message. This plan is based on the explicit findings/requirements in the revision request and the extant Codex audit, not attributed to an unseen report.

- No 2027 exam format, curriculum, scoring threshold, privacy rule, or legal conclusion will be invented.
- The React/TypeScript/Vite + FastAPI/Pydantic + PostgreSQL modular-monolith preference remains intact.
- Immutable published versions, append-only answer events, deterministic scoring, AI write restrictions, data isolation, and no Phase 1 code remain unchanged.
- Auth provider, question types, numerical adaptive thresholds, partial-credit policy, offline capability, privacy/retention, and operations targets remain owner decisions.
- No source document is deleted. Corrected text must match across API, schema, architecture, test, and acceptance documents.

## Completion evidence

After edits, run documentation consistency checks only: verify all required files and links exist, map every C-finding to updated sections, confirm no official exam claim was introduced, and record that no app tests were run. Independent AGY review remains outstanding and must not be replaced with Codex self-review.
