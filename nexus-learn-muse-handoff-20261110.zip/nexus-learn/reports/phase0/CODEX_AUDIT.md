# NEXUS LEARN Phase 0 — Codex Self-Audit

**Role:** Chief Architect / Technical Lead / Reviewer<br>
**Review date:** 2026-11-06<br>
**Scope:** Read all Phase 0 product, architecture, database, API, UI/UX, security, testing, acceptance, status, and decision documents. Findings below are design-document defects or explicit gates, not claims about unimplemented code.

## Findings

### C-01 — Answer events are not relationally bound to the exact session item

- **Severity:** HIGH
- **Documents:** `docs/DATABASE.md`, “ERD”, “Entity inventory”, and “Invariants and constraints” #2; `docs/API.md`, “POST /exam-sessions/{id}/answers”.
- **Evidence / problem:** The ERD links `ANSWER_EVENT` to `EXAM_SESSION` and `QUESTION_VERSION`, but has no session-item entity or link to `BLUEPRINT_ITEM`. API requests carry `item_id`, and responses say a session captures item/version references, yet the database section does not define what `item_id` references or constrain that the selected question version is the version in that session's blueprint. App code alone could accept a mismatched item/version or duplicate/foreign item.
- **Why it matters:** A malformed or raced write can attach an answer to the wrong question while still producing a structurally valid event; scoring and history would then be ambiguous.
- **Correction:** Define `session_items` (or an equivalent explicit key) materialized from the pinned blueprint, with unique session/position and exact blueprint-item/question-version references. Make answer events reference that session item; add composite foreign keys ensuring session, item, blueprint version, and question version agree. If a database-only session-item table is intentionally avoided, specify and test equivalent constraints explicitly.
- **Verification:** PostgreSQL integration tests must reject an answer whose item belongs to another session or whose question version differs from the pinned item; valid item submission and repeat events must succeed.

### C-02 — Redundant owner IDs are not constrained to match their parent session

- **Severity:** HIGH
- **Documents:** `docs/DATABASE.md`, “Entity inventory” (`exam_sessions`, `answer_events`, `score_results`) and “Invariants and constraints” #6.
- **Evidence / problem:** Both sessions and answer events are described as carrying an owner, with the rule that ownership may be direct or reachable. No composite key/FK rule is specified to ensure `answer_events.user_id = exam_sessions.user_id` (or an equivalent owner relation). API authorization is required, but the schema does not preserve this integrity if a service path mis-scopes an insert.
- **Why it matters:** Inconsistent ownership can cause tenant leakage or make event-based progress disagree with session-based results.
- **Correction:** Either remove the duplicated owner from dependent rows and derive it through a constrained parent relation, or declare composite unique keys and foreign keys enforcing owner/session agreement. Apply the same policy to AI artifacts and score rows if they store owner IDs.
- **Verification:** Database integration test attempts cross-owner session/event associations and expects FK rejection; API tests verify two-user read/write isolation.

### C-03 — Curriculum compatibility is named but its cardinality and integrity are unspecified

- **Severity:** MEDIUM
- **Documents:** `docs/DATABASE.md`, “ERD”, “Entity inventory” (`curriculum_profiles`, `question_versions`), “Open schema decisions”.
- **Evidence / problem:** The product requires multiple curricula. `question_versions` says “curriculum compatibility,” but the ERD/entity list has no explicit relation showing whether a version supports one or many curriculum profiles, how that association is versioned, or how topic IDs are scoped to a profile. The catalog separately says topics are profile-scoped.
- **Why it matters:** Implementers could encode a single curriculum field or use ambiguous topic identifiers, undermining the stated multi-curriculum requirement and filtering.
- **Correction:** Specify an explicit profile/version-to-question compatibility relation (or a documented immutable snapshot model), and constrain question-topic membership to the same curriculum profile and subject. Record effective/version semantics.
- **Verification:** Schema tests create one question version compatible with two profiles, reject a topic from the wrong profile/subject, and show profile-filtered queries return only compatible questions.

### C-04 — Idempotency key reuse with a different payload has no defined result

- **Severity:** MEDIUM
- **Documents:** `docs/API.md`, “Contract conventions”, “POST /exam-sessions/{id}/answers”, “Error contract”; `docs/DATABASE.md`, “Indexes and retention (proposal)”.
- **Evidence / problem:** The API says duplicate keys return the original result and lists `IDEMPOTENCY_CONFLICT`, but does not define a request fingerprint or say how the server handles reuse of the same `client_event_id` with a different `item_id` or response. The proposed unique index alone cannot distinguish a retry from conflicting payload reuse.
- **Why it matters:** Client retries or key bugs can silently lose a changed answer or create inconsistent event history.
- **Correction:** Persist a canonical request hash with the idempotency key. Same key plus same hash returns the original response; same key plus different hash returns `IDEMPOTENCY_CONFLICT`. Scope uniqueness to authenticated owner and session as needed.
- **Verification:** API integration tests assert identical retry is idempotent and changed payload with the same key returns the stable conflict code without appending an event.

### C-05 — Learner question responses lack an explicit answer-key disclosure boundary

- **Severity:** MEDIUM
- **Documents:** `docs/API.md`, endpoint inventory `GET /api/v1/questions` and `GET /api/v1/questions/{id}/versions/{version_id}`; `docs/DATABASE.md`, `question_versions`; `docs/UI_UX.md`, “Results review”.
- **Evidence / problem:** The stored question version includes a normalized answer key, and the results screen later displays the correct answer. The API only says “learner-safe fields only”; there is no explicit DTO rule or lifecycle condition preventing answer keys/scoring data from being returned before the relevant session is submitted or review is allowed.
- **Why it matters:** An accidental serialization of the full version object can expose answers during practice and undermine exam integrity.
- **Correction:** Define separate learner and scoring/editor representations. Explicitly exclude answer keys, hidden rubrics, and unreleased explanations from practice endpoints; define when a learner may see each field. Enforce access through server projection, not UI hiding.
- **Verification:** API schema/contract tests prove practice responses omit protected fields and post-submit authorized review exposes only the permitted fields.

### C-06 — Adaptive learning has no cold-start or insufficient-evidence behavior

- **Severity:** MEDIUM
- **Documents:** `docs/PRD.md`, “Purpose”, “Proposed MVP boundary”, “Success measures”; `docs/ARCHITECTURE.md`, “Adaptation/progress”; `docs/ACCEPTANCE.md`, “Progress/adaptation”; `docs/TESTING.md`, “Domain unit tests”.
- **Evidence / problem:** Adaptation is a confirmed product requirement, but no rule defines what progress/recommendations do with no answers, very few answers, stale results, or mixed curriculum/question provenance. Acceptance only asks that recommendations identify inputs/policy; testing names adaptation rules without defining low-sample cases.
- **Why it matters:** Sparse data can be presented as learner ability or a confident recommendation, misleading students and corrupting trust in progress measures.
- **Correction:** Add an explicit cold-start and low-evidence policy (for example, show “not enough practice data” and offer a neutral diagnostic set), define minimum evidence/confidence/recency treatment after owner approval, and never fabricate a proficiency estimate. Keep any numerical thresholds as an owner-approved decision, not an invented exam rule.
- **Verification:** Unit/API tests cover zero, one, sparse, stale, and mixed-source events; the UI/API returns the approved low-evidence state and does not emit unsupported mastery claims.

### C-07 — Session submission and answer-event concurrency are not ordered precisely

- **Severity:** MEDIUM
- **Documents:** `docs/API.md`, “POST /exam-sessions/{id}/answers”, “POST /exam-sessions/{id}/submit”, “Authorization and transaction requirements”; `docs/DATABASE.md`, `answer_events`, `exam_sessions`.
- **Evidence / problem:** Submission must use a stable event cutoff, and the API notes that post-submit policy is unresolved. The documents do not specify whether answer insertion and submit serialize on the session row, how a concurrent answer is accepted/rejected, or which committed answer set is scored.
- **Why it matters:** A learner may receive a result that excludes an answer the UI reported as saved, or an answer may be appended after a supposedly final result without a clear correction/re-score path.
- **Correction:** Define an explicit session state transition and transaction ordering: only OPEN sessions accept answer events; submit atomically closes the session and captures the final sequence/cutoff; concurrent writes either commit before the close and enter scoring or fail with `SESSION_CLOSED`. Treat post-submit correction as a separate auditable flow if approved.
- **Verification:** PostgreSQL concurrency tests race answer and submit and prove a single documented outcome, stable result hash, and idempotent repeated submit.

### C-08 — Offline success measure conflicts with deferred offline writes

- **Severity:** LOW
- **Documents:** `docs/PRD.md`, “Success measures to define with owner”; `docs/ARCHITECTURE.md`, “Deployment and operations proposal”; `docs/DECISIONS.md`, risk “Offline sync duplicates/conflicts”.
- **Evidence / problem:** PRD lists “successful offline/AI-degraded core flows” as a candidate measure, while architecture explicitly defers queued writes pending conflict rules. The wording can be read as an offline practice requirement even though the offline capability is not specified.
- **Why it matters:** Product acceptance can be interpreted as requiring offline answer submission while engineering plans only cached content.
- **Correction:** Split offline behavior from AI-degraded behavior. Until offline write semantics are approved, state that offline mode is read-only cached content (if intended) and measure AI-degraded online core flows; otherwise remove offline from candidate MVP success measures and keep offline as an open decision.
- **Verification:** PRD, architecture, UI, and acceptance describe one identical offline capability and an E2E test covers each promised offline action.

### C-09 — Operational release gate is not objectively verifiable

- **Severity:** MEDIUM
- **Documents:** `docs/ARCHITECTURE.md`, “Deployment and operations proposal”; `docs/TESTING.md`, “Operational checks” and “Release gates”; `docs/ACCEPTANCE.md`, “Data/migrations”; `DECISIONS.md`, M6.
- **Evidence / problem:** Hosting region, retention, recovery objectives, monitoring, and operational owner are deferred. M6 requires “operational monitoring” and backup restore but gives no measurable pass condition or recovery target; health/readiness is mentioned in testing but absent from API/architecture interfaces.
- **Why it matters:** “Pilot ready” can be declared without proving a recoverable database or detecting a failed service.
- **Correction:** Add an owner-gated operations decision covering service health signals, alert ownership, backup restore evidence, and approved recovery objectives. Define a measurable pilot gate only after the owner selects targets; do not invent RPO/RTO values.
- **Verification:** A runbook-backed staging exercise demonstrates health alerting and restore, measured against approved targets, and M6 links to the evidence.

### C-10 — Topic practice has no session creation contract

- **Severity:** HIGH
- **Documents:** `docs/UI_UX.md`, “Main learner flow” and frontend route map; `docs/PRD.md`, “Proposed MVP boundary”; `docs/API.md`, `POST /api/v1/exam-sessions`; `docs/DATABASE.md`, `exam_sessions`.
- **Evidence / problem:** UI offers “practice or configured exam” and topic practice, but the only session-creation request requires `blueprint_version_id`, and `exam_sessions` is described as holding an exact blueprint version. A practice session without an exam blueprint cannot be represented or started by the documented API/data model.
- **Why it matters:** A primary learner flow shown in UI and MVP scope is unimplementable under the current contract, or implementers may invent a second incompatible session path.
- **Correction:** Model a session kind (`exam` / `practice`) and immutable `session_items` for both. Exam items bind to exact blueprint items and question versions; practice items bind to exact question versions plus a recorded selection-policy/configuration snapshot. Make blueprint version required only for exam sessions. Document typed create requests.
- **Verification:** Contract/schema tests create both session kinds, prove exam versions are mandatory for exam sessions and absent for practice, and verify all session items retain exact question versions after source updates.

### C-11 — Scoring history does not specify unanswered items

- **Severity:** MEDIUM
- **Documents:** `docs/DATABASE.md`, “Entity inventory” (`score_results`, `score_items`) and “Invariants and constraints”; `docs/API.md`, submit response shape; `docs/ACCEPTANCE.md`, “Objective scoring”.
- **Evidence / problem:** A score item is described as linked to an answer event, but a learner may submit a session with unanswered items and there is no answer event for those items. The result shape promises per-item outcomes, yet the schema does not say whether `answer_event_id` is nullable or how unanswered items participate in total/max score.
- **Why it matters:** A valid incomplete submission can fail to produce a complete result or be scored differently by different implementations.
- **Correction:** State that score items cover every session item; an unanswered item has a null selected answer-event reference and a deterministic outcome/points value from the scoring policy. Keep exact partial-credit and unanswered-point rules gated on the owner selecting question/scoring types.
- **Verification:** Scoring fixtures cover fully answered, partially answered, and empty submissions; they produce stable per-item rows and totals for a fixed scoring-policy version.

### C-12 — Question publication endpoint does not identify the version being published

- **Severity:** MEDIUM
- **Documents:** `docs/API.md`, endpoint inventory `POST /api/v1/editor/questions/{id}/publish` and “Authorization and transaction requirements”; `docs/DATABASE.md`, “question_versions”.
- **Evidence / problem:** Question versions are immutable successors, but the publish route identifies only the logical question `{id}`. The prose says the reviewed transaction publishes an exact version without specifying how that version is selected in the request/path.
- **Why it matters:** Concurrent drafts or a newer version can make the reviewer approve one snapshot while the service publishes another.
- **Correction:** Address publication by explicit version ID, e.g. `POST /api/v1/editor/questions/{id}/versions/{version_id}/publish`; validate the version belongs to the question and the reviewed content hash matches.
- **Verification:** API tests submit a version from another question, a stale hash, and concurrent successor versions; only the exact reviewed version can publish.

## Open decisions (not classified as defects)

- Authentication provider/session mechanism, question types, scoring details, exam source/curriculum selection, post-submit correction policy, learner age/privacy/retention rules, AI data sharing, and numeric adaptation thresholds require owner input.
- The docs correctly avoid asserting official 2027 exam structure. No official-rule claim was found in the reviewed text.

## Coverage and limitations

All ten requested documents were inspected. No product code exists, so no runtime behavior, migration, API, or test result was inferred. AGY review status is recorded separately in `AGY_AUDIT.md`.
