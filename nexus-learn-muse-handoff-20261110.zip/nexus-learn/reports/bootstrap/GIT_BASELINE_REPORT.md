# NEXUS LEARN — Git Baseline Setup Report

**Status: PASS — baseline committed and verification report prepared.**<br>
**Repository:** `/data/data/com.termux/files/home/nexus-learn`<br>
**Branch:** `main`<br>
**Baseline commit SHA:** `71795e2beb6c2c6c7f39c4e5671ec7eda7fa8515`<br>
**Commit identity:** `FangYuan36 <313061649+FangYuan36@users.noreply.github.com>` (author and committer).

## Preflight

| Check | Status | Evidence |
|---|---|---|
| Working directory | PASS | `pwd -P` → `/data/data/com.termux/files/home/nexus-learn`. |
| Git root | PASS | `git rev-parse --show-toplevel` → `/data/data/com.termux/files/home/nexus-learn`. |
| Branch | PASS | `git branch --show-current` → `main`. |
| Starting history/status | PASS | `git status --short --branch` showed `No commits yet on main`; no prior commit exists (`git rev-parse --verify HEAD` reports no revision). |
| Remote | PASS | `git remote` returned no configured remotes. No remote was added and nothing was pushed. |
| Repository-local Git identity | PASS | `git config --local --get user.name` → `FangYuan36`; `git config --local --get user.email` → `313061649+FangYuan36@users.noreply.github.com`. Global identity was not changed. |
| Runtime | PASS | Linux Android 14 kernel, `aarch64`; Node `android/arm64 v26.13.0`; Python `android 3.14.10`; Termux `PREFIX=/data/data/com.termux/files/usr`, `TERMUX_VERSION=0.118.3`. |
| Workspace boundaries | PASS | No files were changed in `/storage/emulated/0/collab` or `/storage/emulated/0/anti`; no workspace was moved. |

## Ignore rules and runtime files

Existing `.gitignore` rules were retained. Python caches/bytecode, virtual environments, private-key files (`*.pem`, `*.key`, `id_rsa*`, `id_ed25519*`), secret directories, local `*.log`, `node_modules/`, and `dist/` each have one matching rule. Idempotent rules were added once for:

- `agent-hub/logagy.txt`
- `agent-hub/logds.txt`
- `agent-hub/processed_tasks.jsonl`
- `agent-hub/task_state.json`

`agent-hub/README.md` identifies `agent-hub/chung.txt` as the Agent Hub conversation log; this runtime artifact was also ignored. The files remain on disk and are not staged. `git check-ignore -v --no-index` confirmed the runtime, cache, key, log, and generated-build patterns. No `.env` or `job1.zip` is present in this repository. `node_modules/` is absent in the repository; the locked dependency cache used for checks is outside the repository under Termux temporary storage.

## Security audit

**PASS.** Filename and content scans covered the 58 staged baseline files, all UTF-8 text. No suspicious secret filenames, private-key blocks, real credentials, or foreign project paths were found. No secret values were printed or transmitted.

Two pattern matches were manually classified as safe, with values suppressed:

- `agent-hub/deepseek_client.py`: API key is supplied as a parameter or read from `DEEPSEEK_API_KEY`; there is no literal credential.
- `agent-hub/tests/test_deepseek.py`: a synthetic fake-key fixture used to test log masking.

`agent-hub/config.example.json` contains the environment-variable name only. `agent-hub/chung.txt` and `agent-hub/rqcodex.txt` were scanned; `chung.txt` was excluded as runtime output. The staged scan found no unreviewed match requiring a hold.

## Baseline file review

**Staged for the initial baseline, not committed:** 58 NEXUS LEARN files. Every staged path is an addition within the repository. No `git add -A` was used. The 58-file baseline set had 6,054 insertions. After adding this report, the final staged stat was **59 files changed, 6,179 insertions**. The full staged name-status list was reviewed; all entries were `A` and none were outside NEXUS LEARN.

```text
.gitignore
AGENTS.md
AGY_REPORT.md
CODEX_REVIEW.md
DECISIONS.md
NEXUS_LEARN_PRODUCT_BRIEF_AND_CODEX_PROMPT.md
PLANS.md
PROJECT_STATUS.md
README.md
TASKS.md
agent-hub/AGENTS.md
agent-hub/README.md
agent-hub/bridge.py
agent-hub/config.example.json
agent-hub/deepseek_client.py
agent-hub/rqcodex.txt
agent-hub/tests/run_all_tests.py
agent-hub/tests/test_bridge.py
agent-hub/tests/test_deepseek.py
docs/ACCEPTANCE.md
docs/AGENT_WORKFLOW.md
docs/AI_GOVERNANCE.md
docs/API.md
docs/ARCHITECTURE.md
docs/DATABASE.md
docs/OPERATIONS.md
docs/PRD.md
docs/PRIVACY.md
docs/SECURITY.md
docs/TESTING.md
docs/TRACEABILITY.md
docs/UI_UX.md
docs/adr/ADR-001-stack-and-bootstrap-boundaries.md
docs/research/COMPETITOR_RESEARCH.md
docs/superpowers/plans/2026-11-07-nexus-bootstrap.md
index.html
package-lock.json
package.json
reports/bootstrap/PRE_DISPATCH_RECONCILIATION.md
reports/bootstrap/PRE_DISPATCH_VERIFICATION.md
reports/bootstrap/REPOSITORY_RECON.md
reports/phase0/AGY_AUDIT.md
reports/phase0/CODEX_AUDIT.md
reports/phase0/CORRECTION_PLAN.md
reports/phase0/FINAL_VERIFICATION.md
reports/phase0/FINDINGS_RECONCILIATION.md
reports/phase0/REVISED_AUDIT.md
reports/phase0/TRACEABILITY_REVIEW.md
scripts/run.mjs
scripts/test-discovery.d.mts
scripts/test-discovery.mjs
src/App.tsx
src/domain/contracts.test.ts
src/domain/contracts.ts
src/main.tsx
src/styles.css
tsconfig.json
vite.config.ts
```

Excluded from the baseline: `node_modules/`, generated `dist/`, Python cache/bytecode and virtual environments, `.env*` files, private keys, local logs, the four named Agent Hub state/log files, `agent-hub/chung.txt`, and `job1.zip` (absent). No feature code was edited. To make the required whitespace check pass without changing Markdown rendering, 23 existing trailing-space hard breaks in 13 Markdown files were converted to explicit `<br>` line breaks; the text content and line breaks are preserved.

## Checks

| Command | Status | Result |
|---|---|---|
| `npm test` | PASS | Exit 0; 10 tests passed, 0 failed. Ran from the existing lockfile-matched Termux dependency staging; no package versions or dependencies were changed. |
| `npm run build` | PASS | Exit 0; TypeScript check passed and Vite 8.3.6 transformed 16 modules and built successfully. Generated `dist/` is ignored. |
| `python3 agent-hub/tests/run_all_tests.py` | PASS | Exit 0; 9 Agent Hub tests passed. |
| `git diff --cached --check` | PASS | Exit 0 after Markdown hard-break preservation adjustment. |
| `git diff --cached --stat` | PASS | Initial baseline set: 58 files, 6,054 insertions; final staged index including this report: 59 files, 6,179 insertions. |
| `git diff --cached --name-status` | PASS | Full final list reviewed; 59 additions, no foreign paths or excluded runtime artifacts. |
| Baseline candidate secret scan | PASS | 58 text files scanned; no real secret found. After adding this report, the final combined 59-file staged scan found only the same two safe matches noted above. |

## Commit result

The baseline commit succeeded:

- **SHA:** `71795e2beb6c2c6c7f39c4e5671ec7eda7fa8515`
- **Subject:** `chore: establish NEXUS LEARN bootstrap baseline`
- **Author and committer:** `FangYuan36 <313061649+FangYuan36@users.noreply.github.com>`

This report is being saved in a separate documentation commit as requested. No remote was configured, no push or history rewrite occurred, and no feature code or TASK-NL-001 implementation was performed. No AGY task was claimed or started.
