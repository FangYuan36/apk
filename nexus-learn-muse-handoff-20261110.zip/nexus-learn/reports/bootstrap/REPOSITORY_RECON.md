# NEXUS LEARN — Repository Recon Report

**Date:** 2026-11-07<br>
**Workspace:** `/storage/emulated/0/collab` (shell path `/sdcard/collab`)<br>
**Purpose:** Establish the actual starting state for the product bootstrap without treating adjacent or archived material as NEXUS source.

## Repository and history

- The workspace contains NEXUS product/engineering documents and the local Python Agent Hub.
- No `.git` directory is present at the workspace root or its parents within the accessible project area. `git status`, branch, commit history and a VCS baseline therefore cannot be produced.
- A nearby Git checkout at `/storage/emulated/0/anti` is a separate TX statistical research project. At recon it was on `master` with 36 modified/untracked paths. It was not edited.
- `job1.zip` was listed but not opened/extracted. Its file listing includes `main-4.py`, tests, requirements, and a `.env`; it is not identified as NEXUS and may contain credentials.

## Files and implementation baseline

- NEXUS product brief and decision/status docs: present.
- Product/engineering docs: PRD, architecture, database, API, UI/UX, security, privacy, AI governance, testing, acceptance, operations, agent workflow, and traceability present.
- Phase 0 reports: Codex audit, AGY audit, correction plan, findings reconciliation, revised audit, traceability review, and final verification present.
- Agent Hub: `agent-hub/bridge.py`, `deepseek_client.py`, config example, task files, and offline tests present.
- Application baseline: no source app, `package.json`, lockfile, frontend/backend build script, migration, CI config, or product feature tests existed at the start of recon.
- Existing Phase 0 records explicitly say no app code/tests were run; this remains accurate for that milestone. The later bootstrap tests are recorded separately.

## Existing decisions reconciled

- Preserve the preferred React + TypeScript + Vite / FastAPI + Pydantic / PostgreSQL stack and modular monolith.
- Preserve immutable question/blueprint versions, append-only answer history, deterministic objective scoring, AI as optional/advisory, provenance and human content review, and no unsupported official 2027 claims.
- Keep old D-009 as the historical Phase 0 no-code decision. The 2026-11-07 request adds a separate bootstrap scope (D-019).
- Permit a configurable review due date for the first slice without selecting a mastery model (D-020; D-017 remains active for mastery algorithms).
- Preserve personal-first scope and defer school/LMS tenancy (D-021).
- Agent Hub was IDLE with zero processed task IDs; `parse` initially found no task. `agy` CLI was installed, but `agy agents` exposed no available executor entries.

## Runtime and package evidence

- Observed: Node `v26.13.0`, npm `12.2.2`, Python `3.14.10`.
- Earlier project note: Node 22.22.1, treated as historical. Vite 8.3.6's declared engine floor is `^20.19.0 || >=22.12.0`.
- Current npm `latest` TypeScript resolved to 7.0.2 and attempted to resolve `@typescript/typescript-android-arm64`, which was missing. TypeScript 5.9.3 was pinned. Android shared storage also prevented executing/loading native build bindings directly from `/sdcard`.
- `scripts/run.mjs` stages locked source/dependencies in `$PREFIX/tmp/nexus-learn-runtime`; test/build and local server checks succeeded through that mechanism.

## Baseline and final checks

No app tests existed before bootstrap. The pre-existing Agent Hub code was not changed; after adding the task prompt, its offline suite ran successfully: 9 tests passed. App/domain checks and HTTP output are recorded in `PROJECT_STATUS.md` and `CODEX_REVIEW.md`. Browser-based visual inspection, CI, Git history and independent AGY review remain unavailable/not run.

## Initial risk register

| Risk | Evidence | Gate |
|---|---|---|
| Runtime/build compatibility | Android shared storage cannot execute native files; TypeScript 7 Android platform package missing | Pin compatible tooling and run in Termux private storage; recheck actual engines on changes |
| Data persistence | No backend, API, DB or storage exists | Label shell as non-persistent; decide personal-data export before account/migration work |
| Secrets | Archive contains an uninspected `.env`; no repo app config exists | Do not extract archive; no browser secrets; keep env files ignored |
| Content copyright/provenance | No reviewed source/question fixtures present | Use synthetic test-only questions; source/license/human-review gate before publishing |
| Math rendering/answer validation | KaTeX and scoring implementation absent | Add only with an approved question format and deterministic tests |
| Responsive behavior | No prior UI or browser available | CSS uses a 720px breakpoint; actual viewport/accessibility review still needed |
| Lack of verified test data | No learner attempts or authoritative taxonomy data | Abstain on mastery; do not label synthetic data official/verified |
