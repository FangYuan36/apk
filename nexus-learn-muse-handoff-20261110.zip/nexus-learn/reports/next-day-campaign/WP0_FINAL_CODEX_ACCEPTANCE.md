# WP0 Final Codex Independent Verification

**Campaign:** NEXUS LEARN Operational 90
**Repository:** /data/data/com.termux/files/home/nexus-learn
**Branch / HEAD:** main / b502fa7120cadd460c0e224d67fc5b1d8ac43691
**Audit mode:** source/diff/test inspection; no application or acceptance-test edits.
**Verdict: REPAIR REQUIRED.** WP1 is blocked pending a focused AGY repair and a new Codex gate. This is not Product Owner acceptance.

## Repository and scope

At audit start, the working tree already contained the prior dirty TASK-NL-001/TASK-NL-002 and campaign files. Modified tracked paths included AGENTS.md, docs, package.json/package-lock.json, src/App.tsx, src/domain/contracts.ts and prior records. Untracked trees included src/domain/math, src/features, src/infrastructure, src/content, src/acceptance, and campaign docs. No staged paths were reported. No destructive Git operation was run.

AGY_REPORT.md lists these WP0 paths: validator.ts, provenance.ts, scoring-policy.ts, scorer.ts, attempt.ts, index.ts, math-domain.test.ts, MathLearningView.tsx, MathLearningView.test.tsx, App.tsx, AGY_REPORT.md. These are permitted by the current Operational 90 brief; index.ts is expressly allowed for the reviewer helper export. The conditional IndexedDB repository/types files are not in AGY's reported list. The Codex-protected acceptance test was revised before AGY handoff and remains distinct from AGY's reported changes.

Because source/test trees were already untracked and package files were already modified before WP0, Git cannot reconstruct exact before/after attribution for those paths. The AGY file list is therefore reported evidence, not a complete Git-verifiable delta. No new dependency is listed by AGY, but a task-local manifest delta cannot be independently proved from this baseline.

## Findings

### WP0-A — Canonical content integrity: HIGH — FAIL

Positive checks: canonical serialization sorts keys, normalizes strings to NFC, rejects NFC-colliding keys/cycles/non-finite values. When a question body is present, publication resolves the matching solution from context and hashes its explanation/steps/keyPoints; the embedded solution override test passes.

Failure: validator.ts has a separate no-body branch that accepts any non-empty declared contentHash and uses it as the expected review hash. The solution check then accepts a matching SolutionVersion whose only fields are ID/question/version and whose explanation/steps/keyPoints are absent. The protected publication acceptance fixture has no question body and exactly such a sparse solution, yet asserts eligible=true; the full acceptance run passed. Therefore a reviewed hash does not necessarily bind actual question/answer/solution content, and publication can be eligible without required solution content. This defeats the otherwise correct canonical hash path.

**Required:** require a valid question body and complete exact SolutionVersion for publication, compute one canonical hash from actual content, and reject missing/sparse solution instead of trusting declared contentHash.

### WP0-B — Reviewer authorization: HIGH — FAIL

Positive checks: no bare-ID special branch or default registry was found. Review-attached authorization evidence is ignored by publication. Registry entries are matched by reviewer ID; active status, subject and malformed/expired/not-yet-valid dates are checked.

Adversarial failures:
- validateReviewerAuthorization accepts an entry with no authorizedCurriculumVersionIds for a requested curriculum. Direct probe output: authorized=true, errors=[] (validator.ts:112-121).
- Date.parse is used without strict ISO-format validation; JavaScript-accepted non-ISO date strings can pass.
- No production authority/registry exists in this client repository. Explicit fixture injection demonstrates contract behavior only, not a real reviewer. No current pilot candidate is approved as a result of this test.

**Required:** curriculum authorization must be mandatory and exact; validate timestamp syntax and interval strictly. Keep publication fail-closed when authority is absent. Do not represent fixture evidence as a qualified human.

### WP0-C — Provenance and license: HIGH — FAIL

Positive checks: publication passes the operation string publish to isLicenseValidAt; licensed status requires allowedOperations to include it; license status uses an allowlist; source provenance kind and non-empty reference are checked.

Failures:
- For status original, missing allowedOperations is accepted for any operation. Direct probe: isLicenseValidAt(original, ..., publish) returned true with no operation permissions.
- attributionRequired and commercialUseAllowed are declared but not enforced anywhere in publication validation.
- Any non-empty reference plus a recognized provenance kind satisfies SourceAsset validation; it is not checked as traceable rights evidence or proof of permission.
- public_domain is accepted as a provenance kind but the publication license allowlist excludes open status; synthetic/original combinations do not establish rights. No source type combination makes metadata itself proof of legal ownership.

**Required:** operation permission and rights evidence must fail closed for every publishable provenance/license class; explicitly enforce attribution/commercial conditions when applicable and document that metadata is not legal verification. Keep all pilot content draft without actual evidence.

### WP0-D — Scoring policy: HIGH — FAIL

Positive checks: constructor and scorer share validateScoringPolicyVersion; required flags/separator fields and finite/nonnegative point values are checked; policy is still PROPOSED/practice-only. Ordinary MCQ/T-F/numeric suites pass.

Failure: scoreQuestionVersion clamps with Math.min/Math.max (scorer.ts:313-315), but policy validation does not check aggregate arithmetic for overflow. Direct adversarial probe with finite Number.MAX_VALUE points and bonus returned policy valid=true and status=scored with totalPoints=Infinity and maxPoints=Infinity (part values were also Infinity). Clamping neither rejects nor repairs this invalid result. This violates finite score and 0 ≤ total ≤ max invariants.

**Required:** reject aggregate overflow/non-finite derived maxima before scoring; remove silent clamping as a substitute for invariant validation; return a distinct invalid-policy/execution error and never persist it as a scored attempt.

### WP0-E — Delayed recheck linkage: HIGH — PARTIAL / FAIL

Verified: schedule sourceAttemptId is resolved from stored event history; event QuestionVersionRef is compared on question ID, version and content hash; question lookup uses all three; recheck has a distinct session state and event flag, and skill selection is disabled. Schedule completion is included in saveSessionAndAttempt and UI success follows the awaited repository write.

Failure: the resolver never compares schedule.sourceSkillId/skillId with the source question's skill mapping or source session's skill. A valid source attempt for another skill can be attached to a schedule and then presented as that schedule's recheck. The existing tampered-hash/missing-event tests do not cover this case.

**Required:** validate schedule skill, source attempt/session skill and question mapping consistently before recheck. Mismatch must preserve due schedule and show recovery without creating an event.

### WP0-F — AttemptEvent integrity: HIGH — FAIL

Positive checks: constructor and append use validateAttemptEvent; accepted values are deep-cloned/frozen; ordinary duplicate IDs are rejected.

Adversarial failures from direct runtime probe:
- A TRUE_FALSE_CLUSTER response containing a string answer instead of boolean/null and a result with totalPoints=99, maxPoints=1 was accepted by validateAttemptEvent.
- Appending the same logical ID once as “evt” and again as “ evt ” returned a history length of 2 because validation allows surrounding whitespace and append compares unnormalized IDs.
- NativeIndexedDBRepository saveAttemptEvent/saveSessionAndAttempt do not call validateAttemptEvent; direct repository callers can persist malformed events despite the validator.

Nested PartEvidence fields and reconciliation against result totals/max are also not fully validated.

**Required:** validate normalized identity, nested response values, result/part bounds and reconciliation; use the validator at persistence write boundaries. Duplicate/malformed inputs must reject without changing history or storage.

### WP0-G — Persistence disclosure and errors: MEDIUM — PARTIAL

Verified: the footer no longer asserts IndexedDB/cloud; the Study view labels the selected adapter; initial read errors are surfaced; save success is after awaited repository completion; native write promises resolve on transaction completion and reject on abort/error.

Limitations/failures:
- The footer still says device-local storage without distinguishing volatile memory mode; the Study badge is more precise.
- clearLocalData failure has no local try/catch/error presentation in the view.
- Native IndexedDB and reload recovery were NOT RUN in a real browser. Tests use the in-memory adapter/jsdom and cannot establish browser storage behavior.
- No browser engine was available for this audit.

**Required:** clarify memory-only volatility globally or make the label adapter-aware; surface reset failure. Keep Native IndexedDB marked NOT VERIFIED until an actual browser run.

## Test and build evidence

Commands were executed against the current source. Focused commands used the configured tsx runner in the repository's temporary runtime copy, not raw Node TSX execution.

| Command | Exit | Result |
|---|---:|---|
| Focused domain: tsx --test src/domain/math/math-domain.test.ts | 0 | 27 passed, 0 failed, 0 skipped |
| Focused UI: tsx --test src/features/learning-core/MathLearningView.test.tsx | 0 | 7 passed, 0 failed, 0 skipped; 4 React act warning blocks |
| npm test | 0 | 94 total: 83 passed, 0 failed, 11 skipped |
| NEXUS_NL002_ACCEPTANCE=1 npm test | 0 | 94 total: 94 passed, 0 failed, 0 skipped |
| npm run build | 0 | TypeScript and Vite production build passed |
| python3 agent-hub/tests/run_all_tests.py | 0 | 9/9 passed |
| git diff --check | 0 | Passed for tracked diff |
| Browser / Native IndexedDB / mobile | NOT RUN | No browser executable available |

Both full mounted-UI suites emitted React act(...) warnings (five warning blocks per full run). Green tests do not cover the adversarial cases above. The 11 skipped default tests are acceptance-gated; with NEXUS_NL002_ACCEPTANCE=1 they ran and passed, but do not prove legal rights, real reviewer identity, native IndexedDB or mobile layout.

## Gate decision

**WP0: REPAIR REQUIRED.** HIGH findings remain in A, B, C, D, E and F; G is partially complete with MEDIUM runtime-verification/error-state limitations. Do not start WP1. Repair scope is in docs/agent-handoffs/AGY_OPERATIONAL_WP0_FINAL_REPAIR_BRIEF.md. AGY must be sole writer during repair; Codex remains read-only. Product Owner alone accepts.
