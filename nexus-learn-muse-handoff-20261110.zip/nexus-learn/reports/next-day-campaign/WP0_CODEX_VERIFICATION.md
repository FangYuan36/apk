# WP0 Codex Independent Verification

**Task:** NL-MVP-50-WP0
**Repository:** `/data/data/com.termux/files/home/nexus-learn`
**Verified:** 2026-11-09
**Branch / HEAD:** `main` / `b502fa7120cadd460c0e224d67fc5b1d8ac43691`
**Mode:** read-only source/diff/tests; no acceptance test or source edits
**Overall result:** **REPAIR REQUIRED** — WP0-B remains blocked, and WP0-A/C/D/E contain acceptance-impacting gaps.

## Repository and scope

- `git status --short`: existing modified files include repository governance/docs, `AGY_REPORT.md`, `CODEX_REVIEW.md`, `PLANS.md`, `PROJECT_STATUS.md`, `TASKS.md`, package manifests, `src/App.tsx`, `src/styles.css`, and existing source files. Existing untracked trees include `src/domain/math/**`, `src/features/**`, `src/content/**`, `src/components/**`, `src/infrastructure/**`, acceptance tests, and campaign docs.
- No staged files. No reset/clean/checkout/stage/commit/push/delete was run. The only build output was the repository's ignored `dist/`.
- Pre-WP0 notes already recorded the math implementation as untracked. Therefore Git cannot show file-level diffs for that tree; AGY's appended report is the available changed-file declaration. Do not infer every currently untracked file was created by WP0.
- AGY's WP0 file list declares 11 paths. Ten fit the brief's allowlist. **Scope deviation:** `src/domain/math/index.ts` is not in the WP0 allowlist, but AGY reports editing it to export `validateScoringPolicyVersion` (AGY_REPORT.md:661). It was already in the pre-existing untracked math tree, so the exact pre/post contents cannot be reconstructed from Git. The reported edit is still out of scope; it is not silently approved. No dependency change is declared for WP0; package manifests were already dirty before WP0.
- AGY_REPORT.md says all changed files are within the allowlist, which conflicts with its own `index.ts` list. Its WP0-B BLOCKED disclosure is accurate and important; other FIXED/PASS claims below are not all borne out by source.

## Findings by WP0

### WP0-A — Content hash and solution binding: **HIGH — FAIL**

Canonical serialization sorts object keys recursively, normalizes string values to NFC, preserves arrays and rejects non-finite/unsupported/cyclic values. Hashing includes body, identity, skill mapping and solution fields when a `solution` object is supplied. The added stale-review test covers a changed solution in the context-only path.

Two runtime bypasses remain:

1. If the context's matching `SolutionVersion` contains no explanation/steps/keyPoints, `validatePublication` omits solution content from the hash and accepts publication. Direct probe result: `eligible: true` with a matching solution record containing only id/question/version and a review of the hash without solution content.
2. If the QuestionVersion object carries a `solution` property, validator prefers that caller-supplied object over the actual matching solution in `context.solutions` (`validator.ts:195`). Direct adversarial probe supplied the reviewed embedded solution and a tampered actual context solution; result was `eligible: true`.

Thus the old hash can still authorize content whose actual solution differs or is missing. Require complete actual solution data from the trusted version source, hash that exact record only, and fail closed when unavailable. Existing tests prove the hash helper changes with supplied solution fields; they do not cover these validator bypasses.

Additional canonicalization edge: a direct probe with both NFC key é and decomposed key e+combining-acute serialized both as duplicate é keys instead of rejecting the collision. Canonical object serialization should reject keys that collide after normalization.

### WP0-B — Reviewer authorization: **BLOCKED — HIGH**

The `qualified-reviewer` bypass remains at `validator.ts:335-342`. The protected acceptance suite expects a bare `reviewerId: 'qualified-reviewer'` to authorize an otherwise valid publication (`scoring.acceptance.test.ts:214`). No default registry is present, but the hard-coded bypass itself remains and lets publication through without authorization. Additional issues in the evidence path: caller-supplied `authorizationEvidence` on a review is trusted before the injected registry; malformed validity dates are ignored because comparisons run only when parsed timestamps are finite; curriculum authorization IDs are not checked.

Do not change the protected test in this audit and do not accept the bypass as fixed. The conflict is real: strict fail-closed behavior and the current protected assertion cannot both pass as written.

**Safe PO choices:**
1. Authorize a new acceptance-contract revision that changes the protected test to pass explicit trusted test-fixture authorization evidence, then remove all bare-ID/self-asserted-evidence bypasses. Test fixture evidence must remain clearly synthetic and must not represent an actual reviewer.
2. Keep the current protection and fail-closed security requirement; leave publication blocked and the acceptance conflict unresolved until the PO authorizes a compatible test-contract change.

There is no safe option that keeps the current bare-ID assertion green by preserving a production bypass or default synthetic registry.

### WP0-C — Provenance and license: **HIGH — FAIL**

Correctly present: publication status whitelist is `original|licensed`; license constructors reject malformed dates and inverted intervals; `isLicenseValidAt` can reject a requested operation if the caller supplies one; source reference must be non-empty.

Gaps:
- `validatePublication` calls `isLicenseValidAt(lic, now)` without the required publication operation (`validator.ts:270`). `allowedOperations` is therefore not enforced for publication. The utility also permits all operations when the field is absent.
- `attributionRequired` and `commercialUseAllowed` are stored but never enforced by publication validation.
- `sourceAssets` context fields are optional; validator requires a reference but accepts missing `provenanceKind`, issuer/date/rights evidence. An arbitrary ID plus a string reference is not proof of source rights.
- No content validation establishes that a status of `original` proves authorship/ownership. Metadata must not be described as legal permission.

The whitelist/date tests do not cover publication-operation, attribution, commercial or derivative-right enforcement. Keep content draft until required evidence exists.

### WP0-D — Scoring policy: **HIGH — FAIL**

Constructor delegates to runtime validation, and both reject NaN/infinity/negative scalar fields and negative tolerance. Status remains `proposed`; UI description labels it experimental practice scoring.

Runtime validation is incomplete:
- Missing `allowExponent` is accepted (`validateScoringPolicyVersion` returns valid); missing `groupingSeparators` is accepted although the policy interface requires it.
- No invariant bounds incorrect/empty points against the attainable maximum.
- No partial-credit/bonus relationship prevents a scored total exceeding max.

Direct probe: policy with four T/F parts, `pointsPerCorrectStatement=1`, `pointsIncorrect=2`, `pointsEmpty=2` validates as valid and an all-wrong response returns **8/4**, status `scored`. Constructor and runtime validator agree because they share the same incomplete validator; agreement is not sufficient correctness. No official policy claim was observed.

### WP0-E — Delayed recheck: **HIGH — PARTIAL / FAIL**

Implemented correctly: recheck selects by question ID/version rather than current array index; missing lookup produces a recoverable error; navigation buttons are hidden in recheck mode; successful writes use a distinct recheck session and `isDelayedRecheck: true`; schedule completion is included in the same `saveSessionAndAttempt` transaction and only visible after its promise resolves.

Remaining gaps:
- Lookup checks question ID and version but **not contentHash** (`MathLearningView.tsx:90-94`). A different body/hash under the same ID/version is accepted as the source.
- It does not resolve `sourceAttemptId` from history or verify that the referenced attempt points to the same question-version ref.
- The test exercises an in-memory schedule and does not test tampered/mismatched hash or source attempt.
- Recheck session ID is constant per skill (`session-recheck-${skillId}`), so later rechecks for that skill reuse that session rather than receiving distinct session identities.
- Changing the skill selector exits recheck mode; this is explicit user navigation, but no confirmation preserves the active recheck context.

### WP0-F — Deep immutable append: **MEDIUM — PARTIAL**

Deep clone/freeze now occurs even for an outer shallow-frozen object; the added test proves later mutation of nested response/result/evidence does not alter the appended snapshot. Duplicate IDs fail before returning new history.

Malformed validation remains shallow. Direct probe appended `Object.freeze({id:'m', sessionId:'s', questionVersionRef:{}, scoringPolicyVersionRef:{}})` and returned a one-entry history. Missing question ID/version/hash, policy ID/version, response, result, part evidence and timestamp are not rejected by `appendAttemptEvent`. The function isolates data but does not yet enforce a valid AttemptEvent schema.

### WP0-G — Persistence disclosure: **MEDIUM — PARTIAL**

The footer now explicitly says local device IndexedDB and no server/cloud storage. Learning UI chooses `createPersistenceRepository()`; browser IndexedDB adapter's write methods resolve on `tx.oncomplete`, and `saveSessionAndAttempt` uses a multi-store transaction. Save success notification occurs only after repository promise resolves; submit failures surface a storage error. The UI also distinguishes native IndexedDB from in-memory mode.

Limitation: footer's IndexedDB claim is unconditional while the repository factory can select in-memory mode when browser IndexedDB is unavailable; the study badge then says In-Memory. Startup `refreshStorageData` catches errors silently. No browser was available, so active browser storage, persistence, reload, transaction failures and this fallback interaction are NOT VERIFIED.

## Test execution

| Command | Exit | Result |
|---|---:|---|
| `node --test src/domain/math/math-domain.test.ts src/features/learning-core/MathLearningView.test.tsx` | 1 | Raw Node runner cannot resolve extensionless TS imports and rejects `.tsx`; TAP reports 2 test files failed, 0 passed, 0 skipped. This command is not the repository wrapper. |
| `npm test` | 0 | 87 total: 76 passed, 0 failed, 11 skipped. The 11 acceptance tests are gated off by default. React `act(...)` warnings were emitted. |
| `NEXUS_NL002_ACCEPTANCE=1 npm test` | 0 | 87 total: 87 passed, 0 failed, 0 skipped. This includes the protected bare-reviewer expectation; therefore suite green does not clear WP0-B. React `act(...)` warnings were emitted. |
| `npm run build` | 0 | TypeScript/Vite production build passed; JS 284.93 kB (gzip 84.17 kB). |
| `python3 agent-hub/tests/run_all_tests.py` | 0 | 9/9 passed. |
| `git diff --check` | 0 | No whitespace errors in tracked diff. |

Test evidence is primarily unit and jsdom-mounted React integration using `InMemoryPersistenceRepository`. The repository persistence tests are in-memory only. No browser executable, Playwright, Puppeteer, or fake-indexeddb package was available. **Native IndexedDB, actual reload recovery, transaction abort/quota behavior in a browser, and mobile viewport inspection are NOT VERIFIED.** No test result substitutes for these checks.

## Overall gate and open limitations

**WP0 result: REPAIR REQUIRED.** WP0-A, WP0-C, WP0-D and WP0-E have HIGH findings; WP0-B is explicitly BLOCKED; WP0-F/G remain partial MEDIUM findings. Build and test pass do not close these invariants.

Other product limitations remain: all 15 pilot questions are draft; no qualified mathematics reviewer has been verified; scoring policy is PROPOSED/practice-only; no backend/auth/cloud sync; no production AI Tutor/AI Agent; no mobile visual inspection. Product Owner acceptance is not recorded and remains exclusively with the PO.

A narrowly scoped follow-up is prepared in [AGY_WP0_REPAIR_BRIEF.md](../../docs/agent-handoffs/AGY_WP0_REPAIR_BRIEF.md). WP0-B must wait for the PO's choice above before any writer changes its acceptance contract. This verification is not acceptance.
