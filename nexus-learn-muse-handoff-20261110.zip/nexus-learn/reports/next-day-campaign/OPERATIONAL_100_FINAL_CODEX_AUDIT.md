# NEXUS LEARN — Operational Campaign Final Codex Audit

**Audit:** Read-only source, tests, build, and repository inspection after AGY stopped
**Repository:** /data/data/com.termux/files/home/nexus-learn
**Branch / HEAD:** main / b502fa7120cadd460c0e224d67fc5b1d8ac43691
**Verdict: REPAIR REQUIRED. This is not Product Owner acceptance.**

## Executive result

A real React learning screen, three deterministic question evaluators, local repository adapters, draft question fixtures, dashboard/progress views, import preview, and an advisory AI context contract exist. Tests and production compilation pass. The evidence does **not** establish an operational pilot: Native IndexedDB and mobile rendering were not tested in a browser; the importer has no draft-import/write operation; recommendation is not wired into the React learning flow; and several WP0 integrity gaps remain.

No new source fix was made during this audit. The requested report and narrow repair brief are the only audit-authored files. The production build refreshed ignored `dist/` output.

## Repository and attribution

Current Git status has 29 modified tracked paths, including governance/docs, `package.json`, `package-lock.json`, `src/App.tsx`, `src/domain/contracts.ts`, and `src/styles.css`; untracked trees include `src/domain/math/`, `src/domain/persistence/`, `src/infrastructure/`, `src/features/`, `src/content/`, `src/components/`, and `src/acceptance/`, plus campaign docs and reports. No staged files were reported. No reset/clean/checkout/stage/commit/push was used.

The AGY one-shot report names its changed/created files, but the source and test trees were already untracked and package files already dirty. Git therefore cannot establish exact before/after authorship for those files. The current package diff adds `jsdom@31.0.0` as a dev dependency; prior campaign state already had this manifest change, and AGY’s final file list does not claim it. No new dependency attributable to this one-shot campaign can be proven from the available baseline. `scoring.acceptance.test.ts` remains outside AGY’s reported changes; its enabled tests ran.

The authoritative brief defines WP0 through WP5. AGY’s final report uses a different numbering: its dashboard/progress WP1 maps to brief WP2; import WP2 maps to brief WP3; its “WP4 & WP5” persistence/mobile work maps to brief WP1 and WP4; AI WP6 maps to brief WP5. Thus brief WP3’s capability (import preview) exists but was reported under another number. There is no separate brief WP6.

## Findings

### WP0 — Domain and security

| Area | Result | Evidence / remaining issue |
|---|---|---|
| A. Content hash | **HIGH — FAIL** | Canonical serializer sorts keys, NFC-normalizes strings, detects NFC key collisions/cycles/non-finite values. Publication resolves the matching solution from context and hashes body plus explanation/steps/keyPoints. However, `validator.ts:335-337` only rejects a differing hash when `qv.contentHash` is truthy. A missing/empty declared hash can therefore bypass binding of the QuestionVersion’s own required hash field while review is checked against the computed hash. Require a non-empty exact declared hash. |
| B. Reviewer authorization | **HIGH — FAIL** | No bare-ID special case or default production registry was found; identity, status, subject, curriculum presence and scope are checked. Direct runtime probe supplied `validFrom: "2026-99-99T00:00:00.000Z"` with otherwise matching active evidence; `validateReviewerAuthorization` returned `authorized: true, errors: []`. Regex matches but `Date.parse` is NaN and the implementation does not reject it. Also, `preview.ts` takes `reviewerRegistry` from the incoming import package and passes it as authority; package authors can self-supply synthetic authorization and receive `eligibleForPublication: true`. This is preview-only today, not a publication endpoint, but the eligibility result is not trustworthy. Production publication still has no real identity/authority source and must remain fail-closed. |
| C. Provenance/rights | **HIGH — FAIL** | `isLicenseValidAt` enforces operation membership when an operation is requested, and publication requests `publish`; restricted/unknown/expired are rejected. Publication rejects explicit `commercialUseAllowed === false` and checks attribution fields if `attributionRequired` is true. Missing commercial-use permission is accepted, and source reference/issuer/notes are metadata rather than evidence of rights. This does not establish permission or ownership. All pilot candidates remain draft. |
| D. Scoring | **PASS WITH LIMITATIONS** | Runtime policy validator and constructor share validation; required decimal fields, separators, exponent flag and finite bounded points are checked. T/F derived maximum is bounded; evaluator returns invalid execution errors instead of score clamping. Focused domain tests and protected tests pass. Policy is labeled PROPOSED/practice-only. No official scoring alignment is established. |
| E. Delayed recheck | **HIGH — FAIL** | Exact source attempt ID and question ID/version/hash are checked; schedule completion is saved atomically with the new attempt, and UI waits for the repository promise. However, source attempt’s session is never loaded/checked against the schedule skill. The code only checks the question includes schedule skill and optionally compares schedule’s own `sourceSkillId`; these fields can be self-consistent while the original session belongs to another skill. Recheck session IDs are timestamp-derived and do not prove collision-free uniqueness. |
| F. AttemptEvent | **HIGH — FAIL** | Deep-clone/freeze and repository-boundary validation exist. But `validateAttemptEvent` only reconciles part points when `partEvidence.length > 0`; a scored result with positive points and no evidence is accepted. It also accepts `result.status: "invalid"` as a storable event. In-memory and native write methods rely on this validator. UI blocks invalid submissions, but storage integrity must reject malformed/invalid events too. |
| G. Persistence disclosure | **MEDIUM — PARTIAL** | Footer now distinguishes IndexedDB-if-available from volatile session memory and does not imply cloud storage. Study load/save/reset errors are surfaced and save success follows awaited atomic persistence. Dashboard and Progress catch repository read errors and merely stop loading, making storage failure look like zero/empty data. Adapter selection chooses memory only when `window.indexedDB` is absent; an available-but-failing database does not fall back. Native IndexedDB has not run in a browser. |

### Brief WP1 — Persistence, recovery, and recheck

Implementation exists: a shared repository is created by App and passed to the currently mounted view; IndexedDB writes use transaction completion for success, with abort/error rejection and atomic multi-store recheck writes. The direct adapter tests all instantiate `InMemoryPersistenceRepository`; they are not Native IndexedDB tests. No reload/close-open recovery, native quota, migration from a previous database shape, or browser-level recovery was demonstrated. Native IndexedDB and actual reload recovery are **NOT VERIFIED**.

### Brief WP2 — Dashboard, Progress, learning journey

Dashboard and Progress query sessions/attempts/schedules from the repository. Tab views unmount/remount, so their effects reread data after navigation back from Study. Unit tests seed in-memory data only.

Findings:
- Read errors in both views are swallowed and rendered as ordinary zero/empty data.
- Dashboard calls every positive-scoring attempt “correct”; a partially correct T/F/numeric response can inflate the correct count. Accuracy denominator is all events, not just valid scored outcomes.
- Dashboard’s quick “go to Study” callback updates React state without updating the URL hash; active tab and route can diverge.
- The dashboard recommendation/error summary scans only failed MCQ events; Progress scans hypotheses more broadly.
- No evidence-based recommendation is connected to `MathLearningView`; the screen presents diagnosis/solution and a generic study action, not a reasoned next-skill recommendation.
- The current pilot has one hard-coded topic and a skill selector; it does not demonstrate general subject/topic taxonomy navigation.

The core mounted Study test covers answer, deterministic score, explanation, local save, schedule and delayed recheck using the in-memory adapter. It is not a full Dashboard-to-Progress-to-reload end-to-end test.

### Brief WP3 — Question bank ingestion

The implemented capability is **B: validation plus preview**, not C.

`schema.ts` defines TypeScript interfaces; `preview.ts` performs runtime checks and returns per-item errors/warnings/hash/status. There is no actual repository import, draft persistence, batch transaction, rollback, or import command/UI. No `scripts/validate-content.ts` is present. Therefore new content cannot be received into the application repository as persisted drafts without another ingestion step/source change.

Further limitations: unknown skill IDs are not checked against an authoritative taxonomy; package-level global errors do not necessarily invalidate item results; duplicate content hash is a warning and does not make the batch invalid; incoming package can carry its own reviewer registry, making the preview’s publication-eligibility count self-asserted. Draft/in_review status is preserved; no publication path exists in the importer.

### Brief WP4 — Mobile UX and deployable client

Responsive CSS includes narrow-screen rules, horizontal math/table containers and 44px touch targets in selected controls. This is source inspection only. No Chromium/Firefox/browser executable was available; 360×800, 390×844, 414px, wide viewport, keyboard/touch, overflow and formula layout are **NOT VERIFIED**.

Vite production build passes. `docs/OPERATIONS.md` instructs `npm run preview`, but `package.json` has no preview script. No hosting/deployment, runtime configuration, production browser-storage behavior, or version-update flow is verified. This remains a local client build, not a deployed pilot or multi-user service.

### Brief WP5 (AGY label WP6) — AI context contract

`learningContext.ts` is a pure read-only context builder with no provider, secret, network or mutation API; advisory and human-review flags are present. This is an AI context contract, not an AI Tutor. It currently groups attempt evidence by `questionVersionRef.questionId` and labels that value `skillId`, so evidence is attributed to the wrong dimension. Runtime freezing is shallow for summary/hypothesis entry objects even though TypeScript fields are readonly. Do not treat its counts as trustworthy AI context until fixed.

## End-to-end journey

| Transition | Result | Evidence |
|---|---|---|
| Dashboard load from repository | **PASS WITH LIMITATIONS** | Repository-backed effect and jsdom test; errors are mislabeled as empty data. |
| Dashboard → Study | **FAIL** | Quick action changes React section but does not synchronize `location.hash`. |
| Choose subject/topic | **NOT VERIFIED** | One hard-coded Math 12 topic; no demonstrated subject/topic selection. |
| Choose skill | **PASS WITH LIMITATIONS** | Skill selector filters bundled pilot fixtures. |
| Practice three question families | **PASS WITH LIMITATIONS** | MCQ, T/F cluster, numeric controls/scorers exist; fixtures are draft/test candidates. |
| Submit → deterministic score | **PASS WITH LIMITATIONS** | UI blocks invalid/empty results; scorer tests pass. Stored-event validator still allows invalid status. |
| Explanation and diagnosis | **PASS WITH LIMITATIONS** | Explanation and diagnostic hypotheses render; hypotheses are not verified diagnoses. |
| Evidence-based recommendation | **FAIL / NOT IMPLEMENTED** | No recommendation call/render in MathLearningView; generic prompts are not evidence-driven. |
| Review schedule | **PASS WITH LIMITATIONS** | Due schedule is persisted in adapter contract; test uses memory adapter. |
| Delayed recheck | **PASS WITH LIMITATIONS** | Mounted memory-backed flow works; source-session/skill consistency gap remains. |
| Progress timeline | **PASS WITH LIMITATIONS** | Component renders attempt/schedule data from repository; only seeded in-memory test. |
| Reload and recovery | **NOT VERIFIED** | No real browser or Native IndexedDB test executed. |

## Independent test and build evidence

All requested suites were run serially. Focused tests used the configured `tsx` runner in the synchronized Termux runtime copy.

| Check | Result | Counts / duration / warnings |
|---|---:|---|
| Focused domain: `math-domain.test.ts` | exit 0 | 33 passed, 0 failed, 0 skipped; 0.746s |
| Focused Learning UI | exit 0 | 7 passed; 0.633s; React `act(...)` warnings |
| DashboardView | exit 0 | 1 passed; 2.898s |
| ProgressView | exit 0 | 1 passed; 2.802s |
| Import preview | exit 0 | 2 passed; 0.588s |
| AI context | exit 0 | 1 passed; 0.594s |
| IndexedDB repository file | exit 0 | 10 passed; all explicitly in-memory; 0.657s |
| `npm test` | exit 0 | 106 total: 95 passed, 0 failed, 11 skipped; 9.197s test-runner duration; React act warnings |
| `NEXUS_NL002_ACCEPTANCE=1 npm test` | exit 0 | 106 passed, 0 failed, 0 skipped; 8.226s; React act warnings |
| `npm run build` | exit 0 | TypeScript check and Vite build pass; JS 301.91 kB (87.51 kB gzip); Vite 263ms |
| `python3 agent-hub/tests/run_all_tests.py` | exit 0 | 9/9 passed; 0.134s |
| `git diff --check` | exit 0 | No tracked-diff whitespace errors |

The 11 default skips are acceptance-gated tests; all ran under the enabled command. Green tests do not exercise the source findings listed above. No React warnings were suppressed. No browser, Native IndexedDB, visual mobile, or real reload test ran.

## Operational scorecard

Scores are evidence-weighted against the published 100-point scorecard, shown as points earned over each dimension’s allocated weight. They are separate measures, not one combined “percent complete.”

### Functional readiness — 29 / 60 = 48%

| Criterion | Weight | Earned | Evidence and remaining gap |
|---|---:|---:|---|
| Core correctness/security | 20 | 9 | Three evaluators and many invariants exist; HIGH hash, reviewer, rights, recheck and event validation defects remain. |
| Learning journey | 25 | 13 | Mounted in-memory learning/recheck path works; recommendation absent, dashboard hash/error behavior and full app loop unverified. |
| Mobile UX | 10 | 3 | Responsive CSS and semantic controls inspected; no browser/device evidence. |
| Tests/docs/diagnostics | 5 | 4 | All configured suites/build pass; warning cleanup, accurate ops preview command, and independent browser evidence missing. |

### Educational content readiness — 3 / 15 = 20%

| Criterion | Weight | Earned | Evidence and remaining gap |
|---|---:|---:|---|
| Question bank and intake readiness | 15 | 3 | 15 bundled draft candidates and validation/preview exist; zero qualified-reviewed/published items, no repository import, rights and reviewer evidence are not established. |

### Production/deployment readiness — 10 / 25 = 40%

| Criterion | Weight | Earned | Evidence and remaining gap |
|---|---:|---:|---|
| Persistence/recovery | 15 | 6 | IndexedDB adapter and atomic code exist; tests are memory-only, no browser persistence/reload/migration evidence. |
| Build/deployment readiness | 10 | 4 | Production client compiles; no preview script, hosting, runtime/deployment verification or deployed pilot. |

These scores do not mean multi-user production readiness. Backend, authentication, cloud sync, server-side history, CI, and deployment are not implemented. Content coverage is 15 draft candidates and 0 verified/published questions.

## Repair gate and recommendation

**Final verdict: REPAIR REQUIRED.** Do not describe this as an operational 90%/100% web pilot or recommend final acceptance yet.

The narrow repair brief is `docs/agent-handoffs/AGY_OPERATIONAL_100_FINAL_REPAIR_BRIEF.md`. It is a handoff for a later single-writer AGY round; no repair was started in this audit. After those blockers are repaired and independently rechecked, remaining scoped work is actual draft import persistence, evidence-based recommendation wiring, user-facing storage error states, and browser/mobile/Native IndexedDB verification. A real qualified reviewer and substantiated rights evidence remain content-owner inputs. Product Owner retains final acceptance.
