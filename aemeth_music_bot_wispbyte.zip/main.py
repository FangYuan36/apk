"""
File khởi chạy chính của Telegram Music Bot trên Android Termux.
Quản lý hai thành phần Telegram:
1. Bot quản lý (Bot Token): Nhận lệnh, kiểm tra quyền, điều khiển (sử dụng ParseMode.HTML an toàn).
2. Tài khoản người dùng thật (User Account / PyTgCalls): Tham gia Group Voice Chat và phát âm thanh.
"""

import sys
import os
import html
import signal
import asyncio
import logging
from typing import Optional

from pyrogram import Client, filters
from pyrogram.enums import ParseMode
from pyrogram.types import Message
from pyrogram.errors import (
    FloodWait,
    ChatAdminRequired,
    UserAlreadyParticipant,
    UserNotParticipant,
    SessionPasswordNeeded,
)

from pytgcalls import PyTgCalls
from pytgcalls import filters as call_filters
from pytgcalls.types import StreamEnded

from config import (
    BOT_TOKEN,
    API_ID,
    API_HASH,
    OWNER_ID,
    SESSION_NAME,
    TWO_FACTOR_PASS,
    BASE_DIR,
    validate_config,
)
from permissions import (
    permissions,
    PERM_PLAY,
    PERM_PLAYBACK,
    PERM_SKIP,
    PERM_STOP,
    PERM_VOLUME,
    ALL_PERMISSIONS,
    PERM_DESCRIPTIONS,
)
from player import MusicPlayer, Track

# Cấu hình logging tối ưu cho Termux: Không ghi debug rườm rà, tập trung thông tin quan trọng
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("MusicBot")

# Khởi tạo hai đối tượng Client của Telegram (sử dụng HTML parse mode để miễn nhiễm lỗi entity)
bot_client = Client(
    name="bot_manager_session",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN,
    workdir=str(BASE_DIR),
    parse_mode=ParseMode.HTML,
)

user_client = Client(
    name=SESSION_NAME,
    api_id=API_ID,
    api_hash=API_HASH,
    workdir=str(BASE_DIR),
    parse_mode=ParseMode.HTML,
)

# Backend gọi thoại, player và cờ dừng (khởi tạo trong main() trên cùng Event Loop)
shutdown_event: Optional[asyncio.Event] = None
call_py: Optional[PyTgCalls] = None
player: Optional[MusicPlayer] = None


# =====================================================================
# SỰ KIỆN HẾT THỜI GIAN CHỜ 1 PHÚT & KẾT THÚC BÀI HÁT TỰ ĐỘNG
# =====================================================================
async def on_idle_timeout_handler(chat_id: int) -> None:
    """Được gọi khi hết 1 phút chờ mà không có bài hát mới."""
    try:
        await bot_client.send_message(
            chat_id=chat_id,
            text=(
                "👋 <b>Aemeth Music</b> đã hết 1 phút chờ mà không có yêu cầu phát nhạc mới.\n"
                "Tài khoản phát nhạc đã rời Voice Chat và dọn sạch dữ liệu đệm để giải phóng RAM cho điện thoại!"
            ),
        )
    except Exception as e:
        logger.debug("Lỗi gửi tin nhắn hết thời gian chờ: %s", e)


async def on_stream_end_handler(client: PyTgCalls, update: StreamEnded) -> None:
    """Được gọi tự động khi một bài hát phát xong."""
    if not player:
        return
    chat_id = update.chat_id
    logger.info("Luồng âm thanh đã kết thúc trong nhóm %s", chat_id)
    try:
        next_track = await player.handle_stream_end(chat_id)
        if next_track:
            safe_title = html.escape(next_track.title)
            safe_name = html.escape(next_track.requester_name)
            await bot_client.send_message(
                chat_id=chat_id,
                text=(
                    f"▶️ <b>Đang phát tiếp theo:</b>\n"
                    f"🎵 <a href=\"{next_track.web_url}\">{safe_title}</a>\n"
                    f"⏱ Thời lượng: <code>{next_track.duration_str}</code>\n"
                    f"👤 Yêu cầu bởi: {safe_name}"
                ),
                disable_web_page_preview=True,
            )
        else:
            await bot_client.send_message(
                chat_id=chat_id,
                text=(
                    "⏹ <b>Hàng đợi đã hết bài.</b>\n"
                    "⏳ <b>Aemeth Music</b> sẽ ở lại Voice Chat trong <b>1 phút</b> chờ bài tiếp theo...\n"
                    "(Gửi <code>/play &lt;tên bài&gt;</code> để tiếp tục phát ngay lập tức!)"
                ),
            )
    except Exception as e:
        logger.error("Lỗi khi xử lý chuyển bài trong nhóm %s: %s", chat_id, e)


# =====================================================================
# LỆNH XEM ID & TRỢ GIÚP
# =====================================================================
@bot_client.on_message(filters.command("id"))
async def cmd_id(client: Client, message: Message) -> None:
    chat_id = message.chat.id
    user_id = message.from_user.id if message.from_user else 0
    chat_type = message.chat.type.name
    await message.reply_text(
        f"🆔 <b>Chat ID:</b> <code>{chat_id}</code>\n"
        f"👤 <b>User ID:</b> <code>{user_id}</code>\n"
        f"💬 <b>Loại:</b> <code>{chat_type}</code>"
    )


@bot_client.on_message(filters.command(["start", "help"]))
async def cmd_start_help(client: Client, message: Message) -> None:
    user_id = message.from_user.id if message.from_user else 0
    is_owner = permissions.is_owner(user_id)
    user_perms = permissions.get_user_permissions(user_id)
    is_private = message.chat.type.name == "PRIVATE"

    help_text = (
        "🎵 <b>Aemeth Music</b>\n"
        "<i>Bot phát nhạc của 𝑸𝒊𝒙𝒊𝒂</i>\n\n"
        "<b>Lệnh điều khiển phát nhạc:</b>\n"
        "• <code>/play &lt;link hoặc tên bài&gt;</code> — Phát nhạc trong nhóm hiện tại\n"
        "• <code>/pause</code> — Tạm dừng phát nhạc\n"
        "• <code>/resume</code> — Tiếp tục phát nhạc\n"
        "• <code>/skip</code> — Bỏ qua bài hiện tại\n"
        "• <code>/stop</code> — Dừng phát và rời cuộc gọi\n"
        "• <code>/volume &lt;1-200&gt;</code> — Chỉnh âm lượng phát nhạc (hoặc <code>/vol</code>)\n"
        "• <code>/queue</code> — Xem danh sách hàng đợi bài hát\n"
        "• <code>/status</code> — Xem trạng thái bot\n"
        "• <code>/id</code> — Xem ID người dùng và ID nhóm\n\n"
    )

    # Quyền của chủ bot: TUYỆT ĐỐI CHỈ HIỂN THỊ KHI CHỦ BOT NHẮN TIN RIÊNG (PRIVATE CHAT)
    if is_private and is_owner:
        help_text += (
            "👑 <b>Lệnh Quản Trị (Chủ Bot - 𝑸𝒊𝒙𝒊𝒂):</b>\n"
            "• <code>/allow</code> — Xem menu và danh sách quyền đánh số\n"
            "• <code>/allow &lt;user_id&gt; &lt;số ...&gt;</code> — Cấp/thêm quyền cho người dùng\n"
            "• <code>/disallow &lt;user_id&gt; [số ...]</code> — Xóa/bớt quyền (hoặc <code>/revoke</code>)\n"
            "• <code>/users</code> — Xem danh sách người dùng và các quyền đã cấp\n"
            "• <code>/setgroup [group_id]</code> — Cấp phép nhóm phát nhạc\n"
            "• <code>/delgroup &lt;group_id&gt;</code> — Xóa nhóm khỏi danh sách cấp phép\n"
            "• <code>/groups</code> — Xem danh sách các nhóm đã cấp phép\n"
            "• <code>/play &lt;group_id&gt; &lt;link&gt;</code> — Phát nhạc từ xa vào nhóm\n"
            "• <code>/shutdown</code> — Tắt bot và giải phóng tài nguyên trên Termux\n\n"
        )

    if is_owner:
        status_line = "<b>Chủ Bot (𝑸𝒊𝒙𝒊𝒂 - Toàn quyền)</b>"
    elif user_perms:
        perm_tags = ", ".join(f"[{p}]" for p in user_perms)
        status_line = f"<b>Được cấp quyền:</b> {perm_tags}"
    else:
        status_line = "<i>Chưa có quyền sử dụng</i>"

    help_text += (
        f"🆔 ID của bạn: <code>{user_id}</code>\n"
        f"🔐 Trạng thái: {status_line}"
    )

    await message.reply_text(help_text, disable_web_page_preview=True)


# =====================================================================
# LỆNH PHÁT NHẠC (/play)
# =====================================================================
@bot_client.on_message(filters.command("play"))
async def cmd_play(client: Client, message: Message) -> None:
    user = message.from_user
    if not user:
        return

    if not player:
        await message.reply_text("⚠️ Hệ thống phát nhạc đang khởi động, vui lòng thử lại sau giây lát.")
        return

    # 1. Kiểm tra quyền người gửi (Chỉ Chủ Bot 𝑸𝒊𝒙𝒊𝒂 hoặc người được cấp quyền [1])
    if not permissions.has_permission(user.id, PERM_PLAY):
        await message.reply_text(
            "⛔ <b>Bạn không có quyền phát nhạc.</b>\n"
            "Chỉ Chủ Bot (𝑸𝒊𝒙𝒊𝒂) hoặc người được cấp quyền [1] mới có thể phát nhạc."
        )
        return

    args = message.command[1:]
    if not args:
        await message.reply_text("ℹ️ Cú pháp: <code>/play &lt;link bài hát hoặc tên bài&gt;</code>")
        return

    # 2. Xác định nhóm đích
    target_chat_id: Optional[int] = None
    query: str = ""
    is_in_group = message.chat.type.name in ("GROUP", "SUPERGROUP")

    if is_in_group:
        target_chat_id = message.chat.id
        query = " ".join(args)

        # TIỆN ÍCH THÔNG MINH: Nếu Chủ Bot gõ /play trong nhóm, tự động cấp phép nhóm luôn!
        if permissions.is_owner(user.id) and not permissions.is_group_allowed(target_chat_id):
            permissions.add_group(target_chat_id)
            logger.info("Chủ bot đã tự động kích hoạt nhóm %s", target_chat_id)
    else:
        # Chat riêng với bot:
        # Nếu tham số đầu tiên là ID nhóm (ví dụ: /play -100xxx link)
        if len(args) >= 2 and (args[0].startswith("-") or args[0].isdigit()):
            try:
                target_chat_id = int(args[0])
                query = " ".join(args[1:])
            except ValueError:
                pass

        if not target_chat_id:
            # Nếu người dùng không nhập group_id, tự động lấy nhóm đã được cấp phép gần nhất
            allowed = permissions.get_groups()
            if allowed:
                target_chat_id = allowed[-1]
                query = " ".join(args)
            else:
                await message.reply_text(
                    "ℹ️ <b>Chưa có nhóm nào được chọn!</b>\n\n"
                    "👉 <b>Cách 1:</b> Thêm Bot và tài khoản <code>Hiyuki</code> vào nhóm của bạn, rồi gõ lệnh <code>/play &lt;link&gt;</code> ngay trong nhóm.\n"
                    "👉 <b>Cách 2:</b> Trong nhóm, gõ <code>/setgroup</code> để lưu nhóm, sau đó bạn có thể chat riêng với bot thoải mái!"
                )
                return

    if not target_chat_id:
        await message.reply_text("❌ Không xác định được nhóm đích.")
        return

    # 3. Kiểm tra nhóm đích có nằm trong danh sách được phép không
    if not permissions.is_group_allowed(target_chat_id):
        await message.reply_text(
            f"⛔ Nhóm này (<code>{target_chat_id}</code>) chưa được cấp phép phát nhạc.\n"
            f"Chủ bot hãy gõ <code>/setgroup</code> trong nhóm để cấp phép."
        )
        return

    # 4. Gửi thông báo đang tìm nạp
    status_msg = await message.reply_text("🔍 Đang tìm nạp nguồn âm thanh siêu tốc...")

    try:
        # 5. Đảm bảo tài khoản phát nhạc Hiyuki có quyền truy cập nhóm
        try:
            await user_client.get_chat(target_chat_id)
        except Exception:
            # Nếu Hiyuki chưa trong nhóm, bot tự động xuất link mời và mời Hiyuki vào
            try:
                invite_link = await bot_client.export_chat_invite_link(target_chat_id)
                if invite_link:
                    try:
                        await user_client.join_chat(invite_link)
                    except Exception:
                        pass
            except Exception as inv_err:
                logger.debug("Không thể tự động xuất link mời cho Hiyuki: %s", inv_err)

        # 6. Trích xuất luồng qua yt-dlp
        track = await player.extract_track(
            query=query,
            requester_id=user.id,
            requester_name=user.first_name,
        )

        # 7. Đưa vào hàng đợi hoặc phát ngay
        is_playing_now, queue_pos = await player.play_or_queue(target_chat_id, track)
        safe_title = html.escape(track.title)
        safe_name = html.escape(track.requester_name)

        if is_playing_now:
            await status_msg.edit_text(
                f"▶️ <b>Đang phát vào Voice Chat:</b>\n"
                f"🎵 <a href=\"{track.web_url}\">{safe_title}</a>\n"
                f"⏱ Thời lượng: <code>{track.duration_str}</code>\n"
                f"👤 Yêu cầu bởi: {safe_name}",
                disable_web_page_preview=True,
            )
        else:
            await status_msg.edit_text(
                f"📝 <b>Đã thêm vào hàng đợi (#{queue_pos}):</b>\n"
                f"🎵 <a href=\"{track.web_url}\">{safe_title}</a>\n"
                f"⏱ Thời lượng: <code>{track.duration_str}</code>\n"
                f"👤 Yêu cầu bởi: {safe_name}",
                disable_web_page_preview=True,
            )

    except ValueError as ve:
        await status_msg.edit_text(f"⚠️ {html.escape(str(ve))}")
    except Exception as e:
        logger.error("Lỗi khi phát nhạc tại nhóm %s: %s", target_chat_id, e)
        err_str = str(e)
        err_type = type(e).__name__
        if (
            "GROUPCALL" in err_str.upper()
            or "NO GROUP CALL" in err_str.upper()
            or "CALL_NOT_FOUND" in err_str.upper()
            or "GROUPCALLNOTFOUND" in err_type.upper()
        ):
            await status_msg.edit_text(
                "❌ <b>Voice Chat chưa được bật trong nhóm!</b>\n"
                "👉 Vui lòng nhấn vào tiêu đề nhóm -> <b>Bắt đầu trò chuyện thoại (Voice Chat)</b> trước khi gõ <code>/play</code>."
            )
        elif (
            "CHANNEL_INVALID" in err_str
            or "PEER_ID_INVALID" in err_str
            or "USER_NOT_PARTICIPANT" in err_str
            or "NOT IN THE CHAT" in err_str.upper()
        ):
            await status_msg.edit_text(
                "❌ <b>Tài khoản phát nhạc (Hiyuki) chưa tham gia nhóm này!</b>\n"
                "👉 Vui lòng thêm tài khoản <code>Hiyuki</code> vào nhóm và cấp quyền phát biểu trong Voice Chat."
            )
        else:
            await status_msg.edit_text(f"❌ <b>Lỗi phát nhạc:</b> <code>{html.escape(err_str[:150])}</code>")


# =====================================================================
# CÁC LỆNH ĐIỀU KHIỂN: PAUSE, RESUME, SKIP, STOP, QUEUE, STATUS
# =====================================================================
def get_chat_id_from_msg(message: Message) -> Optional[int]:
    """Lấy chat_id hiện tại nếu trong nhóm, hoặc từ tham số / nhóm đã lưu nếu chat riêng."""
    if message.chat.type.name in ("GROUP", "SUPERGROUP"):
        return message.chat.id
    if len(message.command) > 1 and message.command[1].lstrip("-").isdigit():
        return int(message.command[1])
    allowed = permissions.get_groups()
    if allowed:
        return allowed[-1]
    return None


@bot_client.on_message(filters.command("pause"))
async def cmd_pause(client: Client, message: Message) -> None:
    user = message.from_user
    if not user or not permissions.has_permission(user.id, PERM_PLAYBACK):
        await message.reply_text("⛔ Bạn không có quyền tạm dừng nhạc (Cần quyền [2]).")
        return

    if not player:
        await message.reply_text("⚠️ Hệ thống phát nhạc đang khởi động, vui lòng thử lại sau giây lát.")
        return

    chat_id = get_chat_id_from_msg(message)
    if not chat_id:
        await message.reply_text("ℹ️ Cú pháp: <code>/pause</code> trong nhóm hoặc <code>/pause &lt;group_id&gt;</code>")
        return

    success = await player.pause(chat_id)
    if success:
        await message.reply_text("⏸ <b>Đã tạm dừng phát nhạc.</b>")
    else:
        await message.reply_text("⚠️ Hiện không có bài hát nào đang phát hoặc đã tạm dừng trước đó.")


@bot_client.on_message(filters.command("resume"))
async def cmd_resume(client: Client, message: Message) -> None:
    user = message.from_user
    if not user or not permissions.has_permission(user.id, PERM_PLAYBACK):
        await message.reply_text("⛔ Bạn không có quyền tiếp tục phát nhạc (Cần quyền [2]).")
        return

    if not player:
        await message.reply_text("⚠️ Hệ thống phát nhạc đang khởi động, vui lòng thử lại sau giây lát.")
        return

    chat_id = get_chat_id_from_msg(message)
    if not chat_id:
        await message.reply_text("ℹ️ Cú pháp: <code>/resume</code> trong nhóm hoặc <code>/resume &lt;group_id&gt;</code>")
        return

    success = await player.resume(chat_id)
    if success:
        await message.reply_text("▶️ <b>Tiếp tục phát nhạc.</b>")
    else:
        await message.reply_text("⚠️ Không có bài hát nào đang bị tạm dừng.")


@bot_client.on_message(filters.command("skip"))
async def cmd_skip(client: Client, message: Message) -> None:
    user = message.from_user
    if not user or not permissions.has_permission(user.id, PERM_SKIP):
        await message.reply_text("⛔ Bạn không có quyền chuyển bài hát (Cần quyền [3]).")
        return

    if not player:
        await message.reply_text("⚠️ Hệ thống phát nhạc đang khởi động, vui lòng thử lại sau giây lát.")
        return

    chat_id = get_chat_id_from_msg(message)
    if not chat_id:
        await message.reply_text("ℹ️ Cú pháp: <code>/skip</code> trong nhóm hoặc <code>/skip &lt;group_id&gt;</code>")
        return

    next_track = await player.skip(chat_id)
    if next_track:
        safe_title = html.escape(next_track.title)
        safe_name = html.escape(next_track.requester_name)
        await message.reply_text(
            f"⏭ <b>Đã bỏ qua. Đang phát bài tiếp theo:</b>\n"
            f"🎵 <a href=\"{next_track.web_url}\">{safe_title}</a>\n"
            f"⏱ Thời lượng: <code>{next_track.duration_str}</code>\n"
            f"👤 Yêu cầu: {safe_name}",
            disable_web_page_preview=True,
        )
    else:
        await message.reply_text(
            "⏹ <b>Đã bỏ qua bài hát. Hàng đợi hiện đang trống.</b>\n"
            "⏳ Bot sẽ chờ trong <b>1 phút</b> trước khi rời Voice Chat!"
        )


@bot_client.on_message(filters.command("stop"))
async def cmd_stop(client: Client, message: Message) -> None:
    user = message.from_user
    if not user or not permissions.has_permission(user.id, PERM_STOP):
        await message.reply_text("⛔ Bạn không có quyền dừng phát nhạc (Cần quyền [4]).")
        return

    if not player:
        await message.reply_text("⚠️ Hệ thống phát nhạc đang khởi động, vui lòng thử lại sau giây lát.")
        return

    chat_id = get_chat_id_from_msg(message)
    if not chat_id:
        await message.reply_text("ℹ️ Cú pháp: <code>/stop</code> trong nhóm hoặc <code>/stop &lt;group_id&gt;</code>")
        return

    success = await player.stop(chat_id)
    if success:
        await message.reply_text("⏹ <b>Đã dừng phát nhạc, xóa hàng đợi, rời cuộc gọi thoại và dọn rác!</b>")
    else:
        await message.reply_text("ℹ️ Hiện tại không có luồng phát nhạc nào trong nhóm này.")


@bot_client.on_message(filters.command(["volume", "vol"]))
async def cmd_volume(client: Client, message: Message) -> None:
    user = message.from_user
    if not user or not permissions.has_permission(user.id, PERM_VOLUME):
        await message.reply_text("⛔ Bạn không có quyền điều chỉnh âm lượng (Cần quyền [5]).")
        return

    if not player:
        await message.reply_text("⚠️ Hệ thống phát nhạc đang khởi động, vui lòng thử lại sau giây lát.")
        return

    chat_id = get_chat_id_from_msg(message)
    if not chat_id:
        await message.reply_text("ℹ️ Cú pháp: <code>/volume &lt;1-200&gt;</code> trong nhóm hoặc <code>/volume &lt;group_id&gt; &lt;1-200&gt;</code>")
        return

    args = message.command[1:]
    target_vol_str: Optional[str] = None
    if len(args) == 1 and args[0].isdigit():
        target_vol_str = args[0]
    elif len(args) >= 2 and args[1].isdigit():
        target_vol_str = args[1]

    if not target_vol_str:
        curr_vol = player.group_volume.get(chat_id, 100)
        await message.reply_text(
            f"🔊 <b>Âm lượng hiện tại:</b> <code>{curr_vol}%</code>\n"
            f"👉 Cú pháp chỉnh: <code>/volume &lt;1-200&gt;</code> (Ví dụ: <code>/volume 150</code>)"
        )
        return

    vol = int(target_vol_str)
    if vol < 1 or vol > 200:
        await message.reply_text("⚠️ Âm lượng chỉ được phép đặt từ <code>1%</code> đến <code>200%</code>.")
        return

    await player.change_volume(chat_id, vol)
    await message.reply_text(f"🔊 <b>Đã điều chỉnh âm lượng thành công:</b> <code>{vol}%</code>")


@bot_client.on_message(filters.command("queue"))
async def cmd_queue(client: Client, message: Message) -> None:
    user = message.from_user
    if not user or not permissions.has_permission(user.id, PERM_PLAY):
        await message.reply_text("⛔ Bạn không có quyền xem hàng đợi bài hát (Cần quyền [1]).")
        return

    if not player:
        await message.reply_text("⚠️ Hệ thống phát nhạc đang khởi động, vui lòng thử lại sau giây lát.")
        return

    chat_id = get_chat_id_from_msg(message)
    if not chat_id:
        await message.reply_text("ℹ️ Cú pháp: <code>/queue</code> trong nhóm hoặc <code>/queue &lt;group_id&gt;</code>")
        return

    current, queue_list = player.get_queue(chat_id)
    if not current and not queue_list:
        await message.reply_text("📭 <b>Hàng đợi hiện đang trống.</b>")
        return

    lines = ["📋 <b>DANH SÁCH HÀNG ĐỢI PHÁT NHẠC:</b>\n"]
    if current:
        safe_curr_title = html.escape(current.title)
        lines.append(f"▶️ <b>Đang phát:</b> <a href=\"{current.web_url}\">{safe_curr_title}</a> (<code>{current.duration_str}</code>)")

    if queue_list:
        lines.append("\n<b>Bài hát chờ:</b>")
        for i, t in enumerate(queue_list, start=1):
            s_title = html.escape(t.title)
            s_req = html.escape(t.requester_name)
            lines.append(f"<code>{i}.</code> <a href=\"{t.web_url}\">{s_title}</a> (<code>{t.duration_str}</code>) - {s_req}")
    else:
        lines.append("\n<i>(Không còn bài nào chờ trong hàng đợi)</i>")

    await message.reply_text("\n".join(lines), disable_web_page_preview=True)


@bot_client.on_message(filters.command("status"))
async def cmd_status(client: Client, message: Message) -> None:
    user = message.from_user
    if not user:
        return

    if not player:
        await message.reply_text("⚠️ Hệ thống phát nhạc đang khởi động, vui lòng thử lại sau giây lát.")
        return

    chat_id = get_chat_id_from_msg(message)
    active_chats = len(player.current_tracks)

    status_text = (
        "📊 <b>Aemeth Music — TRẠNG THÁI HỆ THỐNG:</b>\n"
        f"• Chủ sở hữu: <code>𝑸𝒊𝒙𝒊𝒂</code>\n"
        f"• Môi trường: <code>Android Termux (ARM64)</code>\n"
        f"• Bot Manager: <code>@aemethmusic_bot (Online)</code>\n"
        f"• Tài khoản Voice: <code>Hiyuki (Đã kết nối)</code>\n"
        f"• Số nhóm đang phát: <code>{active_chats}</code>\n"
    )

    if chat_id:
        chat_status = player.get_status(chat_id)
        if chat_status["active"]:
            curr = chat_status["current_track"]
            state_str = "Tạm dừng" if chat_status["paused"] else "Đang phát"
            safe_title = html.escape(curr.title) if curr else "Không rõ"
            status_text += (
                f"\n<b>Tại nhóm này (<code>{chat_id}</code>):</b>\n"
                f"• Trạng thái: <code>{state_str}</code>\n"
                f"• Đang phát: <code>{safe_title}</code>\n"
                f"• Hàng đợi chờ: <code>{chat_status['queue_length']} bài</code>"
            )
        elif chat_status.get("is_waiting_idle"):
            status_text += f"\n<b>Tại nhóm này:</b> <code>Đang chờ 1 phút trước khi out call</code>"
        else:
            status_text += f"\n<b>Tại nhóm này:</b> <code>Đang rảnh rỗi</code>"

    await message.reply_text(status_text)


# =====================================================================
# LỆNH QUẢN TRỊ CỦA CHỦ BOT (CHỈ 𝑸𝒊𝒙𝒊𝒂 MỚI CÓ QUYỀN)
# =====================================================================
@bot_client.on_message(filters.command("allow"))
async def cmd_allow(client: Client, message: Message) -> None:
    if not message.from_user or not permissions.is_owner(message.from_user.id):
        await message.reply_text("⛔ Chỉ Chủ Bot (𝑸𝒊𝒙𝒊𝒂) mới có quyền cấp phép người dùng.")
        return

    args = message.command[1:]

    # Trường hợp 1: Gõ /allow không có tham số -> Hiện menu và danh sách quyền đánh số
    if not args:
        perm_list_str = "\n".join(
            f"<b>[{num}]</b> {desc}" for num, desc in PERM_DESCRIPTIONS.items()
        )
        await message.reply_text(
            "🔐 <b>QUẢN LÝ PHÂN QUYỀN — Aemeth Music</b>\n"
            "<i>(Bot của 𝑸𝒊𝒙𝒊𝒂)</i>\n\n"
            "📋 <b>Danh sách các quyền đánh số:</b>\n"
            f"{perm_list_str}\n\n"
            "👉 <b>Cú pháp cấp / thêm quyền:</b>\n"
            "• <code>/allow &lt;user_id&gt; 1 3</code> — Cấp quyền 1 và 3 cho user\n"
            "• <code>/allow &lt;user_id&gt; all</code> — Cấp toàn bộ quyền cơ bản\n"
            "• <code>/allow &lt;user_id&gt;</code> — Xem quyền hiện có của user\n\n"
            "👉 <b>Cú pháp xóa / bớt quyền:</b>\n"
            "• <code>/disallow &lt;user_id&gt; 3</code> — Xóa quyền 3 của user\n"
            "• <code>/disallow &lt;user_id&gt;</code> — Xóa toàn bộ quyền của user"
        )
        return

    # Xác định user_id
    if not args[0].isdigit():
        await message.reply_text("❌ User ID phải là số nguyên (ví dụ: <code>/allow 123456789 1 2</code>).")
        return

    target_id = int(args[0])

    if permissions.is_owner(target_id):
        await message.reply_text("ℹ️ Đây là Chủ Bot (𝑸𝒊𝒙𝒊𝒂), luôn có toàn bộ quyền tối cao.")
        return

    # Trường hợp 2: Gõ /allow <user_id> (chưa nhập số quyền) -> Hiện quyền hiện tại và hướng dẫn
    if len(args) == 1:
        current_perms = permissions.get_user_permissions(target_id)
        if current_perms:
            curr_str = "\n".join(f"• <b>[{p}]</b> {PERM_DESCRIPTIONS[p]}" for p in current_perms)
        else:
            curr_str = "<i>(Chưa có quyền nào)</i>"

        perm_list_str = "\n".join(
            f"<b>[{num}]</b> {desc}" for num, desc in PERM_DESCRIPTIONS.items()
        )

        await message.reply_text(
            f"👤 <b>Thông tin quyền của User:</b> <code>{target_id}</code>\n\n"
            f"📋 <b>Quyền hiện tại:</b>\n{curr_str}\n\n"
            f"📋 <b>Danh sách quyền có thể cấp:</b>\n{perm_list_str}\n\n"
            f"👉 <b>Để cấp quyền cho user này, hãy gõ:</b>\n"
            f"• <code>/allow {target_id} 1 2</code> (thêm quyền 1 và 2)\n"
            f"• <code>/allow {target_id} all</code> (cấp tất cả các quyền)"
        )
        return

    # Trường hợp 3: Gõ /allow <user_id> <các số quyền...> hoặc all
    perms_to_add: list[int] = []
    if args[1].lower() in ("all", "full"):
        perms_to_add = list(ALL_PERMISSIONS)
    else:
        for arg in args[1:]:
            if arg.isdigit() and int(arg) in ALL_PERMISSIONS:
                perms_to_add.append(int(arg))

    if not perms_to_add:
        await message.reply_text(
            "⚠️ Vui lòng nhập số quyền hợp lệ từ <code>1</code> đến <code>5</code> hoặc <code>all</code>.\n"
            "Ví dụ: <code>/allow 123456789 1 3</code>"
        )
        return

    updated_perms = permissions.add_user_permissions(target_id, perms_to_add)
    updated_str = "\n".join(f"• <b>[{p}]</b> {PERM_DESCRIPTIONS[p]}" for p in updated_perms)

    await message.reply_text(
        f"✅ <b>Đã cấp quyền thành công cho User:</b> <code>{target_id}</code>\n\n"
        f"📋 <b>Tổng các quyền hiện tại của user:</b>\n{updated_str}"
    )


@bot_client.on_message(filters.command(["disallow", "revoke"]))
async def cmd_disallow(client: Client, message: Message) -> None:
    if not message.from_user or not permissions.is_owner(message.from_user.id):
        await message.reply_text("⛔ Chỉ Chủ Bot (𝑸𝒊𝒙𝒊𝒂) mới có quyền thu hồi quyền.")
        return

    args = message.command[1:]
    if not args or not args[0].isdigit():
        await message.reply_text(
            "ℹ️ <b>Cú pháp:</b>\n"
            "• <code>/disallow &lt;user_id&gt;</code> — Xóa toàn bộ quyền của user\n"
            "• <code>/disallow &lt;user_id&gt; 2 3</code> — Xóa bớt quyền 2 và 3"
        )
        return

    target_id = int(args[0])
    if permissions.is_owner(target_id):
        await message.reply_text("⛔ Không thể thu hồi quyền của Chủ Bot (𝑸𝒊𝒙𝒊𝒂).")
        return

    # Nếu chỉ có user_id hoặc chữ 'all' -> Xóa toàn bộ
    if len(args) == 1 or args[1].lower() in ("all", "full"):
        permissions.remove_user_permissions(target_id)
        await message.reply_text(f"✅ <b>Đã thu hồi toàn bộ quyền của User ID:</b> <code>{target_id}</code>")
        return

    # Xóa các số quyền chỉ định
    perms_to_remove = [int(a) for a in args[1:] if a.isdigit() and int(a) in ALL_PERMISSIONS]
    if not perms_to_remove:
        await message.reply_text("⚠️ Vui lòng nhập số quyền hợp lệ cần xóa (từ 1 đến 5).")
        return

    remaining = permissions.remove_user_permissions(target_id, perms_to_remove)
    del_str = ", ".join(f"[{p}]" for p in perms_to_remove)

    if remaining:
        rem_str = "\n".join(f"• <b>[{p}]</b> {PERM_DESCRIPTIONS[p]}" for p in remaining)
        await message.reply_text(
            f"✅ <b>Đã xóa quyền {del_str} của User:</b> <code>{target_id}</code>\n\n"
            f"📋 <b>Các quyền còn lại:</b>\n{rem_str}"
        )
    else:
        await message.reply_text(
            f"✅ <b>Đã xóa quyền {del_str} của User:</b> <code>{target_id}</code>\n\n"
            f"ℹ️ User này hiện không còn quyền nào trong bot."
        )


@bot_client.on_message(filters.command("users"))
async def cmd_users(client: Client, message: Message) -> None:
    if not message.from_user or not permissions.is_owner(message.from_user.id):
        await message.reply_text("⛔ Chỉ Chủ Bot (𝑸𝒊𝒙𝒊𝒂) mới có quyền xem danh sách người dùng.")
        return

    all_users = permissions.get_all_users_with_perms()
    msg = (
        f"👑 <b>Chủ Bot:</b> <code>{OWNER_ID}</code> (𝑸𝒊𝒙𝒊𝒂 — Toàn quyền)\n\n"
        f"👥 <b>Danh sách người dùng được cấp quyền ({len(all_users)}):</b>\n"
    )

    if all_users:
        user_lines = []
        for uid, perms in all_users.items():
            perm_tags = ", ".join(f"[{p}]" for p in perms)
            user_lines.append(f"• User <code>{uid}</code>: {perm_tags}")
        msg += "\n".join(user_lines)
    else:
        msg += "<i>(Chưa có người dùng nào được cấp quyền. Dùng <code>/allow</code> để thêm)</i>"

    await message.reply_text(msg)


@bot_client.on_message(filters.command("setgroup"))
async def cmd_setgroup(client: Client, message: Message) -> None:
    if not message.from_user or not permissions.is_owner(message.from_user.id):
        await message.reply_text("⛔ Chỉ Chủ Bot (𝑸𝒊𝒙𝒊𝒂) mới có quyền cấu hình nhóm.")
        return

    target_id: Optional[int] = None
    if len(message.command) >= 2:
        try:
            target_id = int(message.command[1])
        except ValueError:
            await message.reply_text("❌ ID nhóm phải là số nguyên (ví dụ: <code>-1001234567890</code>).")
            return
    elif message.chat.type.name in ("GROUP", "SUPERGROUP"):
        target_id = message.chat.id
    else:
        await message.reply_text(
            "ℹ️ <b>Cách cấp phép nhóm:</b>\n"
            "Gửi lệnh <code>/setgroup</code> ngay bên trong nhóm Telegram cần cấp phép,\n"
            "hoặc gõ: <code>/setgroup &lt;group_id&gt;</code>"
        )
        return

    if permissions.add_group(target_id):
        await message.reply_text(f"✅ <b>Đã thêm nhóm <code>{target_id}</code> vào danh sách được phép phát nhạc!</b>")
    else:
        await message.reply_text(f"ℹ️ Nhóm <code>{target_id}</code> đã được cấp phép trước đó.")


@bot_client.on_message(filters.command("delgroup"))
async def cmd_delgroup(client: Client, message: Message) -> None:
    if not message.from_user or not permissions.is_owner(message.from_user.id):
        await message.reply_text("⛔ Chỉ Chủ Bot (𝑸𝒊𝒙𝒊𝒂) mới có quyền xóa nhóm.")
        return

    target_id: Optional[int] = None
    if len(message.command) >= 2:
        try:
            target_id = int(message.command[1])
        except ValueError:
            await message.reply_text("❌ ID nhóm phải là số nguyên.")
            return
    elif message.chat.type.name in ("GROUP", "SUPERGROUP"):
        target_id = message.chat.id
    else:
        await message.reply_text("ℹ️ Cú pháp: <code>/delgroup &lt;group_id&gt;</code>")
        return

    if permissions.remove_group(target_id):
        await message.reply_text(f"✅ Đã xóa nhóm <code>{target_id}</code> khỏi danh sách cấp phép.")
    else:
        await message.reply_text(f"ℹ️ Nhóm <code>{target_id}</code> không có trong danh sách cấp phép.")


@bot_client.on_message(filters.command("groups"))
async def cmd_groups(client: Client, message: Message) -> None:
    user = message.from_user
    if not user or not permissions.is_owner(user.id):
        await message.reply_text("⛔ Chỉ Chủ Bot (𝑸𝒊𝒙𝒊𝒂) mới có quyền xem danh sách nhóm.")
        return

    group_list = permissions.get_groups()
    msg = f"📁 <b>DANH SÁCH NHÓM ĐƯỢC PHÉP PHÁT NHẠC ({len(group_list)}):</b>\n"
    if group_list:
        msg += "\n".join(f"• <code>{gid}</code>" for gid in group_list)
    else:
        msg += "<i>(Chưa có nhóm nào được cấp phép. Dùng <code>/setgroup</code> để thêm)</i>"

    await message.reply_text(msg)


@bot_client.on_message(filters.command("shutdown"))
async def cmd_shutdown(client: Client, message: Message) -> None:
    if not message.from_user or not permissions.is_owner(message.from_user.id):
        await message.reply_text("⛔ Chỉ Chủ Bot (𝑸𝒊𝒙𝒊𝒂) mới có quyền tắt hệ thống.")
        return

    await message.reply_text("🛑 <b>Đang tiến hành tắt hệ thống an toàn...</b>\nGiải phóng tài nguyên âm thanh và kết nối.")
    logger.info("Nhận được lệnh /shutdown từ Chủ Bot (𝑸𝒊𝒙𝒊𝒂).")
    if shutdown_event:
        shutdown_event.set()


# =====================================================================
# QUY TRÌNH KHỞI ĐỘNG VÀ ĐÓNG HỆ THỐNG AN TOÀN
# =====================================================================
async def main() -> None:
    global shutdown_event, call_py, player

    # 1. Xác thực cấu hình
    is_valid, err_msg = validate_config()
    if not is_valid:
        print(f"\n{err_msg}\n")
        sys.exit(1)

    print("=" * 60)
    print("🚀 KHỞI ĐỘNG AEMETH MUSIC (BOT CỦA 𝑸𝒊𝒙𝒊𝒂) TRÊN TERMUX")
    print("=" * 60)

    # Đăng ký bắt tín hiệu thoát hệ thống (Ctrl+C hoặc SIGTERM)
    loop = asyncio.get_running_loop()
    shutdown_event = asyncio.Event()

    def handle_signal():
        logger.info("Nhận được tín hiệu ngắt (Ctrl+C). Bắt đầu dừng...")
        if shutdown_event:
            shutdown_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, handle_signal)
        except NotImplementedError:
            pass

    # 2. Khởi động Bot quản lý
    print("[1/3] Đang kết nối Bot quản trị (Bot Token)...")
    await bot_client.start()
    bot_info = await bot_client.get_me()
    print(f"       ✅ Bot kết nối thành công: @{bot_info.username} (ID: {bot_info.id})")

    # 3. Khởi động Tài khoản người dùng thật
    print("[2/3] Đang kết nối Tài khoản phát nhạc (User Account)...")
    try:
        await user_client.start()
    except SessionPasswordNeeded:
        if TWO_FACTOR_PASS:
            print("       🔐 Đang tự động áp dụng Mật khẩu 2FA từ cấu hình...")
            await user_client.check_password(TWO_FACTOR_PASS)
            print("       ✅ Xác thực 2FA thành công!")
        else:
            raise
    user_info = await user_client.get_me()
    print(f"       ✅ Tài khoản phát nhạc kết nối: {user_info.first_name} (ID: {user_info.id})")

    # 4. Áp dụng bản vá tương thích cho PyTgCalls và khởi động Engine
    print("[3/3] Đang khởi động PyTgCalls WebRTC Engine...")
    try:
        import pytgcalls.ffmpeg as p_ffmpeg
        orig_build = p_ffmpeg.build_command

        def custom_build_command(
            name: str,
            ffmpeg_parameters,
            path: str | None,
            stream_parameters,
            before_commands=None,
            headers=None,
            is_livestream: bool = False,
        ):
            cmd = orig_build(
                name, ffmpeg_parameters, path, stream_parameters, before_commands, headers, is_livestream
            )
            if name == "ffmpeg" and path:
                # Nếu là luồng HLS (.m3u8), loại bỏ -reconnect để chống treo luồng SoundCloud
                if ".m3u8" in path.lower() or "manifest" in path.lower():
                    filtered_cmd = []
                    skip_next = False
                    for token in cmd:
                        if skip_next:
                            skip_next = False
                            continue
                        if token in ("-reconnect", "-reconnect_at_eof", "-reconnect_streamed", "-reconnect_delay_max"):
                            skip_next = True
                            continue
                        filtered_cmd.append(token)
                    cmd = filtered_cmd
            return cmd

        p_ffmpeg.build_command = custom_build_command
    except Exception as patch_err:
        logger.debug("Không thể áp dụng monkey-patch: %s", patch_err)

    call_py = PyTgCalls(user_client)
    player = MusicPlayer(call_py)
    player.idle_timeout_callback = on_idle_timeout_handler
    call_py.add_handler(on_stream_end_handler, call_filters.stream_end())
    await call_py.start()
    print("       ✅ PyTgCalls sẵn sàng phát nhạc vào Group Call!")

    print("=" * 60)
    print("🎉 AEMETH MUSIC ĐÃ HOẠT ĐỘNG HOÀN TOÀN!")
    print(f"👑 Chủ Bot: 𝑸𝒊𝒙𝒊𝒂 (ID {OWNER_ID})")
    print("👉 Hãy mở Telegram, thêm Bot và Tài khoản vào nhóm rồi gửi /start")
    print("👉 Nhấn Ctrl+C trên Termux hoặc gửi /shutdown để dừng chương trình.")
    print("=" * 60)

    # Chờ sự kiện tắt chương trình
    await shutdown_event.wait()

    # Quy trình Shutdown dọn dẹp tài nguyên
    print("\n⏳ Đang thực hiện dọn dẹp hệ thống...")
    try:
        await player.cleanup_all()
    except Exception as e:
        logger.error("Lỗi khi dọn dẹp player: %s", e)

    try:
        await user_client.stop()
    except Exception as e:
        logger.error("Lỗi khi đóng user client: %s", e)

    try:
        await bot_client.stop()
    except Exception as e:
        logger.error("Lỗi khi đóng bot client: %s", e)

    print("✅ Đã giải phóng toàn bộ tài nguyên. Tạm biệt!\n")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
