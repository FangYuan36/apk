"""
Module quản lý hệ thống phân quyền chi tiết (Granular Permissions System).
Chỉ Chủ Bot (𝑸𝒊𝒙𝒊𝒂) có toàn quyền mặc định. Người dùng khác chỉ được phép sử dụng
các quyền cơ bản được Chủ Bot cấp thông qua lệnh /allow.
Lưu trữ danh sách quyền vào permissions.json.
"""

import json
import logging
from typing import Any, Optional
from config import OWNER_ID, PERMISSIONS_FILE

logger = logging.getLogger("Permissions")

# Các hằng số quyền cơ bản được đánh số
PERM_PLAY = 1      # Phát nhạc (/play, /queue)
PERM_PLAYBACK = 2  # Tạm dừng & Tiếp tục (/pause, /resume)
PERM_SKIP = 3      # Bỏ qua bài hát (/skip)
PERM_STOP = 4      # Dừng phát nhạc (/stop)
PERM_VOLUME = 5    # Chỉnh âm lượng (/volume, /vol)

ALL_PERMISSIONS = [PERM_PLAY, PERM_PLAYBACK, PERM_SKIP, PERM_STOP, PERM_VOLUME]

PERM_DESCRIPTIONS = {
    PERM_PLAY: "Phát nhạc (/play, /queue)",
    PERM_PLAYBACK: "Tạm dừng & Tiếp tục (/pause, /resume)",
    PERM_SKIP: "Bỏ qua bài hát (/skip)",
    PERM_STOP: "Dừng phát nhạc (/stop)",
    PERM_VOLUME: "Chỉnh âm lượng (/volume, /vol)",
}


class PermissionManager:
    """Quản lý phân quyền chi tiết cho Aemeth Music."""

    def __init__(self) -> None:
        self.user_permissions: dict[int, set[int]] = {}
        self.allowed_groups: set[int] = set()
        self._load()

    def _load(self) -> None:
        """Đọc danh sách quyền từ file JSON cục bộ."""
        if not PERMISSIONS_FILE.exists():
            self._save()
            return

        try:
            with open(PERMISSIONS_FILE, "r", encoding="utf-8") as f:
                data: dict[str, Any] = json.load(f)

                # Tương thích ngược: nếu allowed_users là list cũ [uid1, uid2]
                raw_users = data.get("allowed_users", {})
                self.user_permissions = {}
                if isinstance(raw_users, list):
                    for uid in raw_users:
                        try:
                            self.user_permissions[int(uid)] = set(ALL_PERMISSIONS)
                        except ValueError:
                            pass
                elif isinstance(raw_users, dict):
                    for uid_str, perms in raw_users.items():
                        try:
                            uid = int(uid_str)
                            if isinstance(perms, list):
                                valid_p = {int(p) for p in perms if int(p) in ALL_PERMISSIONS}
                                if valid_p:
                                    self.user_permissions[uid] = valid_p
                        except (ValueError, TypeError):
                            pass

                self.allowed_groups = set(data.get("allowed_groups", []))
        except Exception as e:
            logger.error("Lỗi khi đọc file permissions.json: %s", e)
            self.user_permissions = {}
            self.allowed_groups = set()

    def _save(self) -> None:
        """Ghi danh sách quyền vào file JSON cục bộ."""
        try:
            data = {
                "allowed_users": {
                    str(uid): sorted(list(perms))
                    for uid, perms in self.user_permissions.items()
                },
                "allowed_groups": sorted(list(self.allowed_groups)),
            }
            with open(PERMISSIONS_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error("Lỗi khi ghi file permissions.json: %s", e)

    def is_owner(self, user_id: int) -> bool:
        """Kiểm tra người dùng có phải là Chủ Bot (𝑸𝒊𝒙𝒊𝒂) hay không."""
        return user_id == OWNER_ID

    def has_permission(self, user_id: int, perm_id: int) -> bool:
        """
        Kiểm tra người dùng có quyền cụ thể hay không.
        Chủ Bot luôn có toàn bộ quyền.
        Người dùng khác phải được cấp quyền perm_id tương ứng.
        """
        if self.is_owner(user_id):
            return True
        return perm_id in self.user_permissions.get(user_id, set())

    def is_user_allowed(self, user_id: int) -> bool:
        """Kiểm tra người dùng có ít nhất một quyền hay không."""
        if self.is_owner(user_id):
            return True
        return bool(self.user_permissions.get(user_id))

    def get_user_permissions(self, user_id: int) -> list[int]:
        """Lấy danh sách các số quyền mà user đang sở hữu."""
        if self.is_owner(user_id):
            return list(ALL_PERMISSIONS)
        return sorted(list(self.user_permissions.get(user_id, set())))

    def add_user_permissions(self, user_id: int, perms: list[int]) -> list[int]:
        """Cấp thêm các quyền cụ thể cho người dùng."""
        if self.is_owner(user_id):
            return list(ALL_PERMISSIONS)

        valid_perms = {p for p in perms if p in ALL_PERMISSIONS}
        if not valid_perms:
            return self.get_user_permissions(user_id)

        if user_id not in self.user_permissions:
            self.user_permissions[user_id] = set()

        self.user_permissions[user_id].update(valid_perms)
        self._save()
        return self.get_user_permissions(user_id)

    def remove_user_permissions(
        self, user_id: int, perms: Optional[list[int]] = None
    ) -> list[int]:
        """
        Thu hồi quyền của người dùng:
        - Nếu perms là None hoặc rỗng: xóa toàn bộ quyền của user.
        - Nếu perms có danh sách: chỉ xóa các quyền chỉ định.
        """
        if self.is_owner(user_id):
            return list(ALL_PERMISSIONS)

        if user_id not in self.user_permissions:
            return []

        if not perms:
            del self.user_permissions[user_id]
            self._save()
            return []

        to_remove = set(perms)
        self.user_permissions[user_id].difference_update(to_remove)
        if not self.user_permissions[user_id]:
            del self.user_permissions[user_id]

        self._save()
        return self.get_user_permissions(user_id)

    def add_user(self, user_id: int) -> bool:
        """Tương thích ngược: cấp toàn bộ quyền cơ bản cho user."""
        if self.is_owner(user_id):
            return False
        self.add_user_permissions(user_id, ALL_PERMISSIONS)
        return True

    def remove_user(self, user_id: int) -> bool:
        """Tương thích ngược: xóa toàn bộ quyền của user."""
        if self.is_owner(user_id):
            return False
        if user_id in self.user_permissions:
            self.remove_user_permissions(user_id)
            return True
        return False

    def get_users(self) -> list[int]:
        """Lấy danh sách ID người dùng có quyền."""
        return sorted(list(self.user_permissions.keys()))

    def get_all_users_with_perms(self) -> dict[int, list[int]]:
        """Lấy từ điển user_id -> danh sách quyền."""
        return {
            uid: sorted(list(perms))
            for uid, perms in self.user_permissions.items()
        }

    def is_group_allowed(self, chat_id: int) -> bool:
        """Kiểm tra nhóm có nằm trong danh sách được phép phát nhạc hay không."""
        return chat_id in self.allowed_groups

    def add_group(self, chat_id: int) -> bool:
        """Thêm nhóm vào danh sách được phép."""
        if chat_id not in self.allowed_groups:
            self.allowed_groups.add(chat_id)
            self._save()
            return True
        return False

    def remove_group(self, chat_id: int) -> bool:
        """Xóa nhóm khỏi danh sách được phép."""
        if chat_id in self.allowed_groups:
            self.allowed_groups.remove(chat_id)
            self._save()
            return True
        return False

    def get_groups(self) -> list[int]:
        """Lấy danh sách ID nhóm được cấp phép."""
        return sorted(list(self.allowed_groups))


# Khởi tạo singleton dùng chung toàn dự án
permissions = PermissionManager()
