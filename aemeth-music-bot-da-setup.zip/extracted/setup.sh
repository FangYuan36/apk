#!/bin/bash
# ========================================================
# Script cài đặt tự động Telegram Music Bot trên Android Termux
# ========================================================

set -e

echo "========================================================"
echo "📦 ĐANG CÀI ĐẶT MÔI TRƯỜNG CHO TELEGRAM MUSIC BOT"
echo "========================================================"

# 1. Cập nhật và cài đặt các gói hệ thống cần thiết qua Termux
echo "[1/4] Cài đặt các gói hệ thống (glibc, sqlite, ffmpeg)..."
pkg update -y
pkg install python-glibc libsqlite-glibc sqlite-glibc ffmpeg -y

# 2. Cài đặt các thư viện Python vào môi trường glibc
echo "[2/4] Cài đặt các thư viện Python (PyTgCalls, PyrogramMod, yt-dlp)..."
grun -s "python3 -m ensurepip" || true
grun -s "python3 -m pip install --upgrade pip"
grun -s "python3 -m pip install -r requirements.txt"

# 3. Tạo file .env nếu chưa có
echo "[3/4] Kiểm tra file cấu hình .env..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "       ⚠️ Đã tạo file .env từ .env.example."
    echo "       👉 Vui lòng mở file .env bằng nano (hoặc trình soạn thảo) để điền BOT_TOKEN, API_ID, API_HASH, OWNER_ID:"
    echo "          nano .env"
else
    echo "       ✅ File .env đã tồn tại."
fi

# 4. Cấp quyền thực thi cho các script
echo "[4/4] Cấp quyền thực thi cho script..."
chmod +x setup.sh start.sh

echo "========================================================"
echo "🎉 CÀI ĐẶT HOÀN TẤT!"
echo "👉 Bước 1: Điền thông tin vào file .env (nano .env)"
echo "👉 Bước 2: Chạy bot bằng lệnh: ./start.sh"
echo "========================================================"
