#!/bin/bash
# ========================================================
# Script khởi chạy Telegram Music Bot trên Android Termux
# ========================================================

# Chuyển vào thư mục chứa script
cd "$(dirname "$0")"

# Kiểm tra file .env
if [ ! -f ".env" ]; then
    echo "❌ Không tìm thấy file .env!"
    echo "Vui lòng sao chép .env.example sang .env và điền thông tin trước:"
    echo "  cp .env.example .env"
    echo "  nano .env"
    exit 1
fi

echo "========================================================"
echo "▶️ Đang khởi động Telegram Music Bot..."
echo "========================================================"

# Chạy thông qua glibc-runner để kích hoạt ntgcalls WebRTC engine
grun -s "python3 main.py"
