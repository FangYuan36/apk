"""
Script đăng nhập tài khoản người dùng phát nhạc (User Account).
Tự động lưu phiên đăng nhập music_user_session.session trên máy.
Tự động áp dụng mật khẩu 2FA từ cấu hình.
"""

import sys
import asyncio
from pyrogram import Client
from pyrogram.errors import (
    SessionPasswordNeeded,
    PhoneCodeInvalid,
    PhoneCodeExpired,
    PhoneNumberInvalid,
    PasswordHashInvalid,
)
from config import API_ID, API_HASH, SESSION_NAME, TWO_FACTOR_PASS, BASE_DIR


async def main() -> None:
    print("=" * 65)
    print("📱 ĐĂNG NHẬP TÀI KHOẢN PHÁT NHẠC TELEGRAM (USER ACCOUNT)")
    print("=" * 65)

    client = Client(
        SESSION_NAME,
        api_id=API_ID,
        api_hash=API_HASH,
        workdir=str(BASE_DIR),
    )

    await client.connect()

    try:
        me = await client.get_me()
        if me:
            print(f"\n✅ Tài khoản ĐÃ ĐĂNG NHẬP THÀNH CÔNG từ trước!")
            print(f"👤 Tên: {me.first_name} {me.last_name or ''}")
            print(f"🆔 ID: {me.id}")
            print(f"📞 Số điện thoại: {me.phone_number}")
            print(f"📁 Session lưu tại: {BASE_DIR}/{SESSION_NAME}.session")
            print("\n👉 Bạn có thể chạy ngay bot bằng lệnh: bash start.sh\n")
            await client.disconnect()
            return
    except Exception:
        pass

    # Nhận số điện thoại
    phone_number = input("\n👉 Nhập số điện thoại Telegram của bạn (kèm mã quốc gia, ví dụ +84xxxxxxxxx): ").strip()
    if not phone_number.startswith("+"):
        if phone_number.startswith("0"):
            phone_number = "+84" + phone_number[1:]
        else:
            phone_number = "+" + phone_number

    print(f"⏳ Đang gửi mã OTP xác thực đến {phone_number}...")
    try:
        sent_code = await client.send_code(phone_number)
    except PhoneNumberInvalid:
        print("❌ Số điện thoại không hợp lệ. Vui lòng kiểm tra lại!")
        await client.disconnect()
        return
    except Exception as e:
        print(f"❌ Lỗi khi gửi mã: {e}")
        await client.disconnect()
        return

    print("✅ Mã OTP đã được Telegram gửi về ứng dụng Telegram trên máy của bạn!")
    phone_code = input("👉 Nhập mã OTP (mã xác thực gồm 5 chữ số): ").strip()

    try:
        await client.sign_in(
            phone_number=phone_number,
            phone_code_hash=sent_code.phone_code_hash,
            phone_code=phone_code,
        )
    except SessionPasswordNeeded:
        print("\n🔐 Tài khoản có bật Mật khẩu 2 bước (Two-Step Verification).")
        password = TWO_FACTOR_PASS
        if not password:
            password = input("👉 Nhập mật khẩu 2FA: ").strip()
        else:
            print("💡 Đang tự động áp dụng Mật khẩu 2FA từ cấu hình...")

        try:
            await client.check_password(password)
            print("✅ Xác thực 2FA thành công!")
        except PasswordHashInvalid:
            print("❌ Mật khẩu 2FA không chính xác!")
            await client.disconnect()
            return
    except PhoneCodeInvalid:
        print("❌ Mã OTP không chính xác. Vui lòng thử lại!")
        await client.disconnect()
        return
    except PhoneCodeExpired:
        print("❌ Mã OTP đã hết hạn. Vui lòng chạy lại để lấy mã mới!")
        await client.disconnect()
        return
    except Exception as e:
        print(f"❌ Lỗi đăng nhập: {e}")
        await client.disconnect()
        return

    me = await client.get_me()
    print("=" * 65)
    print(f"🎉 ĐĂNG NHẬP THÀNH CÔNG!")
    print(f"👤 Tài khoản: {me.first_name} (ID: {me.id})")
    print(f"📁 Session đã được lưu vĩnh viễn tại: {BASE_DIR}/{SESSION_NAME}.session")
    print("👉 Bây giờ bạn chỉ cần chạy: bash start.sh")
    print("=" * 65)

    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
