"""
Module cấu hình và quản lý biến môi trường.
Đọc các giá trị bảo mật từ file .env, xác thực tính hợp lệ và thiết lập các đường dẫn cần thiết.
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Thư mục gốc của dự án
BASE_DIR = Path(__file__).resolve().parent

# Nạp file .env từ thư mục dự án
ENV_PATH = BASE_DIR / ".env"
load_dotenv(dotenv_path=ENV_PATH)

# ==========================================
# CẤU HÌNH BẮT BUỘC
# ==========================================
BOT_TOKEN: str = os.getenv("BOT_TOKEN", "").strip()
API_ID_RAW: str = os.getenv("API_ID", "").strip()
API_HASH: str = os.getenv("API_HASH", "").strip()
OWNER_ID_RAW: str = os.getenv("OWNER_ID", "").strip()

# ==========================================
# CẤU HÌNH TÙY CHỌN & GIỚI HẠN TÀI NGUYÊN
# ==========================================
SESSION_NAME: str = os.getenv("SESSION_NAME", "music_user_session").strip()
TWO_FACTOR_PASS: str = os.getenv("TWO_FACTOR_PASS", "").strip()
MAX_QUEUE_SIZE: int = int(os.getenv("MAX_QUEUE_SIZE", "15"))
AUDIO_BITRATE: int = int(os.getenv("AUDIO_BITRATE", "128"))
IDLE_TIMEOUT_SECONDS: int = int(os.getenv("IDLE_TIMEOUT_SECONDS", "60"))  # 1 phút chờ

# ==========================================
# ĐƯỜNG DẪN DỮ LIỆU CỤC BỘ
# ==========================================
# Sử dụng thư mục tmp nội bộ của Termux (ext4) để đạt tốc độ I/O nhanh nhất
TERMUX_INTERNAL_TMP = Path("/data/data/com.termux/files/usr/tmp/music_bot_cache")
if TERMUX_INTERNAL_TMP.parent.exists():
    TEMP_DIR = TERMUX_INTERNAL_TMP
else:
    TEMP_DIR = BASE_DIR / "temp_cache"

TEMP_DIR.mkdir(parents=True, exist_ok=True)

# File lưu phiên đăng nhập của tài khoản người dùng
SESSION_FILE_PATH = BASE_DIR / f"{SESSION_NAME}.session"

# File JSON lưu danh sách người dùng và nhóm được cấp quyền
PERMISSIONS_FILE = BASE_DIR / "permissions.json"

# Ép kiểu an toàn cho các ID số nguyên
API_ID: int = 0
OWNER_ID: int = 0

if API_ID_RAW.isdigit():
    API_ID = int(API_ID_RAW)

if OWNER_ID_RAW.isdigit() or (OWNER_ID_RAW.startswith("-") and OWNER_ID_RAW[1:].isdigit()):
    OWNER_ID = int(OWNER_ID_RAW)


def validate_config() -> tuple[bool, str]:
    """
    Kiểm tra cấu hình trước khi khởi chạy ứng dụng.
    Trả về: (is_valid: bool, error_message: str)
    """
    missing: list[str] = []

    if not BOT_TOKEN:
        missing.append("BOT_TOKEN (Lấy từ @BotFather)")
    if not API_ID_RAW or API_ID == 0:
        missing.append("API_ID (Số nguyên từ https://my.telegram.org)")
    if not API_HASH:
        missing.append("API_HASH (Chuỗi hash từ https://my.telegram.org)")
    if not OWNER_ID_RAW or OWNER_ID == 0:
        missing.append("OWNER_ID (Telegram User ID của bạn, lấy từ @userinfobot)")

    if missing:
        msg = (
            "❌ THIẾU CẤU HÌNH TRONG FILE .env:\n"
            + "\n".join(f"  - {m}" for m in missing)
            + "\n\nHãy kiểm tra lại file .env trước khi chạy!"
        )
        return False, msg

    return True, ""
