#!/bin/bash
# ========================================================
# Script đăng nhập tài khoản phát nhạc Telegram (User Account)
# ========================================================

cd "$(dirname "$0")"
grun -s "python3 login_user.py"
