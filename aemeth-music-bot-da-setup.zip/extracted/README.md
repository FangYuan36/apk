# TELEGRAM MUSIC BOT TRÊN ANDROID TERMUX (PYTHON)

Dự án Telegram Music Bot mã nguồn mở viết bằng Python, được thiết kế và tối ưu đặc biệt để chạy mượt mà trên **Android Termux (ARM64)** mà không cần root máy, không cần Docker, không cần VPS trả phí.

---

## MỤC LỤC
1. [Giai đoạn 1: Báo cáo tính khả thi](#giai-đoạn-1-báo-cáo-tính-khả-thi)
2. [Giai đoạn 2: Kiến trúc hệ thống](#giai-đoạn-2-kiến-trúc-hệ-thống)
3. [Giai đoạn 3: Cấu trúc mã nguồn](#giai-đoạn-3-cấu-trúc-mã-nguồn)
4. [Giai đoạn 4: Hướng dẫn cài đặt từng bước](#giai-đoạn-4-hướng-dẫn-cài-đặt-từng-bước)
5. [Giai đoạn 5: Quy trình chạy thử nghiệm](#giai-đoạn-5-quy-trình-chạy-thử-nghiệm)
6. [Giai đoạn 6: Kiểm tra và tối ưu tài nguyên trên Termux](#giai-đoạn-6-kiểm-tra-và-tối-ưu-tài-nguyên-trên-termux)
7. [Giai đoạn 7: Khắc phục sự cố thường gặp](#giai-đoạn-7-khắc-phục-sự-cố-thường-gặp)

---

## GIAI ĐOẠN 1: BÁO CÁO TÍNH KHẢ THI

### 1. Bot API thông thường làm được gì và không làm được gì?
* **Làm được:** Bot API của Telegram (dùng Bot Token từ `@BotFather`) nhận tin nhắn, lệnh slash (`/play`, `/stop`), kiểm tra quyền thành viên trong nhóm, gửi tin nhắn trạng thái, tạo nút bấm inline.
* **KHÔNG LÀM ĐƯỢC:** Telegram Bot API **không hỗ trợ tham gia Voice Chat (Group Call) và không hỗ trợ truyền phát âm thanh WebRTC**. Đây là giới hạn từ Telegram server.

### 2. Tài khoản Telegram cá nhân (User Account / MTProto) làm được gì?
* MTProto client (Pyrogram / Telethon) cho phép tài khoản cá nhân tương tác trực tiếp với các RPC nội bộ của Telegram (`phone.joinGroupCall`, `phone.leaveGroupCall`).
* Tuy nhiên, bản thân MTProto chỉ đảm nhiệm **báo hiệu (Signaling)** để lấy thông số máy chủ SFU/WebRTC của Telegram. Việc giải mã và bắn các gói tin âm thanh RTP thời gian thực phải do một **WebRTC Audio Engine** đảm nhiệm.

### 3. Vấn đề tương thích trên Android Termux và giải pháp đột phá
* **Thư viện WebRTC Voice Chat:** `py-tgcalls` (v3.0.0) sử dụng lõi C++ gốc là `ntgcalls` (v3.0.3).
* **Trở ngại trên Termux thông thường:** Termux mặc định sử dụng thư viện **Android Bionic libc**, trong khi các file nhị phân (wheels) trên PyPI của `ntgcalls` được biên dịch cho GNU C Library (`manylinux_2_28_aarch64`). Nếu cài bằng pip thông thường trên Termux, pip sẽ bắt buộc biên dịch C++ từ source (cần CMake, Boost, WebRTC, X11), gây tràn RAM và lỗi biên dịch.
* **Giải pháp tối ưu đã được kiểm chứng thực tế:** Sử dụng môi trường `glibc-runner` (`python-glibc` 3.12) có sẵn trong kho gói Termux. Môi trường này chạy trực tiếp wheel `ntgcalls-3.0.3-cp312-cp312-manylinux_2_28_aarch64.whl` với tốc độ cực nhanh, **không cần biên dịch C++** và không tốn hàng giờ build thủ công!

---

## GIAI ĐOẠN 2: KIẾN TRÚC HỆ THỐNG

Hệ thống hoạt động theo mô hình 2 thành phần phối hợp chặt chẽ:

```
[ Người dùng trong Nhóm / Chat riêng ]
                 │
                 ▼ (Gửi lệnh /play, /pause, /stop)
┌──────────────────────────────────────────────┐
│  Thành phần 1: BOT QUẢN LÝ (Bot Token)       │
│  - Thư viện: PyrogramMod                     │
│  - Xác thực quyền (Owner / Allowed Users)    │
│  - Kiểm tra nhóm được phép (Allowed Groups)  │
│  - Gửi phản hồi trạng thái & hàng đợi        │
└──────────────────────┬───────────────────────┘
                       │ Điều khiển phát
                       ▼
┌──────────────────────────────────────────────┐
│  Thành phần 2: TÀI KHOẢN THẬT (User Account) │
│  - Lõi gọi thoại: PyTgCalls (v3) + ntgcalls │
│  - Bộ trích xuất: yt-dlp (chỉ lấy luồng audio)│
│  - Bộ giải mã âm thanh: FFmpeg Termux        │
│  - Tham gia Voice Chat & truyền phát RTP     │
└──────────────────────────────────────────────┘
```

---

## GIAI ĐOẠN 3: CẤU TRÚC MÃ NGUỒN

Dự án được tổ chức tối giản, rõ ràng:

```
telegram-music-bot/
├── config.py           # Quản lý cấu hình, nạp .env và kiểm tra tính hợp lệ
├── permissions.py      # Hệ thống phân quyền mặc định từ chối (Default-Deny)
├── player.py           # Quản lý hàng đợi nhạc, trích xuất yt-dlp, phát PyTgCalls
├── main.py             # Điểm khởi chạy, xử lý lệnh Bot và vòng lặp sự kiện
├── requirements.txt    # Danh sách thư viện Python
├── .env.example        # Mẫu cấu hình không chứa thông tin thật
├── setup.sh            # Script cài đặt tự động môi trường Termux
├── start.sh            # Script khởi động 1 lệnh
└── README.md           # Hướng dẫn chi tiết
```

---

## GIAI ĐOẠN 4: HƯỚNG DẪN CÀI ĐẶT TỪNG BƯỚC

### Bước 1: Chuẩn bị thông tin tài khoản Telegram

1. **Lấy Bot Token:**
   - Mở Telegram, tìm bot `@BotFather`.
   - Gửi `/newbot`, đặt tên và username cho bot.
   - Nhận chuỗi `BOT_TOKEN` (dạng `123456789:ABCdef...`).
   - Gửi `/setprivacy` cho `@BotFather`, chọn bot của bạn -> chọn **Disable** (để bot có thể đọc được tin nhắn lệnh trong nhóm khi không phải admin).

2. **Lấy API_ID và API_HASH:**
   - Truy cập trang web chính thức của Telegram: [https://my.telegram.org](https://my.telegram.org).
   - Đăng nhập bằng số điện thoại tài khoản Telegram của bạn.
   - Chọn mục **API development tools**.
   - Tạo một ứng dụng mới (đặt tên bất kỳ, ví dụ: `TermuxMusic`).
   - Sao chép `api_id` (dãy số nguyên) và `api_hash` (chuỗi ký tự).

3. **Lấy OWNER_ID (Telegram User ID của bạn):**
   - Mở Telegram, tìm bot `@userinfobot`.
   - Gửi `/start`, bot sẽ phản hồi ID của bạn (ví dụ: `123456789`).

---

### Bước 2: Cài đặt trên Android Termux

Mở ứng dụng Termux và chạy lần lượt các lệnh sau:

```bash
# 1. Chuyển vào thư mục bot
cd /sdcard/aca/telegram-music-bot

# 2. Cài đặt các gói hệ thống và thư viện Python (chỉ chạy 1 lần)
pkg update -y
pkg install python-glibc libsqlite-glibc sqlite-glibc ffmpeg -y
grun -s "python3 -m ensurepip"
grun -s "python3 -m pip install -r requirements.txt"
```

Hoặc bạn có thể chạy file cài đặt tự động:
```bash
bash setup.sh
```

---

### Bước 3: Tạo file cấu hình `.env`

Sao chép file mẫu và chỉnh sửa:
```bash
cp .env.example .env
nano .env
```

Điền các thông tin của bạn vào file `.env`:
```env
BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrSTUvwxYZ
API_ID=12345678
API_HASH=0123456789abcdef0123456789abcdef
OWNER_ID=123456789
SESSION_NAME=music_user_session
MAX_QUEUE_SIZE=10
AUDIO_BITRATE=128
```
*(Nhấn `Ctrl + O` rồi `Enter` để lưu, sau đó nhấn `Ctrl + X` để thoát nano)*.

---

## GIAI ĐOẠN 5: QUY TRÌNH CHẠY THỬ NGHIỆM

### 1. Khởi động chương trình
Trong thư mục dự án trên Termux, chạy lệnh:
```bash
bash start.sh
```

### 2. Xác thực tài khoản người dùng lần đầu (Chỉ 1 lần duy nhất)
* Khi chạy lần đầu tiên, terminal Termux sẽ hiển thị yêu cầu:
  ```
  [2/3] Đang kết nối Tài khoản phát nhạc (User Account)...
  Enter phone number: +84xxxxxxxxx
  ```
* Bạn nhập số điện thoại Telegram của tài khoản dùng để phát nhạc (có mã quốc gia `+84`).
* Telegram sẽ gửi mã OTP về ứng dụng Telegram của bạn. Nhập mã OTP vào terminal.
* Nếu tài khoản có bật Mật khẩu 2 bước (Two-Step Verification), nhập mật khẩu khi được hỏi.
* **Lưu ý bảo mật:** Pyrogram sẽ tự động tạo file `music_user_session.session` cục bộ. Từ lần chạy thứ 2 trở đi, bot sẽ tự động nhận diện session này và **KHÔNG BAO GIỜ** hỏi lại số điện thoại hay mã OTP nữa!

### 3. Cấu hình nhóm trên Telegram
1. Thêm **Bot quản trị** vào nhóm Telegram của bạn.
2. Thêm **Tài khoản phát nhạc (User Account)** vào cùng nhóm đó.
3. Bật cuộc gọi thoại trong nhóm: Bấm vào tên nhóm -> Bấm dấu 3 chấm -> Chọn **Bắt đầu cuộc trò chuyện thoại (Start Voice Chat)**.
4. Trong nhóm, Chủ Bot gửi lệnh:
   ```
   /setgroup
   ```
   Bot sẽ phản hồi: `✅ Đã thêm nhóm -100xxxxxxxxx vào danh sách được phép phát nhạc.`

### 4. Thử nghiệm các lệnh phát nhạc
* **Phát nhạc:**
  ```
  /play https://www.youtube.com/watch?v=dQw4w9WgXcQ
  ```
  hoặc tìm kiếm bằng từ khóa:
  ```
  /play Nơi này có anh
  ```
  hoặc link SoundCloud / direct audio:
  ```
  /play https://example.com/audio.mp3
  ```
* **Tạm dừng / Tiếp tục:**
  ```
  /pause
  /resume
  ```
* **Xem hàng đợi:**
  ```
  /queue
  ```
* **Bỏ qua bài hiện tại:**
  ```
  /skip
  ```
* **Dừng phát và rời cuộc gọi:**
  ```
  /stop
  ```
* **Cấp quyền cho bạn bè:**
  ```
  /allow 987654321
  ```
* **Tắt bot từ xa an toàn:**
  ```
  /shutdown
  ```

---

## GIAI ĐOẠN 6: KIỂM TRA VÀ TỐI ƯU TÀI NGUYÊN TRÊN TERMUX

### 1. Cách đo kiểm RAM và CPU thực tế
Mở một tab Termux mới (vuốt từ cạnh trái màn hình sang phải -> chọn `New Session`):

* **Xem dung lượng RAM đang sử dụng:**
  ```bash
  ps -ef | grep python
  ```
* **Giám sát trực quan với `htop`:**
  ```bash
  pkg install htop -y
  htop
  ```
  *(Tìm tiến trình `python3 main.py` và `ffmpeg`)*.

### 2. Các điểm tối ưu đã được tích hợp trong mã nguồn
1. **Phát theo luồng trực tiếp (Direct Audio Streaming):** `yt-dlp` chỉ trích xuất URL luồng âm thanh trực tiếp (`stream_url`), FFmpeg đọc trực tiếp từ HTTP URL mà **không tải video**, không tốn bộ nhớ flash của điện thoại.
2. **Loại bỏ xử lý Video:** Thiết lập `video_flags=MediaStream.Flags.IGNORE`, tắt hoàn toàn bộ giải mã hình ảnh VP8/H.264, tiết kiệm đến 70% CPU so với các bot video.
3. **Chất lượng âm thanh tối ưu cho di động:** Thiết lập `AudioQuality.MEDIUM` (tần số 36.000 Hz, kênh mono), đảm bảo âm thanh trong trẻo, mượt mà mà không làm nóng máy hay tiêu hao pin nhanh.
4. **Tự động dọn dẹp file tạm:** Bất kỳ file tạm phát sinh nào cũng được xóa ngay lập tức khi bài hát kết thúc hoặc khi nhận lệnh `/stop`.
5. **Không chạy tác vụ ngầm khi không phát nhạc:** Khi hàng đợi hết, tài khoản phát nhạc tự động rời Voice Chat và đóng luồng FFmpeg.

---

## GIAI ĐOẠN 7: KHẮC PHỤC SỰ CỐ THƯỜNG GẶP

| Hiện tượng | Nguyên nhân | Cách khắc phục |
| :--- | :--- | :--- |
| `ApiIdInvalid` | `API_ID` hoặc `API_HASH` trong file `.env` bị sai hoặc chứa ký tự thừa. | Kiểm tra lại trên [my.telegram.org](https://my.telegram.org) và sửa trong `.env`. |
| `Voice Chat chưa được bật!` | Nhóm chưa mở Cuộc trò chuyện thoại. | Quản trị viên nhóm phải mở Voice Chat trước khi gửi `/play`. |
| `Tài khoản phát nhạc chưa tham gia nhóm!` | User Account chưa có mặt trong nhóm. | Thêm tài khoản người dùng thật vào nhóm và cấp quyền nói. |
| Bot không phản hồi khi gõ `/play` trong nhóm | Privacy Mode của BotFather đang bật. | Mở `@BotFather` -> `/setprivacy` -> Chọn bot -> Chọn **Disable**. Hoặc cấp quyền Admin cho bot trong nhóm. |
| `ImportError: libsqlite3.so.0` | Thiếu gói `libsqlite-glibc` trên Termux. | Chạy lệnh: `pkg install libsqlite-glibc sqlite-glibc -y`. |
| `Permission denied` khi chạy `./start.sh` | File nằm trên bộ nhớ ngoài `/sdcard` bị mount `noexec`. | Chạy bằng lệnh: `bash start.sh` thay vì `./start.sh`. |
| Lỗi mạng `Connection Reset` hoặc `Timeout` khi phát YouTube | YouTube thắt chặt kết nối hoặc IP mạng bị chặn tạm thời. | Đổi mạng (bật/tắt 4G hoặc VPN), hoặc cập nhật yt-dlp: `grun -s "python3 -m pip install -U yt-dlp"`. |

---

## KẾT LUẬN & AN TOÀN DỮ LIỆU
* **Session được bảo toàn:** Tập tin `music_user_session.session` được lưu cục bộ an toàn, không bị xóa khi tắt bot.
* **Không lưu vết lịch sử:** Bot không lưu log bài hát, không tạo rác trên điện thoại.
* **Tắt sạch sẽ:** Nhấn `Ctrl + C` hoặc gửi lệnh `/shutdown` sẽ dừng toàn bộ kết nối, đóng FFmpeg và trả lại 100% tài nguyên cho hệ điều hành Android.
