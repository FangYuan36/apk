"""
Module xử lý phát nhạc và quản lý hàng đợi (Music Player & Queue).
Trích xuất luồng âm thanh siêu tốc qua yt-dlp, hỗ trợ nhạc dài (SoundCloud 2 tiếng+),
phát tức thì qua PyTgCalls và tự động ở lại Voice Chat 1 phút sau khi hết nhạc trước khi rời và dọn rác.
"""

import os
import shutil
import asyncio
import logging
from dataclasses import dataclass
from typing import Optional, Callable, Coroutine, Any
from pathlib import Path

import yt_dlp
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream, AudioQuality

from config import MAX_QUEUE_SIZE, TEMP_DIR, IDLE_TIMEOUT_SECONDS

logger = logging.getLogger("Player")

# Danh sách phần mở rộng âm thanh trực tiếp
AUDIO_EXTENSIONS = (".mp3", ".m4a", ".aac", ".ogg", ".opus", ".flac", ".wav")

# Bộ lọc âm thanh trung thực cao (Studio Reference Audio Filter):
# - thread_queue_size 2048: Mở rộng hàng đợi bộ nhớ đệm, chống giật/nghẽn gói tin do mạng di động
# - aresample=48000:filter_size=32:cutoff=0.995: Bộ nội suy Sinc chuẩn phòng thu, SNR > 105 dB,
#   bảo toàn 100% dải tần 20Hz - 20.000Hz, siêu nhẹ chỉ tốn ~2% CPU (tránh nóng máy, nghẽn CPU trên host).
AUDIO_ENHANCE_FILTER = "-thread_queue_size 1024 -af aresample=48000"


@dataclass
class Track:
    """Đại diện cho một bài hát trong hàng đợi."""
    title: str
    duration: int  # Giây
    web_url: str
    stream_url: str
    requester_id: int
    requester_name: str
    headers: Optional[dict[str, str]] = None
    is_temp_file: bool = False
    temp_file_path: Optional[str] = None

    @property
    def duration_str(self) -> str:
        """Định dạng thời lượng mm:ss hoặc hh:mm:ss."""
        if self.duration <= 0:
            return "Trực tiếp / Không xác định"
        mins, secs = divmod(self.duration, 60)
        hours, mins = divmod(mins, 60)
        if hours > 0:
            return f"{hours:02d}:{mins:02d}:{secs:02d}"
        return f"{mins:02d}:{secs:02d}"


class MusicPlayer:
    """Quản lý phát nhạc, chuyển luồng, thời gian chờ và dọn rác."""

    def __init__(self, call_py: PyTgCalls) -> None:
        self.call_py: PyTgCalls = call_py
        self.queues: dict[int, list[Track]] = {}
        self.current_tracks: dict[int, Track] = {}
        self.is_paused: dict[int, bool] = {}
        self.idle_tasks: dict[int, asyncio.Task] = {}
        self.group_volume: dict[int, int] = {}
        self._lock = asyncio.Lock()

        # Callback khi hết thời gian chờ 1 phút để thông báo vào nhóm
        self.idle_timeout_callback: Optional[Callable[[int], Coroutine[Any, Any, None]]] = None

        # Toi uu cho VPS 1.5 CPU / 6GB RAM, khong GPU:
        # - Format 140 (AAC m4a 128k, 1 file duy nhat) thay vi 251 DASH 533 fragment:
        #   tai nhanh hon, khong loi rename fragment, it CPU hon.
        # - 1 lan extract + download duy nhat, khong goi yt-dlp 2 lan.
        # - noprogress: tat log tien trinh (tranh log 125KB), android client: khong can JS runtime.
        self.ydl_opts = {
            "format": "140/bestaudio[ext=m4a]/bestaudio/best",
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "noprogress": True,
            "skip_download": False,
            "extract_flat": False,
            "nocheckcertificate": True,
            "socket_timeout": 15,
            "retries": 1,
            "concurrent_fragment_downloads": 1,
            "buffersize": 1024 * 16,
            "outtmpl": str(TEMP_DIR / "%(id)s.%(ext)s"),
            "js_runtimes": {"node": {"path": "/usr/bin/node"}},
        }

    async def extract_track(
        self, query: str, requester_id: int, requester_name: str
    ) -> Track:
        """
        Trích xuất bài hát từ URL hoặc từ khóa tìm kiếm (chạy trong worker thread để không nghẽn loop).
        Hỗ trợ: YouTube, SoundCloud (kể cả set 2 tiếng), direct audio URL (.mp3, .m4a,...).
        """
        return await asyncio.to_thread(
            self._extract_track_sync, query, requester_id, requester_name
        )

    @staticmethod
    def _prepare_stream_headers(info: dict) -> Optional[dict[str, str]]:
        """
        Chuẩn hóa HTTP headers theo định dạng CRLF (\\r\\n) của FFmpeg.
        PyTgCalls duyệt từng key của dict và thêm cờ '-headers', điều này làm FFmpeg ghi đè
        các header trước đó nếu dict có nhiều key. Gộp tất cả header vào một chuỗi CRLF
        giúp FFmpeg nhận đầy đủ User-Agent, Accept, Range,... chống lỗi 403 Forbidden.
        """
        headers = info.get("http_headers")
        if not headers and "formats" in info:
            for f in reversed(info["formats"]):
                if f.get("http_headers"):
                    headers = f["http_headers"]
                    break
        if not headers:
            headers = {
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36"
                )
            }
        first_key, first_val = next(iter(headers.items()))
        rest = "".join(f"\r\n{k}: {v}" for k, v in list(headers.items())[1:])
        return {first_key: f"{first_val}{rest}\r\n"}

    def _extract_track_sync(
        self, query: str, requester_id: int, requester_name: str
    ) -> Track:
        query = query.strip()

        # Trường hợp 1: URL âm thanh trực tiếp (Direct HTTP Audio Link)
        if any(query.lower().split("?")[0].endswith(ext) for ext in AUDIO_EXTENSIONS):
            filename = Path(query.split("?")[0]).name
            default_headers = {
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36\r\n"
                )
            }
            return Track(
                title=filename,
                duration=0,
                web_url=query,
                stream_url=query,
                requester_id=requester_id,
                requester_name=requester_name,
                headers=default_headers,
                is_temp_file=False,
            )

        # Trường hợp 2: SoundCloud / YouTube / Web Link hoặc tìm kiếm từ khóa
        search_target = query
        if not (query.startswith("http://") or query.startswith("https://") or ":" in query):
            # Nếu người dùng nhập tên bài hát thông thường, ưu tiên YouTube search
            search_target = f"ytsearch1:{query}"

        try:
            TEMP_DIR.mkdir(parents=True, exist_ok=True)
            # Cache: neu file da tai roi thi dung lai, khong tai lai (mix dai tiet kiem 50s)
            import re as _re

            cached_path = None
            vid_match = _re.search(r"(?:v=|youtu\.be/|/shorts/)([A-Za-z0-9_-]{11})", query)
            if vid_match:
                for ext in ("m4a", "webm", "opus", "mp3"):
                    cand = TEMP_DIR / f"{vid_match.group(1)}.{ext}"
                    if cand.exists() and cand.stat().st_size > 10000:
                        cached_path = str(cand)
                        break

            with yt_dlp.YoutubeDL(self.ydl_opts) as ydl:
                # 1 lan duy nhat: vua lay info vua tai file (download=True)
                info = ydl.extract_info(search_target, download=cached_path is None)
                if not info:
                    raise ValueError("Không tìm thấy thông tin bài hát từ nguồn cung cấp.")

                # Nếu là danh sách kết quả, lấy mục đầu tiên hợp lệ
                if "entries" in info:
                    valid_entries = [e for e in info.get("entries") or [] if e is not None]
                    if not valid_entries:
                        raise ValueError("Không tìm thấy bài hát nào phù hợp với từ khóa.")
                    info = valid_entries[0]

                title = info.get("title", "Bài hát không tên")
                duration = int(info.get("duration", 0) or 0)
                web_url = info.get("webpage_url") or query
                stream_url = info.get("url")

                # Kiem tra luong truc tiep hop le tu dinh dang co san
                if not stream_url and "formats" in info:
                    for f in reversed(info["formats"]):
                        if f.get("acodec") != "none" and f.get("url"):
                            stream_url = f["url"]
                            break

                # Uu tien file da tai / vua tai xong
                file_path = cached_path
                if not file_path:
                    req = info.get("requested_downloads") or []
                    if req and req[0].get("filepath"):
                        file_path = req[0]["filepath"]
                    elif info.get("filepath"):
                        file_path = info["filepath"]
                if file_path and Path(file_path).exists():
                    logger.info("Phat file local: %s", file_path)
                    return Track(
                        title=title,
                        duration=duration,
                        web_url=web_url,
                        stream_url=file_path,
                        requester_id=requester_id,
                        requester_name=requester_name,
                        headers=None,
                        is_temp_file=True,
                        temp_file_path=file_path,
                    )

                if not stream_url:
                    raise ValueError("Không thể lấy luồng âm thanh hợp lệ từ nguồn này.")

                headers = self._prepare_stream_headers(info)

                return Track(
                    title=title,
                    duration=duration,
                    web_url=web_url,
                    stream_url=stream_url,
                    requester_id=requester_id,
                    requester_name=requester_name,
                    headers=headers,
                    is_temp_file=False,
                )

        except yt_dlp.utils.DownloadError as e:
            err_msg = str(e)
            if "Private video" in err_msg:
                raise ValueError("Nội dung ở chế độ riêng tư, không thể truy cập.")
            elif "Sign in" in err_msg or "confirm your age" in err_msg:
                raise ValueError("Nội dung yêu cầu đăng nhập hoặc giới hạn độ tuổi.")
            elif "not available" in err_msg:
                raise ValueError("Nội dung không khả dụng hoặc bị giới hạn khu vực.")
            # Fallback: SoundCloud hay timeout -> tìm lại bài đó trên YouTube
            if "soundcloud" in query.lower() or "soundcloud" in err_msg.lower():
                import re as _re
                slug = query.rstrip("/").split("/")[-1].split("?")[0]
                fallback_q = slug.replace("-", " ").replace("_", " ").strip()
                fallback_q = _re.sub(r"\s+\d+$", "", fallback_q).strip()
                if fallback_q:
                    logger.info("SoundCloud lỗi, fallback sang YouTube search: %s", fallback_q)
                    try:
                        return self._extract_track_sync(
                            f"ytsearch1:{fallback_q}", requester_id, requester_name
                        )
                    except Exception as fb_e:
                        logger.error("Fallback YouTube cũng lỗi: %s", fb_e)
            raise ValueError(f"Lỗi nguồn nhạc: {err_msg[:120]}")
        except Exception as e:
            logger.error("Lỗi trích xuất nhạc: %s", e)
            raise ValueError(f"Không thể xử lý nguồn nhạc: {str(e)[:120]}")

    def cancel_idle_timer(self, chat_id: int) -> bool:
        """Hủy bộ đếm thời gian chờ 1 phút nếu có bài hát mới được yêu cầu."""
        if chat_id in self.idle_tasks:
            task = self.idle_tasks.pop(chat_id)
            if not task.done():
                task.cancel()
                logger.info("Đã hủy bộ đếm chờ 1 phút cho nhóm %s do có yêu cầu mới", chat_id)
                return True
        return False

    async def play_or_queue(
        self, chat_id: int, track: Track
    ) -> tuple[bool, int]:
        """
        Thêm bài vào hàng đợi hoặc phát ngay nếu đang rảnh.
        Hủy bộ đếm chờ 1 phút nếu đang trong thời gian chờ.
        Trả về: (đang_phát_ngay: bool, vị_trí_trong_hàng_đợi: int)
        """
        async with self._lock:
            # Hủy timer chờ nếu bot đang trong 1 phút chờ
            self.cancel_idle_timer(chat_id)

            if chat_id not in self.queues:
                self.queues[chat_id] = []

            # Nếu đang có bài phát, đưa bài mới vào hàng đợi
            if chat_id in self.current_tracks:
                if len(self.queues[chat_id]) >= MAX_QUEUE_SIZE:
                    raise ValueError(f"Hàng đợi đã đầy (tối đa {MAX_QUEUE_SIZE} bài).")
                self.queues[chat_id].append(track)
                return False, len(self.queues[chat_id])

            # Nếu chưa có bài nào đang phát, phát ngay lập tức
            await self._start_playback(chat_id, track)
            return True, 0

    async def _start_playback(self, chat_id: int, track: Track) -> None:
        """Khởi tạo luồng phát và gọi PyTgCalls với chuẩn WebRTC Opus 48kHz Stereo."""
        self.current_tracks[chat_id] = track
        self.is_paused[chat_id] = False

        # Tối ưu chuẩn Opus WebRTC 48kHz Stereo (AudioQuality.HIGH)
        # Bổ sung bộ lọc âm thanh cao cấp (bass ấm + vocal trong trẻo + boost âm lượng + chống vỡ tiếng)
        # Bỏ video flags để giảm tải CPU Termux
        stream = MediaStream(
            track.stream_url,
            audio_parameters=AudioQuality.HIGH,
            video_flags=MediaStream.Flags.IGNORE,
            headers=track.headers,
            ffmpeg_parameters=AUDIO_ENHANCE_FILTER,
        )

        logger.info("Bắt đầu phát '%s' (Thời lượng: %ss) trong nhóm %s", track.title, track.duration, chat_id)
        await self.call_py.play(chat_id, stream)

        # Đảm bảo bỏ tắt tiếng (unmute) trong Voice Chat để Telegram phát âm thanh
        for attempt in range(3):
            try:
                await self.call_py.unmute(chat_id)
                logger.info("Đã unmute thành công cho tài khoản phát nhạc tại nhóm %s", chat_id)
                break
            except Exception as unmute_err:
                logger.debug("Chưa thể unmute (lần %s): %s", attempt + 1, unmute_err)
                await asyncio.sleep(0.3)

        current_vol = self.group_volume.get(chat_id, 100)
        try:
            await self.call_py.change_volume_call(chat_id, current_vol)
            logger.info("Đã áp dụng âm lượng %s%% cho cuộc gọi tại nhóm %s", current_vol, chat_id)
        except Exception as vol_err:
            logger.debug("Không thể set volume: %s", vol_err)

    async def change_volume(self, chat_id: int, volume: int) -> bool:
        """Điều chỉnh âm lượng cuộc gọi (1 - 200%)."""
        volume = max(1, min(200, volume))
        self.group_volume[chat_id] = volume
        if self.is_in_call(chat_id):
            try:
                await self.call_py.change_volume_call(chat_id, volume)
                logger.info("Đã điều chỉnh âm lượng thành %s%% cho nhóm %s", volume, chat_id)
                return True
            except Exception as e:
                logger.debug("Không thể điều chỉnh âm lượng cho nhóm %s: %s", chat_id, e)
                return False
        return True

    async def pause(self, chat_id: int) -> bool:
        """Tạm dừng phát nhạc."""
        if chat_id in self.current_tracks and not self.is_paused.get(chat_id, False):
            await self.call_py.pause(chat_id)
            self.is_paused[chat_id] = True
            return True
        return False

    async def resume(self, chat_id: int) -> bool:
        """Tiếp tục phát nhạc."""
        if chat_id in self.current_tracks and self.is_paused.get(chat_id, False):
            await self.call_py.resume(chat_id)
            self.is_paused[chat_id] = False
            return True
        return False

    async def skip(self, chat_id: int) -> Optional[Track]:
        """
        Bỏ qua bài hiện tại. Phát bài tiếp theo trong hàng đợi nếu có.
        Nếu hết bài, bắt đầu đếm ngược 1 phút trước khi rời cuộc gọi.
        """
        async with self._lock:
            # Xóa file tạm của bài hiện tại nếu có
            self._cleanup_track_temp_file(self.current_tracks.get(chat_id))

            queue = self.queues.get(chat_id, [])
            if queue:
                next_track = queue.pop(0)
                await self._start_playback(chat_id, next_track)
                return next_track
            else:
                # Hết hàng đợi: xóa track hiện tại và bắt đầu chờ 1 phút
                self.current_tracks.pop(chat_id, None)
                self.is_paused.pop(chat_id, None)
                self._start_idle_timer(chat_id)
                return None

    def _start_idle_timer(self, chat_id: int) -> None:
        """Bắt đầu tác vụ đếm ngược 1 phút chờ bài hát mới."""
        self.cancel_idle_timer(chat_id)
        self.idle_tasks[chat_id] = asyncio.create_task(self._idle_waiter(chat_id))

    async def _idle_waiter(self, chat_id: int) -> None:
        """Chờ 60 giây. Nếu không có /play tiếp thì rời cuộc gọi và dọn rác."""
        logger.info("Bắt đầu đếm ngược %s giây cho nhóm %s...", IDLE_TIMEOUT_SECONDS, chat_id)
        try:
            await asyncio.sleep(IDLE_TIMEOUT_SECONDS)
            # Sau 1 phút không có ai /play tiếp:
            logger.info("Hết thời gian chờ %ss cho nhóm %s. Rời cuộc gọi và dọn rác.", IDLE_TIMEOUT_SECONDS, chat_id)
            await self.leave_and_clear(chat_id)

            # Gọi callback gửi tin nhắn thông báo vào nhóm
            if self.idle_timeout_callback:
                try:
                    await self.idle_timeout_callback(chat_id)
                except Exception as cb_err:
                    logger.error("Lỗi callback timeout: %s", cb_err)

        except asyncio.CancelledError:
            logger.info("Timer chờ của nhóm %s đã bị hủy do có bài hát mới.", chat_id)
        finally:
            self.idle_tasks.pop(chat_id, None)

    async def stop(self, chat_id: int) -> bool:
        """Dừng hoàn toàn, xóa hàng đợi, hủy timer chờ và rời cuộc gọi nhóm ngay lập tức."""
        async with self._lock:
            self.cancel_idle_timer(chat_id)
            if chat_id in self.current_tracks or chat_id in self.queues or self.is_in_call(chat_id):
                await self.leave_and_clear(chat_id)
                return True
            return False

    def is_in_call(self, chat_id: int) -> bool:
        """Kiểm tra bot có đang trong cuộc gọi nhóm hay không."""
        return chat_id in self.call_py.calls

    async def leave_and_clear(self, chat_id: int) -> None:
        """Rời khỏi cuộc gọi và dọn dẹp triệt để dữ liệu đệm/rác."""
        self.cancel_idle_timer(chat_id)

        # Dọn dẹp file tạm của bài đang phát
        self._cleanup_track_temp_file(self.current_tracks.get(chat_id))

        # Dọn dẹp file tạm của toàn bộ bài trong hàng đợi
        if chat_id in self.queues:
            for t in self.queues[chat_id]:
                self._cleanup_track_temp_file(t)
            self.queues.pop(chat_id, None)

        self.current_tracks.pop(chat_id, None)
        self.is_paused.pop(chat_id, None)

        try:
            await self.call_py.leave_call(chat_id)
        except Exception as e:
            logger.debug("Lỗi khi rời cuộc gọi nhóm %s: %s", chat_id, e)

        # Xóa sạch toàn bộ rác trong thư mục tạm để máy luôn nhẹ
        self.purge_temp_cache()

    def _cleanup_track_temp_file(self, track: Optional[Track]) -> None:
        """Xóa file tạm thời của một bài hát."""
        if track and track.is_temp_file and track.temp_file_path:
            try:
                p = Path(track.temp_file_path)
                if p.exists():
                    p.unlink()
            except Exception as e:
                logger.debug("Lỗi khi xóa file tạm: %s", e)

    def purge_temp_cache(self) -> None:
        """Xóa triệt để mọi file rác và bộ nhớ đệm trong TEMP_DIR."""
        try:
            if TEMP_DIR.exists():
                for item in TEMP_DIR.iterdir():
                    try:
                        if item.is_file() or item.is_symlink():
                            item.unlink()
                        elif item.is_dir():
                            shutil.rmtree(item)
                    except Exception:
                        pass
        except Exception as e:
            logger.debug("Lỗi dọn rác temp cache: %s", e)

    async def handle_stream_end(self, chat_id: int) -> Optional[Track]:
        """
        Xử lý sự kiện khi một bài hát phát xong tự nhiên.
        Tự động chuyển bài tiếp theo hoặc bắt đầu đếm ngược 1 phút.
        """
        return await self.skip(chat_id)

    def get_queue(self, chat_id: int) -> tuple[Optional[Track], list[Track]]:
        """Lấy bài đang phát và danh sách bài chờ."""
        return self.current_tracks.get(chat_id), list(self.queues.get(chat_id, []))

    def get_status(self, chat_id: int) -> dict:
        """Trả về thông tin trạng thái phát nhạc của nhóm."""
        current = self.current_tracks.get(chat_id)
        queue_count = len(self.queues.get(chat_id, []))
        is_waiting = chat_id in self.idle_tasks
        return {
            "active": current is not None,
            "paused": self.is_paused.get(chat_id, False),
            "is_waiting_idle": is_waiting,
            "current_track": current,
            "queue_length": queue_count,
        }

    async def cleanup_all(self) -> None:
        """Dọn dẹp toàn bộ cuộc gọi và file tạm khi ứng dụng tắt."""
        logger.info("Đang giải phóng tài nguyên phát nhạc...")
        for chat_id in list(self.idle_tasks.keys()):
            self.cancel_idle_timer(chat_id)

        for chat_id in list(self.current_tracks.keys()):
            try:
                await self.leave_and_clear(chat_id)
            except Exception as e:
                logger.debug("Lỗi giải phóng chat %s: %s", chat_id, e)

        # Xóa sạch toàn bộ thư mục tạm
        self.purge_temp_cache()
