BOT NHAC AEMETH - DA SETUP XONG, CHI CAN CHAY
=============================================

Da co san trong zip nay:
- .env: bot token, API ID/hash, OWNER_ID da sua dung
- music_user_session.session: da dang nhap xong, KHONG can nhap lai OTP/2FA
- permissions.json: che do mo, ai cung duoc /play, khong can /allow
- player.py: da sua - auto tai file ve roi phat, fallback SoundCloud -> YouTube
- permissions.py: da sua - mo quyen phat nhac cho moi nguoi, moi nhom

Cach chay tren Termux / WispByte / VPS (cho nay UDP mo, phat moi co tieng):
  python3 -m venv venv
  venv/bin/pip install -r requirements.txt
  venv/bin/python main.py

Hoac tren Termux dung file start.sh goc neu muon.

Luu y:
- Dung share file .env va .session nay cho nguoi khac, vi no chua token va phien dang nhap cua ban.
- Neu doi may, chi can giai nen va chay lai, khong can dang nhap lai.
